/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: 
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `goeunserverhub`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `goeunserverhub` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;

USE `goeunserverhub`;

--
-- Table structure for table `Account`
--

DROP TABLE IF EXISTS `Account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Account` (
  `id` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `type` varchar(191) NOT NULL,
  `provider` varchar(191) NOT NULL,
  `providerAccountId` varchar(191) NOT NULL,
  `refresh_token` text DEFAULT NULL,
  `access_token` text DEFAULT NULL,
  `expires_at` int(11) DEFAULT NULL,
  `token_type` varchar(191) DEFAULT NULL,
  `scope` varchar(191) DEFAULT NULL,
  `id_token` text DEFAULT NULL,
  `session_state` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Account_provider_providerAccountId_key` (`provider`,`providerAccountId`),
  KEY `Account_userId_idx` (`userId`),
  CONSTRAINT `Account_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Account`
--

LOCK TABLES `Account` WRITE;
/*!40000 ALTER TABLE `Account` DISABLE KEYS */;
/*!40000 ALTER TABLE `Account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CargoCusDetail`
--

DROP TABLE IF EXISTS `CargoCusDetail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `CargoCusDetail` (
  `id` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `nationality` varchar(191) DEFAULT NULL,
  `passportNo` varchar(191) DEFAULT NULL,
  `passportExp` datetime(3) DEFAULT NULL,
  `idCard` varchar(191) DEFAULT NULL,
  `customsNo` varchar(191) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `customerId` varchar(191) DEFAULT NULL,
  `cargoOrderId` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `CargoCusDetail_customerId_idx` (`customerId`),
  KEY `CargoCusDetail_cargoOrderId_idx` (`cargoOrderId`),
  CONSTRAINT `CargoCusDetail_cargoOrderId_fkey` FOREIGN KEY (`cargoOrderId`) REFERENCES `CargoOrder` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `CargoCusDetail_customerId_fkey` FOREIGN KEY (`customerId`) REFERENCES `Customer` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CargoCusDetail`
--

LOCK TABLES `CargoCusDetail` WRITE;
/*!40000 ALTER TABLE `CargoCusDetail` DISABLE KEYS */;
/*!40000 ALTER TABLE `CargoCusDetail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CargoOrder`
--

DROP TABLE IF EXISTS `CargoOrder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `CargoOrder` (
  `id` varchar(191) NOT NULL,
  `number` varchar(191) NOT NULL,
  `senderName` varchar(191) NOT NULL,
  `senderPhone` varchar(191) DEFAULT NULL,
  `receiverName` varchar(191) NOT NULL,
  `receiverPhone` varchar(191) DEFAULT NULL,
  `receiverAddress` text DEFAULT NULL,
  `direction` varchar(191) NOT NULL DEFAULT 'TH_TO_KR',
  `weightKg` decimal(8,2) DEFAULT NULL,
  `sizeNote` varchar(191) DEFAULT NULL,
  `itemDesc` text DEFAULT NULL,
  `currency` varchar(191) NOT NULL DEFAULT 'THB',
  `income` decimal(10,2) NOT NULL DEFAULT 0.00,
  `expense` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` varchar(191) NOT NULL DEFAULT 'รับพัสดุแล้ว',
  `trackingCode` varchar(191) DEFAULT NULL,
  `passportNo` varchar(191) DEFAULT NULL,
  `imageUrl` text DEFAULT NULL,
  `parcelImageUrl` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `shippedAt` datetime(3) DEFAULT NULL,
  `deliveredAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `clientId` varchar(191) DEFAULT NULL,
  `customerId` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CargoOrder_number_key` (`number`),
  KEY `CargoOrder_status_idx` (`status`),
  KEY `CargoOrder_direction_idx` (`direction`),
  KEY `CargoOrder_createdAt_idx` (`createdAt`),
  KEY `CargoOrder_clientId_idx` (`clientId`),
  KEY `CargoOrder_customerId_idx` (`customerId`),
  CONSTRAINT `CargoOrder_clientId_fkey` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `CargoOrder_customerId_fkey` FOREIGN KEY (`customerId`) REFERENCES `Customer` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CargoOrder`
--

LOCK TABLES `CargoOrder` WRITE;
/*!40000 ALTER TABLE `CargoOrder` DISABLE KEYS */;
/*!40000 ALTER TABLE `CargoOrder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CargoStatusLog`
--

DROP TABLE IF EXISTS `CargoStatusLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `CargoStatusLog` (
  `id` varchar(191) NOT NULL,
  `orderId` varchar(191) NOT NULL,
  `status` varchar(191) NOT NULL,
  `note` text DEFAULT NULL,
  `createdBy` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `CargoStatusLog_orderId_idx` (`orderId`),
  KEY `CargoStatusLog_createdAt_idx` (`createdAt`),
  CONSTRAINT `CargoStatusLog_orderId_fkey` FOREIGN KEY (`orderId`) REFERENCES `CargoOrder` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CargoStatusLog`
--

LOCK TABLES `CargoStatusLog` WRITE;
/*!40000 ALTER TABLE `CargoStatusLog` DISABLE KEYS */;
/*!40000 ALTER TABLE `CargoStatusLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CargoTransaction`
--

DROP TABLE IF EXISTS `CargoTransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `CargoTransaction` (
  `id` varchar(191) NOT NULL,
  `orderId` varchar(191) NOT NULL,
  `type` varchar(191) NOT NULL,
  `category` varchar(191) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(191) NOT NULL DEFAULT 'THB',
  `note` text DEFAULT NULL,
  `receiptRef` varchar(191) DEFAULT NULL,
  `createdBy` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `CargoTransaction_orderId_idx` (`orderId`),
  KEY `CargoTransaction_type_idx` (`type`),
  CONSTRAINT `CargoTransaction_orderId_fkey` FOREIGN KEY (`orderId`) REFERENCES `CargoOrder` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CargoTransaction`
--

LOCK TABLES `CargoTransaction` WRITE;
/*!40000 ALTER TABLE `CargoTransaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `CargoTransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Client`
--

DROP TABLE IF EXISTS `Client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Client` (
  `id` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('ONLINE','MAINTENANCE','COMING_SOON','OFFLINE') NOT NULL DEFAULT 'COMING_SOON',
  `contactEmail` varchar(191) DEFAULT NULL,
  `contactPhone` varchar(191) DEFAULT NULL,
  `contactFax` varchar(191) DEFAULT NULL,
  `systemUrl` varchar(191) DEFAULT NULL,
  `logoUrl` varchar(191) DEFAULT NULL,
  `lineUserId` varchar(191) DEFAULT NULL,
  `domainRegisteredAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `address` text DEFAULT NULL,
  `nameTh` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Client_slug_key` (`slug`),
  KEY `Client_slug_idx` (`slug`),
  KEY `Client_status_idx` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Client`
--

LOCK TABLES `Client` WRITE;
/*!40000 ALTER TABLE `Client` DISABLE KEYS */;
INSERT INTO `Client` VALUES
('cmo6viudt0001qhga9f5j4jzc','M-Factory','m-factory',NULL,'ONLINE','m.factoryandresort@gmail.com','+66 095-241-1833',NULL,'https://m-factoryandresort.com',NULL,NULL,NULL,'2026-04-20 07:28:50.513','2026-04-20 07:28:50.513',NULL,NULL),
('cmo6viueb0002qhgad1v22u6k','M-Group','m-group',NULL,'ONLINE','sale@m-group.in.th','089-4871144',NULL,NULL,NULL,NULL,NULL,'2026-04-20 07:28:50.531','2026-04-20 07:28:50.531',NULL,NULL),
('cmo6viuen0003qhga32hwcu3n','GOEUN SERVER HUB','goeun-server-hub','','ONLINE','goeunserverhub@gmail.com','+66081-234567',NULL,'ge-serverhub.com','/uploads/logos/1776694124366-rd4x8l.jpg',NULL,NULL,'2026-04-20 07:28:50.543','2026-04-20 14:08:48.344','',NULL),
('cmo6x1sht0008qhvqygcgasiq','M-retsort','m-retsort','เอ็มรีสอร์ท  บริการที่พัก บรรยากาศส่วนตัว','ONLINE','mukhngamnuch@gmail.com','095-241-1833',NULL,'https://m-factoryandresort.com/','/uploads/logos/1776692894976-ecji3u.jpg',NULL,NULL,'2026-04-20 08:11:34.146','2026-04-20 15:02:10.074','เอ็มรีสอร์ท 222 ซอย คลองโซน 6 ตำบล ลาดหลุมแก้ว อำเภอลาดหลุมแก้ว ปทุมธานี 12140  ','เอ็มรีสอร์ท'),
('cmo9bve0m0000qhtikd261ug2','Green Retail Group','green-retail-group','ระบบมอนิเตอริ่ง ผู้ใช้ Demo','ONLINE','it@green-retail.example.com','02-555-1199',NULL,'/customer-dashboard-login',NULL,NULL,NULL,'2026-04-22 00:42:02.038','2026-04-22 01:21:00.734',NULL,NULL);
/*!40000 ALTER TABLE `Client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ClientService`
--

DROP TABLE IF EXISTS `ClientService`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ClientService` (
  `clientId` varchar(191) NOT NULL,
  `serviceId` varchar(191) NOT NULL,
  `assignedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`clientId`,`serviceId`),
  KEY `ClientService_clientId_idx` (`clientId`),
  KEY `ClientService_serviceId_idx` (`serviceId`),
  CONSTRAINT `ClientService_clientId_fkey` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ClientService_serviceId_fkey` FOREIGN KEY (`serviceId`) REFERENCES `Service` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ClientService`
--

LOCK TABLES `ClientService` WRITE;
/*!40000 ALTER TABLE `ClientService` DISABLE KEYS */;
/*!40000 ALTER TABLE `ClientService` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Customer`
--

DROP TABLE IF EXISTS `Customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Customer` (
  `id` varchar(191) NOT NULL,
  `clientId` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `idCard` varchar(191) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Customer_clientId_idx` (`clientId`),
  KEY `Customer_name_idx` (`name`),
  CONSTRAINT `Customer_clientId_fkey` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Customer`
--

LOCK TABLES `Customer` WRITE;
/*!40000 ALTER TABLE `Customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `Customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Expense`
--

DROP TABLE IF EXISTS `Expense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Expense` (
  `id` varchar(191) NOT NULL,
  `number` varchar(191) NOT NULL,
  `category` varchar(191) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(191) NOT NULL DEFAULT 'THB',
  `notes` text DEFAULT NULL,
  `date` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `receiptFile` varchar(191) DEFAULT NULL,
  `receiptNumber` varchar(191) DEFAULT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'รอชำระ',
  `clientId` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Expense_number_key` (`number`),
  KEY `Expense_category_idx` (`category`),
  KEY `Expense_date_idx` (`date`),
  KEY `Expense_clientId_idx` (`clientId`),
  CONSTRAINT `Expense_clientId_fkey` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Expense`
--

LOCK TABLES `Expense` WRITE;
/*!40000 ALTER TABLE `Expense` DISABLE KEYS */;
INSERT INTO `Expense` VALUES
('cmo6xw4ux0000qhckz881fb94','EXP260420-00001','ค่าเช่าเซิร์ฟเวอร์/โดเมน',32000.00,'KRW','รอแก้ไขตามยอดที่ชำระจริง     ชำระค่าโดเมนหลัก ge-serverhub.com','2027-04-16 00:00:00.000','2026-04-20 08:35:09.849','2026-04-20 08:35:09.849',NULL,NULL,'รอชำระ',NULL),
('cmo7bf9yg0000qhhdecedr56b','EXP260420-00002','ค่าเช่าเซิร์ฟเวอร์/โดเมน',18702.00,'KRW','ge-serverhub.com     Invoice number NKBQJH4J-0005\n','2026-04-17 00:00:00.000','2026-04-20 14:53:57.929','2026-04-20 14:53:57.929','[\"/uploads/receipts/1776696837141-z8m2uo.jpg\",\"/uploads/receipts/1776696837367-9666uz.pdf\"]','2802-8830','แนบใบเสร็จแล้ว',NULL),
('cmo7bhvm40001qhhdcbg6qh4i','EXP260420-00003','ค่าเช่าเซิร์ฟเวอร์/โดเมน',18702.00,'KRW','m-factoryandresort.com    Invoice number NKBQJH4J-0006','2026-04-20 00:00:00.000','2026-04-20 14:55:59.309','2026-04-20 14:55:59.309','[\"/uploads/receipts/1776696958957-cz79s2.jpg\",\"/uploads/receipts/1776696959136-2dhbkm.pdf\"]','2646-1755','แนบใบเสร็จแล้ว',NULL),
('cmo7bkujm0002qhhdiv26ryxd','EXP260420-00004','ค่าบริการภายนอก',32831.00,'KRW','Claude Pro   AI code   Invoice number K6CHS41L-0004','2026-04-18 00:00:00.000','2026-04-20 14:58:17.890','2026-04-20 14:58:17.890','[\"/uploads/receipts/1776697097592-kc7bgc.jpg\",\"/uploads/receipts/1776697097743-l337lk.pdf\"]','2624-8386-0931','แนบใบเสร็จแล้ว',NULL),
('cmo7bowl50003qhhdnqudjasn','EXP260421-00001','ค่าบริการภายนอก',30251.00,'KRW','ngrok Inc.  Forward IP getaway  Local to Public      Invoice number DYWNCD-00006','2026-04-17 00:00:00.000','2026-04-20 15:01:27.161','2026-04-20 15:01:27.161','[\"/uploads/receipts/1776697286801-yz5wcq.pdf\",\"/uploads/receipts/1776697287014-fj59bl.jpg\"]','DYWNCD-00006','แนบใบเสร็จแล้ว',NULL);
/*!40000 ALTER TABLE `Expense` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FileAppArchiveRecord`
--

DROP TABLE IF EXISTS `FileAppArchiveRecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `FileAppArchiveRecord` (
  `id` varchar(191) NOT NULL,
  `platform` enum('ANDROID','IOS') NOT NULL,
  `fileName` varchar(191) NOT NULL,
  `filePath` text NOT NULL,
  `fileMime` varchar(191) DEFAULT NULL,
  `fileSize` int(11) NOT NULL,
  `fileExtension` varchar(191) NOT NULL,
  `fileSha1` varchar(191) NOT NULL,
  `signingSha1` varchar(191) DEFAULT NULL,
  `packageName` varchar(191) DEFAULT NULL,
  `createdById` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `FileAppArchiveRecord_platform_createdAt_idx` (`platform`,`createdAt`),
  KEY `FileAppArchiveRecord_createdById_idx` (`createdById`),
  CONSTRAINT `FileAppArchiveRecord_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FileAppArchiveRecord`
--

LOCK TABLES `FileAppArchiveRecord` WRITE;
/*!40000 ALTER TABLE `FileAppArchiveRecord` DISABLE KEYS */;
/*!40000 ALTER TABLE `FileAppArchiveRecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Invoice`
--

DROP TABLE IF EXISTS `Invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Invoice` (
  `id` varchar(191) NOT NULL,
  `number` varchar(191) NOT NULL,
  `receiptNumber` varchar(191) DEFAULT NULL,
  `clientId` varchar(191) NOT NULL,
  `userId` varchar(191) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(191) NOT NULL DEFAULT 'THB',
  `status` enum('PENDING','PAID','OVERDUE','CANCELLED') NOT NULL DEFAULT 'PENDING',
  `dueDate` datetime(3) DEFAULT NULL,
  `paidAt` datetime(3) DEFAULT NULL,
  `stripeId` varchar(191) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Invoice_number_key` (`number`),
  UNIQUE KEY `Invoice_receiptNumber_key` (`receiptNumber`),
  UNIQUE KEY `Invoice_stripeId_key` (`stripeId`),
  KEY `Invoice_clientId_idx` (`clientId`),
  KEY `Invoice_status_idx` (`status`),
  KEY `Invoice_userId_fkey` (`userId`),
  CONSTRAINT `Invoice_clientId_fkey` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `Invoice_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Invoice`
--

LOCK TABLES `Invoice` WRITE;
/*!40000 ALTER TABLE `Invoice` DISABLE KEYS */;
INSERT INTO `Invoice` VALUES
('cmo6vyr9g0001qhvq03kwyvp4','INV260420-00001','RCP260417-0001','cmo6viudt0001qhga9f5j4jzc',NULL,2000.00,'THB','PAID','2026-04-16 00:00:00.000','2026-04-20 07:41:12.962',NULL,'ค่าบรืการดูแลระบบ เดือน เมษายน 2569','2026-04-20 07:41:12.964','2026-04-20 07:41:12.964'),
('cmo6vzowk0003qhvqlwjuhobj','INV260420-00002',NULL,'cmo6viudt0001qhga9f5j4jzc',NULL,2000.00,'THB','PENDING','2026-05-16 00:00:00.000',NULL,NULL,'ค่าบริการดูแลระบบ','2026-04-20 07:41:56.564','2026-04-20 07:41:56.564'),
('cmo6w7ju80005qhvq0gqqy4kb','INV260420-00003',NULL,'cmo6viudt0001qhga9f5j4jzc',NULL,1500.00,'THB','PAID','2026-04-16 00:00:00.000','2026-04-20 07:48:03.246',NULL,'ค่าเช่า โดเมน รายปี  ','2026-04-20 07:48:03.248','2026-04-20 07:48:03.248'),
('cmo6w9pq40007qhvqc4td6ml9','INV260420-00004',NULL,'cmo6viudt0001qhga9f5j4jzc',NULL,1500.00,'THB','PENDING','2027-04-16 00:00:00.000',NULL,NULL,'ค่าบริการ เช่าโดเมน รายปี ','2026-04-20 07:49:44.189','2026-04-20 07:49:44.189'),
('cmo6x7v2k000eqhvqhvds8z2k','INV260420-00005',NULL,'cmo6x1sht0008qhvqygcgasiq',NULL,3500.00,'THB','PENDING','2026-04-27 00:00:00.000',NULL,NULL,'ค่ายิงแอดเฟสบุ๊ค รายสัปดาห์','2026-04-20 08:16:17.420','2026-04-20 08:16:17.420'),
('cmo6xa2gz000gqhvq6hzxwilh','INV260420-00006',NULL,'cmo6x1sht0008qhvqygcgasiq',NULL,3500.00,'THB','PAID','2026-04-13 00:00:00.000','2026-04-20 08:18:00.321',NULL,'ค่ายิงแอดเฟสบุ๊ค รายสัปดาห์','2026-04-20 08:18:00.323','2026-04-20 08:18:00.323');
/*!40000 ALTER TABLE `Invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MFactoryInquiry`
--

DROP TABLE IF EXISTS `MFactoryInquiry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `MFactoryInquiry` (
  `id` varchar(191) NOT NULL,
  `type` varchar(191) NOT NULL DEFAULT 'factory',
  `lang` varchar(191) NOT NULL DEFAULT 'th',
  `source` varchar(191) DEFAULT NULL,
  `company` varchar(191) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `taxId` varchar(191) DEFAULT NULL,
  `bookingDate` date DEFAULT NULL,
  `address` text DEFAULT NULL,
  `warehouse` text DEFAULT NULL,
  `rentalType` varchar(191) DEFAULT NULL,
  `paymentRef` varchar(191) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `bookingNumber` varchar(191) DEFAULT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'PENDING',
  `termsAccepted` tinyint(1) NOT NULL DEFAULT 1,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `MFactoryInquiry_bookingNumber_key` (`bookingNumber`),
  KEY `MFactoryInquiry_createdAt_idx` (`createdAt`),
  KEY `MFactoryInquiry_type_idx` (`type`),
  KEY `MFactoryInquiry_status_idx` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MFactoryInquiry`
--

LOCK TABLES `MFactoryInquiry` WRITE;
/*!40000 ALTER TABLE `MFactoryInquiry` DISABLE KEYS */;
INSERT INTO `MFactoryInquiry` VALUES
('cmqeinevt0000jhlnbxaatks0','factory','th','mfac-booking','000','000','0000','00@gmail.com','000','2026-06-15','0000','โกดังลาดหลุมแก้ว ปทุมธานี ขนาด 100 ตรม. ค่าเช่า เดือนละ 12,000 บาท','เช่า','/uploads/mfactory/1781485799008-7gf6i0e.pdf',NULL,'MF-20260615-ULXL','SUBMITTED',1,'2026-06-15 01:10:02.777','2026-06-15 01:10:02.777');
/*!40000 ALTER TABLE `MFactoryInquiry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MGroupOrder`
--

DROP TABLE IF EXISTS `MGroupOrder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `MGroupOrder` (
  `id` varchar(191) NOT NULL,
  `number` varchar(191) NOT NULL,
  `clientId` varchar(191) DEFAULT NULL,
  `customerName` varchar(191) NOT NULL,
  `customerPhone` varchar(191) DEFAULT NULL,
  `customerEmail` varchar(191) DEFAULT NULL,
  `shippingAddress` text DEFAULT NULL,
  `note` text DEFAULT NULL,
  `subtotal` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `currency` varchar(191) NOT NULL DEFAULT 'THB',
  `status` varchar(191) NOT NULL DEFAULT 'PENDING_PAYMENT',
  `paymentSlipUrl` varchar(191) DEFAULT NULL,
  `slipName` varchar(191) DEFAULT NULL,
  `paidAt` datetime(3) DEFAULT NULL,
  `confirmedAt` datetime(3) DEFAULT NULL,
  `shippedAt` datetime(3) DEFAULT NULL,
  `deliveredAt` datetime(3) DEFAULT NULL,
  `cancelledAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `MGroupOrder_number_key` (`number`),
  KEY `MGroupOrder_clientId_idx` (`clientId`),
  KEY `MGroupOrder_status_idx` (`status`),
  KEY `MGroupOrder_createdAt_idx` (`createdAt`),
  CONSTRAINT `MGroupOrder_clientId_fkey` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MGroupOrder`
--

LOCK TABLES `MGroupOrder` WRITE;
/*!40000 ALTER TABLE `MGroupOrder` DISABLE KEYS */;
/*!40000 ALTER TABLE `MGroupOrder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MGroupOrderItem`
--

DROP TABLE IF EXISTS `MGroupOrderItem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `MGroupOrderItem` (
  `id` varchar(191) NOT NULL,
  `orderId` varchar(191) NOT NULL,
  `productId` int(11) DEFAULT NULL,
  `sku` varchar(191) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `qty` int(11) NOT NULL,
  `unitPrice` decimal(10,2) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `MGroupOrderItem_orderId_idx` (`orderId`),
  KEY `MGroupOrderItem_productId_idx` (`productId`),
  CONSTRAINT `MGroupOrderItem_orderId_fkey` FOREIGN KEY (`orderId`) REFERENCES `MGroupOrder` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `MGroupOrderItem_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `Product` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MGroupOrderItem`
--

LOCK TABLES `MGroupOrderItem` WRITE;
/*!40000 ALTER TABLE `MGroupOrderItem` DISABLE KEYS */;
/*!40000 ALTER TABLE `MGroupOrderItem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MartProduct`
--

DROP TABLE IF EXISTS `MartProduct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `MartProduct` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sku` varchar(191) NOT NULL,
  `currency` varchar(191) NOT NULL DEFAULT 'THB',
  `category` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `nameEn` varchar(191) DEFAULT NULL,
  `nameZh` varchar(191) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `priceWholesale` decimal(10,2) DEFAULT NULL,
  `unit` varchar(191) NOT NULL DEFAULT 'ชิ้น',
  `minOrder` int(11) NOT NULL DEFAULT 1,
  `minWholesale` int(11) NOT NULL DEFAULT 10,
  `desc` text DEFAULT NULL,
  `img` varchar(191) DEFAULT NULL,
  `stock` int(11) NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `promotion` varchar(191) DEFAULT NULL,
  `promotionPrice` decimal(10,2) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `MartProduct_sku_key` (`sku`),
  KEY `MartProduct_category_idx` (`category`),
  KEY `MartProduct_active_idx` (`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MartProduct`
--

LOCK TABLES `MartProduct` WRITE;
/*!40000 ALTER TABLE `MartProduct` DISABLE KEYS */;
/*!40000 ALTER TABLE `MartProduct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Notification`
--

DROP TABLE IF EXISTS `Notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Notification` (
  `id` varchar(191) NOT NULL,
  `type` enum('INVOICE','SYSTEM_ALERT','WELCOME','PASSWORD_RESET') NOT NULL,
  `channel` enum('EMAIL','LINE','PUSH') NOT NULL,
  `recipient` varchar(191) NOT NULL,
  `subject` varchar(191) DEFAULT NULL,
  `body` text NOT NULL,
  `sent` tinyint(1) NOT NULL DEFAULT 0,
  `sentAt` datetime(3) DEFAULT NULL,
  `error` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `Notification_sent_idx` (`sent`),
  KEY `Notification_type_idx` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Notification`
--

LOCK TABLES `Notification` WRITE;
/*!40000 ALTER TABLE `Notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `Notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PartnerMonthlyFinancial`
--

DROP TABLE IF EXISTS `PartnerMonthlyFinancial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `PartnerMonthlyFinancial` (
  `id` varchar(191) NOT NULL,
  `year` smallint(6) NOT NULL,
  `month` tinyint(4) NOT NULL,
  `revenueKrw` decimal(14,2) NOT NULL DEFAULT 0.00,
  `investmentKrw` decimal(14,2) NOT NULL DEFAULT 0.00,
  `expenseKrw` decimal(14,2) NOT NULL DEFAULT 0.00,
  `updatedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `PartnerMonthlyFinancial_year_month_key` (`year`,`month`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PartnerMonthlyFinancial`
--

LOCK TABLES `PartnerMonthlyFinancial` WRITE;
/*!40000 ALTER TABLE `PartnerMonthlyFinancial` DISABLE KEYS */;
INSERT INTO `PartnerMonthlyFinancial` VALUES
('106c06e0-86ba-4fc8-b0aa-78ac69b637c8',2026,4,0.00,1500000.00,0.00,'2026-06-15 02:04:20.991'),
('b299b373-ca8b-4ea5-9e59-c00ed9c9b512',2026,5,0.00,1000000.00,2062837.00,'2026-06-15 02:04:21.048'),
('cmqek4aty0002jhj7z5fglceo',2026,6,0.00,0.00,426652.00,'2026-06-15 02:04:21.090');
/*!40000 ALTER TABLE `PartnerMonthlyFinancial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PartnerPersonFinancial`
--

DROP TABLE IF EXISTS `PartnerPersonFinancial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `PartnerPersonFinancial` (
  `id` varchar(191) NOT NULL,
  `personName` varchar(191) NOT NULL,
  `ledgerType` varchar(32) NOT NULL COMMENT 'PROFIT_SHARE | INVESTMENT',
  `amount` decimal(14,2) NOT NULL,
  `currency` varchar(8) NOT NULL DEFAULT 'KRW',
  `transactionId` varchar(191) DEFAULT NULL,
  `recordedAt` datetime(3) NOT NULL,
  `notes` text DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `PartnerPersonFinancial_transactionId_key` (`transactionId`),
  KEY `PartnerPersonFinancial_personName_ledgerType_idx` (`personName`,`ledgerType`),
  KEY `PartnerPersonFinancial_recordedAt_idx` (`recordedAt`),
  CONSTRAINT `PartnerPersonFinancial_transactionId_fkey` FOREIGN KEY (`transactionId`) REFERENCES `PartnerTransaction` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PartnerPersonFinancial`
--

LOCK TABLES `PartnerPersonFinancial` WRITE;
/*!40000 ALTER TABLE `PartnerPersonFinancial` DISABLE KEYS */;
INSERT INTO `PartnerPersonFinancial` VALUES
('0d316772-0212-48c3-973a-07c5d164945f','김동규 부사님','INVESTMENT',1000000.00,'KRW','cmpqhew650000qhot2xedltbu','2026-05-29 00:00:00.000','공동 투자금 **강동규 부사님','2026-05-29 14:43:14.541','2026-05-29 14:57:19.808'),
('43c37dc7-9099-4e24-a822-bc20dcadb3a5','복녀파위니','INVESTMENT',1500000.00,'KRW','cmpqhmgqt0000qh7564w9knmx','2026-04-01 00:00:00.000','파위니 투자금 ','2026-05-29 14:43:14.558','2026-05-29 14:57:19.783');
/*!40000 ALTER TABLE `PartnerPersonFinancial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PartnerProduct`
--

DROP TABLE IF EXISTS `PartnerProduct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `PartnerProduct` (
  `id` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `model` varchar(191) DEFAULT NULL,
  `brand` varchar(191) DEFAULT NULL,
  `currency` varchar(191) NOT NULL DEFAULT 'KRW',
  `imageUrls` text DEFAULT NULL,
  `clientId` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `costPrice` decimal(14,2) DEFAULT NULL,
  `sellPrice` decimal(14,2) DEFAULT NULL,
  `categoryId` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `PartnerProduct_name_idx` (`name`),
  KEY `PartnerProduct_clientId_idx` (`clientId`),
  KEY `PartnerProduct_categoryId_idx` (`categoryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PartnerProduct`
--

LOCK TABLES `PartnerProduct` WRITE;
/*!40000 ALTER TABLE `PartnerProduct` DISABLE KEYS */;
INSERT INTO `PartnerProduct` VALUES
('cmph1wrer0005qhuj7wlp09e0','3-Phase Power Logger','PL-3P200','GOEUN SERVER HUB','KRW',NULL,'cmo6viuen0003qhga32hwcu3n','2026-05-22 15:05:01.635','2026-05-22 15:05:01.635',180000.00,249000.00,NULL),
('cmph1wrfb0009qhujfnx5jq6b','Installation & Commissioning','SVC-INST','GOEUN SERVER HUB','KRW',NULL,'cmo6viuen0003qhga32hwcu3n','2026-05-22 15:05:01.655','2026-05-22 15:05:01.655',150000.00,220000.00,NULL),
('cmpqj0ln40003qhkb9efycsbo','3-Phase Meter Analysis SET + Platform  services','50kVA','Momoge Space','KRW',NULL,'cmo6viuen0003qhga32hwcu3n','2026-05-29 06:13:49.840','2026-05-29 06:13:49.840',559000.00,690000.00,NULL);
/*!40000 ALTER TABLE `PartnerProduct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PartnerProductCategory`
--

DROP TABLE IF EXISTS `PartnerProductCategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `PartnerProductCategory` (
  `id` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `sortOrder` int(11) NOT NULL DEFAULT 0,
  `clientId` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `PartnerProductCategory_clientId_name_key` (`clientId`,`name`),
  KEY `PartnerProductCategory_clientId_idx` (`clientId`),
  KEY `PartnerProductCategory_sortOrder_idx` (`sortOrder`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PartnerProductCategory`
--

LOCK TABLES `PartnerProductCategory` WRITE;
/*!40000 ALTER TABLE `PartnerProductCategory` DISABLE KEYS */;
INSERT INTO `PartnerProductCategory` VALUES
('cat-energy-default','เครื่องประหยัดพลังงาน',20,NULL,'2026-05-29 16:15:36.379','2026-05-29 16:15:36.379'),
('cat-iot-default','อุปกรณ์ IoT',10,NULL,'2026-05-29 16:15:36.379','2026-05-29 16:15:36.379'),
('cat-other-default','อื่นๆ',99,NULL,'2026-05-29 16:15:36.379','2026-05-29 16:15:36.379'),
('cat-service-default','บริการ / ติดตั้ง',30,NULL,'2026-05-29 16:15:36.379','2026-05-29 16:15:36.379');
/*!40000 ALTER TABLE `PartnerProductCategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PartnerTask`
--

DROP TABLE IF EXISTS `PartnerTask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `PartnerTask` (
  `id` varchar(191) NOT NULL,
  `title` varchar(191) NOT NULL,
  `type` varchar(191) NOT NULL DEFAULT 'OPERATION',
  `status` varchar(191) NOT NULL DEFAULT 'PENDING',
  `priority` varchar(191) NOT NULL DEFAULT 'NORMAL',
  `brand` varchar(191) NOT NULL DEFAULT 'MOMOGE SPACE',
  `dueDate` datetime(3) DEFAULT NULL,
  `completedAt` datetime(3) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `clientId` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `PartnerTask_type_idx` (`type`),
  KEY `PartnerTask_status_idx` (`status`),
  KEY `PartnerTask_dueDate_idx` (`dueDate`),
  KEY `PartnerTask_clientId_idx` (`clientId`),
  CONSTRAINT `PartnerTask_clientId_fkey` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PartnerTask`
--

LOCK TABLES `PartnerTask` WRITE;
/*!40000 ALTER TABLE `PartnerTask` DISABLE KEYS */;
INSERT INTO `PartnerTask` VALUES
('cmowezidp0000qhyqthb1w761','전력 품질 보정값 측정을 위한 테스트 장비를 확인하고 있습니다.','OPERATION','COMPLETED','NORMAL','MOMOGE SPACE','2026-05-30 00:00:00.000','2026-05-29 05:51:30.174','고객 출고 전에 테스트할 수 있는 소형 전력 품질 개선 장비와 전류 데이터 측정용 테스트 장비를 검토하고 있습니다.','2026-05-08 04:27:55.208','2026-05-29 05:51:30.176',NULL);
/*!40000 ALTER TABLE `PartnerTask` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PartnerTransaction`
--

DROP TABLE IF EXISTS `PartnerTransaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `PartnerTransaction` (
  `id` varchar(191) NOT NULL,
  `number` varchar(191) NOT NULL,
  `brand` varchar(191) NOT NULL DEFAULT 'MOMOGE SPACE',
  `type` varchar(191) NOT NULL DEFAULT 'SALE',
  `description` varchar(191) DEFAULT NULL,
  `customerName` varchar(191) DEFAULT NULL,
  `amount` decimal(14,2) NOT NULL,
  `currency` varchar(191) NOT NULL DEFAULT 'KRW',
  `status` varchar(191) NOT NULL DEFAULT 'COMPLETED',
  `category` varchar(191) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `date` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `receiptFile` text DEFAULT NULL,
  `clientId` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `PartnerTransaction_number_key` (`number`),
  KEY `PartnerTransaction_type_idx` (`type`),
  KEY `PartnerTransaction_status_idx` (`status`),
  KEY `PartnerTransaction_date_idx` (`date`),
  KEY `PartnerTransaction_brand_idx` (`brand`),
  KEY `PartnerTransaction_clientId_idx` (`clientId`),
  CONSTRAINT `PartnerTransaction_clientId_fkey` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PartnerTransaction`
--

LOCK TABLES `PartnerTransaction` WRITE;
/*!40000 ALTER TABLE `PartnerTransaction` DISABLE KEYS */;
INSERT INTO `PartnerTransaction` VALUES
('clx6e278eaaa9ac4fa30cc32145','EXP20260615-0010','MOMOGE SPACE','EXPENSE','ค่าธรรมเนียมจดทะเบียน',NULL,30000.00,'KRW','COMPLETED',NULL,NULL,'2026-06-15 00:00:00.000','2026-06-15 10:57:42.000','2026-06-15 10:57:42.000',NULL,NULL),
('clxb643e6317f20c76988b8680e','EXP20260615-0009','MOMOGE SPACE','EXPENSE','ค่าเช่าสำนักงาน 1 ปี',NULL,370000.00,'KRW','COMPLETED',NULL,NULL,'2026-06-15 00:00:00.000','2026-06-15 10:44:47.000','2026-06-15 10:44:47.000',NULL,NULL),
('clxc0b4a1d92bf19ec1b6640627','EXP20260615-0011','MOMOGE SPACE','EXPENSE','ค่าอุปกรณ์',NULL,26652.00,'KRW','COMPLETED',NULL,NULL,'2026-06-15 00:00:00.000','2026-06-15 11:04:09.000','2026-06-15 11:04:09.000',NULL,NULL),
('cmowmc6fu0000qhwtm76e9295','EXP20260508-0002','MOMOGE SPACE','EXPENSE','Meter + CT','Shanghai Fangqiu Electric Co.,Ltd',402892.00,'KRW','COMPLETED','ค่าอุปกรณ์','C/I NO : FQ26-KR01   Energy Meter  EM4373 2 PCS , Current transformer : SCT-T24','2026-05-08 00:00:00.000','2026-05-08 07:53:43.578','2026-05-29 05:30:18.099','/uploads/partner-receipts/1780032617429-c9dfxm.jpg',NULL),
('cmpjugsdh0000qh0np6qke3ff','EXP20260524-0001','MOMOGE SPACE','EXPENSE','ค่าใช้จ่ายรายหลัก',NULL,1124000.00,'KRW','COMPLETED',NULL,NULL,'2026-05-24 13:59:57.606','2026-05-24 13:59:57.606','2026-05-29 06:18:25.623',NULL,NULL),
('cmpqhew650000qhot2xedltbu','PIN20260529-0001','MOMOGE SPACE','PARTNER_INVESTMENT','공동 투자금 **강동규 부사님','김동규 부사님',1000000.00,'KRW','COMPLETED','เงินลงทุน','공동 투자금 **강동규 부사님','2026-05-29 00:00:00.000','2026-05-29 05:28:57.437','2026-05-29 14:57:19.797',NULL,NULL),
('cmpqhmgqt0000qh7564w9knmx','PIN20260529-0002','MOMOGE SPACE','PARTNER_INVESTMENT','파위니 투자금 ','복녀파위니',1500000.00,'KRW','COMPLETED','เงินลงทุน','파위니 투자금 ','2026-04-01 00:00:00.000','2026-05-29 05:34:50.693','2026-05-29 14:57:19.770',NULL,NULL),
('cmpqke11t0002qh0b5288tanw','EXP20260529-0003','MOMOGE SPACE','EXPENSE','서작권 수수료',NULL,53000.00,'KRW','COMPLETED','อื่นๆ','서작권 수수료','2026-05-16 00:00:00.000','2026-05-29 06:52:15.954','2026-05-29 06:52:15.954',NULL,NULL),
('cmpqkgmuq0005qh0bnd84hp9o','EXP20260529-0004','MOMOGE SPACE','EXPENSE','통신판매  면허 수수료',NULL,40500.00,'KRW','COMPLETED','อื่นๆ','통신판매  면허 수수료','2026-05-19 00:00:00.000','2026-05-29 06:54:17.522','2026-05-29 06:54:17.522',NULL,NULL),
('cmpqkkrbz0008qh0b6ilhr06m','EXP20260529-0005','MOMOGE SPACE','EXPENSE','명합 +  브렌드 로코',NULL,35000.00,'KRW','COMPLETED','ค่าอุปกรณ์','명합 +  브렌드 로코','2026-05-11 00:00:00.000','2026-05-29 06:57:29.952','2026-05-29 06:57:29.952',NULL,NULL),
('cmpqkm811000bqh0bbq4s8171','EXP20260529-0006','MOMOGE SPACE','EXPENSE','current cable  200M ',NULL,82000.00,'KRW','COMPLETED','ค่าอุปกรณ์','current cable  200M ','2026-05-11 00:00:00.000','2026-05-29 06:58:38.245','2026-05-29 06:58:38.245',NULL,NULL),
('cmpqkn5lp000eqh0bwdg75qzo','EXP20260529-0007','MOMOGE SPACE','EXPENSE','Box cass   2pcs',NULL,25000.00,'KRW','COMPLETED','ค่าอุปกรณ์','Box cass   2pcs','2026-05-05 00:00:00.000','2026-05-29 06:59:21.757','2026-05-29 06:59:21.757',NULL,NULL),
('cmpqkq630000hqh0b2n0u0kf5','EXP20260529-0008','MOMOGE SPACE','EXPENSE','CLAUDE AI    1year',NULL,300445.00,'KRW','COMPLETED','อื่นๆ','CLAUDE AI  ','2026-05-26 00:00:00.000','2026-05-29 07:01:42.348','2026-05-29 07:01:42.348',NULL,NULL);
/*!40000 ALTER TABLE `PartnerTransaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Product`
--

DROP TABLE IF EXISTS `Product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sku` varchar(191) NOT NULL,
  `category` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `nameEn` varchar(191) NOT NULL,
  `nameZh` varchar(191) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `priceWholesale` decimal(10,2) NOT NULL,
  `unit` varchar(191) NOT NULL,
  `minOrder` int(11) NOT NULL DEFAULT 1,
  `minWholesale` int(11) NOT NULL DEFAULT 10,
  `desc` text DEFAULT NULL,
  `img` varchar(191) DEFAULT NULL,
  `stock` int(11) NOT NULL DEFAULT 0,
  `rating` decimal(3,1) NOT NULL DEFAULT 5.0,
  `sold` int(11) NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `promotion` varchar(191) DEFAULT NULL,
  `promotionPrice` decimal(10,2) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Product_sku_key` (`sku`),
  KEY `Product_category_idx` (`category`),
  KEY `Product_active_idx` (`active`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Product`
--

LOCK TABLES `Product` WRITE;
/*!40000 ALTER TABLE `Product` DISABLE KEYS */;
INSERT INTO `Product` VALUES
(1,'AG-001','agri','ถังพ่นยา 20 ลิตร','20L Spray Tank','20升喷药桶',890.00,750.00,'ถัง',1,10,'ถังพ่นยาสะพายหลัง 20 ลิตร ปั๊มมือ ทนทาน เหมาะสำหรับพ่นยาฆ่าแมลงและปุ๋ย',NULL,150,4.5,320,1,NULL,NULL,'2026-04-20 16:14:06.231','2026-04-20 16:14:06.231'),
(2,'AG-002','agri','เครื่องตัดหญ้า 2 จังหวะ','2-Stroke Brush Cutter','二冲程割草机',3200.00,2800.00,'เครื่อง',1,5,'เครื่องตัดหญ้าแบบสะพายหลัง เครื่องยนต์ 2 จังหวะ กำลัง 26cc น้ำหนักเบา ใช้งานง่าย',NULL,80,4.7,210,1,NULL,NULL,'2026-04-20 16:14:06.249','2026-04-20 16:14:06.249'),
(3,'AG-003','agri','ปั๊มน้ำไฟฟ้า 0.5 แรงม้า','0.5 HP Water Pump','0.5马力水泵',1450.00,1250.00,'เครื่อง',1,5,'ปั๊มน้ำอัตโนมัติสำหรับสวนเกษตร ทนทาน ประหยัดไฟ',NULL,60,4.4,185,1,NULL,NULL,'2026-04-20 16:14:06.261','2026-04-20 16:14:06.261'),
(4,'AG-004','agri','สายยาง PVC 1 นิ้ว (50 เมตร)','PVC Hose 1 inch 50m','1寸PVC水管50米',650.00,520.00,'ม้วน',1,10,'สายยาง PVC คุณภาพสูง ทนแรงดันน้ำ ไม่แข็งตัวในอากาศเย็น',NULL,200,4.3,450,1,NULL,NULL,'2026-04-20 16:14:06.272','2026-04-20 16:14:06.272'),
(5,'AG-005','agri','เครื่องชั่งดิจิตอล 100 กก.','100kg Digital Scale','100公斤数字秤',2100.00,1850.00,'เครื่อง',1,3,'เครื่องชั่งดิจิตอลแสดงผลแม่นยำ ทนทาน เหมาะสำหรับงานเกษตรและคลังสินค้า',NULL,45,4.6,98,1,NULL,NULL,'2026-04-20 16:14:06.282','2026-04-20 16:14:06.282'),
(6,'RB-001','rubber','จอกยางพารา (100 ชิ้น)','Rubber Latex Cup x100','乳胶杯100个',380.00,300.00,'แพ็ค',1,20,'จอกรองน้ำยางพาราคุณภาพดี ทนทาน ใช้ได้นาน',NULL,500,4.5,620,1,NULL,NULL,'2026-04-20 16:14:06.292','2026-04-20 16:14:06.292'),
(7,'RB-002','rubber','จักรรีดยาง รีดน้ำยางสด','Rubber Wringer Machine','橡胶压榨机',5500.00,4900.00,'เครื่อง',1,2,'จักรรีดยางพาราสดแบบมือหมุน โครงเหล็ก แข็งแรง ทนทาน',NULL,30,4.8,75,1,NULL,NULL,'2026-04-20 16:14:06.301','2026-04-20 16:14:06.301'),
(8,'RB-003','rubber','มีดกรีดยาง สแตนเลส (แพ็ค 5)','Rubber Tapping Knife x5','割胶刀不锈钢5把',220.00,175.00,'แพ็ค',1,20,'มีดกรีดยางพาราสแตนเลสคุณภาพสูง คมทนนาน จับถนัดมือ',NULL,300,4.4,380,1,NULL,NULL,'2026-04-20 16:14:06.311','2026-04-20 16:14:06.311'),
(9,'FS-001','fishing','เชือกอวนไนล่อน 3 มม. (100 เมตร)','Nylon Net Rope 3mm 100m','3mm尼龙绳100米',480.00,400.00,'ม้วน',1,20,'เชือกอวนไนล่อนความแข็งแรงสูง ทนน้ำทะเล เหมาะสำหรับงานประมงและเกษตร',NULL,400,4.5,520,1,NULL,NULL,'2026-04-20 16:14:06.319','2026-04-20 16:14:06.319'),
(10,'FS-002','fishing','ตาข่ายพลาสติก 1.5×50 เมตร','Plastic Net 1.5×50m','塑料网1.5×50米',750.00,620.00,'ม้วน',1,10,'ตาข่ายพลาสติก HDPE ช่องตาข่าย 2 นิ้ว ทนแสงแดด UV ใช้งานได้หลายปี',NULL,180,4.6,290,1,NULL,NULL,'2026-04-20 16:14:06.330','2026-04-20 16:14:06.330'),
(11,'FS-003','fishing','ตาข่ายลวดกัลวาไนซ์ 1×30 เมตร','Galvanized Wire Mesh 1×30m','镀锌铁丝网1×30米',1200.00,980.00,'ม้วน',1,5,'ตาข่ายลวดกัลวาไนซ์ทนสนิม ช่องตาข่าย 1 นิ้ว เหมาะสำหรับงานรั้วและกรง',NULL,120,4.7,175,1,NULL,NULL,'2026-04-20 16:14:06.344','2026-04-20 16:14:06.344'),
(12,'CS-001','construction','สแลนกรองแสง 70% (2×50 เมตร)','70% Shade Cloth 2×50m','70%遮阳网2×50米',1650.00,1400.00,'ม้วน',1,5,'สแลนกรองแสง 70% สีดำ ใยสังเคราะห์ HDPE ทนทาน ลดอุณหภูมิ ป้องกัน UV',NULL,90,4.5,240,1,NULL,NULL,'2026-04-20 16:14:06.354','2026-04-20 16:14:06.354'),
(13,'CS-002','construction','มุ้งไนล่อน 1.2×30 เมตร','Nylon Mesh 1.2×30m','尼龙防虫网1.2×30米',980.00,820.00,'ม้วน',1,10,'มุ้งไนล่อนกันแมลง ตาถี่ ใช้คลุมผักและโรงเรือนเกษตร ทนทาน',NULL,150,4.4,320,1,NULL,NULL,'2026-04-20 16:14:06.362','2026-04-20 16:14:06.362'),
(14,'SF-001','safety','ถุงมือยางกันสารเคมี (คู่)','Chemical Rubber Gloves','防化学品橡胶手套',85.00,65.00,'คู่',5,100,'ถุงมือยางธรรมชาติ กันสารเคมี น้ำยาง และสิ่งสกปรก ยาวถึงข้อศอก',NULL,1000,4.5,850,1,NULL,NULL,'2026-04-20 16:14:06.372','2026-04-20 16:14:06.372'),
(15,'SF-002','safety','รองเท้าบูทยาง Safety (คู่)','Rubber Safety Boots','橡胶安全靴',390.00,320.00,'คู่',1,12,'รองเท้าบูทยาง PVC กันน้ำ กันสารเคมี พื้นกันลื่น เหมาะงานเกษตรและก่อสร้าง',NULL,200,4.6,420,1,NULL,NULL,'2026-04-20 16:14:06.382','2026-04-20 16:14:06.382'),
(16,'SF-003','safety','หมวกนิรภัย Safety Helmet','Safety Helmet','安全帽',185.00,145.00,'ใบ',1,20,'หมวกนิรภัยมาตรฐาน มอก. ABS รับแรงกระแทก ปรับขนาดได้ หลายสี',NULL,350,4.3,560,1,NULL,NULL,'2026-04-20 16:14:06.392','2026-04-20 16:14:06.392'),
(17,'MC-001','misc','ไฟสปอร์ตไลท์ LED 100W','LED Spotlight 100W','100W LED射灯',890.00,740.00,'ดวง',1,10,'ไฟสปอร์ตไลท์ LED 100W กันน้ำ IP65 แสงขาว 6500K เหมาะกลางแจ้งและโรงงาน',NULL,120,4.7,290,1,NULL,NULL,'2026-04-20 16:14:06.404','2026-04-20 16:14:06.404'),
(18,'MC-002','misc','ไฟล้อม LED สายยาว 10 เมตร','LED String Light 10m','LED灯串10米',350.00,280.00,'ชุด',1,20,'ไฟประดับ LED สายยาว 10 เมตร กันน้ำ ใช้ได้ทั้งในและนอกอาคาร',NULL,250,4.4,380,1,NULL,NULL,'2026-04-20 16:14:06.415','2026-04-20 16:14:06.415'),
(19,'AG-006','agri','โดรนพ่นยา 10 ลิตร (เช่า)','10L Drone Sprayer (Rental)','10升无人机喷药(租赁)',1500.00,1200.00,'วัน',1,3,'บริการเช่าโดรนพ่นยา 10 ลิตร พร้อมนักบิน บินได้ 15 ไร่/ชม.',NULL,5,4.9,45,1,NULL,NULL,'2026-04-20 16:14:06.424','2026-04-20 16:14:06.424'),
(20,'CS-003','construction','ลวดผูกเหล็ก 1 กก.','Binding Wire 1kg','绑扎铁丝1公斤',65.00,50.00,'ม้วน',5,50,'ลวดผูกเหล็กอ่อน ชุบดำ ขนาด 18 เบอร์ ใช้ผูกเหล็กก่อสร้าง',NULL,800,4.2,970,1,NULL,NULL,'2026-04-20 16:14:06.432','2026-04-20 16:14:06.432'),
(21,'AG-007','agri','ถาดเพาะกล้า 50 หลุม','50-Cell Seedling Tray','50孔育苗盘',35.00,25.00,'ใบ',10,100,'ถาดเพาะกล้าพลาสติก 50 หลุม ทนทาน ใช้ซ้ำได้ เหมาะสำหรับเพาะพืชผักและไม้ดอก','/m-group-products/1.png',500,4.4,380,1,NULL,NULL,'2026-04-20 16:14:06.440','2026-04-20 16:14:06.440'),
(22,'AG-008','agri','เครื่องพ่นยาไฟฟ้า 12V 16 ลิตร','12V Electric Sprayer 16L','12V电动喷雾器16升',1290.00,1050.00,'เครื่อง',1,5,'เครื่องพ่นยาไฟฟ้าสะพายหลัง 16 ลิตร ใช้แบตเตอรี่ 12V ปรับแรงดันได้ หัวพ่น 4 แบบ','/m-group-products/2.png',70,4.6,155,1,NULL,NULL,'2026-04-20 16:14:06.448','2026-04-20 16:14:06.448'),
(23,'AG-009','agri','ปั๊มหอยโข่ง 1 แรงม้า','Centrifugal Pump 1HP','1马力离心泵',1850.00,1600.00,'เครื่อง',1,3,'ปั๊มหอยโข่งมอเตอร์ 1 แรงม้า ดูดน้ำได้ลึก 8 เมตร อัตราการไหล 100 ลิตร/นาที','/m-group-products/4.png',40,4.5,88,1,NULL,NULL,'2026-04-20 16:14:06.456','2026-04-20 16:14:06.456'),
(24,'AG-010','agri','จอบด้ามไม้ เหล็กหล่อ','Iron Hoe with Wooden Handle','铸铁锄头木柄',185.00,145.00,'เล่ม',1,20,'จอบเหล็กหล่อคุณภาพสูง ด้ามไม้แข็งแรง เหมาะสำหรับขุดดิน พรวนดิน และปลูกพืช','/m-group-products/6.png',250,4.3,310,1,NULL,NULL,'2026-04-20 16:14:06.464','2026-04-20 16:14:06.464'),
(25,'AG-011','agri','รถไถเดินตาม 6 แรงม้า','6HP Power Tiller','6马力手扶拖拉机',28500.00,25000.00,'เครื่อง',1,1,'รถไถเดินตาม เครื่องยนต์ดีเซล 6 แรงม้า ไถ พรวน และสูบน้ำได้ น้ำหนักเบา ใช้งานง่าย','/m-group-products/7.png',12,4.8,34,1,NULL,NULL,'2026-04-20 16:14:06.472','2026-04-20 16:14:06.472'),
(26,'AG-012','agri','อาหารไก่ เนื้อ 30 กก.','Broiler Chicken Feed 30kg','肉鸡饲料30公斤',520.00,450.00,'กระสอบ',1,20,'อาหารไก่เนื้อ สูตรครบถ้วน โปรตีนสูง วิตามินและแร่ธาตุครบ เร่งการเจริญเติบโต','/m-group-products/5.png',200,4.5,420,1,NULL,NULL,'2026-04-20 16:14:06.480','2026-04-20 16:14:06.480'),
(27,'AG-013','agri','สายยางดำ PE 3/4 นิ้ว (100 เมตร)','PE Hose 3/4 inch 100m','3/4寸PE黑管100米',980.00,820.00,'ม้วน',1,5,'สายยางดำ PE ทนแดด ทนน้ำ ใช้สำหรับระบบน้ำหยดและสปริงเกลอร์ในสวนเกษตร',NULL,150,4.4,265,1,NULL,NULL,'2026-04-20 16:14:06.488','2026-04-20 16:14:06.488'),
(28,'RB-004','rubber','อีทีฟอน 39% (Ethephon) 1 ลิตร','Ethephon 39% 1L','乙烯利39%溶液1升',280.00,230.00,'ขวด',1,24,'สารกระตุ้นน้ำยางพาราอีทีฟอน 39% ใช้ทาหน้ายาง เพิ่มผลผลิตน้ำยาง ได้รับการรับรอง','/m-group-products/9.png',200,4.7,480,1,NULL,NULL,'2026-04-20 16:14:06.496','2026-04-20 16:14:06.496'),
(29,'RB-005','rubber','กล่องใส่น้ำยาง 2 ลิตร (แพ็ค 50)','Latex Box 2L x50','2升乳胶盒50个装',290.00,230.00,'แพ็ค',1,10,'กล่องบรรจุน้ำยางพาราขนาด 2 ลิตร ทรงสี่เหลี่ยม มีฝาปิด สะอาด ปลอดภัย ส่งโรงงาน',NULL,300,4.5,290,1,NULL,NULL,'2026-04-20 16:14:06.504','2026-04-20 16:14:06.504'),
(30,'RB-006','rubber','ถังน้ำยาง HDPE 20 ลิตร','HDPE Latex Tank 20L','HDPE乳胶桶20升',185.00,145.00,'ใบ',1,20,'ถังน้ำยาง HDPE 20 ลิตร ฝาเกลียว ทนทาน ไม่เป็นสนิม ใช้เก็บและขนส่งน้ำยางพารา',NULL,400,4.6,340,1,NULL,NULL,'2026-04-20 16:14:06.514','2026-04-20 16:14:06.514'),
(31,'RB-007','rubber','เสาฉากยางพารา เหล็กชุบ (แพ็ค 10)','Rubber Tapping Stand x10','橡胶采集架10个',340.00,280.00,'แพ็ค',1,10,'เสาฉากสำหรับวางจอกรองน้ำยาง ทำจากเหล็กชุบกันสนิม แข็งแรง ติดตั้งง่าย','/m-group-products/8.png',180,4.4,210,1,NULL,NULL,'2026-04-20 16:14:06.524','2026-04-20 16:14:06.524'),
(32,'FS-004','fishing','เชือก PE 3 เส้น 6 มม. (100 เมตร)','PE Rope 3-Strand 6mm 100m','PE三股绳6mm100米',560.00,460.00,'ม้วน',1,10,'เชือก PE 3 เส้น ขนาด 6 มม. ทนน้ำทะเล แรงดึง 500 กก. สีขาว ใช้ในงานประมงและเกษตร',NULL,300,4.5,410,1,NULL,NULL,'2026-04-20 16:14:06.531','2026-04-20 16:14:06.531'),
(33,'FS-005','fishing','อวนล้อม ตา 1.5 นิ้ว ยาว 100 เมตร','Surrounding Net 1.5inch 100m','围网1.5寸100米',2200.00,1850.00,'ม้วน',1,3,'อวนล้อมไนล่อน ตาห่าง 1.5 นิ้ว ยาว 100 เมตร ลึก 3 เมตร ทนทาน ทนแดด UV','/m-group-products/10.png',60,4.6,85,1,NULL,NULL,'2026-04-20 16:14:06.540','2026-04-20 16:14:06.540'),
(34,'FS-006','fishing','ตะกั่วถ่วงน้ำหนัก 1 กก.','Fishing Lead Sinkers 1kg','渔铅坠1公斤',120.00,95.00,'กก.',1,20,'ตะกั่วถ่วงน้ำหนักสำหรับงานประมง หล่อจากตะกั่วบริสุทธิ์ หลากหลายขนาด',NULL,250,4.3,320,1,NULL,NULL,'2026-04-20 16:14:06.548','2026-04-20 16:14:06.548'),
(35,'FS-007','fishing','เชือกกล้วย PP 3 มม. (200 เมตร)','PP Rope 3mm 200m','PP绳3mm200米',180.00,140.00,'ม้วน',2,30,'เชือกกล้วย PP สีเหลือง-ดำ ขนาด 3 มม. ยาว 200 เมตร เหนียว ทนทาน ราคาประหยัด',NULL,600,4.4,780,1,NULL,NULL,'2026-04-20 16:14:06.556','2026-04-20 16:14:06.556'),
(36,'CS-004','construction','รถเข็นมือ ล้อยาง 100 กก.','Wheelbarrow 100kg Rubber Wheel','橡胶轮手推车100公斤',1450.00,1200.00,'คัน',1,3,'รถเข็นมือ โครงเหล็กหนา ล้อยางเติมลม ความจุ 100 กก. เหมาะสำหรับงานก่อสร้างและเกษตร','/m-group-products/12.png',45,4.7,120,1,NULL,NULL,'2026-04-20 16:14:06.564','2026-04-20 16:14:06.564'),
(37,'CS-005','construction','สแลนกรองแสง 50% (1×50 เมตร)','50% Shade Cloth 1×50m','50%遮阳网1×50米',780.00,640.00,'ม้วน',1,10,'สแลนกรองแสง 50% สีเขียว ใยสังเคราะห์ HDPE กันแดด กันฝุ่น ใช้ในโรงเรือนและก่อสร้าง',NULL,110,4.5,195,1,NULL,NULL,'2026-04-20 16:14:06.574','2026-04-20 16:14:06.574'),
(38,'CS-006','construction','ท่อ PVC ชั้น 8.5 ขนาด 4 นิ้ว (4 เมตร)','PVC Pipe Class 8.5 4inch 4m','4寸PVC管8.5级4米',320.00,260.00,'ท่อน',1,20,'ท่อ PVC ชั้น 8.5 ขนาด 4 นิ้ว ยาว 4 เมตร มอก.17-2532 ทนแรงดัน เหมาะงานระบบน้ำและก่อสร้าง',NULL,80,4.3,145,1,NULL,NULL,'2026-04-20 16:14:06.581','2026-04-20 16:14:06.581'),
(39,'CS-007','construction','แผ่นโปลีคาร์บอเนต 4 มม. (1.22×2.44 เมตร)','Polycarbonate Sheet 4mm 1.22×2.44m','4mm聚碳酸酯板1.22×2.44米',1380.00,1150.00,'แผ่น',1,5,'แผ่นโปลีคาร์บอเนตใส 4 มม. กันกระแทก กันแดด UV ใช้ทำหลังคา โรงเรือน และหน้าต่าง',NULL,55,4.6,98,1,NULL,NULL,'2026-04-20 16:14:06.591','2026-04-20 16:14:06.591'),
(40,'SF-004','safety','แว่นตานิรภัย กันสะเก็ด','Safety Goggles Anti-Splatter','防溅安全护目镜',65.00,48.00,'อัน',5,50,'แว่นตานิรภัยโพลีคาร์บอเนต กันสะเก็ด กันสารเคมี มาตรฐาน ANSI Z87.1','/m-group-products/11.png',500,4.5,680,1,NULL,NULL,'2026-04-20 16:14:06.598','2026-04-20 16:14:06.598'),
(41,'SF-005','safety','ชุด PPE กันสารเคมี (ชิ้น)','Chemical PPE Coverall','化学防护服',480.00,390.00,'ชุด',1,20,'ชุด PPE กันสารเคมีแบบทั้งตัว วัสดุโพลีโพรพีลีน กันไอระเหย กันสารเคมีกลุ่ม A-C',NULL,150,4.4,240,1,NULL,NULL,'2026-04-20 16:14:06.616','2026-04-20 16:14:06.616'),
(42,'SF-006','safety','หน้ากากกรองฝุ่น N95 (กล่อง 20 ชิ้น)','N95 Dust Mask Box of 20','N95防尘口罩盒装20个',340.00,280.00,'กล่อง',1,10,'หน้ากากกรองฝุ่น N95 มาตรฐาน กรองฝุ่น PM2.5 เชื้อโรค และสารเคมีบางชนิด',NULL,300,4.6,520,1,NULL,NULL,'2026-04-20 16:14:06.624','2026-04-20 16:14:06.624'),
(43,'SF-007','safety','เข็มขัดนิรภัย 2 จุด (Full Body Harness)','Full Body Harness 2-Point','全身安全带双挂点',890.00,720.00,'ชุด',1,10,'เข็มขัดนิรภัยแบบ Full Body รับน้ำหนักได้ถึง 140 กก. มาตรฐาน EN361 เหมาะงานสูง',NULL,80,4.7,145,1,NULL,NULL,'2026-04-20 16:14:06.631','2026-04-20 16:14:06.631'),
(44,'MC-003','misc','กระทะอลูมิเนียม 36 ซม.','Aluminum Wok 36cm','36厘米铝锅',320.00,255.00,'ใบ',1,12,'กระทะอลูมิเนียมหล่อ ขนาด 36 ซม. ก้นหนา 4 มม. ให้ความร้อนสม่ำเสมอ น้ำหนักเบา','/m-group-products/14.png',180,4.4,260,1,NULL,NULL,'2026-04-20 16:14:06.640','2026-04-20 16:14:06.640'),
(45,'MC-004','misc','เครื่องชั่งแบบห้อย 50 กก.','Hanging Scale 50kg','50公斤吊秤',290.00,230.00,'เครื่อง',1,10,'เครื่องชั่งแบบห้อย สเกล 50 กก. อ่านค่าง่าย สปริงเหล็กกล้า เหมาะสำหรับชั่งสินค้าเกษตร','/m-group-products/16.png',120,4.3,190,1,NULL,NULL,'2026-04-20 16:14:06.649','2026-04-20 16:14:06.649'),
(46,'MC-005','misc','ธูปขาว 3 หุน (1 กล่อง)','White Incense Sticks 3 hua (1 box)','白香3分装（1盒）',85.00,65.00,'กล่อง',1,20,'ธูปขาวคุณภาพดี กลิ่นหอมอ่อน ไม่ฉุน ขนาด 3 หุน บรรจุกล่อง ใช้ไหว้บูชา','/m-group-products/18.png',400,4.5,580,1,NULL,NULL,'2026-04-20 16:14:06.656','2026-04-20 16:14:06.656'),
(47,'MC-006','misc','กล่องลัง ลูกฟูก 5 ชั้น (20×30×25 ซม.)','5-Layer Corrugated Box 20×30×25cm','5层瓦楞纸箱20×30×25厘米',28.00,20.00,'ใบ',20,200,'กล่องลังลูกฟูก 5 ชั้น ขนาด 20×30×25 ซม. แข็งแรง ทนน้ำหนัก เหมาะบรรจุสินค้าทั่วไป','/m-group-products/15.png',1000,4.2,1250,1,NULL,NULL,'2026-04-20 16:14:06.663','2026-04-20 16:14:06.663'),
(48,'MC-007','misc','ไฟสปอร์ตไลท์ LED 200W กันน้ำ','LED Floodlight 200W Waterproof','200W防水LED泛光灯',1650.00,1380.00,'ดวง',1,5,'ไฟสปอร์ตไลท์ LED 200W IP66 กันน้ำ กันฝุ่น แสงขาว 6500K ประหยัดไฟ ทนทาน','/m-group-products/13.png',75,4.7,165,1,NULL,NULL,'2026-04-20 16:14:06.672','2026-04-20 16:14:06.672');
/*!40000 ALTER TABLE `Product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Receipt`
--

DROP TABLE IF EXISTS `Receipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Receipt` (
  `id` varchar(191) NOT NULL,
  `number` varchar(191) NOT NULL,
  `clientId` varchar(191) NOT NULL,
  `currency` varchar(191) NOT NULL DEFAULT 'THB',
  `issuedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `subtotal` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `notes` text DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `customerAddress` text DEFAULT NULL,
  `customerEmail` varchar(191) DEFAULT NULL,
  `customerName` varchar(191) NOT NULL DEFAULT '',
  `customerPhone` varchar(191) DEFAULT NULL,
  `customerId` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Receipt_number_key` (`number`),
  KEY `Receipt_clientId_idx` (`clientId`),
  KEY `Receipt_issuedAt_idx` (`issuedAt`),
  KEY `Receipt_customerId_idx` (`customerId`),
  CONSTRAINT `Receipt_clientId_fkey` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `Receipt_customerId_fkey` FOREIGN KEY (`customerId`) REFERENCES `Customer` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Receipt`
--

LOCK TABLES `Receipt` WRITE;
/*!40000 ALTER TABLE `Receipt` DISABLE KEYS */;
INSERT INTO `Receipt` VALUES
('cmo79kw8y0001qh3axzagqao9','RCP260420-00001','cmo6x1sht0008qhvqygcgasiq','THB','2026-04-18 15:00:00.000',6600.00,6400.00,NULL,'2026-04-20 14:02:20.866','2026-04-20 14:31:00.246',NULL,NULL,'Mr.Thanate  Phongthai',NULL,NULL);
/*!40000 ALTER TABLE `Receipt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ReceiptItem`
--

DROP TABLE IF EXISTS `ReceiptItem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ReceiptItem` (
  `id` varchar(191) NOT NULL,
  `receiptId` varchar(191) NOT NULL,
  `description` varchar(191) NOT NULL,
  `quantity` decimal(10,2) NOT NULL DEFAULT 1.00,
  `unitPrice` decimal(10,2) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `sortOrder` int(11) NOT NULL DEFAULT 0,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `discountAmount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `discountPercent` decimal(5,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  KEY `ReceiptItem_receiptId_idx` (`receiptId`),
  KEY `ReceiptItem_sortOrder_idx` (`sortOrder`),
  CONSTRAINT `ReceiptItem_receiptId_fkey` FOREIGN KEY (`receiptId`) REFERENCES `Receipt` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ReceiptItem`
--

LOCK TABLES `ReceiptItem` WRITE;
/*!40000 ALTER TABLE `ReceiptItem` DISABLE KEYS */;
INSERT INTO `ReceiptItem` VALUES
('cmo7alqxl0000qhlqksfrlv6r','cmo79kw8y0001qh3axzagqao9','วันที่เข้าพัก 18-19 เมษายน 2569   1 คืน 2 วัน',1.00,800.00,800.00,0,'2026-04-20 14:31:00.246',0.00,0.00),
('cmo7alqxl0001qhlqx4xo613o','cmo79kw8y0001qh3axzagqao9','วันที่เข้าพัก 19-21 เมษายน 2569   2 คืน 3 วัน  ห้อง VIP',2.00,900.00,1800.00,1,'2026-04-20 14:31:00.246',0.00,0.00),
('cmo7alqxl0002qhlqzwbvhqp1','cmo79kw8y0001qh3axzagqao9','วันที่เข้าพัก 21-26 เมษายน 2569   5 คืน 6 วัน',5.00,800.00,3800.00,2,'2026-04-20 14:31:00.246',0.00,5.00);
/*!40000 ALTER TABLE `ReceiptItem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ResortBooking`
--

DROP TABLE IF EXISTS `ResortBooking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ResortBooking` (
  `id` varchar(191) NOT NULL,
  `number` varchar(191) NOT NULL,
  `guestName` varchar(191) NOT NULL,
  `guestPhone` varchar(191) DEFAULT NULL,
  `guestEmail` varchar(191) DEFAULT NULL,
  `checkIn` datetime(3) NOT NULL,
  `checkOut` datetime(3) DEFAULT NULL,
  `stayType` varchar(191) NOT NULL DEFAULT 'OVERNIGHT',
  `adults` int(11) NOT NULL DEFAULT 1,
  `children` int(11) NOT NULL DEFAULT 0,
  `pricePerNight` decimal(10,2) NOT NULL DEFAULT 800.00,
  `totalPrice` decimal(10,2) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'PENDING',
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ResortBooking_number_key` (`number`),
  KEY `ResortBooking_guestPhone_idx` (`guestPhone`),
  KEY `ResortBooking_checkIn_idx` (`checkIn`),
  KEY `ResortBooking_status_idx` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ResortBooking`
--

LOCK TABLES `ResortBooking` WRITE;
/*!40000 ALTER TABLE `ResortBooking` DISABLE KEYS */;
/*!40000 ALTER TABLE `ResortBooking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Service`
--

DROP TABLE IF EXISTS `Service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Service` (
  `id` varchar(191) NOT NULL,
  `title` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `highlight` varchar(191) NOT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Service`
--

LOCK TABLES `Service` WRITE;
/*!40000 ALTER TABLE `Service` DISABLE KEYS */;
INSERT INTO `Service` VALUES
('cmo6wquzl0000qhusugfmjreb','บริการดูแลระบบ',NULL,'ดูแลและบำรุงรักษาระบบ',NULL,1,'2026-04-20 08:03:04.161','2026-04-20 08:03:04.161'),
('cmo6wqv010001qhusjh92gzm0','บริการเช่าโดเมนรายปี',NULL,'จดและต่ออายุโดเมน',NULL,1,'2026-04-20 08:03:04.178','2026-04-20 08:03:04.178'),
('cmo6wqv0d0002qhusw3mzpmyc','บริการยิงแอด',NULL,'โฆษณา Facebook/Google',NULL,1,'2026-04-20 08:03:04.189','2026-04-20 08:03:04.189'),
('cmo6wqv110003qhusi1vpkl2m','บริการออกแบบหน้าเว็บ',NULL,'UI/UX Design',NULL,1,'2026-04-20 08:03:04.213','2026-04-20 08:03:04.213'),
('cmo6wqv1h0004qhusezds6zuw','บริการพัฒนาระบบ',NULL,'พัฒนาซอฟต์แวร์ตามความต้องการ',NULL,1,'2026-04-20 08:03:04.230','2026-04-20 08:03:04.230'),
('cmo6wqv1y0005qhusaxeobrwk','บริการอื่นๆ',NULL,'บริการเสริมอื่นๆ',NULL,1,'2026-04-20 08:03:04.246','2026-04-20 08:03:04.246');
/*!40000 ALTER TABLE `Service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Session`
--

DROP TABLE IF EXISTS `Session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Session` (
  `id` varchar(191) NOT NULL,
  `sessionToken` varchar(191) NOT NULL,
  `userId` varchar(191) NOT NULL,
  `expires` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Session_sessionToken_key` (`sessionToken`),
  KEY `Session_userId_idx` (`userId`),
  CONSTRAINT `Session_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Session`
--

LOCK TABLES `Session` WRITE;
/*!40000 ALTER TABLE `Session` DISABLE KEYS */;
/*!40000 ALTER TABLE `Session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SoftwareDownloadOrder`
--

DROP TABLE IF EXISTS `SoftwareDownloadOrder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `SoftwareDownloadOrder` (
  `id` varchar(191) NOT NULL,
  `orderCode` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `productId` varchar(191) DEFAULT NULL,
  `productSlug` varchar(191) NOT NULL,
  `productTitle` varchar(191) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(191) NOT NULL DEFAULT 'THB',
  `status` enum('PENDING','AWAITING_REVIEW','PAID','CANCELLED') NOT NULL DEFAULT 'PENDING',
  `stripeCheckoutSessionId` varchar(191) DEFAULT NULL,
  `stripePaymentIntentId` varchar(191) DEFAULT NULL,
  `paymentGateway` varchar(191) DEFAULT NULL,
  `receiptFile` varchar(191) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `paidAt` datetime(3) DEFAULT NULL,
  `downloadCount` int(11) NOT NULL DEFAULT 0,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  `accessPassword` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `SoftwareDownloadOrder_orderCode_key` (`orderCode`),
  KEY `SoftwareDownloadOrder_email_idx` (`email`),
  KEY `SoftwareDownloadOrder_status_idx` (`status`),
  KEY `SoftwareDownloadOrder_productSlug_idx` (`productSlug`),
  KEY `SoftwareDownloadOrder_productId_idx` (`productId`),
  CONSTRAINT `SoftwareDownloadOrder_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `SoftwareDownloadProduct` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SoftwareDownloadOrder`
--

LOCK TABLES `SoftwareDownloadOrder` WRITE;
/*!40000 ALTER TABLE `SoftwareDownloadOrder` DISABLE KEYS */;
INSERT INTO `SoftwareDownloadOrder` VALUES
('cmpy1yksa0001qhmeksw5n4wx','6EPCQQQM','test@test.com','sd_cargo','cargo-android','คาโก้ ไทย-เกาหลี — แอป Android',0.00,'THB','PAID',NULL,NULL,NULL,NULL,'{\"freeDownload\":true,\"confirmedAt\":\"2026-06-03T12:38:31.347Z\"}','2026-06-03 12:38:31.346',0,'2026-06-03 12:38:31.353','2026-06-03 12:38:31.353','YQyYDV7wjn');
/*!40000 ALTER TABLE `SoftwareDownloadOrder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SoftwareDownloadProduct`
--

DROP TABLE IF EXISTS `SoftwareDownloadProduct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `SoftwareDownloadProduct` (
  `id` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `title` varchar(191) NOT NULL,
  `titleTh` varchar(191) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `platform` varchar(191) DEFAULT NULL,
  `version` varchar(191) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `currency` varchar(191) NOT NULL DEFAULT 'THB',
  `filePath` varchar(191) DEFAULT NULL,
  `fileName` varchar(191) DEFAULT NULL,
  `icon` varchar(191) DEFAULT NULL,
  `sortOrder` int(11) NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `free` tinyint(1) NOT NULL DEFAULT 0,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT current_timestamp(3) ON UPDATE current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `SoftwareDownloadProduct_slug_key` (`slug`),
  KEY `SoftwareDownloadProduct_active_idx` (`active`),
  KEY `SoftwareDownloadProduct_sortOrder_idx` (`sortOrder`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SoftwareDownloadProduct`
--

LOCK TABLES `SoftwareDownloadProduct` WRITE;
/*!40000 ALTER TABLE `SoftwareDownloadProduct` DISABLE KEYS */;
INSERT INTO `SoftwareDownloadProduct` VALUES
('sd_cargo','cargo-android','คาโก้ ไทย-เกาหลี (Android)','คาโก้ ไทย-เกาหลี — แอป Android','แอพ บริการส่งสินค้าจากไทย ไปเกาหลี','Android','1.0.0',0.00,'THB','cargo/CargoThaiKorea-android.apk','CargoThaiKorea-android.apk','/cargo/cargo-logo.png',3,1,1,'2026-06-03 20:22:43.661','2026-06-03 20:22:43.661'),
('sd_momoge_space','momoge-space-android','Momoge space (Android)','Momoge space — แอป Android','แอป Customer Dashboard สำหรับ Momoge space','Android','1.0.1',0.00,'THB','momoge-space/MomogeSpace-android.apk','MomogeSpace-android.apk','/momoge/Logo-brand.png',2,1,1,'2026-06-03 20:22:43.654','2026-06-03 20:22:43.654'),
('sd_phone_remote','phone-remote-android','Phone Remote (Android)','Phone Remote — แอป Android','แอปรีโมทและแชร์หน้าจอ พร้อมควบคุมจาก Viewer หลังเปิด Accessibility','Android','1.0.0',10000.00,'KRW','phone-remote/PhoneRemote-android.apk','PhoneRemote-android.apk','/logo-mark.svg',1,1,0,'2026-06-03 20:22:43.648','2026-06-03 20:22:43.648');
/*!40000 ALTER TABLE `SoftwareDownloadProduct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `User` (
  `id` varchar(191) NOT NULL,
  `name` varchar(191) DEFAULT NULL,
  `username` varchar(191) DEFAULT NULL,
  `email` varchar(191) NOT NULL,
  `emailVerified` datetime(3) DEFAULT NULL,
  `image` varchar(191) DEFAULT NULL,
  `password` varchar(191) DEFAULT NULL,
  `role` enum('SUPER_ADMIN','ADMIN','CLIENT','PARTNER') NOT NULL DEFAULT 'CLIENT',
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  `clientId` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `User_email_key` (`email`),
  UNIQUE KEY `User_username_key` (`username`),
  KEY `User_email_idx` (`email`),
  KEY `User_clientId_idx` (`clientId`),
  CONSTRAINT `User_clientId_fkey` FOREIGN KEY (`clientId`) REFERENCES `Client` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES
('c43585d0ad80aeca6ea58f153','Partner01','ge-server-hub-1','partner01@geserverhub.local',NULL,NULL,'$2b$12$P0J5qt02Y.64EWCY5umIIeoZ/N1SyISZ5UfFUXbHz8GdD1m3q/FcS','PARTNER','2026-05-10 14:07:39.000','2026-05-17 11:13:32.696','cmo6viuen0003qhga32hwcu3n'),
('cmo6viud90000qhga458at56f','Super Admin','goeun','superadmin',NULL,NULL,'$2b$12$jVYDMZUa22ZAHxRI54IfS.fNKCvNSYvD39PqjQZgLLONHPAHlN7XG','SUPER_ADMIN','2026-04-20 07:28:50.494','2026-05-10 14:30:41.000','cmo6viuen0003qhga32hwcu3n'),
('cmox6qo9t0000jhpk0qz39m5a','Partner User','partner01','partner',NULL,NULL,'$2b$12$6DsH.oWNPaUBsswnWnN5fe5wyAnM1XzmaCTNEjaneChkUDIYhJF2m','PARTNER','2026-05-08 17:24:52.193','2026-05-22 13:49:59.508','cmo6viuen0003qhga32hwcu3n'),
('green-retail-user-001','Green Retail Demo','greenretail','demo@green-retail.example.com',NULL,NULL,'$2b$10$VB86P90EmP6i/IMuTtYLMu9cpFT.AYp6pIm.yyax5oJfa4WUrHAaS','CLIENT','2026-04-22 13:09:06.000','2026-04-22 13:09:06.000',NULL),
('momoge01','momoge space','MOMOGE SPACE  DEMO','momoge-space@example.com',NULL,NULL,'$2b$12$YJ4BQ1PCBjtCnhNCGmIrpO6kAnPjagugpaXp.g.3SeFUpt6yrVTqK','CLIENT','2026-04-22 13:09:06.000','2026-05-22 13:50:51.783','cmo9bve0m0000qhtikd261ug2');
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VerificationToken`
--

DROP TABLE IF EXISTS `VerificationToken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `VerificationToken` (
  `identifier` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `expires` datetime(3) NOT NULL,
  UNIQUE KEY `VerificationToken_token_key` (`token`),
  UNIQUE KEY `VerificationToken_identifier_token_key` (`identifier`,`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VerificationToken`
--

LOCK TABLES `VerificationToken` WRITE;
/*!40000 ALTER TABLE `VerificationToken` DISABLE KEYS */;
/*!40000 ALTER TABLE `VerificationToken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ai_settings`
--

DROP TABLE IF EXISTS `ai_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `openai_api_key` varchar(512) DEFAULT NULL,
  `openai_model` varchar(64) NOT NULL DEFAULT 'gpt-4o-mini',
  `anthropic_api_key` varchar(512) DEFAULT NULL,
  `anthropic_model` varchar(64) NOT NULL DEFAULT 'claude-haiku-4-5-20251001',
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ai_settings_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_settings`
--

LOCK TABLES `ai_settings` WRITE;
/*!40000 ALTER TABLE `ai_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `ai_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `analysis_results`
--

DROP TABLE IF EXISTS `analysis_results`;
/*!50001 DROP VIEW IF EXISTS `analysis_results`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `analysis_results` AS SELECT
 1 AS `id`,
  1 AS `site_id`,
  1 AS `report_id`,
  1 AS `device_id`,
  1 AS `total_energy`,
  1 AS `average_load`,
  1 AS `max_demand`,
  1 AS `load_factor`,
  1 AS `average_pf`,
  1 AS `current_imbalance`,
  1 AS `voltage_imbalance`,
  1 AS `thdi_avg`,
  1 AS `thdv_avg`,
  1 AS `risk_level`,
  1 AS `created_at` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `api_keys`
--

DROP TABLE IF EXISTS `api_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_keys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `key_name` varchar(100) NOT NULL,
  `api_key` varchar(64) NOT NULL,
  `api_secret` varchar(128) NOT NULL DEFAULT '',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_used_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_api_key` (`api_key`),
  KEY `idx_api_keys_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_keys`
--

LOCK TABLES `api_keys` WRITE;
/*!40000 ALTER TABLE `api_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `api_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `broadcast_messages`
--

DROP TABLE IF EXISTS `broadcast_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `broadcast_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `category` enum('announcement','maintenance','promotion','alert') NOT NULL DEFAULT 'announcement',
  `sent_by` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_active` (`is_active`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `broadcast_messages`
--

LOCK TABLES `broadcast_messages` WRITE;
/*!40000 ALTER TABLE `broadcast_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `broadcast_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carbon_locations`
--

DROP TABLE IF EXISTS `carbon_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `carbon_locations` (
  `locationID` varchar(255) NOT NULL,
  `locationName` varchar(255) NOT NULL,
  `address` text DEFAULT NULL,
  `site` varchar(50) DEFAULT 'thailand',
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT current_timestamp(6),
  `updated_at` datetime(6) DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`locationID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carbon_locations`
--

LOCK TABLES `carbon_locations` WRITE;
/*!40000 ALTER TABLE `carbon_locations` DISABLE KEYS */;
/*!40000 ALTER TABLE `carbon_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carbon_meters`
--

DROP TABLE IF EXISTS `carbon_meters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `carbon_meters` (
  `meterID` varchar(255) NOT NULL,
  `deviceID` int(11) DEFAULT NULL,
  `meterType` enum('before','metrics') DEFAULT 'metrics',
  `meterNo` varchar(50) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT current_timestamp(6),
  `updated_at` datetime(6) DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`meterID`),
  KEY `idx_carbon_meters_device` (`deviceID`),
  CONSTRAINT `fk_carbon_meters_device` FOREIGN KEY (`deviceID`) REFERENCES `devices` (`deviceID`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carbon_meters`
--

LOCK TABLES `carbon_meters` WRITE;
/*!40000 ALTER TABLE `carbon_meters` DISABLE KEYS */;
/*!40000 ALTER TABLE `carbon_meters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carboncre_cacu`
--

DROP TABLE IF EXISTS `carboncre_cacu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `carboncre_cacu` (
  `carbonID` int(10) NOT NULL AUTO_INCREMENT,
  `meterID` varchar(255) NOT NULL,
  `LocationID` varchar(255) NOT NULL,
  `serailID` varchar(255) NOT NULL,
  `deviceID` int(11) DEFAULT NULL,
  `power_record_id` int(11) DEFAULT NULL,
  `power_preinstall_id` int(11) DEFAULT NULL,
  `carbon_kg` decimal(12,4) DEFAULT NULL,
  `energy_kwh` decimal(12,3) DEFAULT NULL,
  `reduction_percent` decimal(8,2) DEFAULT NULL,
  `record_date` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` datetime(6) DEFAULT current_timestamp(6),
  `updated_at` datetime(6) DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`carbonID`),
  KEY `fk_carbon_cacu_meter` (`meterID`),
  KEY `fk_carbon_cacu_location` (`LocationID`),
  KEY `fk_carbon_cacu_device` (`deviceID`),
  KEY `idx_carbon_power_record` (`power_record_id`),
  KEY `idx_carbon_power_preinstall` (`power_preinstall_id`),
  CONSTRAINT `fk_carbon_cacu_device` FOREIGN KEY (`deviceID`) REFERENCES `devices` (`deviceID`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_carbon_cacu_location` FOREIGN KEY (`LocationID`) REFERENCES `carbon_locations` (`locationID`) ON UPDATE CASCADE,
  CONSTRAINT `fk_carbon_cacu_meter` FOREIGN KEY (`meterID`) REFERENCES `carbon_meters` (`meterID`) ON UPDATE CASCADE,
  CONSTRAINT `fk_carbon_cacu_power_preinstall` FOREIGN KEY (`power_preinstall_id`) REFERENCES `power_records_preinstall` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_carbon_cacu_power_record` FOREIGN KEY (`power_record_id`) REFERENCES `power_records` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carboncre_cacu`
--

LOCK TABLES `carboncre_cacu` WRITE;
/*!40000 ALTER TABLE `carboncre_cacu` DISABLE KEYS */;
/*!40000 ALTER TABLE `carboncre_cacu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cc_reports`
--

DROP TABLE IF EXISTS `cc_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cc_reports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `report_number` varchar(64) NOT NULL,
  `site` varchar(32) NOT NULL DEFAULT 'all',
  `period_days` int(11) NOT NULL DEFAULT 30,
  `locale` varchar(10) NOT NULL DEFAULT 'th',
  `device_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`device_ids`)),
  `meter_count` int(11) NOT NULL DEFAULT 0,
  `total_energy_saved_kwh` decimal(14,4) DEFAULT NULL,
  `total_co2_kg` decimal(14,4) DEFAULT NULL,
  `carbon_credits_tonnes` decimal(14,6) DEFAULT NULL,
  `estimated_value` decimal(14,2) DEFAULT NULL,
  `currency` varchar(8) DEFAULT NULL,
  `issue_date` datetime NOT NULL DEFAULT current_timestamp(),
  `prepared_by` varchar(255) DEFAULT 'GE Energy Tech',
  `report_status` enum('printed','draft','archived') NOT NULL DEFAULT 'printed',
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cc_reports_number` (`report_number`),
  KEY `idx_cc_reports_site` (`site`),
  KEY `idx_cc_reports_issue` (`issue_date`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cc_reports`
--

LOCK TABLES `cc_reports` WRITE;
/*!40000 ALTER TABLE `cc_reports` DISABLE KEYS */;
INSERT INTO `cc_reports` VALUES
(1,'GE-CC-20260606-001','thailand',365,'en','[4]',1,270.0000,138.6500,0.138700,35.00,'THB','2026-06-06 23:31:30','GE Energy Tech','printed','2026-06-06 23:31:30.117237'),
(2,'GE-CC-20260606-002','thailand',365,'en','[4]',1,270.0000,138.6500,0.138700,35.00,'THB','2026-06-06 23:33:27','GE Energy Tech','printed','2026-06-06 23:33:27.678826'),
(3,'GE-CC-20260606-003','thailand',365,'en','[3,2,1,5,4]',5,82669.0000,42450.5500,42.450600,10612.00,'THB','2026-06-06 23:34:41','GE Energy Tech','printed','2026-06-06 23:34:41.903242'),
(4,'GE-CC-20260606-004','thailand',365,'ko','[3,2,1,5,4]',5,82669.0000,42450.5500,42.450600,10612.00,'THB','2026-06-06 23:50:55','GE Energy Tech','printed','2026-06-06 23:50:55.499386'),
(5,'GE-CC-20260606-005','thailand',365,'ko','[3,2,1,5,4]',5,82669.0000,42450.5500,42.450600,10612.00,'THB','2026-06-06 23:52:59','GE Energy Tech','printed','2026-06-06 23:52:59.911138'),
(6,'GE-CC-20260606-006','thailand',365,'ko','[3,2,1,5,4]',5,82669.0000,42450.5500,42.450600,10612.00,'THB','2026-06-07 00:11:29','GE Energy Tech','printed','2026-06-07 00:11:29.567548');
/*!40000 ALTER TABLE `cc_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!50001 DROP VIEW IF EXISTS `customers`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `customers` AS SELECT
 1 AS `id`,
  1 AS `customer_name`,
  1 AS `business_type`,
  1 AS `address`,
  1 AS `contact_person`,
  1 AS `phone`,
  1 AS `email`,
  1 AS `created_at`,
  1 AS `updated_at` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `device_connectivity`
--

DROP TABLE IF EXISTS `device_connectivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_connectivity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(11) NOT NULL,
  `mmg_id` int(11) DEFAULT NULL,
  `gateway_model` varchar(50) DEFAULT 'T310',
  `serial_port` varchar(100) DEFAULT '/dev/ttyS1',
  `baud_rate` int(11) NOT NULL DEFAULT 9600,
  `parity` varchar(10) NOT NULL DEFAULT 'none',
  `data_bits` tinyint(4) NOT NULL DEFAULT 8,
  `stop_bits` tinyint(4) NOT NULL DEFAULT 1,
  `slave_before` int(11) NOT NULL DEFAULT 1,
  `slave_metrics` int(11) NOT NULL DEFAULT 2,
  `reg_v_l1` int(11) NOT NULL DEFAULT 0,
  `reg_v_l2` int(11) NOT NULL DEFAULT 2,
  `reg_v_l3` int(11) NOT NULL DEFAULT 4,
  `scale_voltage` decimal(10,4) NOT NULL DEFAULT 10.0000,
  `mqtt_topic` varchar(255) DEFAULT NULL,
  `publish_interval_sec` int(11) NOT NULL DEFAULT 30,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `last_seen_at` datetime DEFAULT NULL,
  `last_record_id` int(11) DEFAULT NULL,
  `online_status` tinyint(1) NOT NULL DEFAULT 0,
  `notes` text DEFAULT NULL,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_device_connectivity_device` (`device_id`),
  KEY `idx_device_connectivity_enabled` (`enabled`),
  KEY `fk_dc_last_record` (`last_record_id`),
  KEY `idx_device_connectivity_mmg_id` (`mmg_id`),
  CONSTRAINT `device_connectivity_device_id_fkey` FOREIGN KEY (`device_id`) REFERENCES `devices` (`deviceID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_dc_last_record` FOREIGN KEY (`last_record_id`) REFERENCES `power_records` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_device_connectivity_mmg_id` FOREIGN KEY (`mmg_id`) REFERENCES `momoge_cus` (`mmgID`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_connectivity`
--

LOCK TABLES `device_connectivity` WRITE;
/*!40000 ALTER TABLE `device_connectivity` DISABLE KEYS */;
INSERT INTO `device_connectivity` VALUES
(1,4,NULL,'T310','/dev/ttyS1',9600,'none',8,1,1,2,0,2,4,10.0000,'ge/GE-TH-001',30,1,'2026-06-06 20:12:34',2632,1,NULL,'2026-06-06 20:12:34'),
(3,3,NULL,'T310','/dev/ttyS1',9600,'none',8,1,1,2,0,2,4,10.0000,NULL,30,1,'2026-06-06 20:35:20',2636,1,NULL,'2026-06-06 20:35:20'),
(7,5,NULL,'T310','/dev/ttyS1',9600,'none',8,1,1,2,0,2,4,10.0000,NULL,30,1,'2026-06-07 16:50:59',2640,1,NULL,'2026-06-07 16:50:59'),
(9,2,NULL,'T310','/dev/ttyS1',9600,'none',8,1,1,2,0,2,4,10.0000,NULL,30,1,'2026-06-06 20:26:58',2635,1,NULL,'2026-06-06 20:26:58');
/*!40000 ALTER TABLE `device_connectivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_notifications`
--

DROP TABLE IF EXISTS `device_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(11) DEFAULT NULL,
  `site` varchar(50) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `severity` varchar(50) DEFAULT 'info',
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` datetime(6) DEFAULT current_timestamp(6),
  `alarm_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `high_active_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `low_active_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `message_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `email_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `output_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_notifications_site` (`site`),
  KEY `fk_device_notifications_device` (`device_id`),
  CONSTRAINT `fk_device_notifications_device` FOREIGN KEY (`device_id`) REFERENCES `devices` (`deviceID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_notifications`
--

LOCK TABLES `device_notifications` WRITE;
/*!40000 ALTER TABLE `device_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `device_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `devices` (
  `deviceID` int(11) NOT NULL AUTO_INCREMENT,
  `deviceName` varchar(255) NOT NULL,
  `GEsaveID` varchar(255) DEFAULT NULL,
  `series_no` varchar(50) DEFAULT NULL,
  `ipAddress` varchar(45) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `site` varchar(20) DEFAULT 'thailand',
  `status` varchar(50) DEFAULT 'OK',
  `beforeMeterNo` varchar(255) DEFAULT '1',
  `metricsMeterNo` varchar(255) DEFAULT '2',
  `U_email` varchar(225) NOT NULL DEFAULT '',
  `P_email` varchar(225) NOT NULL DEFAULT '',
  `phone` varchar(225) NOT NULL DEFAULT '',
  `pass_phone` varchar(225) NOT NULL DEFAULT '',
  `created_at` datetime(6) DEFAULT current_timestamp(6),
  `updated_at` datetime(6) DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  `create_by` varchar(100) DEFAULT 'administrator',
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `customerName` varchar(255) DEFAULT NULL,
  `customerPhone` varchar(50) DEFAULT NULL,
  `customerAddress` text DEFAULT NULL,
  `client_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `record_scope` varchar(32) DEFAULT 'installed',
  PRIMARY KEY (`deviceID`),
  UNIQUE KEY `unique_geID` (`GEsaveID`),
  UNIQUE KEY `unique_GEsaveID` (`GEsaveID`),
  KEY `idx_devices_site` (`site`),
  KEY `idx_devices_customer_id` (`customer_id`),
  KEY `idx_devices_client_id` (`client_id`),
  CONSTRAINT `fk_devices_client` FOREIGN KEY (`client_id`) REFERENCES `Client` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_devices_eq_customer` FOREIGN KEY (`customer_id`) REFERENCES `eq_customers` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devices`
--

LOCK TABLES `devices` WRITE;
/*!40000 ALTER TABLE `devices` DISABLE KEYS */;
INSERT INTO `devices` VALUES
(1,'GE Smart Power Meter','GE-KR-0004','GE2024010001','192.168.1.46','KOREA','korea','ON','1','2','demo@ge-serverhub.com','demo@ge-serverhub.com','010-8105-0384','0000','2026-05-23 13:56:56.475955','2026-06-06 08:22:12.000000','administrator',NULL,NULL,'GE Energy','010-8105-0384',NULL,'cmo6viuen0003qhga32hwcu3n',NULL,'pre_install'),
(2,'GE Smart Power Meter','GE-KR-0003','GE2024010002','192.168.1.2','KOREA','korea','ON','1','2','demo@ge-serverhub.com','demo@ge-serverhub.com','010-8105-0384','0000','2026-05-23 13:56:56.475955','2026-06-06 08:21:38.891376','administrator',NULL,NULL,'Green Retail','010-8105-0384',NULL,'cmo6viuen0003qhga32hwcu3n',NULL,'installed'),
(3,'GE Smart Power Meter','GE-TH-0001','GE2024010007','192.168.1.3','Bangkok','thailand','OFF','1','2','demo@ge-serverhub.com','demo@ge-serverhub.com','02-555-1199','0000','2026-05-23 13:56:56.475955','2026-06-06 08:21:17.610008','administrator',NULL,NULL,'Thaimart','02-555-1199','','cmo6viuen0003qhga32hwcu3n',NULL,'installed'),
(4,'GE Smart Power Meter','GE-KR-0001',NULL,NULL,'Bangkok','korea','OK','1','2','no-reply@ge.local','no-reply@ge.local','-','-','2026-06-05 14:58:05.633198','2026-06-07 00:40:32.938919','administrator',NULL,NULL,'Homemart',NULL,NULL,'cmo6viuen0003qhga32hwcu3n',NULL,'installed'),
(5,'GE Smart Power Meter','GE-KR-0002','00000',NULL,'Korea','korea','inactive','1','2','no-reply@ge.local','no-reply@ge.local','-','-','2026-06-06 07:48:34.991175','2026-06-07 00:40:32.938919','administrator',0.00000000,0.00000000,'home mart','000','000','cmo6viuen0003qhga32hwcu3n',NULL,'installed');
/*!40000 ALTER TABLE `devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `energy_data`
--

DROP TABLE IF EXISTS `energy_data`;
/*!50001 DROP VIEW IF EXISTS `energy_data`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `energy_data` AS SELECT
 1 AS `id`,
  1 AS `device_id`,
  1 AS `timestamp`,
  1 AS `voltage_l1`,
  1 AS `voltage_l2`,
  1 AS `voltage_l3`,
  1 AS `current_l1`,
  1 AS `current_l2`,
  1 AS `current_l3`,
  1 AS `power_kw`,
  1 AS `energy_kwh`,
  1 AS `power_factor`,
  1 AS `frequency`,
  1 AS `thdi_l1`,
  1 AS `thdi_l2`,
  1 AS `thdi_l3`,
  1 AS `thdv_l1`,
  1 AS `thdv_l2`,
  1 AS `thdv_l3` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `eq_analysis_results`
--

DROP TABLE IF EXISTS `eq_analysis_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `eq_analysis_results` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT NULL,
  `report_id` int(11) NOT NULL,
  `device_id` int(11) NOT NULL,
  `total_energy` decimal(14,3) DEFAULT NULL,
  `average_load` decimal(10,2) DEFAULT NULL,
  `max_demand` decimal(10,2) DEFAULT NULL,
  `load_factor` decimal(8,2) DEFAULT NULL,
  `average_pf` decimal(6,3) DEFAULT NULL,
  `current_imbalance` decimal(8,2) DEFAULT NULL,
  `voltage_imbalance` decimal(8,2) DEFAULT NULL,
  `thdi_avg` decimal(8,3) DEFAULT NULL,
  `thdv_avg` decimal(8,3) DEFAULT NULL,
  `risk_level` varchar(20) DEFAULT 'good',
  `peak_demand` decimal(10,2) DEFAULT NULL,
  `peak_time` varchar(64) DEFAULT NULL,
  `peak_ratio` decimal(8,3) DEFAULT NULL,
  `monthly_cost_est` decimal(14,2) DEFAULT NULL,
  `penalty_cost_est` decimal(14,2) DEFAULT NULL,
  `potential_saving` decimal(14,2) DEFAULT NULL,
  `snapshot_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Full report sections for UI/print' CHECK (json_valid(`snapshot_json`)),
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_eq_analysis_report` (`report_id`),
  KEY `idx_eq_analysis_device` (`device_id`),
  KEY `fk_eq_analysis_site` (`site_id`),
  CONSTRAINT `fk_eq_analysis_device` FOREIGN KEY (`device_id`) REFERENCES `devices` (`deviceID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_eq_analysis_report` FOREIGN KEY (`report_id`) REFERENCES `eq_reports` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_eq_analysis_site` FOREIGN KEY (`site_id`) REFERENCES `eq_sites` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eq_analysis_results`
--

LOCK TABLES `eq_analysis_results` WRITE;
/*!40000 ALTER TABLE `eq_analysis_results` DISABLE KEYS */;
INSERT INTO `eq_analysis_results` VALUES
(1,3,1,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'warning',NULL,NULL,NULL,NULL,NULL,NULL,'{\"roi\": [{\"label\": \"권장 솔루션\", \"value\": \"GE Energy Tech Smart Power System\"}, {\"label\": \"투자 비용\", \"value\": \"8,000,000 원\"}, {\"label\": \"월 절감 가능액\", \"value\": \"732,876 원/월\"}, {\"label\": \"투자 회수 기간\", \"value\": \"10.9 개월 (0.9 년) · 우수\"}, {\"label\": \"ROI %\", \"value\": \"110%\"}], \"peak\": [{\"label\": \"15분 피크 수요\", \"value\": \"97.46 A\"}, {\"label\": \"피크 시간\", \"value\": \"24:27\"}, {\"label\": \"피크 시간대\", \"value\": \"00:00–01:00\"}, {\"label\": \"고부하 시간대\", \"value\": \"00:00–02:00, 04:00–05:00, 17:00–21:00, 22:00–24:00\"}, {\"label\": \"On-peak 평균\", \"value\": \"60.05 A\"}, {\"label\": \"Off-peak 평균\", \"value\": \"66.47 A\"}, {\"label\": \"평균 부하 (A)\", \"value\": \"62.99 A\"}, {\"label\": \"피크 / 평균\", \"value\": \"1.55\"}, {\"label\": \"수요 요금 영향\", \"value\": \"주의\"}], \"energy\": [{\"label\": \"총 에너지 (kWh)\", \"value\": \"12,151.44 kWh\"}, {\"label\": \"일평균 kWh\", \"value\": \"1,396.75 kWh\"}, {\"label\": \"월 예상 kWh\", \"value\": \"41,902.56 kWh\"}, {\"label\": \"연 예상 kWh\", \"value\": \"502,830.72 kWh\"}, {\"label\": \"월 예상 비용\", \"value\": \"6,285,384 원\"}], \"balance\": [{\"label\": \"L1 전류\", \"value\": \"98.63 A\"}, {\"label\": \"L2 전류\", \"value\": \"92.74 A\"}, {\"label\": \"L3 전류\", \"value\": \"86.56 A\"}, {\"label\": \"L1 전력 비율\", \"value\": \"35.5%\"}, {\"label\": \"L2 전력 비율\", \"value\": \"33.4%\"}, {\"label\": \"L3 전력 비율\", \"value\": \"31.1%\"}, {\"label\": \"전류 불균형 %\", \"value\": \"13.0%\"}, {\"label\": \"전압 불균형 %\", \"value\": \"—\"}], \"customer\": [{\"label\": \"리포트 ID\", \"value\": \"GE-EQ-3-20260605-001\"}, {\"label\": \"고객명\", \"value\": \"Thailand\"}, {\"label\": \"사이트명\", \"value\": \"GE-TH01\"}, {\"label\": \"위치\", \"value\": \"Bangkok\"}, {\"label\": \"업종\", \"value\": \"Manufacturing / Industrial\"}, {\"label\": \"담당자\", \"value\": \"02-555-1199\"}, {\"label\": \"측정 기간\", \"value\": \"2026. 6. 4. 오후 8:32:41 – 2026. 6. 5. 오후 8:27:41\"}, {\"label\": \"리포트 날짜\", \"value\": \"2026. 6. 5. 오후 4:07:10\"}, {\"label\": \"작성자\", \"value\": \"GE Energy Tech\"}], \"harmonic\": [{\"label\": \"THDI L1\", \"value\": \"10.32%\"}, {\"label\": \"THDI L2\", \"value\": \"10.32%\"}, {\"label\": \"THDI L3\", \"value\": \"10.32%\"}, {\"label\": \"THDI 평균\", \"value\": \"10.32%\"}, {\"label\": \"THDV L1\", \"value\": \"—\"}, {\"label\": \"THDV L2\", \"value\": \"—\"}, {\"label\": \"THDV L3\", \"value\": \"—\"}, {\"label\": \"THDV 평균\", \"value\": \"—\"}, {\"label\": \"고조파 위험 수준\", \"value\": \"주의\"}], \"reportId\": \"GE-EQ-3-20260605-001\", \"equipment\": [{\"label\": \"모터 / 컴프레서\", \"value\": \"주의\"}, {\"label\": \"메인 차단기 / 케이블\", \"value\": \"양호\"}, {\"label\": \"변압기\", \"value\": \"양호\"}, {\"label\": \"유지보수\", \"value\": \"불균형 > 20% 시 열화상 검사\"}], \"executive\": [{\"label\": \"총 에너지 (kWh)\", \"value\": \"12,151.44 kWh\"}, {\"label\": \"평균 부하 (A)\", \"value\": \"62.99 A (24시간 이력 기준)\"}, {\"label\": \"피크 수요 (A)\", \"value\": \"97.46 A (24시간 이력 기준)\"}, {\"label\": \"부하율\", \"value\": \"64.6%\"}, {\"label\": \"평균 역률\", \"value\": \"0.91\"}, {\"label\": \"전류 불균형 %\", \"value\": \"13.0%\"}, {\"label\": \"전압 불균형 %\", \"value\": \"—\"}, {\"label\": \"평균 THDI\", \"value\": \"10.32%\"}, {\"label\": \"평균 THDV\", \"value\": \"—\"}, {\"label\": \"종합 위험 수준\", \"value\": \"주의\"}], \"financial\": [{\"label\": \"월 예상 비용\", \"value\": \"6,285,384 원\"}, {\"label\": \"역률 패널티 (예상)\", \"value\": \"405,407 원\"}, {\"label\": \"월 절감 가능액\", \"value\": \"732,876 원\"}, {\"label\": \"연간 절감\", \"value\": \"8,794,509 원\"}], \"actionPlan\": [{\"items\": [\"상별 부하 확인\", \"피크 시간 프로필 검토\"], \"horizon\": \"즉시 (0–30일)\"}, {\"items\": [\"PF < 0.95 또는 피크/불균형 시 GE Energy Tech 설치\"], \"horizon\": \"단기 (1–3개월)\"}, {\"items\": [\"고조파 필터 평가\", \"수요 관리 계획\"], \"horizon\": \"중기 (3–12개월)\"}, {\"items\": [\"IoT 지속 모니터링\", \"연간 에너지 감사\"], \"horizon\": \"장기 (1–3년)\"}], \"conclusion\": [{\"label\": \"현재 문제\", \"value\": \"평균 역률: 0.91; 평균 THDI: 10.3%\"}, {\"label\": \"기술적 위험\", \"value\": \"주의\"}, {\"label\": \"재무 영향\", \"value\": \"6,285,384 원/월\"}, {\"label\": \"권장 솔루션\", \"value\": \"GE Energy Tech Smart Power 설치\"}, {\"label\": \"예상 절감액\", \"value\": \"732,876 원/월\"}, {\"label\": \"투자 회수 기간\", \"value\": \"10.9 개월 (0.9 년) · 우수\"}, {\"label\": \"다음 단계\", \"value\": \"고객과 검토 후 실행 계획 승인\"}], \"lastUpdate\": \"2026. 6. 5. 오후 8:27:41\", \"phaseTable\": [{\"ch1\": \"66.34\", \"ch2\": \"—\", \"phase\": \"L1\", \"analysis\": \"Phase L1 avg 66.34 — above overall N (62.99) by 5.3% · heaviest load among 3 phases\"}, {\"ch1\": \"63.82\", \"ch2\": \"—\", \"phase\": \"L2\", \"analysis\": \"Phase L2 avg 63.82 — above overall N (62.99) by 1.3%\"}, {\"ch1\": \"58.82\", \"ch2\": \"—\", \"phase\": \"L3\", \"analysis\": \"Phase L3 avg 58.82 — below overall N (62.99) by 6.6% · lightest load among 3 phases\"}, {\"ch1\": \"62.99\", \"ch2\": \"—\", \"phase\": \"평균 N\", \"analysis\": \"Overall N avg 62.99 — current imbalance 11.9% · highest L1 66.34 · lowest L3 58.82\"}], \"reportDate\": \"2026. 6. 5. 오후 4:07:10\", \"measurement\": [{\"label\": \"미터 ID\", \"value\": \"GE-TH01\"}, {\"label\": \"게이트웨이 ID\", \"value\": \"192.168.1.3\"}, {\"label\": \"측정 지점\", \"value\": \"GE-TH01 · CH1 (설치 전)\"}, {\"label\": \"전압 시스템\", \"value\": \"3상 400V\"}, {\"label\": \"데이터 해상도\", \"value\": \"실시간 / 1분\"}, {\"label\": \"총 기록 수\", \"value\": \"288\"}, {\"label\": \"측정 시작\", \"value\": \"2026. 6. 4. 오후 8:32:41\"}, {\"label\": \"측정 종료\", \"value\": \"2026. 6. 5. 오후 8:27:41\"}], \"overallRisk\": \"warning\", \"powerFactor\": [{\"label\": \"평균 역률\", \"value\": \"0.91\"}, {\"label\": \"최소 역률\", \"value\": \"0.91\"}, {\"label\": \"0.95 미만 시간\", \"value\": \"주의\"}, {\"label\": \"역률 패널티 (예상)\", \"value\": \"405,407 원\"}, {\"label\": \"APFC 권장\", \"value\": \"GE Energy Tech 시스템 권장 (전압·전류·안정화·저장)\"}], \"harmonicRisk\": \"caution\", \"professional\": {\"keyFindings\": [{\"measured\": \"41,903 kWh/mo · ~502,831 kWh/yr\", \"standard\": \"—\", \"parameter\": \"총 에너지 (kWh)\", \"assessment\": \"neutral\", \"assessmentLabel\": \"—\"}, {\"measured\": \"60.14 kW @ 24:27\", \"standard\": \"사이트 기준\", \"parameter\": \"15분 피크 수요\", \"assessment\": \"neutral\", \"assessmentLabel\": \"—\"}, {\"measured\": \"64.6%\", \"standard\": \"≥ 60% 권장\", \"parameter\": \"부하율\", \"assessment\": \"excellent\", \"assessmentLabel\": \"✓ 우수\"}, {\"measured\": \"0.907 (지상 (Lagging))\", \"standard\": \"≥ 0.95\", \"parameter\": \"평균 역률\", \"assessment\": \"caution\", \"assessmentLabel\": \"△ 주의\"}, {\"measured\": \"—\", \"standard\": \"< 2% IEC\", \"parameter\": \"전압 불균형 %\", \"assessment\": \"neutral\", \"assessmentLabel\": \"—\"}, {\"measured\": \"13.03%\", \"standard\": \"< 5% IEC\", \"parameter\": \"전류 불균형 %\", \"assessment\": \"caution\", \"assessmentLabel\": \"△ 주의\"}, {\"measured\": \"10.3%\", \"standard\": \"< 5% IEC 61000\", \"parameter\": \"평균 THDI\", \"assessment\": \"caution\", \"assessmentLabel\": \"△ 주의\"}, {\"measured\": \"—\", \"standard\": \"< 5% IEC\", \"parameter\": \"평균 THDV\", \"assessment\": \"neutral\", \"assessmentLabel\": \"—\"}], \"phasedTitle\": \"단계별 권장 사항\", \"reportSubtitle\": \"전력품질·에너지 효율 분석 · 2026. 6. 4. 오후 8:32:41 – 2026. 6. 5. 오후 8:27:41 · 288건 @ 실시간 / 1분\", \"peakPercentiles\": [{\"hint\": \"중앙값 — 시간의 50%가 이보다 낮음\", \"line\": \"P50  38.37 kW\", \"label\": \"P50\", \"value\": \"38.37 kW\"}, {\"hint\": \"보통보다 높음 — 25%의 시간이 이보다 높음\", \"line\": \"P75  56.71 kW\", \"label\": \"P75\", \"value\": \"56.71 kW\"}, {\"hint\": \"높은 부하 — 10%의 시간만 초과\", \"line\": \"P90  59.29 kW\", \"label\": \"P90\", \"value\": \"59.29 kW\"}, {\"hint\": \"매우 높음 — 5%의 시간만 초과\", \"line\": \"P95  59.76 kW\", \"label\": \"P95\", \"value\": \"59.76 kW\"}, {\"hint\": \"피크 근접 — 1%의 시간만 초과\", \"line\": \"P99  60.70 kW\", \"label\": \"P99\", \"value\": \"60.70 kW\"}], \"keyFindingsIntro\": \"핵심 결과 요약 — 종합 기술 위험: 주의 · 월 절감 예상 732,876\", \"recommendedModel\": \"75 kVA\", \"executiveNarrative\": [\"본 리포트는 2026. 6. 4. 오후 8:32:41 – 2026. 6. 5. 오후 8:27:41 기간 288건 (실시간 / 1분) 데이터로 전력품질·효율을 분석합니다\", \"평균 PF 0.907 — 0.0% 시간이 역률 패널티 기준(0.85) 미만 · 평균 THDI 10.3% — de-tuned APFC 적합\", \"평균 전류 불균형 13.03% — IEC 기준 초과 · L1 부하 35.1% (이상 33.3% 초과)\", \"15분 피크 수요 60.14 kW (24:27) — 평균 대비 ~1.5배 · 1분 데이터와 hourly 차이 ~38%\"], \"imbalanceExceedance\": [{\"pct\": \"76.4%\", \"liveLevel\": \"warning\", \"threshold\": \"> 10% (경고)\", \"liveStatus\": \"주의\", \"liveImbDisplay\": \"13.0%\"}, {\"pct\": \"6.3%\", \"liveLevel\": \"good\", \"threshold\": \"> 20% (고위험)\", \"liveStatus\": \"✓ 정상\", \"liveImbDisplay\": \"13.0%\"}, {\"pct\": \"0.0%\", \"liveLevel\": \"good\", \"threshold\": \"> 50% (심각)\", \"liveStatus\": \"✓ 정상\", \"liveImbDisplay\": \"13.0%\"}], \"interpretationTitle\": \"해석\", \"loadProfileNarrative\": \"부하 프로필 고부하 구간: 00:00–02:00, 04:00–05:00, 17:00–21:00, 22:00–24:00 — 청구 피크에서 중부하 이동 권장\", \"overallTechnicalRisk\": \"주의\", \"interpretationBullets\": [\"전류 불균형 13.03% — L1 점유 35.1% · 부하 재분배로 열 스트레스 감소\", \"PF 0.907, 연간 ~502,831 kWh 규모 — PF ≥ 0.95 개선 시 회수 10.9 개월 (0.9 년) · 우수\", \"THDI 10.3% — de-tuned APFC (5.7% 리액터) 설치 안전, 공진 위험 없음\"], \"peakPercentileCaption\": \"피크 수요 통계 (백분위)\", \"phasedRecommendations\": [{\"phase\": \"1단계\", \"title\": \"De-tuned APFC 설치 — ROI 최고\", \"bullets\": [\"THDI 10.3% — 5.7% de-tuning 리액터 APFC 안전 설치\", \"피크 60.14 kW 기준 용량 · L1 평균 전류 62.99 A\"], \"priority\": \"최우선\", \"expectedOutcome\": \"PF 0.907 → ≥ 0.95 · 역률 패널티 제거 · 회수 10.9 개월 (0.9 년) · 우수\"}, {\"phase\": \"2단계\", \"title\": \"3상 부하 재분배\", \"bullets\": [\"L1 회로 1–2개 L3로 이동 — L1 ≤ 35%, L3 ≥ 32% 목표\", \"컴프레서 사이클 시 과도 불균형 감소\"], \"priority\": \"높은 우선순위\", \"expectedOutcome\": \"CI 13.03% → < 10% · 모터·도체 열 스트레스 감소\"}, {\"phase\": \"3단계\", \"title\": \"피크 수요 관리\", \"bullets\": [\"피크 60.14 kW (24:27) — 수요요금 청구 기준\", \"서비스 전 pre-cool · 주방 설비 2–3분 간격 기동\"], \"priority\": \"높은 우선순위\", \"expectedOutcome\": \"피크 ~15–20% 감소 · 수요요금 절감\"}, {\"phase\": \"4단계\", \"title\": \"연간 점검 및 알람\", \"bullets\": [\"메인 패널 L1 연결부 연간 열화상 검사\", \"알람 설정: PF < 0.85 · CI > 15%\"], \"priority\": \"중간 우선순위\", \"expectedOutcome\": \"지속 과부하·불균형으로 인한 손상 예방\"}], \"imbalanceExceedanceCaption\": \"전류 불균형 임계값 초과 시간 비율\"}, \"executiveKpis\": [{\"label\": \"총 에너지 (kWh)\", \"value\": \"12,151.44 kWh\"}, {\"label\": \"평균 부하 (A)\", \"value\": \"62.99 A (24시간 이력 기준)\"}, {\"label\": \"피크 수요 (A)\", \"value\": \"97.46 A (24시간 이력 기준)\"}, {\"label\": \"종합 위험 수준\", \"value\": \"주의\"}], \"statusMetrics\": {\"pf\": 0.907, \"thd\": 10.321, \"currentImbalance\": 13.028460403698766, \"voltageImbalance\": null}, \"recommendations\": [{\"title\": \"GE Energy Tech Smart Power 설치\", \"priority\": 1, \"description\": \"설치 전 비교 — 전압 조정, 3상 전류 조정, 안정화·고조파 제어, 피크/비피크 전력 저장\"}, {\"title\": \"피크 수요 관리\", \"priority\": 2, \"description\": \"00:00–01:00 피크 — 부하 이동 검토.\"}, {\"title\": \"지속 모니터링\", \"priority\": 3, \"description\": \"GE IoT 실시간 모니터링으로 추세 검증.\"}], \"executiveBullets\": [\"미터 누적 에너지 12,151.44 kWh\", \"CH1 평균 전류: 62.99 A (24시간 이력 기준)\", \"최대 피크 수요: 97.46 A @ 24:27 · 00:00–01:00 (24시간 이력 기준)\", \"부하율: 64.6%\", \"평균 역률: 0.91\", \"전류 불균형: 13.0%\", \"종합 위험 수준: 주의\", \"GE Energy Tech: 전압 조정 · 전류 조정 · 안정화 · 전력 저장 후 사용\"], \"overallRiskLabel\": \"주의\", \"harmonicRiskLabel\": \"주의\"}','2026-06-05 18:07:11.444931'),
(2,3,2,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'warning',NULL,NULL,NULL,NULL,NULL,NULL,'{\"reportId\":\"GE-EQ-3-20260605-002\",\"reportDate\":\"2026. 6. 5. 오후 8:19:28\",\"lastUpdate\":\"2026. 6. 5. 오후 8:27:41\",\"overallRisk\":\"warning\",\"overallRiskLabel\":\"주의\",\"harmonicRisk\":\"caution\",\"harmonicRiskLabel\":\"주의\",\"statusMetrics\":{\"pf\":0.907,\"thd\":10.321,\"currentImbalance\":13.028460403698766,\"voltageImbalance\":0.44514096130442055},\"customer\":[{\"label\":\"리포트 ID\",\"value\":\"GE-EQ-3-20260605-002\"},{\"label\":\"고객명\",\"value\":\"Thailand\"},{\"label\":\"사이트명\",\"value\":\"GE-TH01\"},{\"label\":\"위치\",\"value\":\"Bangkok\"},{\"label\":\"업종\",\"value\":\"Manufacturing / Industrial\"},{\"label\":\"담당자\",\"value\":\"02-555-1199\"},{\"label\":\"측정 기간\",\"value\":\"2026. 6. 4. 오후 8:32:41 – 2026. 6. 5. 오후 8:27:41\"},{\"label\":\"리포트 날짜\",\"value\":\"2026. 6. 5. 오후 8:19:28\"},{\"label\":\"작성자\",\"value\":\"GE Energy Tech\"}],\"measurement\":[{\"label\":\"미터 ID\",\"value\":\"GE-TH01\"},{\"label\":\"게이트웨이 ID\",\"value\":\"192.168.1.3\"},{\"label\":\"측정 지점\",\"value\":\"GE-TH01 · CH1 (설치 전)\"},{\"label\":\"전압 시스템\",\"value\":\"3상 400V\"},{\"label\":\"차단기 용량\",\"value\":\"125 A\"},{\"label\":\"권장 설치 용량\",\"value\":\"70 kVA\"},{\"label\":\"데이터 해상도\",\"value\":\"실시간 / 1분\"},{\"label\":\"총 기록 수\",\"value\":\"288\"},{\"label\":\"측정 시작\",\"value\":\"2026. 6. 4. 오후 8:32:41\"},{\"label\":\"측정 종료\",\"value\":\"2026. 6. 5. 오후 8:27:41\"}],\"executive\":[{\"label\":\"총 에너지 (kWh)\",\"value\":\"12,151.44 kWh\"},{\"label\":\"평균 부하 (A)\",\"value\":\"92.64 A\"},{\"label\":\"피크 수요 (A)\",\"value\":\"97.46 A\"},{\"label\":\"부하율\",\"value\":\"64.6%\"},{\"label\":\"평균 역률\",\"value\":\"0.91\"},{\"label\":\"전류 불균형 %\",\"value\":\"13.0%\"},{\"label\":\"전압 불균형 %\",\"value\":\"0.4%\"},{\"label\":\"평균 THDI\",\"value\":\"10.32%\"},{\"label\":\"평균 THDV\",\"value\":\"—\"},{\"label\":\"종합 위험 수준\",\"value\":\"주의\"}],\"executiveBullets\":[\"미터 누적 에너지 12,151.44 kWh\",\"CH1 평균 전류: 92.64 A\",\"최대 피크 수요: 97.46 A @ 24:27 · 00:00–01:00\",\"부하율: 64.6%\",\"평균 역률: 0.91\",\"전류 불균형: 13.0%\",\"종합 위험 수준: 주의\",\"GE Energy Tech: 전압 조정 · 전류 조정 · 안정화 · 전력 저장 후 사용\"],\"executiveKpis\":[{\"label\":\"총 에너지 (kWh)\",\"value\":\"12,151.44 kWh\"},{\"label\":\"평균 부하 (A)\",\"value\":\"92.64 A\"},{\"label\":\"피크 수요 (A)\",\"value\":\"97.46 A\"},{\"label\":\"종합 위험 수준\",\"value\":\"주의\"}],\"energy\":[{\"label\":\"총 에너지 (kWh)\",\"value\":\"12,151.44 kWh\"},{\"label\":\"일평균 kWh\",\"value\":\"1,396.75 kWh\"},{\"label\":\"월 예상 kWh\",\"value\":\"41,902.56 kWh\"},{\"label\":\"연 예상 kWh\",\"value\":\"502,830.72 kWh\"},{\"label\":\"월 예상 비용\",\"value\":\"6,285,384 원\"}],\"peak\":[{\"label\":\"15분 피크 수요\",\"value\":\"97.46 A\"},{\"label\":\"피크 시간\",\"value\":\"24:27\"},{\"label\":\"피크 시간대\",\"value\":\"00:00–01:00\"},{\"label\":\"고부하 시간대\",\"value\":\"00:00–02:00, 04:00–05:00, 17:00–21:00, 22:00–24:00\"},{\"label\":\"On-peak 평균\",\"value\":\"60.05 A\"},{\"label\":\"Off-peak 평균\",\"value\":\"66.47 A\"},{\"label\":\"평균 부하 (A)\",\"value\":\"92.64 A\"},{\"label\":\"피크 / 평균\",\"value\":\"1.05\"},{\"label\":\"수요 요금 영향\",\"value\":\"양호\"}],\"powerFactor\":[{\"label\":\"평균 역률\",\"value\":\"0.91\"},{\"label\":\"최소 역률\",\"value\":\"0.91\"},{\"label\":\"0.95 미만 시간\",\"value\":\"주의\"},{\"label\":\"역률 패널티 (예상)\",\"value\":\"405,407 원\"},{\"label\":\"APFC 권장\",\"value\":\"GE Energy Tech 시스템 권장 (전압·전류·안정화·저장)\"}],\"balance\":[{\"label\":\"L1 전류\",\"value\":\"98.63 A\"},{\"label\":\"L2 전류\",\"value\":\"92.74 A\"},{\"label\":\"L3 전류\",\"value\":\"86.56 A\"},{\"label\":\"L1 전력 비율\",\"value\":\"35.5%\"},{\"label\":\"L2 전력 비율\",\"value\":\"33.4%\"},{\"label\":\"L3 전력 비율\",\"value\":\"31.1%\"},{\"label\":\"전류 불균형 %\",\"value\":\"13.0%\"},{\"label\":\"전압 불균형 %\",\"value\":\"0.4%\"}],\"harmonic\":[{\"label\":\"THDI L1\",\"value\":\"10.32%\"},{\"label\":\"THDI L2\",\"value\":\"10.32%\"},{\"label\":\"THDI L3\",\"value\":\"10.32%\"},{\"label\":\"THDI 평균\",\"value\":\"10.32%\"},{\"label\":\"THDV L1\",\"value\":\"—\"},{\"label\":\"THDV L2\",\"value\":\"—\"},{\"label\":\"THDV L3\",\"value\":\"—\"},{\"label\":\"THDV 평균\",\"value\":\"—\"},{\"label\":\"고조파 위험 수준\",\"value\":\"주의\"}],\"equipment\":[{\"label\":\"모터 / 컴프레서\",\"value\":\"주의\"},{\"label\":\"메인 차단기 / 케이블\",\"value\":\"양호\"},{\"label\":\"변압기\",\"value\":\"양호\"},{\"label\":\"유지보수\",\"value\":\"불균형 > 20% 시 열화상 검사\"}],\"financial\":[{\"label\":\"월 예상 비용\",\"value\":\"6,285,384 원\"},{\"label\":\"역률 패널티 (예상)\",\"value\":\"405,407 원\"},{\"label\":\"월 절감 가능액\",\"value\":\"512,887 원\"},{\"label\":\"연간 절감\",\"value\":\"6,154,648 원\"}],\"roi\":[{\"label\":\"권장 솔루션\",\"value\":\"GE Energy Tech Smart Power System\"},{\"label\":\"투자 비용\",\"value\":\"8,000,000 원\"},{\"label\":\"월 절감 가능액\",\"value\":\"512,887 원/월\"},{\"label\":\"투자 회수 기간\",\"value\":\"15.6 개월 (1.3 년) · 우수\"},{\"label\":\"ROI %\",\"value\":\"77%\"}],\"recommendations\":[{\"priority\":1,\"title\":\"GE Energy Tech Smart Power 설치\",\"description\":\"설치 전 비교 — 전압 조정, 3상 전류 조정, 안정화·고조파 제어, 피크/비피크 전력 저장\"},{\"priority\":2,\"title\":\"지속 모니터링\",\"description\":\"GE IoT 실시간 모니터링으로 추세 검증.\"}],\"actionPlan\":[{\"horizon\":\"즉시 (0–30일)\",\"items\":[\"상별 부하 확인\"]},{\"horizon\":\"단기 (1–3개월)\",\"items\":[\"PF < 0.95 또는 피크/불균형 시 GE Energy Tech 설치\"]},{\"horizon\":\"중기 (3–12개월)\",\"items\":[\"고조파 필터 평가\"]},{\"horizon\":\"장기 (1–3년)\",\"items\":[\"IoT 지속 모니터링\",\"연간 에너지 감사\"]}],\"conclusion\":[{\"label\":\"현재 문제\",\"value\":\"평균 역률: 0.91; 평균 THDI: 10.3%\"},{\"label\":\"기술적 위험\",\"value\":\"주의\"},{\"label\":\"재무 영향\",\"value\":\"6,285,384 원/월\"},{\"label\":\"권장 솔루션\",\"value\":\"GE Energy Tech Smart Power 설치\"},{\"label\":\"예상 절감액\",\"value\":\"512,887 원/월\"},{\"label\":\"투자 회수 기간\",\"value\":\"15.6 개월 (1.3 년) · 우수\"},{\"label\":\"다음 단계\",\"value\":\"고객과 검토 후 실행 계획 승인\"}],\"phaseTable\":[{\"phase\":\"L1\",\"ch1\":\"66.34\",\"ch2\":\"—\",\"analysis\":\"L1 상 평균 66.34 — 전체 N 평균 (62.99) 대비 5.3% 높음 · 3상 중 부하 최대\"},{\"phase\":\"L2\",\"ch1\":\"63.82\",\"ch2\":\"—\",\"analysis\":\"L2 상 평균 63.82 — 전체 N 평균 (62.99) 대비 1.3% 높음\"},{\"phase\":\"L3\",\"ch1\":\"58.82\",\"ch2\":\"—\",\"analysis\":\"L3 상 평균 58.82 — 전체 N 평균 (62.99) 대비 6.6% 낮음 · 3상 중 부하 최소\"},{\"phase\":\"평균 N\",\"ch1\":\"62.99\",\"ch2\":\"—\",\"analysis\":\"전체 N 평균 62.99 — 전류 불균형 11.9% · 최대 L1 66.34 · 최소 L3 58.82\"}],\"professional\":{\"reportSubtitle\":\"전력품질·에너지 효율 분석 · 2026. 6. 4. 오후 8:32:41 – 2026. 6. 5. 오후 8:27:41 · 288건 @ 실시간 / 1분\",\"keyFindingsIntro\":\"핵심 결과 요약 — 종합 기술 위험: 주의 · 월 절감 예상 512,887\",\"keyFindings\":[{\"parameter\":\"총 에너지 (kWh)\",\"measured\":\"41,903 kWh/mo · ~502,831 kWh/yr\",\"standard\":\"—\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"},{\"parameter\":\"15분 피크 수요\",\"measured\":\"60.14 kW @ 24:27\",\"standard\":\"사이트 기준\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"},{\"parameter\":\"부하율\",\"measured\":\"64.6%\",\"standard\":\"≥ 60% 권장\",\"assessment\":\"excellent\",\"assessmentLabel\":\"✓ 우수\"},{\"parameter\":\"평균 역률\",\"measured\":\"0.907 (지상 (Lagging))\",\"standard\":\"≥ 0.95\",\"assessment\":\"caution\",\"assessmentLabel\":\"△ 주의\"},{\"parameter\":\"전압 불균형 %\",\"measured\":\"0.45%\",\"standard\":\"< 2% IEC\",\"assessment\":\"excellent\",\"assessmentLabel\":\"✓ 우수\"},{\"parameter\":\"전류 불균형 %\",\"measured\":\"13.03%\",\"standard\":\"< 5% IEC\",\"assessment\":\"caution\",\"assessmentLabel\":\"△ 주의\"},{\"parameter\":\"평균 THDI\",\"measured\":\"10.3%\",\"standard\":\"< 5% IEC 61000\",\"assessment\":\"caution\",\"assessmentLabel\":\"△ 주의\"},{\"parameter\":\"평균 THDV\",\"measured\":\"—\",\"standard\":\"< 5% IEC\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"}],\"executiveNarrative\":[\"본 리포트는 2026. 6. 4. 오후 8:32:41 – 2026. 6. 5. 오후 8:27:41 기간 288건 (실시간 / 1분) 데이터로 전력품질·효율을 분석합니다\",\"평균 PF 0.907 — 0.0% 시간이 역률 패널티 기준(0.85) 미만 · 평균 THDI 10.3% — de-tuned APFC 적합\",\"평균 전류 불균형 13.03% — IEC 기준 초과 · L1 부하 35.1% (이상 33.3% 초과)\",\"15분 피크 수요 60.14 kW (24:27) — 평균 대비 ~1.5배 · 1분 데이터와 hourly 차이 ~38%\"],\"interpretationTitle\":\"해석\",\"interpretationBullets\":[\"전류 불균형 13.03% — L1 점유 35.1% · 부하 재분배로 열 스트레스 감소\",\"PF 0.907, 연간 ~502,831 kWh 규모 — PF ≥ 0.95 개선 시 회수 15.6 개월 (1.3 년) · 우수\",\"THDI 10.3% — de-tuned APFC (5.7% 리액터) 설치 안전, 공진 위험 없음\",\"전압 불균형 0.45% — 계통측 품질 양호, 부하·수요 관리에 집중\"],\"phasedTitle\":\"단계별 권장 사항\",\"phasedRecommendations\":[{\"phase\":\"1단계\",\"title\":\"De-tuned APFC 설치 — ROI 최고\",\"priority\":\"최우선\",\"bullets\":[\"THDI 10.3% — 5.7% de-tuning 리액터 APFC 안전 설치\",\"피크 60.14 kW 기준 용량 · L1 평균 전류 62.99 A\"],\"expectedOutcome\":\"PF 0.907 → ≥ 0.95 · 역률 패널티 제거 · 회수 15.6 개월 (1.3 년) · 우수\"},{\"phase\":\"2단계\",\"title\":\"3상 부하 재분배\",\"priority\":\"높은 우선순위\",\"bullets\":[\"L1 회로 1–2개 L3로 이동 — L1 ≤ 35%, L3 ≥ 32% 목표\",\"컴프레서 사이클 시 과도 불균형 감소\"],\"expectedOutcome\":\"CI 13.03% → < 10% · 모터·도체 열 스트레스 감소\"},{\"phase\":\"3단계\",\"title\":\"피크 수요 관리\",\"priority\":\"높은 우선순위\",\"bullets\":[\"피크 60.14 kW (24:27) — 수요요금 청구 기준\",\"서비스 전 pre-cool · 주방 설비 2–3분 간격 기동\"],\"expectedOutcome\":\"피크 ~15–20% 감소 · 수요요금 절감\"},{\"phase\":\"4단계\",\"title\":\"연간 점검 및 알람\",\"priority\":\"중간 우선순위\",\"bullets\":[\"메인 패널 L1 연결부 연간 열화상 검사\",\"알람 설정: PF < 0.85 · CI > 15%\"],\"expectedOutcome\":\"지속 과부하·불균형으로 인한 손상 예방\"}],\"peakPercentiles\":[{\"label\":\"P50\",\"value\":\"38.37 kW\",\"line\":\"P50  38.37 kW\",\"hint\":\"중앙값 — 시간의 50%가 이보다 낮음\"},{\"label\":\"P75\",\"value\":\"56.71 kW\",\"line\":\"P75  56.71 kW\",\"hint\":\"보통보다 높음 — 25%의 시간이 이보다 높음\"},{\"label\":\"P90\",\"value\":\"59.29 kW\",\"line\":\"P90  59.29 kW\",\"hint\":\"높은 부하 — 10%의 시간만 초과\"},{\"label\":\"P95\",\"value\":\"59.76 kW\",\"line\":\"P95  59.76 kW\",\"hint\":\"매우 높음 — 5%의 시간만 초과\"},{\"label\":\"P99\",\"value\":\"60.70 kW\",\"line\":\"P99  60.70 kW\",\"hint\":\"피크 근접 — 1%의 시간만 초과\"}],\"peakPercentileCaption\":\"피크 수요 통계 (백분위)\",\"imbalanceExceedance\":[{\"threshold\":\"> 10% (경고)\",\"pct\":\"76.4%\",\"liveStatus\":\"주의\",\"liveLevel\":\"warning\",\"liveImbDisplay\":\"13.0%\"},{\"threshold\":\"> 20% (고위험)\",\"pct\":\"6.3%\",\"liveStatus\":\"✓ 정상\",\"liveLevel\":\"good\",\"liveImbDisplay\":\"13.0%\"},{\"threshold\":\"> 50% (심각)\",\"pct\":\"0.0%\",\"liveStatus\":\"✓ 정상\",\"liveLevel\":\"good\",\"liveImbDisplay\":\"13.0%\"}],\"imbalanceExceedanceCaption\":\"전류 불균형 임계값 초과 시간 비율\",\"loadProfileNarrative\":\"부하 프로필 고부하 구간: 00:00–02:00, 04:00–05:00, 17:00–21:00, 22:00–24:00 — 청구 피크에서 중부하 이동 권장\",\"overallTechnicalRisk\":\"주의\",\"recommendedModel\":\"75 kVA\"}}','2026-06-05 22:19:29.673169'),
(3,3,3,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'warning',NULL,NULL,NULL,NULL,NULL,NULL,'{\"reportId\":\"GE-EQ-3-20260605-003\",\"reportDate\":\"2026. 6. 5. 오후 8:24:54\",\"lastUpdate\":\"2026. 6. 5. 오후 8:27:41\",\"overallRisk\":\"warning\",\"overallRiskLabel\":\"주의\",\"harmonicRisk\":\"caution\",\"harmonicRiskLabel\":\"주의\",\"statusMetrics\":{\"pf\":0.907,\"thd\":10.321,\"currentImbalance\":13.028460403698766,\"voltageImbalance\":0.44514096130442055},\"customer\":[{\"label\":\"리포트 ID\",\"value\":\"GE-EQ-3-20260605-003\"},{\"label\":\"고객명\",\"value\":\"Thailand\"},{\"label\":\"사이트명\",\"value\":\"GE-TH01\"},{\"label\":\"위치\",\"value\":\"Bangkok\"},{\"label\":\"업종\",\"value\":\"Manufacturing / Industrial\"},{\"label\":\"담당자\",\"value\":\"02-555-1199\"},{\"label\":\"측정 기간\",\"value\":\"2026. 6. 4. 오후 8:32:41 – 2026. 6. 5. 오후 8:27:41\"},{\"label\":\"리포트 날짜\",\"value\":\"2026. 6. 5. 오후 8:24:54\"},{\"label\":\"작성자\",\"value\":\"GE Energy Tech\"}],\"measurement\":[{\"label\":\"미터 ID\",\"value\":\"GE-TH01\"},{\"label\":\"게이트웨이 ID\",\"value\":\"192.168.1.3\"},{\"label\":\"측정 지점\",\"value\":\"GE-TH01 · CH1 (설치 전)\"},{\"label\":\"전압 시스템\",\"value\":\"3상 400V\"},{\"label\":\"차단기 용량\",\"value\":\"125 A\"},{\"label\":\"권장 설치 용량\",\"value\":\"70 kVA\"},{\"label\":\"데이터 해상도\",\"value\":\"실시간 / 1분\"},{\"label\":\"총 기록 수\",\"value\":\"288\"},{\"label\":\"측정 시작\",\"value\":\"2026. 6. 4. 오후 8:32:41\"},{\"label\":\"측정 종료\",\"value\":\"2026. 6. 5. 오후 8:27:41\"}],\"executive\":[{\"label\":\"총 에너지 (kWh)\",\"value\":\"12,151.44 kWh\"},{\"label\":\"평균 부하 (A)\",\"value\":\"92.64 A\"},{\"label\":\"피크 수요 (A)\",\"value\":\"97.46 A\"},{\"label\":\"부하율\",\"value\":\"64.6%\"},{\"label\":\"평균 역률\",\"value\":\"0.91\"},{\"label\":\"전류 불균형 %\",\"value\":\"13.0%\"},{\"label\":\"전압 불균형 %\",\"value\":\"0.4%\"},{\"label\":\"평균 THDI\",\"value\":\"10.32%\"},{\"label\":\"평균 THDV\",\"value\":\"—\"},{\"label\":\"종합 위험 수준\",\"value\":\"주의\"}],\"executiveBullets\":[\"미터 누적 에너지 12,151.44 kWh\",\"CH1 평균 전류: 92.64 A\",\"최대 피크 수요: 97.46 A @ 24:27 · 00:00–01:00\",\"부하율: 64.6%\",\"평균 역률: 0.91\",\"전류 불균형: 13.0%\",\"종합 위험 수준: 주의\",\"GE Energy Tech: 전압 조정 · 전류 조정 · 안정화 · 전력 저장 후 사용\"],\"executiveKpis\":[{\"label\":\"총 에너지 (kWh)\",\"value\":\"12,151.44 kWh\"},{\"label\":\"평균 부하 (A)\",\"value\":\"92.64 A\"},{\"label\":\"피크 수요 (A)\",\"value\":\"97.46 A\"},{\"label\":\"종합 위험 수준\",\"value\":\"주의\"}],\"energy\":[{\"label\":\"총 에너지 (kWh)\",\"value\":\"12,151.44 kWh\"},{\"label\":\"일평균 kWh\",\"value\":\"1,396.75 kWh\"},{\"label\":\"월 예상 kWh\",\"value\":\"41,902.56 kWh\"},{\"label\":\"연 예상 kWh\",\"value\":\"502,830.72 kWh\"},{\"label\":\"월 예상 비용\",\"value\":\"6,285,384 원\"}],\"peak\":[{\"label\":\"15분 피크 수요\",\"value\":\"97.46 A\"},{\"label\":\"피크 시간\",\"value\":\"24:27\"},{\"label\":\"피크 시간대\",\"value\":\"00:00–01:00\"},{\"label\":\"고부하 시간대\",\"value\":\"00:00–02:00, 04:00–05:00, 17:00–21:00, 22:00–24:00\"},{\"label\":\"On-peak 평균\",\"value\":\"60.05 A\"},{\"label\":\"Off-peak 평균\",\"value\":\"66.47 A\"},{\"label\":\"평균 부하 (A)\",\"value\":\"92.64 A\"},{\"label\":\"피크 / 평균\",\"value\":\"1.05\"},{\"label\":\"수요 요금 영향\",\"value\":\"양호\"}],\"powerFactor\":[{\"label\":\"평균 역률\",\"value\":\"0.91\"},{\"label\":\"최소 역률\",\"value\":\"0.91\"},{\"label\":\"0.95 미만 시간\",\"value\":\"주의\"},{\"label\":\"역률 패널티 (예상)\",\"value\":\"405,407 원\"},{\"label\":\"APFC 권장\",\"value\":\"GE Energy Tech 시스템 권장 (전압·전류·안정화·저장)\"}],\"balance\":[{\"label\":\"L1 전류\",\"value\":\"98.63 A\"},{\"label\":\"L2 전류\",\"value\":\"92.74 A\"},{\"label\":\"L3 전류\",\"value\":\"86.56 A\"},{\"label\":\"L1 전력 비율\",\"value\":\"35.5%\"},{\"label\":\"L2 전력 비율\",\"value\":\"33.4%\"},{\"label\":\"L3 전력 비율\",\"value\":\"31.1%\"},{\"label\":\"전류 불균형 %\",\"value\":\"13.0%\"},{\"label\":\"전압 불균형 %\",\"value\":\"0.4%\"}],\"harmonic\":[{\"label\":\"THDI L1\",\"value\":\"10.32%\"},{\"label\":\"THDI L2\",\"value\":\"10.32%\"},{\"label\":\"THDI L3\",\"value\":\"10.32%\"},{\"label\":\"THDI 평균\",\"value\":\"10.32%\"},{\"label\":\"THDV L1\",\"value\":\"—\"},{\"label\":\"THDV L2\",\"value\":\"—\"},{\"label\":\"THDV L3\",\"value\":\"—\"},{\"label\":\"THDV 평균\",\"value\":\"—\"},{\"label\":\"고조파 위험 수준\",\"value\":\"주의\"}],\"equipment\":[{\"label\":\"모터 / 컴프레서\",\"value\":\"주의\"},{\"label\":\"메인 차단기 / 케이블\",\"value\":\"양호\"},{\"label\":\"변압기\",\"value\":\"양호\"},{\"label\":\"유지보수\",\"value\":\"불균형 > 20% 시 열화상 검사\"}],\"financial\":[{\"label\":\"월 예상 비용\",\"value\":\"6,285,384 원\"},{\"label\":\"역률 패널티 (예상)\",\"value\":\"405,407 원\"},{\"label\":\"월 절감 가능액\",\"value\":\"512,887 원\"},{\"label\":\"연간 절감\",\"value\":\"6,154,648 원\"}],\"roi\":[{\"label\":\"권장 솔루션\",\"value\":\"GE Energy Tech Smart Power System\"},{\"label\":\"투자 비용\",\"value\":\"8,000,000 원\"},{\"label\":\"월 절감 가능액\",\"value\":\"512,887 원/월\"},{\"label\":\"투자 회수 기간\",\"value\":\"15.6 개월 (1.3 년) · 우수\"},{\"label\":\"ROI %\",\"value\":\"77%\"}],\"recommendations\":[{\"priority\":1,\"title\":\"GE Energy Tech Smart Power 설치\",\"description\":\"설치 전 비교 — 전압 조정, 3상 전류 조정, 안정화·고조파 제어, 피크/비피크 전력 저장\"},{\"priority\":2,\"title\":\"지속 모니터링\",\"description\":\"GE IoT 실시간 모니터링으로 추세 검증.\"}],\"actionPlan\":[{\"horizon\":\"즉시 (0–30일)\",\"items\":[\"상별 부하 확인\"]},{\"horizon\":\"단기 (1–3개월)\",\"items\":[\"PF < 0.95 또는 피크/불균형 시 GE Energy Tech 설치\"]},{\"horizon\":\"중기 (3–12개월)\",\"items\":[\"고조파 필터 평가\"]},{\"horizon\":\"장기 (1–3년)\",\"items\":[\"IoT 지속 모니터링\",\"연간 에너지 감사\"]}],\"conclusion\":[{\"label\":\"현재 문제\",\"value\":\"평균 역률: 0.91; 평균 THDI: 10.3%\"},{\"label\":\"기술적 위험\",\"value\":\"주의\"},{\"label\":\"재무 영향\",\"value\":\"6,285,384 원/월\"},{\"label\":\"권장 솔루션\",\"value\":\"GE Energy Tech Smart Power 설치\"},{\"label\":\"예상 절감액\",\"value\":\"512,887 원/월\"},{\"label\":\"투자 회수 기간\",\"value\":\"15.6 개월 (1.3 년) · 우수\"},{\"label\":\"다음 단계\",\"value\":\"고객과 검토 후 실행 계획 승인\"}],\"phaseTable\":[{\"phase\":\"L1\",\"ch1\":\"66.34\",\"ch2\":\"—\",\"analysis\":\"L1 상 평균 66.34 — 전체 N 평균 (62.99) 대비 5.3% 높음 · 3상 중 부하 최대\"},{\"phase\":\"L2\",\"ch1\":\"63.82\",\"ch2\":\"—\",\"analysis\":\"L2 상 평균 63.82 — 전체 N 평균 (62.99) 대비 1.3% 높음\"},{\"phase\":\"L3\",\"ch1\":\"58.82\",\"ch2\":\"—\",\"analysis\":\"L3 상 평균 58.82 — 전체 N 평균 (62.99) 대비 6.6% 낮음 · 3상 중 부하 최소\"},{\"phase\":\"평균 N\",\"ch1\":\"62.99\",\"ch2\":\"—\",\"analysis\":\"전체 N 평균 62.99 — 전류 불균형 11.9% · 최대 L1 66.34 · 최소 L3 58.82\"}],\"professional\":{\"reportSubtitle\":\"전력품질·에너지 효율 분석 · 2026. 6. 4. 오후 8:32:41 – 2026. 6. 5. 오후 8:27:41 · 288건 @ 실시간 / 1분\",\"keyFindingsIntro\":\"핵심 결과 요약 — 종합 기술 위험: 주의 · 월 절감 예상 512,887\",\"keyFindings\":[{\"parameter\":\"총 에너지 (kWh)\",\"measured\":\"41,903 kWh/mo · ~502,831 kWh/yr\",\"standard\":\"—\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"},{\"parameter\":\"15분 피크 수요\",\"measured\":\"60.14 kW @ 24:27\",\"standard\":\"사이트 기준\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"},{\"parameter\":\"부하율\",\"measured\":\"64.6%\",\"standard\":\"≥ 60% 권장\",\"assessment\":\"excellent\",\"assessmentLabel\":\"✓ 우수\"},{\"parameter\":\"평균 역률\",\"measured\":\"0.907 (지상 (Lagging))\",\"standard\":\"≥ 0.95\",\"assessment\":\"caution\",\"assessmentLabel\":\"△ 주의\"},{\"parameter\":\"전압 불균형 %\",\"measured\":\"0.45%\",\"standard\":\"< 2% IEC\",\"assessment\":\"excellent\",\"assessmentLabel\":\"✓ 우수\"},{\"parameter\":\"전류 불균형 %\",\"measured\":\"13.03%\",\"standard\":\"< 5% IEC\",\"assessment\":\"caution\",\"assessmentLabel\":\"△ 주의\"},{\"parameter\":\"평균 THDI\",\"measured\":\"10.3%\",\"standard\":\"< 5% IEC 61000\",\"assessment\":\"caution\",\"assessmentLabel\":\"△ 주의\"},{\"parameter\":\"평균 THDV\",\"measured\":\"—\",\"standard\":\"< 5% IEC\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"}],\"executiveNarrative\":[\"본 리포트는 2026. 6. 4. 오후 8:32:41 – 2026. 6. 5. 오후 8:27:41 기간 288건 (실시간 / 1분) 데이터로 전력품질·효율을 분석합니다\",\"평균 PF 0.907 — 0.0% 시간이 역률 패널티 기준(0.85) 미만 · 평균 THDI 10.3% — de-tuned APFC 적합\",\"평균 전류 불균형 13.03% — IEC 기준 초과 · L1 부하 35.1% (이상 33.3% 초과)\",\"15분 피크 수요 60.14 kW (24:27) — 평균 대비 ~1.5배 · 1분 데이터와 hourly 차이 ~38%\"],\"interpretationTitle\":\"해석\",\"interpretationBullets\":[\"전류 불균형 13.03% — L1 점유 35.1% · 부하 재분배로 열 스트레스 감소\",\"PF 0.907, 연간 ~502,831 kWh 규모 — PF ≥ 0.95 개선 시 회수 15.6 개월 (1.3 년) · 우수\",\"THDI 10.3% — de-tuned APFC (5.7% 리액터) 설치 안전, 공진 위험 없음\",\"전압 불균형 0.45% — 계통측 품질 양호, 부하·수요 관리에 집중\"],\"phasedTitle\":\"단계별 권장 사항\",\"phasedRecommendations\":[{\"phase\":\"1단계\",\"title\":\"De-tuned APFC 설치 — ROI 최고\",\"priority\":\"최우선\",\"bullets\":[\"THDI 10.3% — 5.7% de-tuning 리액터 APFC 안전 설치\",\"피크 60.14 kW 기준 용량 · L1 평균 전류 62.99 A\"],\"expectedOutcome\":\"PF 0.907 → ≥ 0.95 · 역률 패널티 제거 · 회수 15.6 개월 (1.3 년) · 우수\"},{\"phase\":\"2단계\",\"title\":\"3상 부하 재분배\",\"priority\":\"높은 우선순위\",\"bullets\":[\"L1 회로 1–2개 L3로 이동 — L1 ≤ 35%, L3 ≥ 32% 목표\",\"컴프레서 사이클 시 과도 불균형 감소\"],\"expectedOutcome\":\"CI 13.03% → < 10% · 모터·도체 열 스트레스 감소\"},{\"phase\":\"3단계\",\"title\":\"피크 수요 관리\",\"priority\":\"높은 우선순위\",\"bullets\":[\"피크 60.14 kW (24:27) — 수요요금 청구 기준\",\"서비스 전 pre-cool · 주방 설비 2–3분 간격 기동\"],\"expectedOutcome\":\"피크 ~15–20% 감소 · 수요요금 절감\"},{\"phase\":\"4단계\",\"title\":\"연간 점검 및 알람\",\"priority\":\"중간 우선순위\",\"bullets\":[\"메인 패널 L1 연결부 연간 열화상 검사\",\"알람 설정: PF < 0.85 · CI > 15%\"],\"expectedOutcome\":\"지속 과부하·불균형으로 인한 손상 예방\"}],\"peakPercentiles\":[{\"label\":\"P50\",\"value\":\"38.37 kW\",\"line\":\"P50  38.37 kW\",\"hint\":\"중앙값 — 시간의 50%가 이보다 낮음\"},{\"label\":\"P75\",\"value\":\"56.71 kW\",\"line\":\"P75  56.71 kW\",\"hint\":\"보통보다 높음 — 25%의 시간이 이보다 높음\"},{\"label\":\"P90\",\"value\":\"59.29 kW\",\"line\":\"P90  59.29 kW\",\"hint\":\"높은 부하 — 10%의 시간만 초과\"},{\"label\":\"P95\",\"value\":\"59.76 kW\",\"line\":\"P95  59.76 kW\",\"hint\":\"매우 높음 — 5%의 시간만 초과\"},{\"label\":\"P99\",\"value\":\"60.70 kW\",\"line\":\"P99  60.70 kW\",\"hint\":\"피크 근접 — 1%의 시간만 초과\"}],\"peakPercentileCaption\":\"피크 수요 통계 (백분위)\",\"imbalanceExceedance\":[{\"threshold\":\"> 10% (경고)\",\"pct\":\"76.4%\",\"liveStatus\":\"주의\",\"liveLevel\":\"warning\",\"liveImbDisplay\":\"13.0%\"},{\"threshold\":\"> 20% (고위험)\",\"pct\":\"6.3%\",\"liveStatus\":\"✓ 정상\",\"liveLevel\":\"good\",\"liveImbDisplay\":\"13.0%\"},{\"threshold\":\"> 50% (심각)\",\"pct\":\"0.0%\",\"liveStatus\":\"✓ 정상\",\"liveLevel\":\"good\",\"liveImbDisplay\":\"13.0%\"}],\"imbalanceExceedanceCaption\":\"전류 불균형 임계값 초과 시간 비율\",\"loadProfileNarrative\":\"부하 프로필 고부하 구간: 00:00–02:00, 04:00–05:00, 17:00–21:00, 22:00–24:00 — 청구 피크에서 중부하 이동 권장\",\"overallTechnicalRisk\":\"주의\",\"recommendedModel\":\"75 kVA\"}}','2026-06-05 22:24:57.358432'),
(4,3,4,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'warning',NULL,NULL,NULL,NULL,NULL,NULL,'{\"reportId\":\"GE-EQ-3-20260605-004\",\"reportDate\":\"2026. 6. 5. 오후 8:28:36\",\"lastUpdate\":\"2026. 6. 5. 오후 8:27:41\",\"overallRisk\":\"warning\",\"overallRiskLabel\":\"주의\",\"harmonicRisk\":\"caution\",\"harmonicRiskLabel\":\"주의\",\"statusMetrics\":{\"pf\":0.907,\"thd\":10.321,\"currentImbalance\":13.028460403698766,\"voltageImbalance\":0.44514096130442055},\"customer\":[{\"label\":\"리포트 ID\",\"value\":\"GE-EQ-3-20260605-004\"},{\"label\":\"고객명\",\"value\":\"Thailand\"},{\"label\":\"사이트명\",\"value\":\"GE-TH01\"},{\"label\":\"위치\",\"value\":\"Bangkok\"},{\"label\":\"업종\",\"value\":\"Manufacturing / Industrial\"},{\"label\":\"담당자\",\"value\":\"02-555-1199\"},{\"label\":\"측정 기간\",\"value\":\"2026. 6. 4. 오후 8:32:41 – 2026. 6. 5. 오후 8:27:41\"},{\"label\":\"리포트 날짜\",\"value\":\"2026. 6. 5. 오후 8:28:36\"},{\"label\":\"작성자\",\"value\":\"GE Energy Tech\"}],\"measurement\":[{\"label\":\"미터 ID\",\"value\":\"GE-TH01\"},{\"label\":\"게이트웨이 ID\",\"value\":\"192.168.1.3\"},{\"label\":\"측정 지점\",\"value\":\"GE-TH01 · CH1 (설치 전)\"},{\"label\":\"전압 시스템\",\"value\":\"3상 400V\"},{\"label\":\"차단기 용량\",\"value\":\"125 A\"},{\"label\":\"권장 설치 용량\",\"value\":\"70 kVA\"},{\"label\":\"데이터 해상도\",\"value\":\"실시간 / 1분\"},{\"label\":\"총 기록 수\",\"value\":\"288\"},{\"label\":\"측정 시작\",\"value\":\"2026. 6. 4. 오후 8:32:41\"},{\"label\":\"측정 종료\",\"value\":\"2026. 6. 5. 오후 8:27:41\"}],\"executive\":[{\"label\":\"총 에너지 (kWh)\",\"value\":\"12,151.44 kWh\"},{\"label\":\"평균 부하 (A)\",\"value\":\"92.64 A\"},{\"label\":\"피크 수요 (A)\",\"value\":\"97.46 A\"},{\"label\":\"부하율\",\"value\":\"64.6%\"},{\"label\":\"평균 역률\",\"value\":\"0.91\"},{\"label\":\"전류 불균형 %\",\"value\":\"13.0%\"},{\"label\":\"전압 불균형 %\",\"value\":\"0.4%\"},{\"label\":\"평균 THDI\",\"value\":\"10.32%\"},{\"label\":\"평균 THDV\",\"value\":\"—\"},{\"label\":\"종합 위험 수준\",\"value\":\"주의\"}],\"executiveBullets\":[\"미터 누적 에너지 12,151.44 kWh\",\"CH1 평균 전류: 92.64 A\",\"최대 피크 수요: 97.46 A @ 24:27 · 00:00–01:00\",\"부하율: 64.6%\",\"평균 역률: 0.91\",\"전류 불균형: 13.0%\",\"종합 위험 수준: 주의\",\"GE Energy Tech: 전압 조정 · 전류 조정 · 안정화 · 전력 저장 후 사용\"],\"executiveKpis\":[{\"label\":\"총 에너지 (kWh)\",\"value\":\"12,151.44 kWh\"},{\"label\":\"평균 부하 (A)\",\"value\":\"92.64 A\"},{\"label\":\"피크 수요 (A)\",\"value\":\"97.46 A\"},{\"label\":\"종합 위험 수준\",\"value\":\"주의\"}],\"energy\":[{\"label\":\"총 에너지 (kWh)\",\"value\":\"12,151.44 kWh\"},{\"label\":\"일평균 kWh\",\"value\":\"1,396.75 kWh\"},{\"label\":\"월 예상 kWh\",\"value\":\"41,902.56 kWh\"},{\"label\":\"연 예상 kWh\",\"value\":\"502,830.72 kWh\"},{\"label\":\"월 예상 비용\",\"value\":\"6,285,384 원\"}],\"peak\":[{\"label\":\"15분 피크 수요\",\"value\":\"97.46 A\"},{\"label\":\"피크 시간\",\"value\":\"24:27\"},{\"label\":\"피크 시간대\",\"value\":\"00:00–01:00\"},{\"label\":\"고부하 시간대\",\"value\":\"00:00–02:00, 04:00–05:00, 17:00–21:00, 22:00–24:00\"},{\"label\":\"On-peak 평균\",\"value\":\"60.05 A\"},{\"label\":\"Off-peak 평균\",\"value\":\"66.47 A\"},{\"label\":\"평균 부하 (A)\",\"value\":\"92.64 A\"},{\"label\":\"피크 / 평균\",\"value\":\"1.05\"},{\"label\":\"수요 요금 영향\",\"value\":\"양호\"}],\"powerFactor\":[{\"label\":\"평균 역률\",\"value\":\"0.91\"},{\"label\":\"최소 역률\",\"value\":\"0.91\"},{\"label\":\"0.95 미만 시간\",\"value\":\"주의\"},{\"label\":\"역률 패널티 (예상)\",\"value\":\"405,407 원\"},{\"label\":\"APFC 권장\",\"value\":\"GE Energy Tech 시스템 권장 (전압·전류·안정화·저장)\"}],\"balance\":[{\"label\":\"L1 전류\",\"value\":\"98.63 A\"},{\"label\":\"L2 전류\",\"value\":\"92.74 A\"},{\"label\":\"L3 전류\",\"value\":\"86.56 A\"},{\"label\":\"L1 전력 비율\",\"value\":\"35.5%\"},{\"label\":\"L2 전력 비율\",\"value\":\"33.4%\"},{\"label\":\"L3 전력 비율\",\"value\":\"31.1%\"},{\"label\":\"전류 불균형 %\",\"value\":\"13.0%\"},{\"label\":\"전압 불균형 %\",\"value\":\"0.4%\"}],\"harmonic\":[{\"label\":\"THDI L1\",\"value\":\"10.32%\"},{\"label\":\"THDI L2\",\"value\":\"10.32%\"},{\"label\":\"THDI L3\",\"value\":\"10.32%\"},{\"label\":\"THDI 평균\",\"value\":\"10.32%\"},{\"label\":\"THDV L1\",\"value\":\"—\"},{\"label\":\"THDV L2\",\"value\":\"—\"},{\"label\":\"THDV L3\",\"value\":\"—\"},{\"label\":\"THDV 평균\",\"value\":\"—\"},{\"label\":\"고조파 위험 수준\",\"value\":\"주의\"}],\"equipment\":[{\"label\":\"모터 / 컴프레서\",\"value\":\"주의\"},{\"label\":\"메인 차단기 / 케이블\",\"value\":\"양호\"},{\"label\":\"변압기\",\"value\":\"양호\"},{\"label\":\"유지보수\",\"value\":\"불균형 > 20% 시 열화상 검사\"}],\"financial\":[{\"label\":\"월 예상 비용\",\"value\":\"6,285,384 원\"},{\"label\":\"역률 패널티 (예상)\",\"value\":\"405,407 원\"},{\"label\":\"월 절감 가능액\",\"value\":\"512,887 원\"},{\"label\":\"연간 절감\",\"value\":\"6,154,648 원\"}],\"roi\":[{\"label\":\"권장 솔루션\",\"value\":\"GE Energy Tech Smart Power System\"},{\"label\":\"투자 비용\",\"value\":\"8,000,000 원\"},{\"label\":\"월 절감 가능액\",\"value\":\"512,887 원/월\"},{\"label\":\"투자 회수 기간\",\"value\":\"15.6 개월 (1.3 년) · 우수\"},{\"label\":\"ROI %\",\"value\":\"77%\"}],\"recommendations\":[{\"priority\":1,\"title\":\"GE Energy Tech Smart Power 설치\",\"description\":\"설치 전 비교 — 전압 조정, 3상 전류 조정, 안정화·고조파 제어, 피크/비피크 전력 저장\"},{\"priority\":2,\"title\":\"지속 모니터링\",\"description\":\"GE IoT 실시간 모니터링으로 추세 검증.\"}],\"actionPlan\":[{\"horizon\":\"즉시 (0–30일)\",\"items\":[\"상별 부하 확인\"]},{\"horizon\":\"단기 (1–3개월)\",\"items\":[\"PF < 0.95 또는 피크/불균형 시 GE Energy Tech 설치\"]},{\"horizon\":\"중기 (3–12개월)\",\"items\":[\"고조파 필터 평가\"]},{\"horizon\":\"장기 (1–3년)\",\"items\":[\"IoT 지속 모니터링\",\"연간 에너지 감사\"]}],\"conclusion\":[{\"label\":\"현재 문제\",\"value\":\"평균 역률: 0.91; 평균 THDI: 10.3%\"},{\"label\":\"기술적 위험\",\"value\":\"주의\"},{\"label\":\"재무 영향\",\"value\":\"6,285,384 원/월\"},{\"label\":\"권장 솔루션\",\"value\":\"GE Energy Tech Smart Power 설치\"},{\"label\":\"예상 절감액\",\"value\":\"512,887 원/월\"},{\"label\":\"투자 회수 기간\",\"value\":\"15.6 개월 (1.3 년) · 우수\"},{\"label\":\"다음 단계\",\"value\":\"고객과 검토 후 실행 계획 승인\"}],\"phaseTable\":[{\"phase\":\"L1\",\"ch1\":\"66.34\",\"ch2\":\"—\",\"analysis\":\"L1 상 평균 66.34 — 전체 N 평균 (62.99) 대비 5.3% 높음 · 3상 중 부하 최대\"},{\"phase\":\"L2\",\"ch1\":\"63.82\",\"ch2\":\"—\",\"analysis\":\"L2 상 평균 63.82 — 전체 N 평균 (62.99) 대비 1.3% 높음\"},{\"phase\":\"L3\",\"ch1\":\"58.82\",\"ch2\":\"—\",\"analysis\":\"L3 상 평균 58.82 — 전체 N 평균 (62.99) 대비 6.6% 낮음 · 3상 중 부하 최소\"},{\"phase\":\"평균 N\",\"ch1\":\"62.99\",\"ch2\":\"—\",\"analysis\":\"전체 N 평균 62.99 — 전류 불균형 11.9% · 최대 L1 66.34 · 최소 L3 58.82\"}],\"professional\":{\"reportSubtitle\":\"전력품질·에너지 효율 분석 · 2026. 6. 4. 오후 8:32:41 – 2026. 6. 5. 오후 8:27:41 · 288건 @ 실시간 / 1분\",\"keyFindingsIntro\":\"핵심 결과 요약 — 종합 기술 위험: 주의 · 월 절감 예상 512,887\",\"keyFindings\":[{\"parameter\":\"총 에너지 (kWh)\",\"measured\":\"41,903 kWh/mo · ~502,831 kWh/yr\",\"standard\":\"—\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"},{\"parameter\":\"15분 피크 수요\",\"measured\":\"60.14 kW @ 24:27\",\"standard\":\"사이트 기준\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"},{\"parameter\":\"부하율\",\"measured\":\"64.6%\",\"standard\":\"≥ 60% 권장\",\"assessment\":\"excellent\",\"assessmentLabel\":\"✓ 우수\"},{\"parameter\":\"평균 역률\",\"measured\":\"0.907 (지상 (Lagging))\",\"standard\":\"≥ 0.95\",\"assessment\":\"caution\",\"assessmentLabel\":\"△ 주의\"},{\"parameter\":\"전압 불균형 %\",\"measured\":\"0.45%\",\"standard\":\"< 2% IEC\",\"assessment\":\"excellent\",\"assessmentLabel\":\"✓ 우수\"},{\"parameter\":\"전류 불균형 %\",\"measured\":\"13.03%\",\"standard\":\"< 5% IEC\",\"assessment\":\"caution\",\"assessmentLabel\":\"△ 주의\"},{\"parameter\":\"평균 THDI\",\"measured\":\"10.3%\",\"standard\":\"< 5% IEC 61000\",\"assessment\":\"caution\",\"assessmentLabel\":\"△ 주의\"},{\"parameter\":\"평균 THDV\",\"measured\":\"—\",\"standard\":\"< 5% IEC\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"}],\"executiveNarrative\":[\"본 리포트는 2026. 6. 4. 오후 8:32:41 – 2026. 6. 5. 오후 8:27:41 기간 288건 (실시간 / 1분) 데이터로 전력품질·효율을 분석합니다\",\"평균 PF 0.907 — 0.0% 시간이 역률 패널티 기준(0.85) 미만 · 평균 THDI 10.3% — de-tuned APFC 적합\",\"평균 전류 불균형 13.03% — IEC 기준 초과 · L1 부하 35.1% (이상 33.3% 초과)\",\"15분 피크 수요 60.14 kW (24:27) — 평균 대비 ~1.5배 · 1분 데이터와 hourly 차이 ~38%\"],\"interpretationTitle\":\"해석\",\"interpretationBullets\":[\"전류 불균형 13.03% — L1 점유 35.1% · 부하 재분배로 열 스트레스 감소\",\"PF 0.907, 연간 ~502,831 kWh 규모 — PF ≥ 0.95 개선 시 회수 15.6 개월 (1.3 년) · 우수\",\"THDI 10.3% — de-tuned APFC (5.7% 리액터) 설치 안전, 공진 위험 없음\",\"전압 불균형 0.45% — 계통측 품질 양호, 부하·수요 관리에 집중\"],\"phasedTitle\":\"단계별 권장 사항\",\"phasedRecommendations\":[{\"phase\":\"1단계\",\"title\":\"De-tuned APFC 설치 — ROI 최고\",\"priority\":\"최우선\",\"bullets\":[\"THDI 10.3% — 5.7% de-tuning 리액터 APFC 안전 설치\",\"피크 60.14 kW 기준 용량 · L1 평균 전류 62.99 A\"],\"expectedOutcome\":\"PF 0.907 → ≥ 0.95 · 역률 패널티 제거 · 회수 15.6 개월 (1.3 년) · 우수\"},{\"phase\":\"2단계\",\"title\":\"3상 부하 재분배\",\"priority\":\"높은 우선순위\",\"bullets\":[\"L1 회로 1–2개 L3로 이동 — L1 ≤ 35%, L3 ≥ 32% 목표\",\"컴프레서 사이클 시 과도 불균형 감소\"],\"expectedOutcome\":\"CI 13.03% → < 10% · 모터·도체 열 스트레스 감소\"},{\"phase\":\"3단계\",\"title\":\"피크 수요 관리\",\"priority\":\"높은 우선순위\",\"bullets\":[\"피크 60.14 kW (24:27) — 수요요금 청구 기준\",\"서비스 전 pre-cool · 주방 설비 2–3분 간격 기동\"],\"expectedOutcome\":\"피크 ~15–20% 감소 · 수요요금 절감\"},{\"phase\":\"4단계\",\"title\":\"연간 점검 및 알람\",\"priority\":\"중간 우선순위\",\"bullets\":[\"메인 패널 L1 연결부 연간 열화상 검사\",\"알람 설정: PF < 0.85 · CI > 15%\"],\"expectedOutcome\":\"지속 과부하·불균형으로 인한 손상 예방\"}],\"peakPercentiles\":[{\"label\":\"P50\",\"value\":\"38.37 kW\",\"line\":\"P50  38.37 kW\",\"hint\":\"중앙값 — 시간의 50%가 이보다 낮음\"},{\"label\":\"P75\",\"value\":\"56.71 kW\",\"line\":\"P75  56.71 kW\",\"hint\":\"보통보다 높음 — 25%의 시간이 이보다 높음\"},{\"label\":\"P90\",\"value\":\"59.29 kW\",\"line\":\"P90  59.29 kW\",\"hint\":\"높은 부하 — 10%의 시간만 초과\"},{\"label\":\"P95\",\"value\":\"59.76 kW\",\"line\":\"P95  59.76 kW\",\"hint\":\"매우 높음 — 5%의 시간만 초과\"},{\"label\":\"P99\",\"value\":\"60.70 kW\",\"line\":\"P99  60.70 kW\",\"hint\":\"피크 근접 — 1%의 시간만 초과\"}],\"peakPercentileCaption\":\"피크 수요 통계 (백분위)\",\"imbalanceExceedance\":[{\"threshold\":\"> 10% (경고)\",\"pct\":\"76.4%\",\"liveStatus\":\"주의\",\"liveLevel\":\"warning\",\"liveImbDisplay\":\"13.0%\"},{\"threshold\":\"> 20% (고위험)\",\"pct\":\"6.3%\",\"liveStatus\":\"✓ 정상\",\"liveLevel\":\"good\",\"liveImbDisplay\":\"13.0%\"},{\"threshold\":\"> 50% (심각)\",\"pct\":\"0.0%\",\"liveStatus\":\"✓ 정상\",\"liveLevel\":\"good\",\"liveImbDisplay\":\"13.0%\"}],\"imbalanceExceedanceCaption\":\"전류 불균형 임계값 초과 시간 비율\",\"loadProfileNarrative\":\"부하 프로필 고부하 구간: 00:00–02:00, 04:00–05:00, 17:00–21:00, 22:00–24:00 — 청구 피크에서 중부하 이동 권장\",\"overallTechnicalRisk\":\"주의\",\"recommendedModel\":\"75 kVA\"}}','2026-06-05 22:28:37.952617'),
(5,1,5,1,NULL,NULL,30.41,86.10,NULL,23.20,0.40,10.120,NULL,'critical',30.41,NULL,1.080,NULL,NULL,NULL,'{\"reportId\":\"GE-EQ-1-20260606-001\",\"reportDate\":\"6/6/2569 15:29:12\",\"lastUpdate\":\"5/6/2569 20:27:35\",\"overallRisk\":\"critical\",\"overallRiskLabel\":\"วิกฤต (Critical)\",\"harmonicRisk\":\"caution\",\"harmonicRiskLabel\":\"ระวัง\",\"statusMetrics\":{\"pf\":0.901,\"thd\":10.116,\"currentImbalance\":23.199716211422487,\"voltageImbalance\":0.44727263640983006},\"customer\":[{\"label\":\"รหัสรายงาน\",\"value\":\"GE-EQ-1-20260606-001\"},{\"label\":\"ชื่อลูกค้า\",\"value\":\"GE Energy\"},{\"label\":\"ชื่อไซต์\",\"value\":\"GE01\"},{\"label\":\"โลเคชั่น\",\"value\":\"KOREA\"},{\"label\":\"ประเภทธุรกิจ\",\"value\":\"Electronics / Factory\"},{\"label\":\"ผู้ติดต่อ\",\"value\":\"010-8105-0384\"},{\"label\":\"ช่วงการวัด\",\"value\":\"4/6/2569 20:32:35 – 5/6/2569 20:27:35\"},{\"label\":\"วันที่จัดทำรายงาน\",\"value\":\"6/6/2569 15:29:12\"},{\"label\":\"ผู้จัดทำ\",\"value\":\"GE Energy Tech\"}],\"measurement\":[{\"label\":\"Meter ID\",\"value\":\"GE-KR-0004\"},{\"label\":\"Gateway ID\",\"value\":\"192.168.1.46\"},{\"label\":\"จุดตรวจวัด\",\"value\":\"GE Smart Power Meter · CH1 (ก่อนติดตั้ง)\"},{\"label\":\"ระบบแรงดัน\",\"value\":\"3-Phase 400V\"},{\"label\":\"ขนาดเบรกเกอร์\",\"value\":\"40 A\"},{\"label\":\"ขนาดเครื่องที่แนะนำติดตั้ง\",\"value\":\"50 kVA\"},{\"label\":\"ความละเอียดข้อมูล\",\"value\":\"เรียลไทม์ / 1 นาที\"},{\"label\":\"จำนวนบันทึก\",\"value\":\"288\"},{\"label\":\"เริ่มวัด\",\"value\":\"4/6/2569 20:32:35\"},{\"label\":\"สิ้นสุดวัด\",\"value\":\"5/6/2569 20:27:35\"}],\"executive\":[{\"label\":\"พลังงานรวม (kWh)\",\"value\":\"12,051.44 kWh\"},{\"label\":\"กระแสเฉลี่ย (A)\",\"value\":\"28.19 A\"},{\"label\":\"Peak Demand (A)\",\"value\":\"30.41 A\"},{\"label\":\"Load Factor\",\"value\":\"86.1%\"},{\"label\":\"Power Factor เฉลี่ย\",\"value\":\"0.90\"},{\"label\":\"Current Imbalance %\",\"value\":\"23.2%\"},{\"label\":\"Voltage Imbalance %\",\"value\":\"0.4%\"},{\"label\":\"THDI เฉลี่ย\",\"value\":\"10.12%\"},{\"label\":\"THDV เฉลี่ย\",\"value\":\"—\"},{\"label\":\"ระดับความเสี่ยงรวม\",\"value\":\"วิกฤต (Critical)\"}],\"executiveBullets\":[\"พลังงานสะสม 12,051.44 kWh จากมิเตอร์\",\"กระแสเฉลี่ย CH1: 28.19 A\",\"Peak Demand สูงสุด: 30.41 A @ 15:42 · 15:00–16:00\",\"Load Factor: 86.1%\",\"Power Factor เฉลี่ย: 0.90\",\"ความไม่สมดุลกระแส: 23.2%\",\"ระดับความเสี่ยงรวม: วิกฤต (Critical)\",\"แนวทาง GE Energy Tech: ปรับแรงดัน · ปรับกระแส · ปรับเสถียร · เก็บกระแสไว้ใช้ภายหลัง\"],\"executiveKpis\":[{\"label\":\"พลังงานรวม (kWh)\",\"value\":\"12,051.44 kWh\"},{\"label\":\"กระแสเฉลี่ย (A)\",\"value\":\"28.19 A\"},{\"label\":\"Peak Demand (A)\",\"value\":\"30.41 A\"},{\"label\":\"ระดับความเสี่ยงรวม\",\"value\":\"วิกฤต (Critical)\"}],\"energy\":[{\"label\":\"พลังงานรวม (kWh)\",\"value\":\"12,051.44 kWh\"},{\"label\":\"พลังงานเฉลี่ยรายวัน (kWh)\",\"value\":\"422.33 kWh\"},{\"label\":\"ประมาณการรายเดือน (kWh)\",\"value\":\"12,669.84 kWh\"},{\"label\":\"ประมาณการรายปี (kWh)\",\"value\":\"152,038.08 kWh\"},{\"label\":\"ค่าไฟโดยประมาณ/เดือน\",\"value\":\"53,213 บาท\"}],\"peak\":[{\"label\":\"Peak Demand 15 นาที\",\"value\":\"30.41 A\"},{\"label\":\"เวลา Peak\",\"value\":\"15:42\"},{\"label\":\"ช่วงเวลา Peak\",\"value\":\"15:00–16:00\"},{\"label\":\"ช่วงโหลดสูง\",\"value\":\"—\"},{\"label\":\"On-peak เฉลี่ย\",\"value\":\"26.18 A\"},{\"label\":\"Off-peak เฉลี่ย\",\"value\":\"26.19 A\"},{\"label\":\"กระแสเฉลี่ย (A)\",\"value\":\"28.19 A\"},{\"label\":\"Peak / Average\",\"value\":\"1.08\"},{\"label\":\"ผลกระทบ Demand Charge\",\"value\":\"ดี (Good)\"}],\"powerFactor\":[{\"label\":\"Power Factor เฉลี่ย\",\"value\":\"0.90\"},{\"label\":\"PF ต่ำสุด\",\"value\":\"0.90\"},{\"label\":\"เวลาที่ PF ต่ำกว่า 0.95\",\"value\":\"เตือน (Warning)\"},{\"label\":\"ค่าปรับ PF (ประมาณ)\",\"value\":\"3,911 บาท\"},{\"label\":\"แนะนำ APFC\",\"value\":\"แนะนำระบบ GE Energy Tech (ปรับแรงดัน·กระแส·เสถียร·เก็บพลังงาน)\"}],\"balance\":[{\"label\":\"กระแส L1\",\"value\":\"32.47 A\"},{\"label\":\"กระแส L2\",\"value\":\"25.93 A\"},{\"label\":\"กระแส L3\",\"value\":\"26.17 A\"},{\"label\":\"สัดส่วนกำลัง L1\",\"value\":\"38.4%\"},{\"label\":\"สัดส่วนกำลัง L2\",\"value\":\"30.7%\"},{\"label\":\"สัดส่วนกำลัง L3\",\"value\":\"30.9%\"},{\"label\":\"Current Imbalance %\",\"value\":\"23.2%\"},{\"label\":\"Voltage Imbalance %\",\"value\":\"0.4%\"}],\"harmonic\":[{\"label\":\"THDI L1\",\"value\":\"10.12%\"},{\"label\":\"THDI L2\",\"value\":\"10.12%\"},{\"label\":\"THDI L3\",\"value\":\"10.12%\"},{\"label\":\"THDI เฉลี่ย\",\"value\":\"10.12%\"},{\"label\":\"THDV L1\",\"value\":\"—\"},{\"label\":\"THDV L2\",\"value\":\"—\"},{\"label\":\"THDV L3\",\"value\":\"—\"},{\"label\":\"THDV เฉลี่ย\",\"value\":\"—\"},{\"label\":\"ระดับความเสี่ยง Harmonic\",\"value\":\"ระวัง\"}],\"equipment\":[{\"label\":\"มอเตอร์ / คอมเพรสเซอร์\",\"value\":\"วิกฤต (Critical)\"},{\"label\":\"เมนเบรกเกอร์ / สายเคเบิล\",\"value\":\"ดี (Good)\"},{\"label\":\"หม้อแปลง\",\"value\":\"ดี (Good)\"},{\"label\":\"การบำรุงรักษา\",\"value\":\"ตรวจ Thermographic หาก imbalance > 20%\"}],\"financial\":[{\"label\":\"ค่าไฟโดยประมาณ/เดือน\",\"value\":\"53,213 บาท\"},{\"label\":\"ค่าปรับ PF (ประมาณ)\",\"value\":\"3,911 บาท\"},{\"label\":\"ประหยัดได้/เดือน\",\"value\":\"6,056 บาท\"},{\"label\":\"ประหยัดรายปี\",\"value\":\"72,668 บาท\"}],\"roi\":[{\"label\":\"แนวทางแก้ไข\",\"value\":\"GE Energy Tech Smart Saving System\"},{\"label\":\"เงินลงทุน\",\"value\":\"66,340 บาท\"},{\"label\":\"ประหยัดได้/เดือน\",\"value\":\"6,056 บาท/เดือน\"},{\"label\":\"ระยะคืนทุน\",\"value\":\"11.0 เดือน (0.9 ปี) · เยี่ยม\"},{\"label\":\"ROI %\",\"value\":\"110%\"}],\"recommendations\":[{\"priority\":1,\"title\":\"ติดตั้งระบบ GE Energy Tech Smart Saving\",\"description\":\"เปรียบเทียบก่อนติดตั้ง — ระบบปรับแรงดัน ปรับกระแส 3 เฟส ปรับเสถียรลดฮาร์มอนิก และเก็บกระแสไฟใช้ช่วง Peak/Off-peak\"},{\"priority\":2,\"title\":\"กระจายโหลด 3 เฟส\",\"description\":\"สมดุล L1/L2/L3 ลดความเครียดสายและเบรกเกอร์\"},{\"priority\":3,\"title\":\"ติดตามอย่างต่อเนื่อง\",\"description\":\"ใช้ระบบ GE IoT ติดตามแนวโน้ม\"}],\"actionPlan\":[{\"horizon\":\"ทันที (0–30 วัน)\",\"items\":[\"ตรวจการโหลดแต่ละเฟส\"]},{\"horizon\":\"ระยะสั้น (1–3 เดือน)\",\"items\":[\"ติดตั้งระบบ GE Energy Tech หาก PF < 0.95 หรือมี Peak/ไม่สมดุล\",\"กระจายโหลดเฟสเดียว\"]},{\"horizon\":\"ระยะกลาง (3–12 เดือน)\",\"items\":[\"ประเมิน Harmonic filter\"]},{\"horizon\":\"ระยะยาว (1–3 ปี)\",\"items\":[\"ติดตาม IoT ต่อเนื่อง\",\"ตรวจพลังงานประจำปี\"]}],\"conclusion\":[{\"label\":\"ปัญหาปัจจุบัน\",\"value\":\"Current Imbalance %: 23.2%; Power Factor เฉลี่ย: 0.90; THDI เฉลี่ย: 10.1%\"},{\"label\":\"ความเสี่ยงทางเทคนิค\",\"value\":\"วิกฤต (Critical)\"},{\"label\":\"ผลกระทบทางการเงิน\",\"value\":\"53,213 บาท/เดือน\"},{\"label\":\"แนวทางแนะนำ\",\"value\":\"ติดตั้งระบบ GE Energy Tech Smart Saving\"},{\"label\":\"ประหยัดที่คาดหวัง\",\"value\":\"6,056 บาท/เดือน\"},{\"label\":\"ระยะคืนทุน\",\"value\":\"11.0 เดือน (0.9 ปี) · เยี่ยม\"},{\"label\":\"ขั้นตอนถัดไป\",\"value\":\"ทบทวนกับลูกค้าและอนุมัติแผน\"}],\"phaseTable\":[{\"phase\":\"L1\",\"ch1\":\"27.88\",\"ch2\":\"—\",\"analysis\":\"เฟส L1 เฉลี่ย 27.88 — สูงกว่าค่าเฉลี่ยรวม N (26.19) 6.5% · รับโหลดมากที่สุดใน 3 เฟส\"},{\"phase\":\"L2\",\"ch1\":\"25.71\",\"ch2\":\"—\",\"analysis\":\"เฟส L2 เฉลี่ย 25.71 — ต่ำกว่าค่าเฉลี่ยรวม N (26.19) 1.8%\"},{\"phase\":\"L3\",\"ch1\":\"24.97\",\"ch2\":\"—\",\"analysis\":\"เฟส L3 เฉลี่ย 24.97 — ต่ำกว่าค่าเฉลี่ยรวม N (26.19) 4.7% · โหลดเบาที่สุดใน 3 เฟส\"},{\"phase\":\"เฉลี่ย N\",\"ch1\":\"26.19\",\"ch2\":\"—\",\"analysis\":\"ค่าเฉลี่ยรวม N 26.19 — ความไม่สมดุลกระแส 11.1% · เฟสสูงสุด L1 27.88 · เฟสต่ำสุด L3 24.97\"}],\"professional\":{\"reportSubtitle\":\"รายงานวิเคราะห์คุณภาพไฟฟ้าและประสิทธิภาพพลังงาน · 4/6/2569 20:32:35 – 5/6/2569 20:27:35 · 288 บันทึก @ เรียลไทม์ / 1 นาที\",\"keyFindingsIntro\":\"สรุปผลวิเคราะห์หลัก — ระดับความเสี่ยงทางเทคนิค: CRITICAL · ประหยัดได้โดยประมาณ 6,056/เดือน\",\"keyFindings\":[{\"parameter\":\"พลังงานรวม (kWh)\",\"measured\":\"12,670 kWh/mo · ~152,038 kWh/yr\",\"standard\":\"—\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"},{\"parameter\":\"Peak Demand 15 นาที\",\"measured\":\"16.70 kW @ 15:42\",\"standard\":\"ตามไซต์\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"},{\"parameter\":\"Load Factor\",\"measured\":\"86.1%\",\"standard\":\"≥ 60% แนะนำ\",\"assessment\":\"excellent\",\"assessmentLabel\":\"✓ ดีเยี่ยม\"},{\"parameter\":\"Power Factor เฉลี่ย\",\"measured\":\"0.901 (Lagging)\",\"standard\":\"≥ 0.95\",\"assessment\":\"caution\",\"assessmentLabel\":\"△ ควรระวัง\"},{\"parameter\":\"Voltage Imbalance %\",\"measured\":\"0.45%\",\"standard\":\"< 2% IEC\",\"assessment\":\"excellent\",\"assessmentLabel\":\"✓ ดีเยี่ยม\"},{\"parameter\":\"Current Imbalance %\",\"measured\":\"23.20%\",\"standard\":\"< 5% IEC\",\"assessment\":\"warning\",\"assessmentLabel\":\"⚠ เตือน\"},{\"parameter\":\"THDI เฉลี่ย\",\"measured\":\"10.1%\",\"standard\":\"< 5% IEC 61000\",\"assessment\":\"caution\",\"assessmentLabel\":\"△ ควรระวัง\"},{\"parameter\":\"THDV เฉลี่ย\",\"measured\":\"—\",\"standard\":\"< 5% IEC\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"}],\"executiveNarrative\":[\"รายงานนี้วิเคราะห์คุณภาพไฟฟ้าและประสิทธิภาพพลังงานจากข้อมูล 288 บันทึก (เรียลไทม์ / 1 นาที) ในช่วง 4/6/2569 20:32:35 – 5/6/2569 20:27:35\",\"Power Factor เฉลี่ย 0.901 — 0.0% ของเวลาอยู่ต่ำกว่าเกณฑ์ค่าปรับ MEA (0.85) · THDI เฉลี่ย 10.1% — เหมาะสำหรับ APFC แบบ de-tuned\",\"Current Imbalance เฉลี่ย 23.20% — สูงกว่าเกณฑ์ IEC · L1 รับโหลด 35.5% (เกินค่า ideal 33.3%)\",\"Peak Demand 15 นาที 16.70 kW ที่ 15:42 — สูงกว่าเฉลี่ย ~1.2× · ข้อมูลความละเอียด 1 นาทีต่างจาก hourly ~45%\"],\"interpretationTitle\":\"การตีความ (Interpretation)\",\"interpretationBullets\":[\"Current Imbalance 23.20% — L1 รับโหลด 35.5% · ควรกระจายโหลด 3 เฟสเพื่อลดความเครียด thermal\",\"PF 0.901 ที่สเกลพลังงาน ~152,038 kWh/ปี — ปรับ PF ให้ ≥ 0.95 คืนทุน 11.0 เดือน (0.9 ปี) · เยี่ยม\",\"THDI 10.1% — ติดตั้ง de-tuned APFC (5.7% reactor) ปลอดภัย ไม่เสี่ยง resonance\",\"Voltage Imbalance 0.45% — คุณภาพแรงดันดี ปัญหาอยู่ที่โหลดและการบริหาร Demand\"],\"phasedTitle\":\"คำแนะนำเชิงปฏิบัติ (Phased Recommendations)\",\"phasedRecommendations\":[{\"phase\":\"Phase 1\",\"title\":\"ติดตั้ง De-tuned APFC — ROI สูงสุด\",\"priority\":\"ลำดับความสำคัญสูงสุด\",\"bullets\":[\"THDI 10.1% — ติดตั้ง APFC + reactor de-tuning 5.7% ปลอดภัย\",\"จัดอ ratings จาก Peak 16.70 kW · กระแสเฉลี่ย L1 26.19 A\"],\"expectedOutcome\":\"PF 0.901 → ≥ 0.95 · ลดค่าปรับ MEA · คืนทุน 11.0 เดือน (0.9 ปี) · เยี่ยม\"},{\"phase\":\"Phase 2\",\"title\":\"กระจายโหลด 3 เฟส\",\"priority\":\"ลำดับความสำคัญสูง\",\"bullets\":[\"ย้ายวงจร AC/ครัวจาก L1 ไป L3 ให้ L1 ≤ 35%, L3 ≥ 32%\",\"ลด transient imbalance ตอน compressor cycle on\"],\"expectedOutcome\":\"CI 23.20% → < 10% · ลด thermal stress มอเตอร์และสาย\"},{\"phase\":\"Phase 4\",\"title\":\"ตรวจสอบและแจ้งเตือนประจำปี\",\"priority\":\"ลำดับความสำคัญปานกลาง\",\"bullets\":[\"Thermographic inspection ที่ main panel L1 เป็นประจำ\",\"ตั้ง alarm: PF < 0.85 · CI > 15%\"],\"expectedOutcome\":\"ป้องกันความเสียหายจาก overload และ imbalance สะสม\"}],\"peakPercentiles\":[{\"label\":\"P50\",\"value\":\"16.05 kW\",\"line\":\"P50  16.05 kW\",\"hint\":\"ค่ามัธยฐาน — 50% ของเวลาโหลดต่ำกว่านี้\"},{\"label\":\"P75\",\"value\":\"16.70 kW\",\"line\":\"P75  16.70 kW\",\"hint\":\"โหลดสูงกว่าปกติ — 25% ของเวลาสูงกว่านี้\"},{\"label\":\"P90\",\"value\":\"17.38 kW\",\"line\":\"P90  17.38 kW\",\"hint\":\"โหลดสูง — เกินค่านี้แค่ 10% ของเวลา\"},{\"label\":\"P95\",\"value\":\"17.87 kW\",\"line\":\"P95  17.87 kW\",\"hint\":\"โหลดสูงมาก — เกินค่านี้แค่ 5% ของเวลา\"},{\"label\":\"P99\",\"value\":\"18.32 kW\",\"line\":\"P99  18.32 kW\",\"hint\":\"ใกล้ Peak สูงสุด — เกินค่านี้แค่ 1% ของเวลา\"}],\"peakPercentileCaption\":\"สถิติ Peak Demand (Percentile)\",\"imbalanceExceedance\":[{\"threshold\":\"> 10% (เตือน)\",\"pct\":\"82.6%\",\"liveStatus\":\"เตือน (Warning)\",\"liveLevel\":\"warning\",\"liveImbDisplay\":\"23.2%\"},{\"threshold\":\"> 20% (เสี่ยงสูง)\",\"pct\":\"50.3%\",\"liveStatus\":\"ความเสี่ยงสูง\",\"liveLevel\":\"critical\",\"liveImbDisplay\":\"23.2%\"},{\"threshold\":\"> 50% (รุนแรง)\",\"pct\":\"0.0%\",\"liveStatus\":\"✓ ปกติ\",\"liveLevel\":\"good\",\"liveImbDisplay\":\"23.2%\"}],\"imbalanceExceedanceCaption\":\"สัดส่วนเวลาที่ Current Imbalance เกินเกณฑ์\",\"loadProfileNarrative\":null,\"overallTechnicalRisk\":\"CRITICAL\",\"recommendedModel\":\"50 kVA\"}}','2026-06-06 17:29:14.741298'),
(6,1,6,1,NULL,NULL,30.41,86.10,NULL,23.20,0.40,10.120,NULL,'critical',30.41,NULL,1.080,NULL,NULL,NULL,'{\"reportId\":\"GE-EQ-1-20260606-002\",\"reportDate\":\"6/6/2569 15:39:22\",\"lastUpdate\":\"5/6/2569 20:27:35\",\"overallRisk\":\"critical\",\"overallRiskLabel\":\"วิกฤต (Critical)\",\"harmonicRisk\":\"caution\",\"harmonicRiskLabel\":\"ระวัง\",\"statusMetrics\":{\"pf\":0.901,\"thd\":10.116,\"currentImbalance\":23.199716211422487,\"voltageImbalance\":0.44727263640983006},\"customer\":[{\"label\":\"รหัสรายงาน\",\"value\":\"GE-EQ-1-20260606-002\"},{\"label\":\"ชื่อลูกค้า\",\"value\":\"GE Energy\"},{\"label\":\"ชื่อไซต์\",\"value\":\"GE01\"},{\"label\":\"โลเคชั่น\",\"value\":\"KOREA\"},{\"label\":\"ประเภทธุรกิจ\",\"value\":\"Electronics / Factory\"},{\"label\":\"ผู้ติดต่อ\",\"value\":\"010-8105-0384\"},{\"label\":\"ช่วงการวัด\",\"value\":\"4/6/2569 20:32:35 – 5/6/2569 20:27:35\"},{\"label\":\"วันที่จัดทำรายงาน\",\"value\":\"6/6/2569 15:39:22\"},{\"label\":\"ผู้จัดทำ\",\"value\":\"GE Energy Tech\"}],\"measurement\":[{\"label\":\"Meter ID\",\"value\":\"GE-KR-0004\"},{\"label\":\"Gateway ID\",\"value\":\"192.168.1.46\"},{\"label\":\"จุดตรวจวัด\",\"value\":\"GE Smart Power Meter · CH1 (ก่อนติดตั้ง)\"},{\"label\":\"ระบบแรงดัน\",\"value\":\"3-Phase 400V\"},{\"label\":\"ขนาดเบรกเกอร์\",\"value\":\"40 A\"},{\"label\":\"ขนาดเครื่องที่แนะนำติดตั้ง\",\"value\":\"50 kVA\"},{\"label\":\"ความละเอียดข้อมูล\",\"value\":\"เรียลไทม์ / 1 นาที\"},{\"label\":\"จำนวนบันทึก\",\"value\":\"288\"},{\"label\":\"เริ่มวัด\",\"value\":\"4/6/2569 20:32:35\"},{\"label\":\"สิ้นสุดวัด\",\"value\":\"5/6/2569 20:27:35\"}],\"executive\":[{\"label\":\"พลังงานรวม (kWh)\",\"value\":\"12,051.44 kWh\"},{\"label\":\"กระแสเฉลี่ย (A)\",\"value\":\"28.19 A\"},{\"label\":\"Peak Demand (A)\",\"value\":\"30.41 A\"},{\"label\":\"Load Factor\",\"value\":\"86.1%\"},{\"label\":\"Power Factor เฉลี่ย\",\"value\":\"0.90\"},{\"label\":\"Current Imbalance %\",\"value\":\"23.2%\"},{\"label\":\"Voltage Imbalance %\",\"value\":\"0.4%\"},{\"label\":\"THDI เฉลี่ย\",\"value\":\"10.12%\"},{\"label\":\"THDV เฉลี่ย\",\"value\":\"—\"},{\"label\":\"ระดับความเสี่ยงรวม\",\"value\":\"วิกฤต (Critical)\"}],\"executiveBullets\":[\"พลังงานสะสม 12,051.44 kWh จากมิเตอร์\",\"กระแสเฉลี่ย CH1: 28.19 A\",\"Peak Demand สูงสุด: 30.41 A @ 15:42 · 15:00–16:00\",\"Load Factor: 86.1%\",\"Power Factor เฉลี่ย: 0.90\",\"ความไม่สมดุลกระแส: 23.2%\",\"ระดับความเสี่ยงรวม: วิกฤต (Critical)\",\"แนวทาง GE Energy Tech: ปรับแรงดัน · ปรับกระแส · ปรับเสถียร · เก็บกระแสไว้ใช้ภายหลัง\"],\"executiveKpis\":[{\"label\":\"พลังงานรวม (kWh)\",\"value\":\"12,051.44 kWh\"},{\"label\":\"กระแสเฉลี่ย (A)\",\"value\":\"28.19 A\"},{\"label\":\"Peak Demand (A)\",\"value\":\"30.41 A\"},{\"label\":\"ระดับความเสี่ยงรวม\",\"value\":\"วิกฤต (Critical)\"}],\"energy\":[{\"label\":\"พลังงานรวม (kWh)\",\"value\":\"12,051.44 kWh\"},{\"label\":\"พลังงานเฉลี่ยรายวัน (kWh)\",\"value\":\"422.33 kWh\"},{\"label\":\"ประมาณการรายเดือน (kWh)\",\"value\":\"12,669.84 kWh\"},{\"label\":\"ประมาณการรายปี (kWh)\",\"value\":\"152,038.08 kWh\"},{\"label\":\"ค่าไฟโดยประมาณ/เดือน\",\"value\":\"53,213 บาท\"}],\"peak\":[{\"label\":\"Peak Demand 15 นาที\",\"value\":\"30.41 A\"},{\"label\":\"เวลา Peak\",\"value\":\"15:42\"},{\"label\":\"ช่วงเวลา Peak\",\"value\":\"15:00–16:00\"},{\"label\":\"ช่วงโหลดสูง\",\"value\":\"—\"},{\"label\":\"On-peak เฉลี่ย\",\"value\":\"26.18 A\"},{\"label\":\"Off-peak เฉลี่ย\",\"value\":\"26.19 A\"},{\"label\":\"กระแสเฉลี่ย (A)\",\"value\":\"28.19 A\"},{\"label\":\"Peak / Average\",\"value\":\"1.08\"},{\"label\":\"ผลกระทบ Demand Charge\",\"value\":\"ดี (Good)\"}],\"powerFactor\":[{\"label\":\"Power Factor เฉลี่ย\",\"value\":\"0.90\"},{\"label\":\"PF ต่ำสุด\",\"value\":\"0.90\"},{\"label\":\"เวลาที่ PF ต่ำกว่า 0.95\",\"value\":\"เตือน (Warning)\"},{\"label\":\"ค่าปรับ PF (ประมาณ)\",\"value\":\"3,911 บาท\"},{\"label\":\"แนะนำ APFC\",\"value\":\"แนะนำระบบ GE Energy Tech (ปรับแรงดัน·กระแส·เสถียร·เก็บพลังงาน)\"}],\"balance\":[{\"label\":\"กระแส L1\",\"value\":\"32.47 A\"},{\"label\":\"กระแส L2\",\"value\":\"25.93 A\"},{\"label\":\"กระแส L3\",\"value\":\"26.17 A\"},{\"label\":\"สัดส่วนกำลัง L1\",\"value\":\"38.4%\"},{\"label\":\"สัดส่วนกำลัง L2\",\"value\":\"30.7%\"},{\"label\":\"สัดส่วนกำลัง L3\",\"value\":\"30.9%\"},{\"label\":\"Current Imbalance %\",\"value\":\"23.2%\"},{\"label\":\"Voltage Imbalance %\",\"value\":\"0.4%\"}],\"harmonic\":[{\"label\":\"THDI L1\",\"value\":\"10.12%\"},{\"label\":\"THDI L2\",\"value\":\"10.12%\"},{\"label\":\"THDI L3\",\"value\":\"10.12%\"},{\"label\":\"THDI เฉลี่ย\",\"value\":\"10.12%\"},{\"label\":\"THDV L1\",\"value\":\"—\"},{\"label\":\"THDV L2\",\"value\":\"—\"},{\"label\":\"THDV L3\",\"value\":\"—\"},{\"label\":\"THDV เฉลี่ย\",\"value\":\"—\"},{\"label\":\"ระดับความเสี่ยง Harmonic\",\"value\":\"ระวัง\"}],\"equipment\":[{\"label\":\"มอเตอร์ / คอมเพรสเซอร์\",\"value\":\"วิกฤต (Critical)\"},{\"label\":\"เมนเบรกเกอร์ / สายเคเบิล\",\"value\":\"ดี (Good)\"},{\"label\":\"หม้อแปลง\",\"value\":\"ดี (Good)\"},{\"label\":\"การบำรุงรักษา\",\"value\":\"ตรวจ Thermographic หาก imbalance > 20%\"}],\"financial\":[{\"label\":\"ค่าไฟโดยประมาณ/เดือน\",\"value\":\"53,213 บาท\"},{\"label\":\"ค่าปรับ PF (ประมาณ)\",\"value\":\"3,911 บาท\"},{\"label\":\"ประหยัดได้/เดือน\",\"value\":\"6,056 บาท\"},{\"label\":\"ประหยัดรายปี\",\"value\":\"72,668 บาท\"}],\"roi\":[{\"label\":\"แนวทางแก้ไข\",\"value\":\"GE Energy Tech Smart Saving System\"},{\"label\":\"เงินลงทุน\",\"value\":\"66,340 บาท\"},{\"label\":\"ประหยัดได้/เดือน\",\"value\":\"6,056 บาท/เดือน\"},{\"label\":\"ระยะคืนทุน\",\"value\":\"11.0 เดือน (0.9 ปี) · เยี่ยม\"},{\"label\":\"ROI %\",\"value\":\"110%\"}],\"recommendations\":[{\"priority\":1,\"title\":\"ติดตั้งระบบ GE Energy Tech Smart Saving\",\"description\":\"เปรียบเทียบก่อนติดตั้ง — ระบบปรับแรงดัน ปรับกระแส 3 เฟส ปรับเสถียรลดฮาร์มอนิก และเก็บกระแสไฟใช้ช่วง Peak/Off-peak\"},{\"priority\":2,\"title\":\"กระจายโหลด 3 เฟส\",\"description\":\"สมดุล L1/L2/L3 ลดความเครียดสายและเบรกเกอร์\"},{\"priority\":3,\"title\":\"ติดตามอย่างต่อเนื่อง\",\"description\":\"ใช้ระบบ GE IoT ติดตามแนวโน้ม\"}],\"actionPlan\":[{\"horizon\":\"ทันที (0–30 วัน)\",\"items\":[\"ตรวจการโหลดแต่ละเฟส\"]},{\"horizon\":\"ระยะสั้น (1–3 เดือน)\",\"items\":[\"ติดตั้งระบบ GE Energy Tech หาก PF < 0.95 หรือมี Peak/ไม่สมดุล\",\"กระจายโหลดเฟสเดียว\"]},{\"horizon\":\"ระยะกลาง (3–12 เดือน)\",\"items\":[\"ประเมิน Harmonic filter\"]},{\"horizon\":\"ระยะยาว (1–3 ปี)\",\"items\":[\"ติดตาม IoT ต่อเนื่อง\",\"ตรวจพลังงานประจำปี\"]}],\"conclusion\":[{\"label\":\"ปัญหาปัจจุบัน\",\"value\":\"Current Imbalance %: 23.2%; Power Factor เฉลี่ย: 0.90; THDI เฉลี่ย: 10.1%\"},{\"label\":\"ความเสี่ยงทางเทคนิค\",\"value\":\"วิกฤต (Critical)\"},{\"label\":\"ผลกระทบทางการเงิน\",\"value\":\"53,213 บาท/เดือน\"},{\"label\":\"แนวทางแนะนำ\",\"value\":\"ติดตั้งระบบ GE Energy Tech Smart Saving\"},{\"label\":\"ประหยัดที่คาดหวัง\",\"value\":\"6,056 บาท/เดือน\"},{\"label\":\"ระยะคืนทุน\",\"value\":\"11.0 เดือน (0.9 ปี) · เยี่ยม\"},{\"label\":\"ขั้นตอนถัดไป\",\"value\":\"ทบทวนกับลูกค้าและอนุมัติแผน\"}],\"phaseTable\":[{\"phase\":\"L1\",\"ch1\":\"27.88\",\"ch2\":\"—\",\"analysis\":\"เฟส L1 เฉลี่ย 27.88 — สูงกว่าค่าเฉลี่ยรวม N (26.19) 6.5% · รับโหลดมากที่สุดใน 3 เฟส\"},{\"phase\":\"L2\",\"ch1\":\"25.71\",\"ch2\":\"—\",\"analysis\":\"เฟส L2 เฉลี่ย 25.71 — ต่ำกว่าค่าเฉลี่ยรวม N (26.19) 1.8%\"},{\"phase\":\"L3\",\"ch1\":\"24.97\",\"ch2\":\"—\",\"analysis\":\"เฟส L3 เฉลี่ย 24.97 — ต่ำกว่าค่าเฉลี่ยรวม N (26.19) 4.7% · โหลดเบาที่สุดใน 3 เฟส\"},{\"phase\":\"เฉลี่ย N\",\"ch1\":\"26.19\",\"ch2\":\"—\",\"analysis\":\"ค่าเฉลี่ยรวม N 26.19 — ความไม่สมดุลกระแส 11.1% · เฟสสูงสุด L1 27.88 · เฟสต่ำสุด L3 24.97\"}],\"professional\":{\"reportSubtitle\":\"รายงานวิเคราะห์คุณภาพไฟฟ้าและประสิทธิภาพพลังงาน · 4/6/2569 20:32:35 – 5/6/2569 20:27:35 · 288 บันทึก @ เรียลไทม์ / 1 นาที\",\"keyFindingsIntro\":\"สรุปผลวิเคราะห์หลัก — ระดับความเสี่ยงทางเทคนิค: CRITICAL · ประหยัดได้โดยประมาณ 6,056/เดือน\",\"keyFindings\":[{\"parameter\":\"พลังงานรวม (kWh)\",\"measured\":\"12,670 kWh/mo · ~152,038 kWh/yr\",\"standard\":\"—\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"},{\"parameter\":\"Peak Demand 15 นาที\",\"measured\":\"16.70 kW @ 15:42\",\"standard\":\"ตามไซต์\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"},{\"parameter\":\"Load Factor\",\"measured\":\"86.1%\",\"standard\":\"≥ 60% แนะนำ\",\"assessment\":\"excellent\",\"assessmentLabel\":\"✓ ดีเยี่ยม\"},{\"parameter\":\"Power Factor เฉลี่ย\",\"measured\":\"0.901 (Lagging)\",\"standard\":\"≥ 0.95\",\"assessment\":\"caution\",\"assessmentLabel\":\"△ ควรระวัง\"},{\"parameter\":\"Voltage Imbalance %\",\"measured\":\"0.45%\",\"standard\":\"< 2% IEC\",\"assessment\":\"excellent\",\"assessmentLabel\":\"✓ ดีเยี่ยม\"},{\"parameter\":\"Current Imbalance %\",\"measured\":\"23.20%\",\"standard\":\"< 5% IEC\",\"assessment\":\"warning\",\"assessmentLabel\":\"⚠ เตือน\"},{\"parameter\":\"THDI เฉลี่ย\",\"measured\":\"10.1%\",\"standard\":\"< 5% IEC 61000\",\"assessment\":\"caution\",\"assessmentLabel\":\"△ ควรระวัง\"},{\"parameter\":\"THDV เฉลี่ย\",\"measured\":\"—\",\"standard\":\"< 5% IEC\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"}],\"executiveNarrative\":[\"รายงานนี้วิเคราะห์คุณภาพไฟฟ้าและประสิทธิภาพพลังงานจากข้อมูล 288 บันทึก (เรียลไทม์ / 1 นาที) ในช่วง 4/6/2569 20:32:35 – 5/6/2569 20:27:35\",\"Power Factor เฉลี่ย 0.901 — 0.0% ของเวลาอยู่ต่ำกว่าเกณฑ์ค่าปรับ MEA (0.85) · THDI เฉลี่ย 10.1% — เหมาะสำหรับ APFC แบบ de-tuned\",\"Current Imbalance เฉลี่ย 23.20% — สูงกว่าเกณฑ์ IEC · L1 รับโหลด 35.5% (เกินค่า ideal 33.3%)\",\"Peak Demand 15 นาที 16.70 kW ที่ 15:42 — สูงกว่าเฉลี่ย ~1.2× · ข้อมูลความละเอียด 1 นาทีต่างจาก hourly ~45%\"],\"interpretationTitle\":\"การตีความ (Interpretation)\",\"interpretationBullets\":[\"Current Imbalance 23.20% — L1 รับโหลด 35.5% · ควรกระจายโหลด 3 เฟสเพื่อลดความเครียด thermal\",\"PF 0.901 ที่สเกลพลังงาน ~152,038 kWh/ปี — ปรับ PF ให้ ≥ 0.95 คืนทุน 11.0 เดือน (0.9 ปี) · เยี่ยม\",\"THDI 10.1% — ติดตั้ง de-tuned APFC (5.7% reactor) ปลอดภัย ไม่เสี่ยง resonance\",\"Voltage Imbalance 0.45% — คุณภาพแรงดันดี ปัญหาอยู่ที่โหลดและการบริหาร Demand\"],\"phasedTitle\":\"คำแนะนำเชิงปฏิบัติ (Phased Recommendations)\",\"phasedRecommendations\":[{\"phase\":\"Phase 1\",\"title\":\"ติดตั้ง De-tuned APFC — ROI สูงสุด\",\"priority\":\"ลำดับความสำคัญสูงสุด\",\"bullets\":[\"THDI 10.1% — ติดตั้ง APFC + reactor de-tuning 5.7% ปลอดภัย\",\"จัดอ ratings จาก Peak 16.70 kW · กระแสเฉลี่ย L1 26.19 A\"],\"expectedOutcome\":\"PF 0.901 → ≥ 0.95 · ลดค่าปรับ MEA · คืนทุน 11.0 เดือน (0.9 ปี) · เยี่ยม\"},{\"phase\":\"Phase 2\",\"title\":\"กระจายโหลด 3 เฟส\",\"priority\":\"ลำดับความสำคัญสูง\",\"bullets\":[\"ย้ายวงจร AC/ครัวจาก L1 ไป L3 ให้ L1 ≤ 35%, L3 ≥ 32%\",\"ลด transient imbalance ตอน compressor cycle on\"],\"expectedOutcome\":\"CI 23.20% → < 10% · ลด thermal stress มอเตอร์และสาย\"},{\"phase\":\"Phase 4\",\"title\":\"ตรวจสอบและแจ้งเตือนประจำปี\",\"priority\":\"ลำดับความสำคัญปานกลาง\",\"bullets\":[\"Thermographic inspection ที่ main panel L1 เป็นประจำ\",\"ตั้ง alarm: PF < 0.85 · CI > 15%\"],\"expectedOutcome\":\"ป้องกันความเสียหายจาก overload และ imbalance สะสม\"}],\"peakPercentiles\":[{\"label\":\"P50\",\"value\":\"16.05 kW\",\"line\":\"P50  16.05 kW\",\"hint\":\"ค่ามัธยฐาน — 50% ของเวลาโหลดต่ำกว่านี้\"},{\"label\":\"P75\",\"value\":\"16.70 kW\",\"line\":\"P75  16.70 kW\",\"hint\":\"โหลดสูงกว่าปกติ — 25% ของเวลาสูงกว่านี้\"},{\"label\":\"P90\",\"value\":\"17.38 kW\",\"line\":\"P90  17.38 kW\",\"hint\":\"โหลดสูง — เกินค่านี้แค่ 10% ของเวลา\"},{\"label\":\"P95\",\"value\":\"17.87 kW\",\"line\":\"P95  17.87 kW\",\"hint\":\"โหลดสูงมาก — เกินค่านี้แค่ 5% ของเวลา\"},{\"label\":\"P99\",\"value\":\"18.32 kW\",\"line\":\"P99  18.32 kW\",\"hint\":\"ใกล้ Peak สูงสุด — เกินค่านี้แค่ 1% ของเวลา\"}],\"peakPercentileCaption\":\"สถิติ Peak Demand (Percentile)\",\"imbalanceExceedance\":[{\"threshold\":\"> 10% (เตือน)\",\"pct\":\"82.6%\",\"liveStatus\":\"เตือน (Warning)\",\"liveLevel\":\"warning\",\"liveImbDisplay\":\"23.2%\"},{\"threshold\":\"> 20% (เสี่ยงสูง)\",\"pct\":\"50.3%\",\"liveStatus\":\"ความเสี่ยงสูง\",\"liveLevel\":\"critical\",\"liveImbDisplay\":\"23.2%\"},{\"threshold\":\"> 50% (รุนแรง)\",\"pct\":\"0.0%\",\"liveStatus\":\"✓ ปกติ\",\"liveLevel\":\"good\",\"liveImbDisplay\":\"23.2%\"}],\"imbalanceExceedanceCaption\":\"สัดส่วนเวลาที่ Current Imbalance เกินเกณฑ์\",\"loadProfileNarrative\":null,\"overallTechnicalRisk\":\"CRITICAL\",\"recommendedModel\":\"50 kVA\"}}','2026-06-06 17:39:25.490751'),
(7,1,7,1,NULL,NULL,30.41,86.10,NULL,23.20,0.40,10.120,NULL,'critical',30.41,NULL,1.080,NULL,NULL,NULL,'{\"reportId\":\"GE-EQ-1-20260606-003\",\"reportDate\":\"6/6/2569 15:39:45\",\"lastUpdate\":\"5/6/2569 20:27:35\",\"overallRisk\":\"critical\",\"overallRiskLabel\":\"วิกฤต (Critical)\",\"harmonicRisk\":\"caution\",\"harmonicRiskLabel\":\"ระวัง\",\"statusMetrics\":{\"pf\":0.901,\"thd\":10.116,\"currentImbalance\":23.199716211422487,\"voltageImbalance\":0.44727263640983006},\"customer\":[{\"label\":\"รหัสรายงาน\",\"value\":\"GE-EQ-1-20260606-003\"},{\"label\":\"ชื่อลูกค้า\",\"value\":\"GE Energy\"},{\"label\":\"ชื่อไซต์\",\"value\":\"GE01\"},{\"label\":\"โลเคชั่น\",\"value\":\"KOREA\"},{\"label\":\"ประเภทธุรกิจ\",\"value\":\"Electronics / Factory\"},{\"label\":\"ผู้ติดต่อ\",\"value\":\"010-8105-0384\"},{\"label\":\"ช่วงการวัด\",\"value\":\"4/6/2569 20:32:35 – 5/6/2569 20:27:35\"},{\"label\":\"วันที่จัดทำรายงาน\",\"value\":\"6/6/2569 15:39:45\"},{\"label\":\"ผู้จัดทำ\",\"value\":\"GE Energy Tech\"}],\"measurement\":[{\"label\":\"Meter ID\",\"value\":\"GE-KR-0004\"},{\"label\":\"Gateway ID\",\"value\":\"192.168.1.46\"},{\"label\":\"จุดตรวจวัด\",\"value\":\"GE Smart Power Meter · CH1 (ก่อนติดตั้ง)\"},{\"label\":\"ระบบแรงดัน\",\"value\":\"3-Phase 400V\"},{\"label\":\"ขนาดเบรกเกอร์\",\"value\":\"40 A\"},{\"label\":\"ขนาดเครื่องที่แนะนำติดตั้ง\",\"value\":\"50 kVA\"},{\"label\":\"ความละเอียดข้อมูล\",\"value\":\"เรียลไทม์ / 1 นาที\"},{\"label\":\"จำนวนบันทึก\",\"value\":\"288\"},{\"label\":\"เริ่มวัด\",\"value\":\"4/6/2569 20:32:35\"},{\"label\":\"สิ้นสุดวัด\",\"value\":\"5/6/2569 20:27:35\"}],\"executive\":[{\"label\":\"พลังงานรวม (kWh)\",\"value\":\"12,051.44 kWh\"},{\"label\":\"กระแสเฉลี่ย (A)\",\"value\":\"28.19 A\"},{\"label\":\"Peak Demand (A)\",\"value\":\"30.41 A\"},{\"label\":\"Load Factor\",\"value\":\"86.1%\"},{\"label\":\"Power Factor เฉลี่ย\",\"value\":\"0.90\"},{\"label\":\"Current Imbalance %\",\"value\":\"23.2%\"},{\"label\":\"Voltage Imbalance %\",\"value\":\"0.4%\"},{\"label\":\"THDI เฉลี่ย\",\"value\":\"10.12%\"},{\"label\":\"THDV เฉลี่ย\",\"value\":\"—\"},{\"label\":\"ระดับความเสี่ยงรวม\",\"value\":\"วิกฤต (Critical)\"}],\"executiveBullets\":[\"พลังงานสะสม 12,051.44 kWh จากมิเตอร์\",\"กระแสเฉลี่ย CH1: 28.19 A\",\"Peak Demand สูงสุด: 30.41 A @ 15:42 · 15:00–16:00\",\"Load Factor: 86.1%\",\"Power Factor เฉลี่ย: 0.90\",\"ความไม่สมดุลกระแส: 23.2%\",\"ระดับความเสี่ยงรวม: วิกฤต (Critical)\",\"แนวทาง GE Energy Tech: ปรับแรงดัน · ปรับกระแส · ปรับเสถียร · เก็บกระแสไว้ใช้ภายหลัง\"],\"executiveKpis\":[{\"label\":\"พลังงานรวม (kWh)\",\"value\":\"12,051.44 kWh\"},{\"label\":\"กระแสเฉลี่ย (A)\",\"value\":\"28.19 A\"},{\"label\":\"Peak Demand (A)\",\"value\":\"30.41 A\"},{\"label\":\"ระดับความเสี่ยงรวม\",\"value\":\"วิกฤต (Critical)\"}],\"energy\":[{\"label\":\"พลังงานรวม (kWh)\",\"value\":\"12,051.44 kWh\"},{\"label\":\"พลังงานเฉลี่ยรายวัน (kWh)\",\"value\":\"422.33 kWh\"},{\"label\":\"ประมาณการรายเดือน (kWh)\",\"value\":\"12,669.84 kWh\"},{\"label\":\"ประมาณการรายปี (kWh)\",\"value\":\"152,038.08 kWh\"},{\"label\":\"ค่าไฟโดยประมาณ/เดือน\",\"value\":\"53,213 บาท\"}],\"peak\":[{\"label\":\"Peak Demand 15 นาที\",\"value\":\"30.41 A\"},{\"label\":\"เวลา Peak\",\"value\":\"15:42\"},{\"label\":\"ช่วงเวลา Peak\",\"value\":\"15:00–16:00\"},{\"label\":\"ช่วงโหลดสูง\",\"value\":\"—\"},{\"label\":\"On-peak เฉลี่ย\",\"value\":\"26.18 A\"},{\"label\":\"Off-peak เฉลี่ย\",\"value\":\"26.19 A\"},{\"label\":\"กระแสเฉลี่ย (A)\",\"value\":\"28.19 A\"},{\"label\":\"Peak / Average\",\"value\":\"1.08\"},{\"label\":\"ผลกระทบ Demand Charge\",\"value\":\"ดี (Good)\"}],\"powerFactor\":[{\"label\":\"Power Factor เฉลี่ย\",\"value\":\"0.90\"},{\"label\":\"PF ต่ำสุด\",\"value\":\"0.90\"},{\"label\":\"เวลาที่ PF ต่ำกว่า 0.95\",\"value\":\"เตือน (Warning)\"},{\"label\":\"ค่าปรับ PF (ประมาณ)\",\"value\":\"3,911 บาท\"},{\"label\":\"แนะนำ APFC\",\"value\":\"แนะนำระบบ GE Energy Tech (ปรับแรงดัน·กระแส·เสถียร·เก็บพลังงาน)\"}],\"balance\":[{\"label\":\"กระแส L1\",\"value\":\"32.47 A\"},{\"label\":\"กระแส L2\",\"value\":\"25.93 A\"},{\"label\":\"กระแส L3\",\"value\":\"26.17 A\"},{\"label\":\"สัดส่วนกำลัง L1\",\"value\":\"38.4%\"},{\"label\":\"สัดส่วนกำลัง L2\",\"value\":\"30.7%\"},{\"label\":\"สัดส่วนกำลัง L3\",\"value\":\"30.9%\"},{\"label\":\"Current Imbalance %\",\"value\":\"23.2%\"},{\"label\":\"Voltage Imbalance %\",\"value\":\"0.4%\"}],\"harmonic\":[{\"label\":\"THDI L1\",\"value\":\"10.12%\"},{\"label\":\"THDI L2\",\"value\":\"10.12%\"},{\"label\":\"THDI L3\",\"value\":\"10.12%\"},{\"label\":\"THDI เฉลี่ย\",\"value\":\"10.12%\"},{\"label\":\"THDV L1\",\"value\":\"—\"},{\"label\":\"THDV L2\",\"value\":\"—\"},{\"label\":\"THDV L3\",\"value\":\"—\"},{\"label\":\"THDV เฉลี่ย\",\"value\":\"—\"},{\"label\":\"ระดับความเสี่ยง Harmonic\",\"value\":\"ระวัง\"}],\"equipment\":[{\"label\":\"มอเตอร์ / คอมเพรสเซอร์\",\"value\":\"วิกฤต (Critical)\"},{\"label\":\"เมนเบรกเกอร์ / สายเคเบิล\",\"value\":\"ดี (Good)\"},{\"label\":\"หม้อแปลง\",\"value\":\"ดี (Good)\"},{\"label\":\"การบำรุงรักษา\",\"value\":\"ตรวจ Thermographic หาก imbalance > 20%\"}],\"financial\":[{\"label\":\"ค่าไฟโดยประมาณ/เดือน\",\"value\":\"53,213 บาท\"},{\"label\":\"ค่าปรับ PF (ประมาณ)\",\"value\":\"3,911 บาท\"},{\"label\":\"ประหยัดได้/เดือน\",\"value\":\"6,056 บาท\"},{\"label\":\"ประหยัดรายปี\",\"value\":\"72,668 บาท\"}],\"roi\":[{\"label\":\"แนวทางแก้ไข\",\"value\":\"GE Energy Tech Smart Saving System\"},{\"label\":\"เงินลงทุน\",\"value\":\"66,340 บาท\"},{\"label\":\"ประหยัดได้/เดือน\",\"value\":\"6,056 บาท/เดือน\"},{\"label\":\"ระยะคืนทุน\",\"value\":\"11.0 เดือน (0.9 ปี) · เยี่ยม\"},{\"label\":\"ROI %\",\"value\":\"110%\"}],\"recommendations\":[{\"priority\":1,\"title\":\"ติดตั้งระบบ GE Energy Tech Smart Saving\",\"description\":\"เปรียบเทียบก่อนติดตั้ง — ระบบปรับแรงดัน ปรับกระแส 3 เฟส ปรับเสถียรลดฮาร์มอนิก และเก็บกระแสไฟใช้ช่วง Peak/Off-peak\"},{\"priority\":2,\"title\":\"กระจายโหลด 3 เฟส\",\"description\":\"สมดุล L1/L2/L3 ลดความเครียดสายและเบรกเกอร์\"},{\"priority\":3,\"title\":\"ติดตามอย่างต่อเนื่อง\",\"description\":\"ใช้ระบบ GE IoT ติดตามแนวโน้ม\"}],\"actionPlan\":[{\"horizon\":\"ทันที (0–30 วัน)\",\"items\":[\"ตรวจการโหลดแต่ละเฟส\"]},{\"horizon\":\"ระยะสั้น (1–3 เดือน)\",\"items\":[\"ติดตั้งระบบ GE Energy Tech หาก PF < 0.95 หรือมี Peak/ไม่สมดุล\",\"กระจายโหลดเฟสเดียว\"]},{\"horizon\":\"ระยะกลาง (3–12 เดือน)\",\"items\":[\"ประเมิน Harmonic filter\"]},{\"horizon\":\"ระยะยาว (1–3 ปี)\",\"items\":[\"ติดตาม IoT ต่อเนื่อง\",\"ตรวจพลังงานประจำปี\"]}],\"conclusion\":[{\"label\":\"ปัญหาปัจจุบัน\",\"value\":\"Current Imbalance %: 23.2%; Power Factor เฉลี่ย: 0.90; THDI เฉลี่ย: 10.1%\"},{\"label\":\"ความเสี่ยงทางเทคนิค\",\"value\":\"วิกฤต (Critical)\"},{\"label\":\"ผลกระทบทางการเงิน\",\"value\":\"53,213 บาท/เดือน\"},{\"label\":\"แนวทางแนะนำ\",\"value\":\"ติดตั้งระบบ GE Energy Tech Smart Saving\"},{\"label\":\"ประหยัดที่คาดหวัง\",\"value\":\"6,056 บาท/เดือน\"},{\"label\":\"ระยะคืนทุน\",\"value\":\"11.0 เดือน (0.9 ปี) · เยี่ยม\"},{\"label\":\"ขั้นตอนถัดไป\",\"value\":\"ทบทวนกับลูกค้าและอนุมัติแผน\"}],\"phaseTable\":[{\"phase\":\"L1\",\"ch1\":\"27.88\",\"ch2\":\"—\",\"analysis\":\"เฟส L1 เฉลี่ย 27.88 — สูงกว่าค่าเฉลี่ยรวม N (26.19) 6.5% · รับโหลดมากที่สุดใน 3 เฟส\"},{\"phase\":\"L2\",\"ch1\":\"25.71\",\"ch2\":\"—\",\"analysis\":\"เฟส L2 เฉลี่ย 25.71 — ต่ำกว่าค่าเฉลี่ยรวม N (26.19) 1.8%\"},{\"phase\":\"L3\",\"ch1\":\"24.97\",\"ch2\":\"—\",\"analysis\":\"เฟส L3 เฉลี่ย 24.97 — ต่ำกว่าค่าเฉลี่ยรวม N (26.19) 4.7% · โหลดเบาที่สุดใน 3 เฟส\"},{\"phase\":\"เฉลี่ย N\",\"ch1\":\"26.19\",\"ch2\":\"—\",\"analysis\":\"ค่าเฉลี่ยรวม N 26.19 — ความไม่สมดุลกระแส 11.1% · เฟสสูงสุด L1 27.88 · เฟสต่ำสุด L3 24.97\"}],\"professional\":{\"reportSubtitle\":\"รายงานวิเคราะห์คุณภาพไฟฟ้าและประสิทธิภาพพลังงาน · 4/6/2569 20:32:35 – 5/6/2569 20:27:35 · 288 บันทึก @ เรียลไทม์ / 1 นาที\",\"keyFindingsIntro\":\"สรุปผลวิเคราะห์หลัก — ระดับความเสี่ยงทางเทคนิค: CRITICAL · ประหยัดได้โดยประมาณ 6,056/เดือน\",\"keyFindings\":[{\"parameter\":\"พลังงานรวม (kWh)\",\"measured\":\"12,670 kWh/mo · ~152,038 kWh/yr\",\"standard\":\"—\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"},{\"parameter\":\"Peak Demand 15 นาที\",\"measured\":\"16.70 kW @ 15:42\",\"standard\":\"ตามไซต์\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"},{\"parameter\":\"Load Factor\",\"measured\":\"86.1%\",\"standard\":\"≥ 60% แนะนำ\",\"assessment\":\"excellent\",\"assessmentLabel\":\"✓ ดีเยี่ยม\"},{\"parameter\":\"Power Factor เฉลี่ย\",\"measured\":\"0.901 (Lagging)\",\"standard\":\"≥ 0.95\",\"assessment\":\"caution\",\"assessmentLabel\":\"△ ควรระวัง\"},{\"parameter\":\"Voltage Imbalance %\",\"measured\":\"0.45%\",\"standard\":\"< 2% IEC\",\"assessment\":\"excellent\",\"assessmentLabel\":\"✓ ดีเยี่ยม\"},{\"parameter\":\"Current Imbalance %\",\"measured\":\"23.20%\",\"standard\":\"< 5% IEC\",\"assessment\":\"warning\",\"assessmentLabel\":\"⚠ เตือน\"},{\"parameter\":\"THDI เฉลี่ย\",\"measured\":\"10.1%\",\"standard\":\"< 5% IEC 61000\",\"assessment\":\"caution\",\"assessmentLabel\":\"△ ควรระวัง\"},{\"parameter\":\"THDV เฉลี่ย\",\"measured\":\"—\",\"standard\":\"< 5% IEC\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"}],\"executiveNarrative\":[\"รายงานนี้วิเคราะห์คุณภาพไฟฟ้าและประสิทธิภาพพลังงานจากข้อมูล 288 บันทึก (เรียลไทม์ / 1 นาที) ในช่วง 4/6/2569 20:32:35 – 5/6/2569 20:27:35\",\"Power Factor เฉลี่ย 0.901 — 0.0% ของเวลาอยู่ต่ำกว่าเกณฑ์ค่าปรับ MEA (0.85) · THDI เฉลี่ย 10.1% — เหมาะสำหรับ APFC แบบ de-tuned\",\"Current Imbalance เฉลี่ย 23.20% — สูงกว่าเกณฑ์ IEC · L1 รับโหลด 35.5% (เกินค่า ideal 33.3%)\",\"Peak Demand 15 นาที 16.70 kW ที่ 15:42 — สูงกว่าเฉลี่ย ~1.2× · ข้อมูลความละเอียด 1 นาทีต่างจาก hourly ~45%\"],\"interpretationTitle\":\"การตีความ (Interpretation)\",\"interpretationBullets\":[\"Current Imbalance 23.20% — L1 รับโหลด 35.5% · ควรกระจายโหลด 3 เฟสเพื่อลดความเครียด thermal\",\"PF 0.901 ที่สเกลพลังงาน ~152,038 kWh/ปี — ปรับ PF ให้ ≥ 0.95 คืนทุน 11.0 เดือน (0.9 ปี) · เยี่ยม\",\"THDI 10.1% — ติดตั้ง de-tuned APFC (5.7% reactor) ปลอดภัย ไม่เสี่ยง resonance\",\"Voltage Imbalance 0.45% — คุณภาพแรงดันดี ปัญหาอยู่ที่โหลดและการบริหาร Demand\"],\"phasedTitle\":\"คำแนะนำเชิงปฏิบัติ (Phased Recommendations)\",\"phasedRecommendations\":[{\"phase\":\"Phase 1\",\"title\":\"ติดตั้ง De-tuned APFC — ROI สูงสุด\",\"priority\":\"ลำดับความสำคัญสูงสุด\",\"bullets\":[\"THDI 10.1% — ติดตั้ง APFC + reactor de-tuning 5.7% ปลอดภัย\",\"จัดอ ratings จาก Peak 16.70 kW · กระแสเฉลี่ย L1 26.19 A\"],\"expectedOutcome\":\"PF 0.901 → ≥ 0.95 · ลดค่าปรับ MEA · คืนทุน 11.0 เดือน (0.9 ปี) · เยี่ยม\"},{\"phase\":\"Phase 2\",\"title\":\"กระจายโหลด 3 เฟส\",\"priority\":\"ลำดับความสำคัญสูง\",\"bullets\":[\"ย้ายวงจร AC/ครัวจาก L1 ไป L3 ให้ L1 ≤ 35%, L3 ≥ 32%\",\"ลด transient imbalance ตอน compressor cycle on\"],\"expectedOutcome\":\"CI 23.20% → < 10% · ลด thermal stress มอเตอร์และสาย\"},{\"phase\":\"Phase 4\",\"title\":\"ตรวจสอบและแจ้งเตือนประจำปี\",\"priority\":\"ลำดับความสำคัญปานกลาง\",\"bullets\":[\"Thermographic inspection ที่ main panel L1 เป็นประจำ\",\"ตั้ง alarm: PF < 0.85 · CI > 15%\"],\"expectedOutcome\":\"ป้องกันความเสียหายจาก overload และ imbalance สะสม\"}],\"peakPercentiles\":[{\"label\":\"P50\",\"value\":\"16.05 kW\",\"line\":\"P50  16.05 kW\",\"hint\":\"ค่ามัธยฐาน — 50% ของเวลาโหลดต่ำกว่านี้\"},{\"label\":\"P75\",\"value\":\"16.70 kW\",\"line\":\"P75  16.70 kW\",\"hint\":\"โหลดสูงกว่าปกติ — 25% ของเวลาสูงกว่านี้\"},{\"label\":\"P90\",\"value\":\"17.38 kW\",\"line\":\"P90  17.38 kW\",\"hint\":\"โหลดสูง — เกินค่านี้แค่ 10% ของเวลา\"},{\"label\":\"P95\",\"value\":\"17.87 kW\",\"line\":\"P95  17.87 kW\",\"hint\":\"โหลดสูงมาก — เกินค่านี้แค่ 5% ของเวลา\"},{\"label\":\"P99\",\"value\":\"18.32 kW\",\"line\":\"P99  18.32 kW\",\"hint\":\"ใกล้ Peak สูงสุด — เกินค่านี้แค่ 1% ของเวลา\"}],\"peakPercentileCaption\":\"สถิติ Peak Demand (Percentile)\",\"imbalanceExceedance\":[{\"threshold\":\"> 10% (เตือน)\",\"pct\":\"82.6%\",\"liveStatus\":\"เตือน (Warning)\",\"liveLevel\":\"warning\",\"liveImbDisplay\":\"23.2%\"},{\"threshold\":\"> 20% (เสี่ยงสูง)\",\"pct\":\"50.3%\",\"liveStatus\":\"ความเสี่ยงสูง\",\"liveLevel\":\"critical\",\"liveImbDisplay\":\"23.2%\"},{\"threshold\":\"> 50% (รุนแรง)\",\"pct\":\"0.0%\",\"liveStatus\":\"✓ ปกติ\",\"liveLevel\":\"good\",\"liveImbDisplay\":\"23.2%\"}],\"imbalanceExceedanceCaption\":\"สัดส่วนเวลาที่ Current Imbalance เกินเกณฑ์\",\"loadProfileNarrative\":null,\"overallTechnicalRisk\":\"CRITICAL\",\"recommendedModel\":\"50 kVA\"}}','2026-06-06 17:39:45.796892'),
(8,1,8,1,NULL,NULL,30.41,86.10,NULL,23.20,0.40,10.120,NULL,'critical',30.41,NULL,1.080,NULL,NULL,NULL,'{\"reportId\":\"GE-EQ-1-20260606-004\",\"reportDate\":\"6/6/2569 15:40:04\",\"lastUpdate\":\"5/6/2569 20:27:35\",\"overallRisk\":\"critical\",\"overallRiskLabel\":\"วิกฤต (Critical)\",\"harmonicRisk\":\"caution\",\"harmonicRiskLabel\":\"ระวัง\",\"statusMetrics\":{\"pf\":0.901,\"thd\":10.116,\"currentImbalance\":23.199716211422487,\"voltageImbalance\":0.44727263640983006},\"customer\":[{\"label\":\"รหัสรายงาน\",\"value\":\"GE-EQ-1-20260606-004\"},{\"label\":\"ชื่อลูกค้า\",\"value\":\"GE Energy\"},{\"label\":\"ชื่อไซต์\",\"value\":\"GE01\"},{\"label\":\"โลเคชั่น\",\"value\":\"KOREA\"},{\"label\":\"ประเภทธุรกิจ\",\"value\":\"Electronics / Factory\"},{\"label\":\"ผู้ติดต่อ\",\"value\":\"010-8105-0384\"},{\"label\":\"ช่วงการวัด\",\"value\":\"4/6/2569 20:32:35 – 5/6/2569 20:27:35\"},{\"label\":\"วันที่จัดทำรายงาน\",\"value\":\"6/6/2569 15:40:04\"},{\"label\":\"ผู้จัดทำ\",\"value\":\"GE Energy Tech\"}],\"measurement\":[{\"label\":\"Meter ID\",\"value\":\"GE-KR-0004\"},{\"label\":\"Gateway ID\",\"value\":\"192.168.1.46\"},{\"label\":\"จุดตรวจวัด\",\"value\":\"GE Smart Power Meter · CH1 (ก่อนติดตั้ง)\"},{\"label\":\"ระบบแรงดัน\",\"value\":\"3-Phase 400V\"},{\"label\":\"ขนาดเบรกเกอร์\",\"value\":\"40 A\"},{\"label\":\"ขนาดเครื่องที่แนะนำติดตั้ง\",\"value\":\"50 kVA\"},{\"label\":\"ความละเอียดข้อมูล\",\"value\":\"เรียลไทม์ / 1 นาที\"},{\"label\":\"จำนวนบันทึก\",\"value\":\"288\"},{\"label\":\"เริ่มวัด\",\"value\":\"4/6/2569 20:32:35\"},{\"label\":\"สิ้นสุดวัด\",\"value\":\"5/6/2569 20:27:35\"}],\"executive\":[{\"label\":\"พลังงานรวม (kWh)\",\"value\":\"12,051.44 kWh\"},{\"label\":\"กระแสเฉลี่ย (A)\",\"value\":\"28.19 A\"},{\"label\":\"Peak Demand (A)\",\"value\":\"30.41 A\"},{\"label\":\"Load Factor\",\"value\":\"86.1%\"},{\"label\":\"Power Factor เฉลี่ย\",\"value\":\"0.90\"},{\"label\":\"Current Imbalance %\",\"value\":\"23.2%\"},{\"label\":\"Voltage Imbalance %\",\"value\":\"0.4%\"},{\"label\":\"THDI เฉลี่ย\",\"value\":\"10.12%\"},{\"label\":\"THDV เฉลี่ย\",\"value\":\"—\"},{\"label\":\"ระดับความเสี่ยงรวม\",\"value\":\"วิกฤต (Critical)\"}],\"executiveBullets\":[\"พลังงานสะสม 12,051.44 kWh จากมิเตอร์\",\"กระแสเฉลี่ย CH1: 28.19 A\",\"Peak Demand สูงสุด: 30.41 A @ 15:42 · 15:00–16:00\",\"Load Factor: 86.1%\",\"Power Factor เฉลี่ย: 0.90\",\"ความไม่สมดุลกระแส: 23.2%\",\"ระดับความเสี่ยงรวม: วิกฤต (Critical)\",\"แนวทาง GE Energy Tech: ปรับแรงดัน · ปรับกระแส · ปรับเสถียร · เก็บกระแสไว้ใช้ภายหลัง\"],\"executiveKpis\":[{\"label\":\"พลังงานรวม (kWh)\",\"value\":\"12,051.44 kWh\"},{\"label\":\"กระแสเฉลี่ย (A)\",\"value\":\"28.19 A\"},{\"label\":\"Peak Demand (A)\",\"value\":\"30.41 A\"},{\"label\":\"ระดับความเสี่ยงรวม\",\"value\":\"วิกฤต (Critical)\"}],\"energy\":[{\"label\":\"พลังงานรวม (kWh)\",\"value\":\"12,051.44 kWh\"},{\"label\":\"พลังงานเฉลี่ยรายวัน (kWh)\",\"value\":\"422.33 kWh\"},{\"label\":\"ประมาณการรายเดือน (kWh)\",\"value\":\"12,669.84 kWh\"},{\"label\":\"ประมาณการรายปี (kWh)\",\"value\":\"152,038.08 kWh\"},{\"label\":\"ค่าไฟโดยประมาณ/เดือน\",\"value\":\"53,213 บาท\"}],\"peak\":[{\"label\":\"Peak Demand 15 นาที\",\"value\":\"30.41 A\"},{\"label\":\"เวลา Peak\",\"value\":\"15:42\"},{\"label\":\"ช่วงเวลา Peak\",\"value\":\"15:00–16:00\"},{\"label\":\"ช่วงโหลดสูง\",\"value\":\"—\"},{\"label\":\"On-peak เฉลี่ย\",\"value\":\"26.18 A\"},{\"label\":\"Off-peak เฉลี่ย\",\"value\":\"26.19 A\"},{\"label\":\"กระแสเฉลี่ย (A)\",\"value\":\"28.19 A\"},{\"label\":\"Peak / Average\",\"value\":\"1.08\"},{\"label\":\"ผลกระทบ Demand Charge\",\"value\":\"ดี (Good)\"}],\"powerFactor\":[{\"label\":\"Power Factor เฉลี่ย\",\"value\":\"0.90\"},{\"label\":\"PF ต่ำสุด\",\"value\":\"0.90\"},{\"label\":\"เวลาที่ PF ต่ำกว่า 0.95\",\"value\":\"เตือน (Warning)\"},{\"label\":\"ค่าปรับ PF (ประมาณ)\",\"value\":\"3,911 บาท\"},{\"label\":\"แนะนำ APFC\",\"value\":\"แนะนำระบบ GE Energy Tech (ปรับแรงดัน·กระแส·เสถียร·เก็บพลังงาน)\"}],\"balance\":[{\"label\":\"กระแส L1\",\"value\":\"32.47 A\"},{\"label\":\"กระแส L2\",\"value\":\"25.93 A\"},{\"label\":\"กระแส L3\",\"value\":\"26.17 A\"},{\"label\":\"สัดส่วนกำลัง L1\",\"value\":\"38.4%\"},{\"label\":\"สัดส่วนกำลัง L2\",\"value\":\"30.7%\"},{\"label\":\"สัดส่วนกำลัง L3\",\"value\":\"30.9%\"},{\"label\":\"Current Imbalance %\",\"value\":\"23.2%\"},{\"label\":\"Voltage Imbalance %\",\"value\":\"0.4%\"}],\"harmonic\":[{\"label\":\"THDI L1\",\"value\":\"10.12%\"},{\"label\":\"THDI L2\",\"value\":\"10.12%\"},{\"label\":\"THDI L3\",\"value\":\"10.12%\"},{\"label\":\"THDI เฉลี่ย\",\"value\":\"10.12%\"},{\"label\":\"THDV L1\",\"value\":\"—\"},{\"label\":\"THDV L2\",\"value\":\"—\"},{\"label\":\"THDV L3\",\"value\":\"—\"},{\"label\":\"THDV เฉลี่ย\",\"value\":\"—\"},{\"label\":\"ระดับความเสี่ยง Harmonic\",\"value\":\"ระวัง\"}],\"equipment\":[{\"label\":\"มอเตอร์ / คอมเพรสเซอร์\",\"value\":\"วิกฤต (Critical)\"},{\"label\":\"เมนเบรกเกอร์ / สายเคเบิล\",\"value\":\"ดี (Good)\"},{\"label\":\"หม้อแปลง\",\"value\":\"ดี (Good)\"},{\"label\":\"การบำรุงรักษา\",\"value\":\"ตรวจ Thermographic หาก imbalance > 20%\"}],\"financial\":[{\"label\":\"ค่าไฟโดยประมาณ/เดือน\",\"value\":\"53,213 บาท\"},{\"label\":\"ค่าปรับ PF (ประมาณ)\",\"value\":\"3,911 บาท\"},{\"label\":\"ประหยัดได้/เดือน\",\"value\":\"6,056 บาท\"},{\"label\":\"ประหยัดรายปี\",\"value\":\"72,668 บาท\"}],\"roi\":[{\"label\":\"แนวทางแก้ไข\",\"value\":\"GE Energy Tech Smart Saving System\"},{\"label\":\"เงินลงทุน\",\"value\":\"66,340 บาท\"},{\"label\":\"ประหยัดได้/เดือน\",\"value\":\"6,056 บาท/เดือน\"},{\"label\":\"ระยะคืนทุน\",\"value\":\"11.0 เดือน (0.9 ปี) · เยี่ยม\"},{\"label\":\"ROI %\",\"value\":\"110%\"}],\"recommendations\":[{\"priority\":1,\"title\":\"ติดตั้งระบบ GE Energy Tech Smart Saving\",\"description\":\"เปรียบเทียบก่อนติดตั้ง — ระบบปรับแรงดัน ปรับกระแส 3 เฟส ปรับเสถียรลดฮาร์มอนิก และเก็บกระแสไฟใช้ช่วง Peak/Off-peak\"},{\"priority\":2,\"title\":\"กระจายโหลด 3 เฟส\",\"description\":\"สมดุล L1/L2/L3 ลดความเครียดสายและเบรกเกอร์\"},{\"priority\":3,\"title\":\"ติดตามอย่างต่อเนื่อง\",\"description\":\"ใช้ระบบ GE IoT ติดตามแนวโน้ม\"}],\"actionPlan\":[{\"horizon\":\"ทันที (0–30 วัน)\",\"items\":[\"ตรวจการโหลดแต่ละเฟส\"]},{\"horizon\":\"ระยะสั้น (1–3 เดือน)\",\"items\":[\"ติดตั้งระบบ GE Energy Tech หาก PF < 0.95 หรือมี Peak/ไม่สมดุล\",\"กระจายโหลดเฟสเดียว\"]},{\"horizon\":\"ระยะกลาง (3–12 เดือน)\",\"items\":[\"ประเมิน Harmonic filter\"]},{\"horizon\":\"ระยะยาว (1–3 ปี)\",\"items\":[\"ติดตาม IoT ต่อเนื่อง\",\"ตรวจพลังงานประจำปี\"]}],\"conclusion\":[{\"label\":\"ปัญหาปัจจุบัน\",\"value\":\"Current Imbalance %: 23.2%; Power Factor เฉลี่ย: 0.90; THDI เฉลี่ย: 10.1%\"},{\"label\":\"ความเสี่ยงทางเทคนิค\",\"value\":\"วิกฤต (Critical)\"},{\"label\":\"ผลกระทบทางการเงิน\",\"value\":\"53,213 บาท/เดือน\"},{\"label\":\"แนวทางแนะนำ\",\"value\":\"ติดตั้งระบบ GE Energy Tech Smart Saving\"},{\"label\":\"ประหยัดที่คาดหวัง\",\"value\":\"6,056 บาท/เดือน\"},{\"label\":\"ระยะคืนทุน\",\"value\":\"11.0 เดือน (0.9 ปี) · เยี่ยม\"},{\"label\":\"ขั้นตอนถัดไป\",\"value\":\"ทบทวนกับลูกค้าและอนุมัติแผน\"}],\"phaseTable\":[{\"phase\":\"L1\",\"ch1\":\"27.88\",\"ch2\":\"—\",\"analysis\":\"เฟส L1 เฉลี่ย 27.88 — สูงกว่าค่าเฉลี่ยรวม N (26.19) 6.5% · รับโหลดมากที่สุดใน 3 เฟส\"},{\"phase\":\"L2\",\"ch1\":\"25.71\",\"ch2\":\"—\",\"analysis\":\"เฟส L2 เฉลี่ย 25.71 — ต่ำกว่าค่าเฉลี่ยรวม N (26.19) 1.8%\"},{\"phase\":\"L3\",\"ch1\":\"24.97\",\"ch2\":\"—\",\"analysis\":\"เฟส L3 เฉลี่ย 24.97 — ต่ำกว่าค่าเฉลี่ยรวม N (26.19) 4.7% · โหลดเบาที่สุดใน 3 เฟส\"},{\"phase\":\"เฉลี่ย N\",\"ch1\":\"26.19\",\"ch2\":\"—\",\"analysis\":\"ค่าเฉลี่ยรวม N 26.19 — ความไม่สมดุลกระแส 11.1% · เฟสสูงสุด L1 27.88 · เฟสต่ำสุด L3 24.97\"}],\"professional\":{\"reportSubtitle\":\"รายงานวิเคราะห์คุณภาพไฟฟ้าและประสิทธิภาพพลังงาน · 4/6/2569 20:32:35 – 5/6/2569 20:27:35 · 288 บันทึก @ เรียลไทม์ / 1 นาที\",\"keyFindingsIntro\":\"สรุปผลวิเคราะห์หลัก — ระดับความเสี่ยงทางเทคนิค: CRITICAL · ประหยัดได้โดยประมาณ 6,056/เดือน\",\"keyFindings\":[{\"parameter\":\"พลังงานรวม (kWh)\",\"measured\":\"12,670 kWh/mo · ~152,038 kWh/yr\",\"standard\":\"—\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"},{\"parameter\":\"Peak Demand 15 นาที\",\"measured\":\"16.70 kW @ 15:42\",\"standard\":\"ตามไซต์\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"},{\"parameter\":\"Load Factor\",\"measured\":\"86.1%\",\"standard\":\"≥ 60% แนะนำ\",\"assessment\":\"excellent\",\"assessmentLabel\":\"✓ ดีเยี่ยม\"},{\"parameter\":\"Power Factor เฉลี่ย\",\"measured\":\"0.901 (Lagging)\",\"standard\":\"≥ 0.95\",\"assessment\":\"caution\",\"assessmentLabel\":\"△ ควรระวัง\"},{\"parameter\":\"Voltage Imbalance %\",\"measured\":\"0.45%\",\"standard\":\"< 2% IEC\",\"assessment\":\"excellent\",\"assessmentLabel\":\"✓ ดีเยี่ยม\"},{\"parameter\":\"Current Imbalance %\",\"measured\":\"23.20%\",\"standard\":\"< 5% IEC\",\"assessment\":\"warning\",\"assessmentLabel\":\"⚠ เตือน\"},{\"parameter\":\"THDI เฉลี่ย\",\"measured\":\"10.1%\",\"standard\":\"< 5% IEC 61000\",\"assessment\":\"caution\",\"assessmentLabel\":\"△ ควรระวัง\"},{\"parameter\":\"THDV เฉลี่ย\",\"measured\":\"—\",\"standard\":\"< 5% IEC\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"}],\"executiveNarrative\":[\"รายงานนี้วิเคราะห์คุณภาพไฟฟ้าและประสิทธิภาพพลังงานจากข้อมูล 288 บันทึก (เรียลไทม์ / 1 นาที) ในช่วง 4/6/2569 20:32:35 – 5/6/2569 20:27:35\",\"Power Factor เฉลี่ย 0.901 — 0.0% ของเวลาอยู่ต่ำกว่าเกณฑ์ค่าปรับ MEA (0.85) · THDI เฉลี่ย 10.1% — เหมาะสำหรับ APFC แบบ de-tuned\",\"Current Imbalance เฉลี่ย 23.20% — สูงกว่าเกณฑ์ IEC · L1 รับโหลด 35.5% (เกินค่า ideal 33.3%)\",\"Peak Demand 15 นาที 16.70 kW ที่ 15:42 — สูงกว่าเฉลี่ย ~1.2× · ข้อมูลความละเอียด 1 นาทีต่างจาก hourly ~45%\"],\"interpretationTitle\":\"การตีความ (Interpretation)\",\"interpretationBullets\":[\"Current Imbalance 23.20% — L1 รับโหลด 35.5% · ควรกระจายโหลด 3 เฟสเพื่อลดความเครียด thermal\",\"PF 0.901 ที่สเกลพลังงาน ~152,038 kWh/ปี — ปรับ PF ให้ ≥ 0.95 คืนทุน 11.0 เดือน (0.9 ปี) · เยี่ยม\",\"THDI 10.1% — ติดตั้ง de-tuned APFC (5.7% reactor) ปลอดภัย ไม่เสี่ยง resonance\",\"Voltage Imbalance 0.45% — คุณภาพแรงดันดี ปัญหาอยู่ที่โหลดและการบริหาร Demand\"],\"phasedTitle\":\"คำแนะนำเชิงปฏิบัติ (Phased Recommendations)\",\"phasedRecommendations\":[{\"phase\":\"Phase 1\",\"title\":\"ติดตั้ง De-tuned APFC — ROI สูงสุด\",\"priority\":\"ลำดับความสำคัญสูงสุด\",\"bullets\":[\"THDI 10.1% — ติดตั้ง APFC + reactor de-tuning 5.7% ปลอดภัย\",\"จัดอ ratings จาก Peak 16.70 kW · กระแสเฉลี่ย L1 26.19 A\"],\"expectedOutcome\":\"PF 0.901 → ≥ 0.95 · ลดค่าปรับ MEA · คืนทุน 11.0 เดือน (0.9 ปี) · เยี่ยม\"},{\"phase\":\"Phase 2\",\"title\":\"กระจายโหลด 3 เฟส\",\"priority\":\"ลำดับความสำคัญสูง\",\"bullets\":[\"ย้ายวงจร AC/ครัวจาก L1 ไป L3 ให้ L1 ≤ 35%, L3 ≥ 32%\",\"ลด transient imbalance ตอน compressor cycle on\"],\"expectedOutcome\":\"CI 23.20% → < 10% · ลด thermal stress มอเตอร์และสาย\"},{\"phase\":\"Phase 4\",\"title\":\"ตรวจสอบและแจ้งเตือนประจำปี\",\"priority\":\"ลำดับความสำคัญปานกลาง\",\"bullets\":[\"Thermographic inspection ที่ main panel L1 เป็นประจำ\",\"ตั้ง alarm: PF < 0.85 · CI > 15%\"],\"expectedOutcome\":\"ป้องกันความเสียหายจาก overload และ imbalance สะสม\"}],\"peakPercentiles\":[{\"label\":\"P50\",\"value\":\"16.05 kW\",\"line\":\"P50  16.05 kW\",\"hint\":\"ค่ามัธยฐาน — 50% ของเวลาโหลดต่ำกว่านี้\"},{\"label\":\"P75\",\"value\":\"16.70 kW\",\"line\":\"P75  16.70 kW\",\"hint\":\"โหลดสูงกว่าปกติ — 25% ของเวลาสูงกว่านี้\"},{\"label\":\"P90\",\"value\":\"17.38 kW\",\"line\":\"P90  17.38 kW\",\"hint\":\"โหลดสูง — เกินค่านี้แค่ 10% ของเวลา\"},{\"label\":\"P95\",\"value\":\"17.87 kW\",\"line\":\"P95  17.87 kW\",\"hint\":\"โหลดสูงมาก — เกินค่านี้แค่ 5% ของเวลา\"},{\"label\":\"P99\",\"value\":\"18.32 kW\",\"line\":\"P99  18.32 kW\",\"hint\":\"ใกล้ Peak สูงสุด — เกินค่านี้แค่ 1% ของเวลา\"}],\"peakPercentileCaption\":\"สถิติ Peak Demand (Percentile)\",\"imbalanceExceedance\":[{\"threshold\":\"> 10% (เตือน)\",\"pct\":\"82.6%\",\"liveStatus\":\"เตือน (Warning)\",\"liveLevel\":\"warning\",\"liveImbDisplay\":\"23.2%\"},{\"threshold\":\"> 20% (เสี่ยงสูง)\",\"pct\":\"50.3%\",\"liveStatus\":\"ความเสี่ยงสูง\",\"liveLevel\":\"critical\",\"liveImbDisplay\":\"23.2%\"},{\"threshold\":\"> 50% (รุนแรง)\",\"pct\":\"0.0%\",\"liveStatus\":\"✓ ปกติ\",\"liveLevel\":\"good\",\"liveImbDisplay\":\"23.2%\"}],\"imbalanceExceedanceCaption\":\"สัดส่วนเวลาที่ Current Imbalance เกินเกณฑ์\",\"loadProfileNarrative\":null,\"overallTechnicalRisk\":\"CRITICAL\",\"recommendedModel\":\"50 kVA\"}}','2026-06-06 17:40:07.995470'),
(9,1,9,1,NULL,NULL,30.41,86.10,NULL,23.20,0.40,10.120,NULL,'critical',30.41,NULL,1.080,NULL,NULL,NULL,'{\"reportId\":\"GE-EQ-1-20260606-005\",\"reportDate\":\"6/6/2569 15:54:09\",\"lastUpdate\":\"5/6/2569 20:27:35\",\"overallRisk\":\"critical\",\"overallRiskLabel\":\"วิกฤต (Critical)\",\"harmonicRisk\":\"caution\",\"harmonicRiskLabel\":\"ระวัง\",\"statusMetrics\":{\"pf\":0.901,\"thd\":10.116,\"currentImbalance\":23.199716211422487,\"voltageImbalance\":0.44727263640983006},\"customer\":[{\"label\":\"รหัสรายงาน\",\"value\":\"GE-EQ-1-20260606-005\"},{\"label\":\"ชื่อลูกค้า\",\"value\":\"GE Energy\"},{\"label\":\"ชื่อไซต์\",\"value\":\"GE01\"},{\"label\":\"โลเคชั่น\",\"value\":\"KOREA\"},{\"label\":\"ประเภทธุรกิจ\",\"value\":\"Electronics / Factory\"},{\"label\":\"ผู้ติดต่อ\",\"value\":\"010-8105-0384\"},{\"label\":\"ช่วงการวัด\",\"value\":\"4/6/2569 20:32:35 – 5/6/2569 20:27:35\"},{\"label\":\"วันที่จัดทำรายงาน\",\"value\":\"6/6/2569 15:54:09\"},{\"label\":\"ผู้จัดทำ\",\"value\":\"GE Energy Tech\"}],\"measurement\":[{\"label\":\"Meter ID\",\"value\":\"GE-KR-0004\"},{\"label\":\"Gateway ID\",\"value\":\"192.168.1.46\"},{\"label\":\"จุดตรวจวัด\",\"value\":\"GE Smart Power Meter · CH1 (ก่อนติดตั้ง)\"},{\"label\":\"ระบบแรงดัน\",\"value\":\"3-Phase 400V\"},{\"label\":\"ขนาดเบรกเกอร์\",\"value\":\"40 A\"},{\"label\":\"ขนาดเครื่องที่แนะนำติดตั้ง\",\"value\":\"50 kVA\"},{\"label\":\"ความละเอียดข้อมูล\",\"value\":\"เรียลไทม์ / 1 นาที\"},{\"label\":\"จำนวนบันทึก\",\"value\":\"288\"},{\"label\":\"เริ่มวัด\",\"value\":\"4/6/2569 20:32:35\"},{\"label\":\"สิ้นสุดวัด\",\"value\":\"5/6/2569 20:27:35\"}],\"executive\":[{\"label\":\"พลังงานรวม (kWh)\",\"value\":\"12,051.44 kWh\"},{\"label\":\"กระแสเฉลี่ย (A)\",\"value\":\"28.19 A\"},{\"label\":\"Peak Demand (A)\",\"value\":\"30.41 A\"},{\"label\":\"Load Factor\",\"value\":\"86.1%\"},{\"label\":\"Power Factor เฉลี่ย\",\"value\":\"0.90\"},{\"label\":\"Current Imbalance %\",\"value\":\"23.2%\"},{\"label\":\"Voltage Imbalance %\",\"value\":\"0.4%\"},{\"label\":\"THDI เฉลี่ย\",\"value\":\"10.12%\"},{\"label\":\"THDV เฉลี่ย\",\"value\":\"—\"},{\"label\":\"ระดับความเสี่ยงรวม\",\"value\":\"วิกฤต (Critical)\"}],\"executiveBullets\":[\"พลังงานสะสม 12,051.44 kWh จากมิเตอร์\",\"กระแสเฉลี่ย CH1: 28.19 A\",\"Peak Demand สูงสุด: 30.41 A @ 15:42 · 15:00–16:00\",\"Load Factor: 86.1%\",\"Power Factor เฉลี่ย: 0.90\",\"ความไม่สมดุลกระแส: 23.2%\",\"ระดับความเสี่ยงรวม: วิกฤต (Critical)\",\"แนวทาง GE Energy Tech: ปรับแรงดัน · ปรับกระแส · ปรับเสถียร · เก็บกระแสไว้ใช้ภายหลัง\"],\"executiveKpis\":[{\"label\":\"พลังงานรวม (kWh)\",\"value\":\"12,051.44 kWh\"},{\"label\":\"กระแสเฉลี่ย (A)\",\"value\":\"28.19 A\"},{\"label\":\"Peak Demand (A)\",\"value\":\"30.41 A\"},{\"label\":\"ระดับความเสี่ยงรวม\",\"value\":\"วิกฤต (Critical)\"}],\"energy\":[{\"label\":\"พลังงานรวม (kWh)\",\"value\":\"12,051.44 kWh\"},{\"label\":\"พลังงานเฉลี่ยรายวัน (kWh)\",\"value\":\"422.33 kWh\"},{\"label\":\"ประมาณการรายเดือน (kWh)\",\"value\":\"12,669.84 kWh\"},{\"label\":\"ประมาณการรายปี (kWh)\",\"value\":\"152,038.08 kWh\"},{\"label\":\"ค่าไฟโดยประมาณ/เดือน\",\"value\":\"53,213 บาท\"}],\"peak\":[{\"label\":\"Peak Demand 15 นาที\",\"value\":\"30.41 A\"},{\"label\":\"เวลา Peak\",\"value\":\"15:42\"},{\"label\":\"ช่วงเวลา Peak\",\"value\":\"15:00–16:00\"},{\"label\":\"ช่วงโหลดสูง\",\"value\":\"—\"},{\"label\":\"On-peak เฉลี่ย\",\"value\":\"26.18 A\"},{\"label\":\"Off-peak เฉลี่ย\",\"value\":\"26.19 A\"},{\"label\":\"กระแสเฉลี่ย (A)\",\"value\":\"28.19 A\"},{\"label\":\"Peak / Average\",\"value\":\"1.08\"},{\"label\":\"ผลกระทบ Demand Charge\",\"value\":\"ดี (Good)\"}],\"powerFactor\":[{\"label\":\"Power Factor เฉลี่ย\",\"value\":\"0.90\"},{\"label\":\"PF ต่ำสุด\",\"value\":\"0.90\"},{\"label\":\"เวลาที่ PF ต่ำกว่า 0.95\",\"value\":\"เตือน (Warning)\"},{\"label\":\"ค่าปรับ PF (ประมาณ)\",\"value\":\"3,911 บาท\"},{\"label\":\"แนะนำ APFC\",\"value\":\"แนะนำระบบ GE Energy Tech (ปรับแรงดัน·กระแส·เสถียร·เก็บพลังงาน)\"}],\"balance\":[{\"label\":\"กระแส L1\",\"value\":\"32.47 A\"},{\"label\":\"กระแส L2\",\"value\":\"25.93 A\"},{\"label\":\"กระแส L3\",\"value\":\"26.17 A\"},{\"label\":\"สัดส่วนกำลัง L1\",\"value\":\"38.4%\"},{\"label\":\"สัดส่วนกำลัง L2\",\"value\":\"30.7%\"},{\"label\":\"สัดส่วนกำลัง L3\",\"value\":\"30.9%\"},{\"label\":\"Current Imbalance %\",\"value\":\"23.2%\"},{\"label\":\"Voltage Imbalance %\",\"value\":\"0.4%\"}],\"harmonic\":[{\"label\":\"THDI L1\",\"value\":\"10.12%\"},{\"label\":\"THDI L2\",\"value\":\"10.12%\"},{\"label\":\"THDI L3\",\"value\":\"10.12%\"},{\"label\":\"THDI เฉลี่ย\",\"value\":\"10.12%\"},{\"label\":\"THDV L1\",\"value\":\"—\"},{\"label\":\"THDV L2\",\"value\":\"—\"},{\"label\":\"THDV L3\",\"value\":\"—\"},{\"label\":\"THDV เฉลี่ย\",\"value\":\"—\"},{\"label\":\"ระดับความเสี่ยง Harmonic\",\"value\":\"ระวัง\"}],\"equipment\":[{\"label\":\"มอเตอร์ / คอมเพรสเซอร์\",\"value\":\"วิกฤต (Critical)\"},{\"label\":\"เมนเบรกเกอร์ / สายเคเบิล\",\"value\":\"ดี (Good)\"},{\"label\":\"หม้อแปลง\",\"value\":\"ดี (Good)\"},{\"label\":\"การบำรุงรักษา\",\"value\":\"ตรวจ Thermographic หาก imbalance > 20%\"}],\"financial\":[{\"label\":\"ค่าไฟโดยประมาณ/เดือน\",\"value\":\"53,213 บาท\"},{\"label\":\"ค่าปรับ PF (ประมาณ)\",\"value\":\"3,911 บาท\"},{\"label\":\"ประหยัดได้/เดือน\",\"value\":\"6,056 บาท\"},{\"label\":\"ประหยัดรายปี\",\"value\":\"72,668 บาท\"}],\"roi\":[{\"label\":\"แนวทางแก้ไข\",\"value\":\"GE Energy Tech Smart Saving System\"},{\"label\":\"เงินลงทุน\",\"value\":\"66,340 บาท\"},{\"label\":\"ประหยัดได้/เดือน\",\"value\":\"6,056 บาท/เดือน\"},{\"label\":\"ระยะคืนทุน\",\"value\":\"11.0 เดือน (0.9 ปี) · เยี่ยม\"},{\"label\":\"ROI %\",\"value\":\"110%\"}],\"recommendations\":[{\"priority\":1,\"title\":\"ติดตั้งระบบ GE Energy Tech Smart Saving\",\"description\":\"เปรียบเทียบก่อนติดตั้ง — ระบบปรับแรงดัน ปรับกระแส 3 เฟส ปรับเสถียรลดฮาร์มอนิก และเก็บกระแสไฟใช้ช่วง Peak/Off-peak\"},{\"priority\":2,\"title\":\"กระจายโหลด 3 เฟส\",\"description\":\"สมดุล L1/L2/L3 ลดความเครียดสายและเบรกเกอร์\"},{\"priority\":3,\"title\":\"ติดตามอย่างต่อเนื่อง\",\"description\":\"ใช้ระบบ GE IoT ติดตามแนวโน้ม\"}],\"actionPlan\":[{\"horizon\":\"ทันที (0–30 วัน)\",\"items\":[\"ตรวจการโหลดแต่ละเฟส\"]},{\"horizon\":\"ระยะสั้น (1–3 เดือน)\",\"items\":[\"ติดตั้งระบบ GE Energy Tech หาก PF < 0.95 หรือมี Peak/ไม่สมดุล\",\"กระจายโหลดเฟสเดียว\"]},{\"horizon\":\"ระยะกลาง (3–12 เดือน)\",\"items\":[\"ประเมิน Harmonic filter\"]},{\"horizon\":\"ระยะยาว (1–3 ปี)\",\"items\":[\"ติดตาม IoT ต่อเนื่อง\",\"ตรวจพลังงานประจำปี\"]}],\"conclusion\":[{\"label\":\"ปัญหาปัจจุบัน\",\"value\":\"Current Imbalance %: 23.2%; Power Factor เฉลี่ย: 0.90; THDI เฉลี่ย: 10.1%\"},{\"label\":\"ความเสี่ยงทางเทคนิค\",\"value\":\"วิกฤต (Critical)\"},{\"label\":\"ผลกระทบทางการเงิน\",\"value\":\"53,213 บาท/เดือน\"},{\"label\":\"แนวทางแนะนำ\",\"value\":\"ติดตั้งระบบ GE Energy Tech Smart Saving\"},{\"label\":\"ประหยัดที่คาดหวัง\",\"value\":\"6,056 บาท/เดือน\"},{\"label\":\"ระยะคืนทุน\",\"value\":\"11.0 เดือน (0.9 ปี) · เยี่ยม\"},{\"label\":\"ขั้นตอนถัดไป\",\"value\":\"ทบทวนกับลูกค้าและอนุมัติแผน\"}],\"phaseTable\":[{\"phase\":\"L1\",\"ch1\":\"27.88\",\"ch2\":\"—\",\"analysis\":\"เฟส L1 เฉลี่ย 27.88 — สูงกว่าค่าเฉลี่ยรวม N (26.19) 6.5% · รับโหลดมากที่สุดใน 3 เฟส\"},{\"phase\":\"L2\",\"ch1\":\"25.71\",\"ch2\":\"—\",\"analysis\":\"เฟส L2 เฉลี่ย 25.71 — ต่ำกว่าค่าเฉลี่ยรวม N (26.19) 1.8%\"},{\"phase\":\"L3\",\"ch1\":\"24.97\",\"ch2\":\"—\",\"analysis\":\"เฟส L3 เฉลี่ย 24.97 — ต่ำกว่าค่าเฉลี่ยรวม N (26.19) 4.7% · โหลดเบาที่สุดใน 3 เฟส\"},{\"phase\":\"เฉลี่ย N\",\"ch1\":\"26.19\",\"ch2\":\"—\",\"analysis\":\"ค่าเฉลี่ยรวม N 26.19 — ความไม่สมดุลกระแส 11.1% · เฟสสูงสุด L1 27.88 · เฟสต่ำสุด L3 24.97\"}],\"professional\":{\"reportSubtitle\":\"รายงานวิเคราะห์คุณภาพไฟฟ้าและประสิทธิภาพพลังงาน · 4/6/2569 20:32:35 – 5/6/2569 20:27:35 · 288 บันทึก @ เรียลไทม์ / 1 นาที\",\"keyFindingsIntro\":\"สรุปผลวิเคราะห์หลัก — ระดับความเสี่ยงทางเทคนิค: CRITICAL · ประหยัดได้โดยประมาณ 6,056/เดือน\",\"keyFindings\":[{\"parameter\":\"พลังงานรวม (kWh)\",\"measured\":\"12,670 kWh/mo · ~152,038 kWh/yr\",\"standard\":\"—\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"},{\"parameter\":\"Peak Demand 15 นาที\",\"measured\":\"16.70 kW @ 15:42\",\"standard\":\"ตามไซต์\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"},{\"parameter\":\"Load Factor\",\"measured\":\"86.1%\",\"standard\":\"≥ 60% แนะนำ\",\"assessment\":\"excellent\",\"assessmentLabel\":\"✓ ดีเยี่ยม\"},{\"parameter\":\"Power Factor เฉลี่ย\",\"measured\":\"0.901 (Lagging)\",\"standard\":\"≥ 0.95\",\"assessment\":\"caution\",\"assessmentLabel\":\"△ ควรระวัง\"},{\"parameter\":\"Voltage Imbalance %\",\"measured\":\"0.45%\",\"standard\":\"< 2% IEC\",\"assessment\":\"excellent\",\"assessmentLabel\":\"✓ ดีเยี่ยม\"},{\"parameter\":\"Current Imbalance %\",\"measured\":\"23.20%\",\"standard\":\"< 5% IEC\",\"assessment\":\"warning\",\"assessmentLabel\":\"⚠ เตือน\"},{\"parameter\":\"THDI เฉลี่ย\",\"measured\":\"10.1%\",\"standard\":\"< 5% IEC 61000\",\"assessment\":\"caution\",\"assessmentLabel\":\"△ ควรระวัง\"},{\"parameter\":\"THDV เฉลี่ย\",\"measured\":\"—\",\"standard\":\"< 5% IEC\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"}],\"executiveNarrative\":[\"รายงานนี้วิเคราะห์คุณภาพไฟฟ้าและประสิทธิภาพพลังงานจากข้อมูล 288 บันทึก (เรียลไทม์ / 1 นาที) ในช่วง 4/6/2569 20:32:35 – 5/6/2569 20:27:35\",\"Power Factor เฉลี่ย 0.901 — 0.0% ของเวลาอยู่ต่ำกว่าเกณฑ์ค่าปรับ MEA (0.85) · THDI เฉลี่ย 10.1% — เหมาะสำหรับ APFC แบบ de-tuned\",\"Current Imbalance เฉลี่ย 23.20% — สูงกว่าเกณฑ์ IEC · L1 รับโหลด 35.5% (เกินค่า ideal 33.3%)\",\"Peak Demand 15 นาที 16.70 kW ที่ 15:42 — สูงกว่าเฉลี่ย ~1.2× · ข้อมูลความละเอียด 1 นาทีต่างจาก hourly ~45%\"],\"interpretationTitle\":\"การตีความ (Interpretation)\",\"interpretationBullets\":[\"Current Imbalance 23.20% — L1 รับโหลด 35.5% · ควรกระจายโหลด 3 เฟสเพื่อลดความเครียด thermal\",\"PF 0.901 ที่สเกลพลังงาน ~152,038 kWh/ปี — ปรับ PF ให้ ≥ 0.95 คืนทุน 11.0 เดือน (0.9 ปี) · เยี่ยม\",\"THDI 10.1% — ติดตั้ง de-tuned APFC (5.7% reactor) ปลอดภัย ไม่เสี่ยง resonance\",\"Voltage Imbalance 0.45% — คุณภาพแรงดันดี ปัญหาอยู่ที่โหลดและการบริหาร Demand\"],\"phasedTitle\":\"คำแนะนำเชิงปฏิบัติ (Phased Recommendations)\",\"phasedRecommendations\":[{\"phase\":\"Phase 1\",\"title\":\"ติดตั้ง De-tuned APFC — ROI สูงสุด\",\"priority\":\"ลำดับความสำคัญสูงสุด\",\"bullets\":[\"THDI 10.1% — ติดตั้ง APFC + reactor de-tuning 5.7% ปลอดภัย\",\"จัดอ ratings จาก Peak 16.70 kW · กระแสเฉลี่ย L1 26.19 A\"],\"expectedOutcome\":\"PF 0.901 → ≥ 0.95 · ลดค่าปรับ MEA · คืนทุน 11.0 เดือน (0.9 ปี) · เยี่ยม\"},{\"phase\":\"Phase 2\",\"title\":\"กระจายโหลด 3 เฟส\",\"priority\":\"ลำดับความสำคัญสูง\",\"bullets\":[\"ย้ายวงจร AC/ครัวจาก L1 ไป L3 ให้ L1 ≤ 35%, L3 ≥ 32%\",\"ลด transient imbalance ตอน compressor cycle on\"],\"expectedOutcome\":\"CI 23.20% → < 10% · ลด thermal stress มอเตอร์และสาย\"},{\"phase\":\"Phase 4\",\"title\":\"ตรวจสอบและแจ้งเตือนประจำปี\",\"priority\":\"ลำดับความสำคัญปานกลาง\",\"bullets\":[\"Thermographic inspection ที่ main panel L1 เป็นประจำ\",\"ตั้ง alarm: PF < 0.85 · CI > 15%\"],\"expectedOutcome\":\"ป้องกันความเสียหายจาก overload และ imbalance สะสม\"}],\"peakPercentiles\":[{\"label\":\"P50\",\"value\":\"16.05 kW\",\"line\":\"P50  16.05 kW\",\"hint\":\"ค่ามัธยฐาน — 50% ของเวลาโหลดต่ำกว่านี้\"},{\"label\":\"P75\",\"value\":\"16.70 kW\",\"line\":\"P75  16.70 kW\",\"hint\":\"โหลดสูงกว่าปกติ — 25% ของเวลาสูงกว่านี้\"},{\"label\":\"P90\",\"value\":\"17.38 kW\",\"line\":\"P90  17.38 kW\",\"hint\":\"โหลดสูง — เกินค่านี้แค่ 10% ของเวลา\"},{\"label\":\"P95\",\"value\":\"17.87 kW\",\"line\":\"P95  17.87 kW\",\"hint\":\"โหลดสูงมาก — เกินค่านี้แค่ 5% ของเวลา\"},{\"label\":\"P99\",\"value\":\"18.32 kW\",\"line\":\"P99  18.32 kW\",\"hint\":\"ใกล้ Peak สูงสุด — เกินค่านี้แค่ 1% ของเวลา\"}],\"peakPercentileCaption\":\"สถิติ Peak Demand (Percentile)\",\"imbalanceExceedance\":[{\"threshold\":\"> 10% (เตือน)\",\"pct\":\"82.6%\",\"liveStatus\":\"เตือน (Warning)\",\"liveLevel\":\"warning\",\"liveImbDisplay\":\"23.2%\"},{\"threshold\":\"> 20% (เสี่ยงสูง)\",\"pct\":\"50.3%\",\"liveStatus\":\"ความเสี่ยงสูง\",\"liveLevel\":\"critical\",\"liveImbDisplay\":\"23.2%\"},{\"threshold\":\"> 50% (รุนแรง)\",\"pct\":\"0.0%\",\"liveStatus\":\"✓ ปกติ\",\"liveLevel\":\"good\",\"liveImbDisplay\":\"23.2%\"}],\"imbalanceExceedanceCaption\":\"สัดส่วนเวลาที่ Current Imbalance เกินเกณฑ์\",\"loadProfileNarrative\":null,\"overallTechnicalRisk\":\"CRITICAL\",\"recommendedModel\":\"50 kVA\"}}','2026-06-06 17:54:11.023646'),
(10,1,10,1,NULL,NULL,30.41,86.10,NULL,23.20,0.40,10.120,NULL,'critical',30.41,NULL,1.080,NULL,NULL,NULL,'{\"reportId\":\"GE-EQ-1-20260606-006\",\"reportDate\":\"6/6/2569 15:54:43\",\"lastUpdate\":\"5/6/2569 20:27:35\",\"overallRisk\":\"critical\",\"overallRiskLabel\":\"วิกฤต (Critical)\",\"harmonicRisk\":\"caution\",\"harmonicRiskLabel\":\"ระวัง\",\"statusMetrics\":{\"pf\":0.901,\"thd\":10.116,\"currentImbalance\":23.199716211422487,\"voltageImbalance\":0.44727263640983006},\"customer\":[{\"label\":\"รหัสรายงาน\",\"value\":\"GE-EQ-1-20260606-006\"},{\"label\":\"ชื่อลูกค้า\",\"value\":\"GE Energy\"},{\"label\":\"ชื่อไซต์\",\"value\":\"GE01\"},{\"label\":\"โลเคชั่น\",\"value\":\"KOREA\"},{\"label\":\"ประเภทธุรกิจ\",\"value\":\"Electronics / Factory\"},{\"label\":\"ผู้ติดต่อ\",\"value\":\"010-8105-0384\"},{\"label\":\"ช่วงการวัด\",\"value\":\"4/6/2569 20:32:35 – 5/6/2569 20:27:35\"},{\"label\":\"วันที่จัดทำรายงาน\",\"value\":\"6/6/2569 15:54:43\"},{\"label\":\"ผู้จัดทำ\",\"value\":\"GE Energy Tech\"}],\"measurement\":[{\"label\":\"Meter ID\",\"value\":\"GE-KR-0004\"},{\"label\":\"Gateway ID\",\"value\":\"192.168.1.46\"},{\"label\":\"จุดตรวจวัด\",\"value\":\"GE Smart Power Meter · CH1 (ก่อนติดตั้ง)\"},{\"label\":\"ระบบแรงดัน\",\"value\":\"3-Phase 400V\"},{\"label\":\"ขนาดเบรกเกอร์\",\"value\":\"40 A\"},{\"label\":\"ขนาดเครื่องที่แนะนำติดตั้ง\",\"value\":\"50 kVA\"},{\"label\":\"ความละเอียดข้อมูล\",\"value\":\"เรียลไทม์ / 1 นาที\"},{\"label\":\"จำนวนบันทึก\",\"value\":\"288\"},{\"label\":\"เริ่มวัด\",\"value\":\"4/6/2569 20:32:35\"},{\"label\":\"สิ้นสุดวัด\",\"value\":\"5/6/2569 20:27:35\"}],\"executive\":[{\"label\":\"พลังงานรวม (kWh)\",\"value\":\"12,051.44 kWh\"},{\"label\":\"กระแสเฉลี่ย (A)\",\"value\":\"28.19 A\"},{\"label\":\"Peak Demand (A)\",\"value\":\"30.41 A\"},{\"label\":\"Load Factor\",\"value\":\"86.1%\"},{\"label\":\"Power Factor เฉลี่ย\",\"value\":\"0.90\"},{\"label\":\"Current Imbalance %\",\"value\":\"23.2%\"},{\"label\":\"Voltage Imbalance %\",\"value\":\"0.4%\"},{\"label\":\"THDI เฉลี่ย\",\"value\":\"10.12%\"},{\"label\":\"THDV เฉลี่ย\",\"value\":\"—\"},{\"label\":\"ระดับความเสี่ยงรวม\",\"value\":\"วิกฤต (Critical)\"}],\"executiveBullets\":[\"พลังงานสะสม 12,051.44 kWh จากมิเตอร์\",\"กระแสเฉลี่ย CH1: 28.19 A\",\"Peak Demand สูงสุด: 30.41 A @ 15:42 · 15:00–16:00\",\"Load Factor: 86.1%\",\"Power Factor เฉลี่ย: 0.90\",\"ความไม่สมดุลกระแส: 23.2%\",\"ระดับความเสี่ยงรวม: วิกฤต (Critical)\",\"แนวทาง GE Energy Tech: ปรับแรงดัน · ปรับกระแส · ปรับเสถียร · เก็บกระแสไว้ใช้ภายหลัง\"],\"executiveKpis\":[{\"label\":\"พลังงานรวม (kWh)\",\"value\":\"12,051.44 kWh\"},{\"label\":\"กระแสเฉลี่ย (A)\",\"value\":\"28.19 A\"},{\"label\":\"Peak Demand (A)\",\"value\":\"30.41 A\"},{\"label\":\"ระดับความเสี่ยงรวม\",\"value\":\"วิกฤต (Critical)\"}],\"energy\":[{\"label\":\"พลังงานรวม (kWh)\",\"value\":\"12,051.44 kWh\"},{\"label\":\"พลังงานเฉลี่ยรายวัน (kWh)\",\"value\":\"422.33 kWh\"},{\"label\":\"ประมาณการรายเดือน (kWh)\",\"value\":\"12,669.84 kWh\"},{\"label\":\"ประมาณการรายปี (kWh)\",\"value\":\"152,038.08 kWh\"},{\"label\":\"ค่าไฟโดยประมาณ/เดือน\",\"value\":\"53,213 บาท\"}],\"peak\":[{\"label\":\"Peak Demand 15 นาที\",\"value\":\"30.41 A\"},{\"label\":\"เวลา Peak\",\"value\":\"15:42\"},{\"label\":\"ช่วงเวลา Peak\",\"value\":\"15:00–16:00\"},{\"label\":\"ช่วงโหลดสูง\",\"value\":\"—\"},{\"label\":\"On-peak เฉลี่ย\",\"value\":\"26.18 A\"},{\"label\":\"Off-peak เฉลี่ย\",\"value\":\"26.19 A\"},{\"label\":\"กระแสเฉลี่ย (A)\",\"value\":\"28.19 A\"},{\"label\":\"Peak / Average\",\"value\":\"1.08\"},{\"label\":\"ผลกระทบ Demand Charge\",\"value\":\"ดี (Good)\"}],\"powerFactor\":[{\"label\":\"Power Factor เฉลี่ย\",\"value\":\"0.90\"},{\"label\":\"PF ต่ำสุด\",\"value\":\"0.90\"},{\"label\":\"เวลาที่ PF ต่ำกว่า 0.95\",\"value\":\"เตือน (Warning)\"},{\"label\":\"ค่าปรับ PF (ประมาณ)\",\"value\":\"3,911 บาท\"},{\"label\":\"แนะนำ APFC\",\"value\":\"แนะนำระบบ GE Energy Tech (ปรับแรงดัน·กระแส·เสถียร·เก็บพลังงาน)\"}],\"balance\":[{\"label\":\"กระแส L1\",\"value\":\"32.47 A\"},{\"label\":\"กระแส L2\",\"value\":\"25.93 A\"},{\"label\":\"กระแส L3\",\"value\":\"26.17 A\"},{\"label\":\"สัดส่วนกำลัง L1\",\"value\":\"38.4%\"},{\"label\":\"สัดส่วนกำลัง L2\",\"value\":\"30.7%\"},{\"label\":\"สัดส่วนกำลัง L3\",\"value\":\"30.9%\"},{\"label\":\"Current Imbalance %\",\"value\":\"23.2%\"},{\"label\":\"Voltage Imbalance %\",\"value\":\"0.4%\"}],\"harmonic\":[{\"label\":\"THDI L1\",\"value\":\"10.12%\"},{\"label\":\"THDI L2\",\"value\":\"10.12%\"},{\"label\":\"THDI L3\",\"value\":\"10.12%\"},{\"label\":\"THDI เฉลี่ย\",\"value\":\"10.12%\"},{\"label\":\"THDV L1\",\"value\":\"—\"},{\"label\":\"THDV L2\",\"value\":\"—\"},{\"label\":\"THDV L3\",\"value\":\"—\"},{\"label\":\"THDV เฉลี่ย\",\"value\":\"—\"},{\"label\":\"ระดับความเสี่ยง Harmonic\",\"value\":\"ระวัง\"}],\"equipment\":[{\"label\":\"มอเตอร์ / คอมเพรสเซอร์\",\"value\":\"วิกฤต (Critical)\"},{\"label\":\"เมนเบรกเกอร์ / สายเคเบิล\",\"value\":\"ดี (Good)\"},{\"label\":\"หม้อแปลง\",\"value\":\"ดี (Good)\"},{\"label\":\"การบำรุงรักษา\",\"value\":\"ตรวจ Thermographic หาก imbalance > 20%\"}],\"financial\":[{\"label\":\"ค่าไฟโดยประมาณ/เดือน\",\"value\":\"53,213 บาท\"},{\"label\":\"ค่าปรับ PF (ประมาณ)\",\"value\":\"3,911 บาท\"},{\"label\":\"ประหยัดได้/เดือน\",\"value\":\"6,056 บาท\"},{\"label\":\"ประหยัดรายปี\",\"value\":\"72,668 บาท\"}],\"roi\":[{\"label\":\"แนวทางแก้ไข\",\"value\":\"GE Energy Tech Smart Saving System\"},{\"label\":\"เงินลงทุน\",\"value\":\"66,340 บาท\"},{\"label\":\"ประหยัดได้/เดือน\",\"value\":\"6,056 บาท/เดือน\"},{\"label\":\"ระยะคืนทุน\",\"value\":\"11.0 เดือน (0.9 ปี) · เยี่ยม\"},{\"label\":\"ROI %\",\"value\":\"110%\"}],\"recommendations\":[{\"priority\":1,\"title\":\"ติดตั้งระบบ GE Energy Tech Smart Saving\",\"description\":\"เปรียบเทียบก่อนติดตั้ง — ระบบปรับแรงดัน ปรับกระแส 3 เฟส ปรับเสถียรลดฮาร์มอนิก และเก็บกระแสไฟใช้ช่วง Peak/Off-peak\"},{\"priority\":2,\"title\":\"กระจายโหลด 3 เฟส\",\"description\":\"สมดุล L1/L2/L3 ลดความเครียดสายและเบรกเกอร์\"},{\"priority\":3,\"title\":\"ติดตามอย่างต่อเนื่อง\",\"description\":\"ใช้ระบบ GE IoT ติดตามแนวโน้ม\"}],\"actionPlan\":[{\"horizon\":\"ทันที (0–30 วัน)\",\"items\":[\"ตรวจการโหลดแต่ละเฟส\"]},{\"horizon\":\"ระยะสั้น (1–3 เดือน)\",\"items\":[\"ติดตั้งระบบ GE Energy Tech หาก PF < 0.95 หรือมี Peak/ไม่สมดุล\",\"กระจายโหลดเฟสเดียว\"]},{\"horizon\":\"ระยะกลาง (3–12 เดือน)\",\"items\":[\"ประเมิน Harmonic filter\"]},{\"horizon\":\"ระยะยาว (1–3 ปี)\",\"items\":[\"ติดตาม IoT ต่อเนื่อง\",\"ตรวจพลังงานประจำปี\"]}],\"conclusion\":[{\"label\":\"ปัญหาปัจจุบัน\",\"value\":\"Current Imbalance %: 23.2%; Power Factor เฉลี่ย: 0.90; THDI เฉลี่ย: 10.1%\"},{\"label\":\"ความเสี่ยงทางเทคนิค\",\"value\":\"วิกฤต (Critical)\"},{\"label\":\"ผลกระทบทางการเงิน\",\"value\":\"53,213 บาท/เดือน\"},{\"label\":\"แนวทางแนะนำ\",\"value\":\"ติดตั้งระบบ GE Energy Tech Smart Saving\"},{\"label\":\"ประหยัดที่คาดหวัง\",\"value\":\"6,056 บาท/เดือน\"},{\"label\":\"ระยะคืนทุน\",\"value\":\"11.0 เดือน (0.9 ปี) · เยี่ยม\"},{\"label\":\"ขั้นตอนถัดไป\",\"value\":\"ทบทวนกับลูกค้าและอนุมัติแผน\"}],\"phaseTable\":[{\"phase\":\"L1\",\"ch1\":\"27.88\",\"ch2\":\"—\",\"analysis\":\"เฟส L1 เฉลี่ย 27.88 — สูงกว่าค่าเฉลี่ยรวม N (26.19) 6.5% · รับโหลดมากที่สุดใน 3 เฟส\"},{\"phase\":\"L2\",\"ch1\":\"25.71\",\"ch2\":\"—\",\"analysis\":\"เฟส L2 เฉลี่ย 25.71 — ต่ำกว่าค่าเฉลี่ยรวม N (26.19) 1.8%\"},{\"phase\":\"L3\",\"ch1\":\"24.97\",\"ch2\":\"—\",\"analysis\":\"เฟส L3 เฉลี่ย 24.97 — ต่ำกว่าค่าเฉลี่ยรวม N (26.19) 4.7% · โหลดเบาที่สุดใน 3 เฟส\"},{\"phase\":\"เฉลี่ย N\",\"ch1\":\"26.19\",\"ch2\":\"—\",\"analysis\":\"ค่าเฉลี่ยรวม N 26.19 — ความไม่สมดุลกระแส 11.1% · เฟสสูงสุด L1 27.88 · เฟสต่ำสุด L3 24.97\"}],\"professional\":{\"reportSubtitle\":\"รายงานวิเคราะห์คุณภาพไฟฟ้าและประสิทธิภาพพลังงาน · 4/6/2569 20:32:35 – 5/6/2569 20:27:35 · 288 บันทึก @ เรียลไทม์ / 1 นาที\",\"keyFindingsIntro\":\"สรุปผลวิเคราะห์หลัก — ระดับความเสี่ยงทางเทคนิค: CRITICAL · ประหยัดได้โดยประมาณ 6,056/เดือน\",\"keyFindings\":[{\"parameter\":\"พลังงานรวม (kWh)\",\"measured\":\"12,670 kWh/mo · ~152,038 kWh/yr\",\"standard\":\"—\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"},{\"parameter\":\"Peak Demand 15 นาที\",\"measured\":\"16.70 kW @ 15:42\",\"standard\":\"ตามไซต์\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"},{\"parameter\":\"Load Factor\",\"measured\":\"86.1%\",\"standard\":\"≥ 60% แนะนำ\",\"assessment\":\"excellent\",\"assessmentLabel\":\"✓ ดีเยี่ยม\"},{\"parameter\":\"Power Factor เฉลี่ย\",\"measured\":\"0.901 (Lagging)\",\"standard\":\"≥ 0.95\",\"assessment\":\"caution\",\"assessmentLabel\":\"△ ควรระวัง\"},{\"parameter\":\"Voltage Imbalance %\",\"measured\":\"0.45%\",\"standard\":\"< 2% IEC\",\"assessment\":\"excellent\",\"assessmentLabel\":\"✓ ดีเยี่ยม\"},{\"parameter\":\"Current Imbalance %\",\"measured\":\"23.20%\",\"standard\":\"< 5% IEC\",\"assessment\":\"warning\",\"assessmentLabel\":\"⚠ เตือน\"},{\"parameter\":\"THDI เฉลี่ย\",\"measured\":\"10.1%\",\"standard\":\"< 5% IEC 61000\",\"assessment\":\"caution\",\"assessmentLabel\":\"△ ควรระวัง\"},{\"parameter\":\"THDV เฉลี่ย\",\"measured\":\"—\",\"standard\":\"< 5% IEC\",\"assessment\":\"neutral\",\"assessmentLabel\":\"—\"}],\"executiveNarrative\":[\"รายงานนี้วิเคราะห์คุณภาพไฟฟ้าและประสิทธิภาพพลังงานจากข้อมูล 288 บันทึก (เรียลไทม์ / 1 นาที) ในช่วง 4/6/2569 20:32:35 – 5/6/2569 20:27:35\",\"Power Factor เฉลี่ย 0.901 — 0.0% ของเวลาอยู่ต่ำกว่าเกณฑ์ค่าปรับ MEA (0.85) · THDI เฉลี่ย 10.1% — เหมาะสำหรับ APFC แบบ de-tuned\",\"Current Imbalance เฉลี่ย 23.20% — สูงกว่าเกณฑ์ IEC · L1 รับโหลด 35.5% (เกินค่า ideal 33.3%)\",\"Peak Demand 15 นาที 16.70 kW ที่ 15:42 — สูงกว่าเฉลี่ย ~1.2× · ข้อมูลความละเอียด 1 นาทีต่างจาก hourly ~45%\"],\"interpretationTitle\":\"การตีความ (Interpretation)\",\"interpretationBullets\":[\"Current Imbalance 23.20% — L1 รับโหลด 35.5% · ควรกระจายโหลด 3 เฟสเพื่อลดความเครียด thermal\",\"PF 0.901 ที่สเกลพลังงาน ~152,038 kWh/ปี — ปรับ PF ให้ ≥ 0.95 คืนทุน 11.0 เดือน (0.9 ปี) · เยี่ยม\",\"THDI 10.1% — ติดตั้ง de-tuned APFC (5.7% reactor) ปลอดภัย ไม่เสี่ยง resonance\",\"Voltage Imbalance 0.45% — คุณภาพแรงดันดี ปัญหาอยู่ที่โหลดและการบริหาร Demand\"],\"phasedTitle\":\"คำแนะนำเชิงปฏิบัติ (Phased Recommendations)\",\"phasedRecommendations\":[{\"phase\":\"Phase 1\",\"title\":\"ติดตั้ง De-tuned APFC — ROI สูงสุด\",\"priority\":\"ลำดับความสำคัญสูงสุด\",\"bullets\":[\"THDI 10.1% — ติดตั้ง APFC + reactor de-tuning 5.7% ปลอดภัย\",\"จัดอ ratings จาก Peak 16.70 kW · กระแสเฉลี่ย L1 26.19 A\"],\"expectedOutcome\":\"PF 0.901 → ≥ 0.95 · ลดค่าปรับ MEA · คืนทุน 11.0 เดือน (0.9 ปี) · เยี่ยม\"},{\"phase\":\"Phase 2\",\"title\":\"กระจายโหลด 3 เฟส\",\"priority\":\"ลำดับความสำคัญสูง\",\"bullets\":[\"ย้ายวงจร AC/ครัวจาก L1 ไป L3 ให้ L1 ≤ 35%, L3 ≥ 32%\",\"ลด transient imbalance ตอน compressor cycle on\"],\"expectedOutcome\":\"CI 23.20% → < 10% · ลด thermal stress มอเตอร์และสาย\"},{\"phase\":\"Phase 4\",\"title\":\"ตรวจสอบและแจ้งเตือนประจำปี\",\"priority\":\"ลำดับความสำคัญปานกลาง\",\"bullets\":[\"Thermographic inspection ที่ main panel L1 เป็นประจำ\",\"ตั้ง alarm: PF < 0.85 · CI > 15%\"],\"expectedOutcome\":\"ป้องกันความเสียหายจาก overload และ imbalance สะสม\"}],\"peakPercentiles\":[{\"label\":\"P50\",\"value\":\"16.05 kW\",\"line\":\"P50  16.05 kW\",\"hint\":\"ค่ามัธยฐาน — 50% ของเวลาโหลดต่ำกว่านี้\"},{\"label\":\"P75\",\"value\":\"16.70 kW\",\"line\":\"P75  16.70 kW\",\"hint\":\"โหลดสูงกว่าปกติ — 25% ของเวลาสูงกว่านี้\"},{\"label\":\"P90\",\"value\":\"17.38 kW\",\"line\":\"P90  17.38 kW\",\"hint\":\"โหลดสูง — เกินค่านี้แค่ 10% ของเวลา\"},{\"label\":\"P95\",\"value\":\"17.87 kW\",\"line\":\"P95  17.87 kW\",\"hint\":\"โหลดสูงมาก — เกินค่านี้แค่ 5% ของเวลา\"},{\"label\":\"P99\",\"value\":\"18.32 kW\",\"line\":\"P99  18.32 kW\",\"hint\":\"ใกล้ Peak สูงสุด — เกินค่านี้แค่ 1% ของเวลา\"}],\"peakPercentileCaption\":\"สถิติ Peak Demand (Percentile)\",\"imbalanceExceedance\":[{\"threshold\":\"> 10% (เตือน)\",\"pct\":\"82.6%\",\"liveStatus\":\"เตือน (Warning)\",\"liveLevel\":\"warning\",\"liveImbDisplay\":\"23.2%\"},{\"threshold\":\"> 20% (เสี่ยงสูง)\",\"pct\":\"50.3%\",\"liveStatus\":\"ความเสี่ยงสูง\",\"liveLevel\":\"critical\",\"liveImbDisplay\":\"23.2%\"},{\"threshold\":\"> 50% (รุนแรง)\",\"pct\":\"0.0%\",\"liveStatus\":\"✓ ปกติ\",\"liveLevel\":\"good\",\"liveImbDisplay\":\"23.2%\"}],\"imbalanceExceedanceCaption\":\"สัดส่วนเวลาที่ Current Imbalance เกินเกณฑ์\",\"loadProfileNarrative\":null,\"overallTechnicalRisk\":\"CRITICAL\",\"recommendedModel\":\"50 kVA\"}}','2026-06-06 17:54:44.640896');
/*!40000 ALTER TABLE `eq_analysis_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eq_customers`
--

DROP TABLE IF EXISTS `eq_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `eq_customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(255) NOT NULL,
  `business_type` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `legacy_client_id` varchar(191) DEFAULT NULL COMMENT 'Optional link to Client.id',
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`id`),
  KEY `idx_eq_customers_name` (`customer_name`),
  KEY `idx_eq_customers_legacy_client` (`legacy_client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eq_customers`
--

LOCK TABLES `eq_customers` WRITE;
/*!40000 ALTER TABLE `eq_customers` DISABLE KEYS */;
INSERT INTO `eq_customers` VALUES
(1,'GE Energy','Electronics / Factory','KOREA','GE Energy','010-8105-0384','contact@ge01.local','cmo6viuen0003qhga32hwcu3n','2026-06-05 11:25:19.964554','2026-06-05 16:51:04.542204'),
(2,'Green Retail','Electronics / Factory','KOREA','Green Retail','010-8105-0384','contact@ge02.local','cmo6viuen0003qhga32hwcu3n','2026-06-05 11:25:20.047104','2026-06-05 16:51:04.542204'),
(3,'Thailand','Manufacturing / Industrial','Bangkok','Thailand','02-555-1199','contact@geth01.local','cmo6viuen0003qhga32hwcu3n','2026-06-05 11:25:20.109481','2026-06-05 16:51:04.542204');
/*!40000 ALTER TABLE `eq_customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eq_device_sites`
--

DROP TABLE IF EXISTS `eq_device_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `eq_device_sites` (
  `device_id` int(11) NOT NULL COMMENT 'devices.deviceID',
  `site_id` int(11) NOT NULL,
  `measurement_point` varchar(255) DEFAULT NULL,
  `gateway_id` varchar(100) DEFAULT NULL,
  `installed_date` date DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`device_id`),
  UNIQUE KEY `uq_eq_device_sites_site_device` (`site_id`,`device_id`),
  CONSTRAINT `fk_eq_device_sites_device` FOREIGN KEY (`device_id`) REFERENCES `devices` (`deviceID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_eq_device_sites_site` FOREIGN KEY (`site_id`) REFERENCES `eq_sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eq_device_sites`
--

LOCK TABLES `eq_device_sites` WRITE;
/*!40000 ALTER TABLE `eq_device_sites` DISABLE KEYS */;
INSERT INTO `eq_device_sites` VALUES
(1,1,'GE01','GE01',NULL,'2026-06-05 11:25:20.030923','2026-06-05 11:25:20.030923'),
(2,2,'GE02','GE02',NULL,'2026-06-05 11:25:20.078975','2026-06-05 11:25:20.078975'),
(3,3,'GE-TH01','GE-TH01',NULL,'2026-06-05 11:25:20.148035','2026-06-05 11:25:20.148035');
/*!40000 ALTER TABLE `eq_device_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eq_energy_data`
--

DROP TABLE IF EXISTS `eq_energy_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `eq_energy_data` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `device_id` int(11) NOT NULL,
  `recorded_at` datetime NOT NULL,
  `voltage_l1` decimal(10,2) DEFAULT NULL,
  `voltage_l2` decimal(10,2) DEFAULT NULL,
  `voltage_l3` decimal(10,2) DEFAULT NULL,
  `current_l1` decimal(10,2) DEFAULT NULL,
  `current_l2` decimal(10,2) DEFAULT NULL,
  `current_l3` decimal(10,2) DEFAULT NULL,
  `power_kw` decimal(12,3) DEFAULT NULL,
  `energy_kwh` decimal(14,3) DEFAULT NULL,
  `power_factor` decimal(6,3) DEFAULT NULL,
  `frequency` decimal(8,3) DEFAULT NULL,
  `thdi_l1` decimal(8,3) DEFAULT NULL,
  `thdi_l2` decimal(8,3) DEFAULT NULL,
  `thdi_l3` decimal(8,3) DEFAULT NULL,
  `thdv_l1` decimal(8,3) DEFAULT NULL,
  `thdv_l2` decimal(8,3) DEFAULT NULL,
  `thdv_l3` decimal(8,3) DEFAULT NULL,
  `reactive_kvar` decimal(12,3) DEFAULT NULL,
  `apparent_kva` decimal(12,3) DEFAULT NULL,
  `source` varchar(32) NOT NULL DEFAULT 'live',
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  PRIMARY KEY (`id`),
  KEY `idx_eq_energy_data_device_time` (`device_id`,`recorded_at`),
  CONSTRAINT `fk_eq_energy_data_device` FOREIGN KEY (`device_id`) REFERENCES `devices` (`deviceID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eq_energy_data`
--

LOCK TABLES `eq_energy_data` WRITE;
/*!40000 ALTER TABLE `eq_energy_data` DISABLE KEYS */;
INSERT INTO `eq_energy_data` VALUES
(1,1,'2026-06-05 12:12:50',400.00,401.20,399.50,39.05,19.89,17.15,11.566,12050.287,0.859,49.975,11.730,11.144,12.317,7.038,7.273,6.803,6.893,13.464,'seed','2026-06-05 12:12:53.182043'),
(2,2,'2026-06-05 12:12:53',400.00,401.20,399.50,41.02,18.44,17.16,11.646,12100.287,0.846,49.985,10.393,9.873,10.913,6.236,6.444,6.028,7.340,13.766,'seed','2026-06-05 12:12:55.972137'),
(3,3,'2026-06-05 12:12:56',400.00,401.20,399.50,41.45,17.94,14.86,11.286,12150.287,0.865,49.979,11.190,10.631,11.750,6.714,6.938,6.490,6.546,13.047,'seed','2026-06-05 12:12:58.617288'),
(4,1,'2026-06-05 13:14:14',400.00,401.20,399.50,101.62,43.88,40.49,38.908,12050.861,0.904,49.999,8.133,7.726,8.540,4.880,5.042,4.717,18.401,43.040,'seed','2026-06-05 13:14:16.332075'),
(5,2,'2026-06-05 13:14:16',400.00,401.20,399.50,104.49,43.25,38.12,37.724,12100.861,0.881,49.988,8.259,7.846,8.672,4.955,5.121,4.790,20.260,42.820,'seed','2026-06-05 13:14:18.265946'),
(6,3,'2026-06-05 13:14:18',400.00,401.20,399.50,102.44,43.55,39.38,37.764,12150.861,0.884,49.998,8.747,8.310,9.184,5.248,5.423,5.073,19.970,42.719,'seed','2026-06-05 13:14:20.371494'),
(7,1,'2026-06-05 13:27:35',400.46,400.97,399.18,97.31,92.58,87.14,57.673,12051.435,0.901,49.996,10.116,9.610,10.622,6.070,6.272,5.867,27.769,64.010,'seed','2026-06-05 13:27:38.187029'),
(8,2,'2026-06-05 13:27:38',399.34,401.67,398.97,98.48,93.14,85.83,57.730,12101.435,0.901,50.008,9.344,8.877,9.811,5.606,5.793,5.420,27.796,64.073,'seed','2026-06-05 13:27:40.494141'),
(9,3,'2026-06-05 13:27:41',400.18,400.61,398.83,98.63,92.74,86.56,58.198,12151.435,0.907,49.989,10.321,9.805,10.837,6.193,6.399,5.986,27.021,64.165,'seed','2026-06-05 13:27:43.033018'),
(10,3,'2026-06-05 07:51:09',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 16:51:09.340147'),
(11,3,'2026-06-05 07:51:41',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 16:51:40.668328'),
(12,3,'2026-06-05 07:52:01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'live','2026-06-05 16:52:01.457747'),
(13,3,'2026-06-05 07:52:34',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 16:52:34.251226'),
(14,3,'2026-06-05 07:53:09',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 16:53:08.808334'),
(15,3,'2026-06-05 07:53:44',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 16:53:44.477208'),
(16,3,'2026-06-05 07:54:15',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 16:54:14.796556'),
(17,3,'2026-06-05 07:54:57',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 16:54:57.141815'),
(18,3,'2026-06-05 07:55:57',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 16:55:56.960686'),
(19,3,'2026-06-05 07:56:30',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 16:56:29.914162'),
(20,3,'2026-06-05 07:57:04',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 16:57:04.051353'),
(21,3,'2026-06-05 07:57:39',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 16:57:38.990073'),
(22,3,'2026-06-05 07:58:14',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 16:58:13.818252'),
(23,3,'2026-06-05 07:58:44',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 16:58:43.969663'),
(24,3,'2026-06-05 07:59:14',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 16:59:14.016687'),
(25,3,'2026-06-05 07:59:45',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 16:59:44.822553'),
(26,3,'2026-06-05 08:00:15',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:00:14.933496'),
(27,3,'2026-06-05 08:00:51',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:00:51.212872'),
(28,3,'2026-06-05 08:01:57',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:01:57.071827'),
(29,3,'2026-06-05 08:02:57',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:02:56.888302'),
(30,3,'2026-06-05 08:03:57',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:03:56.948755'),
(31,3,'2026-06-05 08:04:50',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:04:50.011642'),
(32,3,'2026-06-05 08:05:25',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:05:25.103770'),
(33,3,'2026-06-05 08:05:58',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:05:57.902747'),
(34,3,'2026-06-05 08:06:31',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:06:30.622407'),
(35,3,'2026-06-05 08:07:12',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:07:11.575588'),
(36,3,'2026-06-05 08:07:44',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:07:44.009919'),
(37,3,'2026-06-05 08:08:18',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:08:17.570734'),
(38,3,'2026-06-05 08:08:48',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:08:47.851400'),
(39,3,'2026-06-05 08:09:20',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:09:19.844731'),
(40,3,'2026-06-05 08:09:51',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:09:50.946469'),
(41,3,'2026-06-05 08:10:25',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:10:24.941332'),
(42,3,'2026-06-05 08:10:55',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:10:54.935460'),
(43,3,'2026-06-05 08:11:30',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:11:30.070919'),
(44,3,'2026-06-05 08:12:05',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:12:04.614567'),
(45,3,'2026-06-05 08:12:35',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:12:35.254407'),
(46,3,'2026-06-05 08:13:10',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:13:09.501766'),
(47,3,'2026-06-05 08:13:40',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:13:39.964804'),
(48,3,'2026-06-05 08:14:15',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:14:14.879812'),
(49,3,'2026-06-05 08:14:50',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:14:49.649915'),
(50,3,'2026-06-05 08:15:20',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:15:20.110952'),
(51,3,'2026-06-05 08:15:55',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:15:55.136113'),
(52,3,'2026-06-05 08:16:30',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:16:29.728330'),
(53,3,'2026-06-05 08:17:00',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:17:00.231252'),
(54,3,'2026-06-05 08:17:30',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:17:30.404890'),
(55,3,'2026-06-05 08:18:02',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:18:02.023574'),
(56,3,'2026-06-05 08:19:01',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:19:01.326538'),
(57,3,'2026-06-05 08:19:20',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:19:20.187125'),
(58,3,'2026-06-05 08:20:04',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:20:04.176096'),
(59,3,'2026-06-05 08:20:35',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:20:34.829620'),
(60,3,'2026-06-05 08:21:05',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:21:05.214464'),
(61,3,'2026-06-05 08:21:40',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:21:39.933321'),
(62,3,'2026-06-05 08:22:16',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:22:15.688167'),
(63,3,'2026-06-05 08:22:50',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:22:49.931279'),
(64,3,'2026-06-05 08:23:20',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:23:20.275803'),
(65,3,'2026-06-05 08:23:55',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:23:55.310906'),
(66,3,'2026-06-05 08:24:26',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:24:26.180363'),
(67,3,'2026-06-05 08:25:00',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:25:00.149939'),
(68,3,'2026-06-05 08:25:30',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:25:30.174523'),
(69,3,'2026-06-05 08:26:01',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:26:01.088154'),
(70,3,'2026-06-05 08:26:35',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:26:35.493063'),
(71,3,'2026-06-05 08:27:11',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:27:10.595948'),
(72,3,'2026-06-05 08:27:45',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:27:45.088427'),
(73,3,'2026-06-05 08:28:16',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:28:15.563309'),
(74,3,'2026-06-05 08:28:50',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:28:49.825168'),
(75,3,'2026-06-05 08:29:21',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:29:20.633444'),
(76,3,'2026-06-05 08:29:55',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:29:54.845699'),
(77,3,'2026-06-05 08:30:26',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:30:25.919591'),
(78,3,'2026-06-05 08:30:58',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:30:57.965951'),
(79,3,'2026-06-05 08:31:29',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:31:28.818566'),
(80,3,'2026-06-05 08:32:03',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:32:03.382957'),
(81,3,'2026-06-05 08:32:34',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:32:34.082436'),
(82,3,'2026-06-05 08:33:04',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:33:04.067968'),
(83,3,'2026-06-05 08:33:34',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:33:34.305501'),
(84,3,'2026-06-05 08:34:09',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:34:08.680629'),
(85,3,'2026-06-05 08:34:39',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:34:39.096668'),
(86,3,'2026-06-05 08:35:13',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:35:13.310847'),
(87,3,'2026-06-05 08:35:44',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:35:43.638719'),
(88,3,'2026-06-05 08:36:14',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:36:13.692731'),
(89,3,'2026-06-05 08:36:44',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:36:44.162554'),
(90,3,'2026-06-05 08:37:14',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:37:14.193275'),
(91,3,'2026-06-05 08:37:44',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:37:44.287479'),
(92,3,'2026-06-05 08:38:19',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:38:18.559404'),
(93,3,'2026-06-05 08:38:49',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:38:49.016238'),
(94,3,'2026-06-05 08:39:19',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:39:19.259837'),
(95,3,'2026-06-05 08:39:54',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:39:53.528512'),
(96,3,'2026-06-05 08:40:24',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:40:23.876493'),
(97,3,'2026-06-05 08:40:55',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:40:54.669491'),
(98,3,'2026-06-05 08:41:29',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:41:28.542233'),
(99,3,'2026-06-05 08:41:59',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:41:58.957950'),
(100,3,'2026-06-05 08:42:29',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:42:29.187813'),
(101,3,'2026-06-05 08:43:04',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:43:03.677456'),
(102,3,'2026-06-05 08:43:34',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:43:34.302489'),
(103,3,'2026-06-05 08:44:08',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:44:08.178127'),
(104,3,'2026-06-05 08:44:39',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:44:38.803531'),
(105,3,'2026-06-05 08:45:13',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:45:13.157705'),
(106,3,'2026-06-05 08:45:44',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:45:44.090989'),
(107,3,'2026-06-05 08:46:14',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:46:14.459009'),
(108,3,'2026-06-05 08:46:36',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 17:46:36.194290'),
(109,3,'2026-06-05 09:07:11',NULL,NULL,NULL,NULL,NULL,NULL,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 18:07:11.408027'),
(110,3,'2026-06-05 13:19:29',400.18,400.61,398.83,98.63,92.74,86.56,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 22:19:29.575213'),
(111,3,'2026-06-05 13:24:57',400.18,400.61,398.83,98.63,92.74,86.56,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 22:24:57.274263'),
(112,3,'2026-06-05 13:28:37',400.18,400.61,398.83,98.63,92.74,86.56,58.198,12151.435,0.907,49.989,10.321,10.321,10.321,NULL,NULL,NULL,27.021,64.165,'live','2026-06-05 22:28:37.904142'),
(113,1,'2026-06-06 08:29:14',400.46,400.97,399.18,32.47,25.93,26.17,17.597,12051.435,0.901,49.996,10.116,10.116,10.116,NULL,NULL,NULL,8.473,19.531,'live','2026-06-06 17:29:14.584667'),
(114,1,'2026-06-06 08:39:25',400.46,400.97,399.18,32.47,25.93,26.17,17.597,12051.435,0.901,49.996,10.116,10.116,10.116,NULL,NULL,NULL,8.473,19.531,'live','2026-06-06 17:39:25.418592'),
(115,1,'2026-06-06 08:39:45',400.46,400.97,399.18,32.47,25.93,26.17,17.597,12051.435,0.901,49.996,10.116,10.116,10.116,NULL,NULL,NULL,8.473,19.531,'live','2026-06-06 17:39:45.737425'),
(116,1,'2026-06-06 08:40:07',400.46,400.97,399.18,32.47,25.93,26.17,17.597,12051.435,0.901,49.996,10.116,10.116,10.116,NULL,NULL,NULL,8.473,19.531,'live','2026-06-06 17:40:07.944528'),
(117,1,'2026-06-06 08:54:10',400.46,400.97,399.18,32.47,25.93,26.17,17.597,12051.435,0.901,49.996,10.116,10.116,10.116,NULL,NULL,NULL,8.473,19.531,'live','2026-06-06 17:54:10.448880'),
(118,1,'2026-06-06 08:54:44',400.46,400.97,399.18,32.47,25.93,26.17,17.597,12051.435,0.901,49.996,10.116,10.116,10.116,NULL,NULL,NULL,8.473,19.531,'live','2026-06-06 17:54:44.494160');
/*!40000 ALTER TABLE `eq_energy_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eq_recommendations`
--

DROP TABLE IF EXISTS `eq_recommendations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `eq_recommendations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_id` int(11) NOT NULL,
  `priority` int(11) NOT NULL DEFAULT 1,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `expected_saving` decimal(14,2) DEFAULT NULL,
  `investment_cost` decimal(14,2) DEFAULT NULL,
  `payback_period` varchar(64) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  PRIMARY KEY (`id`),
  KEY `idx_eq_recommendations_report` (`report_id`,`priority`),
  CONSTRAINT `fk_eq_recommendations_report` FOREIGN KEY (`report_id`) REFERENCES `eq_reports` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eq_recommendations`
--

LOCK TABLES `eq_recommendations` WRITE;
/*!40000 ALTER TABLE `eq_recommendations` DISABLE KEYS */;
INSERT INTO `eq_recommendations` VALUES
(1,1,1,'GE Energy Tech Smart Power 설치','설치 전 비교 — 전압 조정, 3상 전류 조정, 안정화·고조파 제어, 피크/비피크 전력 저장',NULL,NULL,NULL,'2026-06-05 18:07:11.472252'),
(2,1,2,'피크 수요 관리','00:00–01:00 피크 — 부하 이동 검토.',NULL,NULL,NULL,'2026-06-05 18:07:11.479818'),
(3,1,3,'지속 모니터링','GE IoT 실시간 모니터링으로 추세 검증.',NULL,NULL,NULL,'2026-06-05 18:07:11.488835'),
(4,2,1,'GE Energy Tech Smart Power 설치','설치 전 비교 — 전압 조정, 3상 전류 조정, 안정화·고조파 제어, 피크/비피크 전력 저장',NULL,NULL,NULL,'2026-06-05 22:19:29.896104'),
(5,2,2,'지속 모니터링','GE IoT 실시간 모니터링으로 추세 검증.',NULL,NULL,NULL,'2026-06-05 22:19:29.918803'),
(6,3,1,'GE Energy Tech Smart Power 설치','설치 전 비교 — 전압 조정, 3상 전류 조정, 안정화·고조파 제어, 피크/비피크 전력 저장',NULL,NULL,NULL,'2026-06-05 22:24:57.471351'),
(7,3,2,'지속 모니터링','GE IoT 실시간 모니터링으로 추세 검증.',NULL,NULL,NULL,'2026-06-05 22:24:57.494224'),
(8,4,1,'GE Energy Tech Smart Power 설치','설치 전 비교 — 전압 조정, 3상 전류 조정, 안정화·고조파 제어, 피크/비피크 전력 저장',NULL,NULL,NULL,'2026-06-05 22:28:38.183524'),
(9,4,2,'지속 모니터링','GE IoT 실시간 모니터링으로 추세 검증.',NULL,NULL,NULL,'2026-06-05 22:28:38.247602'),
(10,5,1,'ติดตั้งระบบ GE Energy Tech Smart Saving','เปรียบเทียบก่อนติดตั้ง — ระบบปรับแรงดัน ปรับกระแส 3 เฟส ปรับเสถียรลดฮาร์มอนิก และเก็บกระแสไฟใช้ช่วง Peak/Off-peak',NULL,NULL,NULL,'2026-06-06 17:29:14.919810'),
(11,5,2,'กระจายโหลด 3 เฟส','สมดุล L1/L2/L3 ลดความเครียดสายและเบรกเกอร์',NULL,NULL,NULL,'2026-06-06 17:29:15.001369'),
(12,5,3,'ติดตามอย่างต่อเนื่อง','ใช้ระบบ GE IoT ติดตามแนวโน้ม',NULL,NULL,NULL,'2026-06-06 17:29:15.026953'),
(13,6,1,'ติดตั้งระบบ GE Energy Tech Smart Saving','เปรียบเทียบก่อนติดตั้ง — ระบบปรับแรงดัน ปรับกระแส 3 เฟส ปรับเสถียรลดฮาร์มอนิก และเก็บกระแสไฟใช้ช่วง Peak/Off-peak',NULL,NULL,NULL,'2026-06-06 17:39:25.796241'),
(14,6,2,'กระจายโหลด 3 เฟส','สมดุล L1/L2/L3 ลดความเครียดสายและเบรกเกอร์',NULL,NULL,NULL,'2026-06-06 17:39:25.826627'),
(15,6,3,'ติดตามอย่างต่อเนื่อง','ใช้ระบบ GE IoT ติดตามแนวโน้ม',NULL,NULL,NULL,'2026-06-06 17:39:27.509391'),
(16,7,1,'ติดตั้งระบบ GE Energy Tech Smart Saving','เปรียบเทียบก่อนติดตั้ง — ระบบปรับแรงดัน ปรับกระแส 3 เฟส ปรับเสถียรลดฮาร์มอนิก และเก็บกระแสไฟใช้ช่วง Peak/Off-peak',NULL,NULL,NULL,'2026-06-06 17:39:45.951637'),
(17,7,2,'กระจายโหลด 3 เฟส','สมดุล L1/L2/L3 ลดความเครียดสายและเบรกเกอร์',NULL,NULL,NULL,'2026-06-06 17:39:45.973765'),
(18,7,3,'ติดตามอย่างต่อเนื่อง','ใช้ระบบ GE IoT ติดตามแนวโน้ม',NULL,NULL,NULL,'2026-06-06 17:39:45.998264'),
(19,8,1,'ติดตั้งระบบ GE Energy Tech Smart Saving','เปรียบเทียบก่อนติดตั้ง — ระบบปรับแรงดัน ปรับกระแส 3 เฟส ปรับเสถียรลดฮาร์มอนิก และเก็บกระแสไฟใช้ช่วง Peak/Off-peak',NULL,NULL,NULL,'2026-06-06 17:40:08.234936'),
(20,8,2,'กระจายโหลด 3 เฟส','สมดุล L1/L2/L3 ลดความเครียดสายและเบรกเกอร์',NULL,NULL,NULL,'2026-06-06 17:40:08.255486'),
(21,8,3,'ติดตามอย่างต่อเนื่อง','ใช้ระบบ GE IoT ติดตามแนวโน้ม',NULL,NULL,NULL,'2026-06-06 17:40:08.279773'),
(22,9,1,'ติดตั้งระบบ GE Energy Tech Smart Saving','เปรียบเทียบก่อนติดตั้ง — ระบบปรับแรงดัน ปรับกระแส 3 เฟส ปรับเสถียรลดฮาร์มอนิก และเก็บกระแสไฟใช้ช่วง Peak/Off-peak',NULL,NULL,NULL,'2026-06-06 17:54:11.551330'),
(23,9,2,'กระจายโหลด 3 เฟส','สมดุล L1/L2/L3 ลดความเครียดสายและเบรกเกอร์',NULL,NULL,NULL,'2026-06-06 17:54:11.609657'),
(24,9,3,'ติดตามอย่างต่อเนื่อง','ใช้ระบบ GE IoT ติดตามแนวโน้ม',NULL,NULL,NULL,'2026-06-06 17:54:11.818373'),
(25,10,1,'ติดตั้งระบบ GE Energy Tech Smart Saving','เปรียบเทียบก่อนติดตั้ง — ระบบปรับแรงดัน ปรับกระแส 3 เฟส ปรับเสถียรลดฮาร์มอนิก และเก็บกระแสไฟใช้ช่วง Peak/Off-peak',NULL,NULL,NULL,'2026-06-06 17:54:44.781819'),
(26,10,2,'กระจายโหลด 3 เฟส','สมดุล L1/L2/L3 ลดความเครียดสายและเบรกเกอร์',NULL,NULL,NULL,'2026-06-06 17:54:44.810337'),
(27,10,3,'ติดตามอย่างต่อเนื่อง','ใช้ระบบ GE IoT ติดตามแนวโน้ม',NULL,NULL,NULL,'2026-06-06 17:54:44.833861');
/*!40000 ALTER TABLE `eq_recommendations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eq_reports`
--

DROP TABLE IF EXISTS `eq_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `eq_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_number` varchar(64) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `site_id` int(11) DEFAULT NULL,
  `device_id` int(11) NOT NULL,
  `report_title` varchar(255) DEFAULT 'Customer Energy Analysis Report',
  `measurement_start` datetime DEFAULT NULL,
  `measurement_end` datetime DEFAULT NULL,
  `issue_date` datetime NOT NULL DEFAULT current_timestamp(),
  `prepared_by` varchar(255) DEFAULT 'GE Energy Tech',
  `report_status` enum('draft','analyzed','reviewed','approved','sent','archived') NOT NULL DEFAULT 'draft',
  `pdf_file_path` varchar(512) DEFAULT NULL,
  `locale` varchar(10) DEFAULT 'th',
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_eq_reports_number` (`report_number`),
  KEY `idx_eq_reports_device` (`device_id`),
  KEY `idx_eq_reports_status` (`report_status`),
  KEY `fk_eq_reports_customer` (`customer_id`),
  KEY `fk_eq_reports_site` (`site_id`),
  CONSTRAINT `fk_eq_reports_customer` FOREIGN KEY (`customer_id`) REFERENCES `eq_customers` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_eq_reports_device` FOREIGN KEY (`device_id`) REFERENCES `devices` (`deviceID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_eq_reports_site` FOREIGN KEY (`site_id`) REFERENCES `eq_sites` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eq_reports`
--

LOCK TABLES `eq_reports` WRITE;
/*!40000 ALTER TABLE `eq_reports` DISABLE KEYS */;
INSERT INTO `eq_reports` VALUES
(1,'GE-EQ-3-20260605-001',3,3,3,'Customer Energy Analysis Report',NULL,NULL,'2026-06-05 18:07:11','GE Energy Tech','analyzed',NULL,'ko','2026-06-05 18:07:11.424532','2026-06-05 18:07:11.424532'),
(2,'GE-EQ-3-20260605-002',3,3,3,'Customer Energy Analysis Report',NULL,NULL,'2026-06-05 22:19:29','GE Energy Tech','analyzed',NULL,'ko','2026-06-05 22:19:29.616401','2026-06-05 22:19:29.616401'),
(3,'GE-EQ-3-20260605-003',3,3,3,'Customer Energy Analysis Report',NULL,NULL,'2026-06-05 22:24:57','GE Energy Tech','analyzed',NULL,'ko','2026-06-05 22:24:57.335468','2026-06-05 22:24:57.335468'),
(4,'GE-EQ-3-20260605-004',3,3,3,'Customer Energy Analysis Report',NULL,NULL,'2026-06-05 22:28:37','GE Energy Tech','analyzed',NULL,'ko','2026-06-05 22:28:37.930167','2026-06-05 22:28:37.930167'),
(5,'GE-EQ-1-20260606-001',1,1,1,'Customer Energy Analysis Report','2569-04-06 20:32:35','2569-05-06 20:27:35','2026-06-06 17:29:14','GE Energy Tech','analyzed',NULL,'th','2026-06-06 17:29:14.637957','2026-06-06 17:29:14.637957'),
(6,'GE-EQ-1-20260606-002',1,1,1,'Customer Energy Analysis Report','2569-04-06 20:32:35','2569-05-06 20:27:35','2026-06-06 17:39:25','GE Energy Tech','analyzed',NULL,'th','2026-06-06 17:39:25.456094','2026-06-06 17:39:25.456094'),
(7,'GE-EQ-1-20260606-003',1,1,1,'Customer Energy Analysis Report','2569-04-06 20:32:35','2569-05-06 20:27:35','2026-06-06 17:39:45','GE Energy Tech','analyzed',NULL,'th','2026-06-06 17:39:45.768734','2026-06-06 17:39:45.768734'),
(8,'GE-EQ-1-20260606-004',1,1,1,'Customer Energy Analysis Report','2569-04-06 20:32:35','2569-05-06 20:27:35','2026-06-06 17:40:07','GE Energy Tech','analyzed',NULL,'th','2026-06-06 17:40:07.970915','2026-06-06 17:40:07.970915'),
(9,'GE-EQ-1-20260606-005',1,1,1,'Customer Energy Analysis Report','2569-04-06 20:32:35','2569-05-06 20:27:35','2026-06-06 17:54:10','GE Energy Tech','analyzed',NULL,'th','2026-06-06 17:54:10.936836','2026-06-06 17:54:10.936836'),
(10,'GE-EQ-1-20260606-006',1,1,1,'Customer Energy Analysis Report','2569-04-06 20:32:35','2569-05-06 20:27:35','2026-06-06 17:54:44','GE Energy Tech','analyzed',NULL,'th','2026-06-06 17:54:44.573684','2026-06-06 17:54:44.573684');
/*!40000 ALTER TABLE `eq_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eq_sites`
--

DROP TABLE IF EXISTS `eq_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `eq_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `site_name` varchar(255) NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `site_region` varchar(50) DEFAULT 'thailand' COMMENT 'thailand|korea|vietnam|malaysia',
  `transformer_size` varchar(100) DEFAULT NULL,
  `contract_demand` decimal(12,3) DEFAULT NULL,
  `voltage_system` varchar(50) DEFAULT '3-Phase 400V',
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`id`),
  KEY `idx_eq_sites_customer` (`customer_id`),
  KEY `idx_eq_sites_region` (`site_region`),
  CONSTRAINT `fk_eq_sites_customer` FOREIGN KEY (`customer_id`) REFERENCES `eq_customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eq_sites`
--

LOCK TABLES `eq_sites` WRITE;
/*!40000 ALTER TABLE `eq_sites` DISABLE KEYS */;
INSERT INTO `eq_sites` VALUES
(1,1,'GE01','KOREA','korea','500 kVA',350.000,'3-Phase 400V','2026-06-05 11:25:20.014517','2026-06-05 12:12:50.269464'),
(2,2,'GE02','KOREA','korea','500 kVA',350.000,'3-Phase 400V','2026-06-05 11:25:20.064739','2026-06-05 12:12:50.295657'),
(3,3,'GE-TH01','Bangkok','thailand','500 kVA',350.000,'3-Phase 400V','2026-06-05 11:25:20.130970','2026-06-05 12:12:50.318624');
/*!40000 ALTER TABLE `eq_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback_replies`
--

DROP TABLE IF EXISTS `feedback_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `feedback_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `feedback_id` int(11) NOT NULL,
  `sender_type` enum('partner','customer') NOT NULL DEFAULT 'partner',
  `sender_name` varchar(255) DEFAULT NULL,
  `message` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_feedback_id` (`feedback_id`),
  CONSTRAINT `fk_feedback_replies_feedback_id` FOREIGN KEY (`feedback_id`) REFERENCES `user_feedback` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback_replies`
--

LOCK TABLES `feedback_replies` WRITE;
/*!40000 ALTER TABLE `feedback_replies` DISABLE KEYS */;
INSERT INTO `feedback_replies` VALUES
(1,1,'partner','Super Admin','00000','2026-05-26 01:08:18'),
(2,2,'partner','Super Admin','0000000','2026-05-26 01:14:28'),
(3,2,'customer','pavinee boknoi','0000','2026-05-26 01:30:16'),
(4,2,'partner','Super Admin','152435','2026-05-26 01:30:46'),
(5,2,'customer','pavinee boknoi','12','2026-05-26 01:46:26'),
(6,1,'customer','pavinee boknoi','Hi','2026-05-31 15:36:36'),
(7,1,'customer','pavinee boknoi','สวัสดี','2026-05-31 15:37:10');
/*!40000 ALTER TABLE `feedback_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_after_sales_chat_message`
--

DROP TABLE IF EXISTS `ge_after_sales_chat_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_after_sales_chat_message` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `thread_id` bigint(20) unsigned NOT NULL,
  `sender` varchar(20) NOT NULL,
  `sender_name` varchar(191) DEFAULT NULL,
  `message_text` text NOT NULL,
  `read_by_customer` tinyint(1) NOT NULL DEFAULT 0,
  `read_by_agent` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ge_after_sales_chat_message_thread` (`thread_id`,`id`),
  CONSTRAINT `fk_ge_after_sales_chat_message_thread` FOREIGN KEY (`thread_id`) REFERENCES `ge_after_sales_chat_thread` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_after_sales_chat_message`
--

LOCK TABLES `ge_after_sales_chat_message` WRITE;
/*!40000 ALTER TABLE `ge_after_sales_chat_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_after_sales_chat_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_after_sales_chat_thread`
--

DROP TABLE IF EXISTS `ge_after_sales_chat_thread`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_after_sales_chat_thread` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `thread_code` varchar(64) NOT NULL,
  `customer_lang` varchar(16) DEFAULT NULL,
  `customer_name` varchar(191) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'open',
  `last_message_preview` varchar(500) DEFAULT NULL,
  `last_customer_message_at` datetime DEFAULT NULL,
  `last_agent_message_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ge_after_sales_chat_thread_code` (`thread_code`),
  KEY `idx_ge_after_sales_chat_thread_status` (`status`),
  KEY `idx_ge_after_sales_chat_thread_updated` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_after_sales_chat_thread`
--

LOCK TABLES `ge_after_sales_chat_thread` WRITE;
/*!40000 ALTER TABLE `ge_after_sales_chat_thread` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_after_sales_chat_thread` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_customer_energy_saver_orders`
--

DROP TABLE IF EXISTS `ge_customer_energy_saver_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_customer_energy_saver_orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_no` varchar(64) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `shipping_address` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(80) NOT NULL,
  `breaker_size` varchar(64) NOT NULL,
  `machine_kva` varchar(64) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `unit_price` int(11) NOT NULL DEFAULT 0,
  `total_price` int(11) NOT NULL DEFAULT 0,
  `site_photo_path` varchar(512) NOT NULL DEFAULT '',
  `payment_slip_path` varchar(512) NOT NULL DEFAULT '',
  `monthly_bill_paths_json` longtext DEFAULT NULL,
  `monthly_bill_count` int(11) NOT NULL DEFAULT 0,
  `status` varchar(32) NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_customer_energy_saver_order_no` (`order_no`),
  KEY `idx_customer_energy_saver_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_customer_energy_saver_orders`
--

LOCK TABLES `ge_customer_energy_saver_orders` WRITE;
/*!40000 ALTER TABLE `ge_customer_energy_saver_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_customer_energy_saver_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_electricity_rates`
--

DROP TABLE IF EXISTS `ge_electricity_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_electricity_rates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site` varchar(32) NOT NULL,
  `rate_per_kwh` decimal(12,4) NOT NULL,
  `effective_from` datetime DEFAULT NULL,
  `effective_to` datetime DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`id`),
  KEY `idx_ge_rates_site` (`site`),
  KEY `idx_ge_rates_range` (`site`,`effective_from`,`effective_to`),
  KEY `idx_ge_rates_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_electricity_rates`
--

LOCK TABLES `ge_electricity_rates` WRITE;
/*!40000 ALTER TABLE `ge_electricity_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_electricity_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_energy_meter_device_binding`
--

DROP TABLE IF EXISTS `ge_energy_meter_device_binding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_energy_meter_device_binding` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `device_id` bigint(20) NOT NULL,
  `meter_id` varchar(191) NOT NULL,
  `meter_channel` varchar(8) NOT NULL DEFAULT 'ch1',
  `meter_role` varchar(16) NOT NULL DEFAULT 'output',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ge_energy_meter_binding_meter_channel` (`meter_id`,`meter_channel`),
  UNIQUE KEY `uq_ge_energy_meter_binding_device_role` (`device_id`,`meter_role`),
  KEY `idx_ge_energy_meter_binding_device` (`device_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_energy_meter_device_binding`
--

LOCK TABLES `ge_energy_meter_device_binding` WRITE;
/*!40000 ALTER TABLE `ge_energy_meter_device_binding` DISABLE KEYS */;
INSERT INTO `ge_energy_meter_device_binding` VALUES
(1,1,'GE-KR-0004','ch1','input','2026-06-13 19:23:20','2026-06-13 19:23:52'),
(2,1,'GE-KR-0004','ch2','output','2026-06-13 19:23:44','2026-06-13 19:23:53');
/*!40000 ALTER TABLE `ge_energy_meter_device_binding` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_ai_insight`
--

DROP TABLE IF EXISTS `ge_erp_ai_insight`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_ai_insight` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `insight_type` varchar(20) NOT NULL COMMENT 'performance|issue|growth',
  `department_id` int(10) unsigned DEFAULT NULL,
  `period_key` varchar(12) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `summary` text DEFAULT NULL,
  `problem_detail` text DEFAULT NULL,
  `fix_recommendation` text DEFAULT NULL,
  `trend_direction` varchar(12) DEFAULT NULL COMMENT 'up|down|stable',
  `trend_pct` decimal(8,2) DEFAULT NULL,
  `severity` varchar(20) NOT NULL DEFAULT 'info',
  `is_resolved` tinyint(1) NOT NULL DEFAULT 0,
  `generated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ge_erp_ai_type` (`insight_type`),
  KEY `idx_ge_erp_ai_dept` (`department_id`),
  KEY `idx_ge_erp_ai_generated` (`generated_at`),
  CONSTRAINT `fk_ge_erp_ai_dept` FOREIGN KEY (`department_id`) REFERENCES `ge_erp_department` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_ai_insight`
--

LOCK TABLES `ge_erp_ai_insight` WRITE;
/*!40000 ALTER TABLE `ge_erp_ai_insight` DISABLE KEYS */;
INSERT INTO `ge_erp_ai_insight` VALUES
(9,'performance',NULL,'2026-05','Company financial snapshot','Revenue (invoiced) 0 THB, expenses 0 THB. Estimated margin 0.0%.',NULL,'Review high-cost expense categories and accelerate collections on open invoices.','stable',0.00,'warning',0,'2026-05-27 23:28:53'),
(10,'growth',3,'2026-05','Sales & market activity trend','0 sales orders on record; pipeline units 0.',NULL,'Align marketing campaigns with top-selling products; expand follow-ups on customer contact reports.','stable',0.00,'info',0,'2026-05-27 23:28:53'),
(55,'performance',NULL,'2026-05','Company financial snapshot','Revenue (invoiced) ₩0, expenses ₩0. Estimated margin 0.0%.',NULL,'Review high-cost expense categories and accelerate collections on open invoices.','stable',0.00,'warning',0,'2026-05-28 23:43:04'),
(56,'growth',3,'2026-05','Sales & market activity trend','0 sales orders on record; pipeline units 0.',NULL,'Align marketing campaigns with top-selling products; expand follow-ups on customer contact reports.','stable',0.00,'info',0,'2026-05-28 23:43:04'),
(57,'performance',NULL,'2026-05','Company financial snapshot','Revenue (invoiced) ₩0, expenses ₩0. Estimated margin 0.0%.',NULL,'Review high-cost expense categories and accelerate collections on open invoices.','stable',0.00,'warning',0,'2026-05-30 22:19:56'),
(58,'growth',3,'2026-05','Sales & market activity trend','0 sales orders on record; pipeline units 0.',NULL,'Align marketing campaigns with top-selling products; expand follow-ups on customer contact reports.','stable',0.00,'info',0,'2026-05-30 22:19:56'),
(67,'performance',NULL,'2026-05','Company financial snapshot','Revenue (invoiced) ₩0, expenses ₩0. Estimated margin 0.0%.',NULL,'Review high-cost expense categories and accelerate collections on open invoices.','stable',0.00,'warning',0,'2026-05-31 16:42:07'),
(68,'growth',3,'2026-05','Sales & market activity trend','0 sales orders on record; pipeline units 0.',NULL,'Align marketing campaigns with top-selling products; expand follow-ups on customer contact reports.','stable',0.00,'info',0,'2026-05-31 16:42:07'),
(69,'performance',NULL,'2026-06','Company financial snapshot','Revenue (invoiced) ₩0, expenses ₩0. Estimated margin 0.0%.',NULL,'Review high-cost expense categories and accelerate collections on open invoices.','stable',0.00,'warning',0,'2026-06-03 10:25:10'),
(70,'growth',3,'2026-06','Sales & market activity trend','0 sales orders on record; pipeline units 0.',NULL,'Align marketing campaigns with top-selling products; expand follow-ups on customer contact reports.','stable',0.00,'info',0,'2026-06-03 10:25:10');
/*!40000 ALTER TABLE `ge_erp_ai_insight` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_approval_request`
--

DROP TABLE IF EXISTS `ge_erp_approval_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_approval_request` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `request_no` varchar(40) NOT NULL,
  `department_id` int(10) unsigned NOT NULL,
  `source_type` varchar(40) NOT NULL,
  `source_id` int(10) unsigned NOT NULL,
  `title` varchar(200) NOT NULL,
  `amount` decimal(14,2) DEFAULT NULL,
  `requested_by` int(10) unsigned DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `priority` varchar(20) NOT NULL DEFAULT 'normal',
  `due_date` date DEFAULT NULL,
  `reviewed_by_user_id` varchar(191) DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `review_note` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ge_erp_approval_no` (`request_no`),
  UNIQUE KEY `uk_ge_erp_approval_source` (`source_type`,`source_id`),
  KEY `idx_ge_erp_approval_status` (`status`),
  KEY `idx_ge_erp_approval_dept` (`department_id`),
  KEY `fk_ge_erp_approval_employee` (`requested_by`),
  CONSTRAINT `fk_ge_erp_approval_dept` FOREIGN KEY (`department_id`) REFERENCES `ge_erp_department` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_ge_erp_approval_employee` FOREIGN KEY (`requested_by`) REFERENCES `ge_erp_employee` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_approval_request`
--

LOCK TABLES `ge_erp_approval_request` WRITE;
/*!40000 ALTER TABLE `ge_erp_approval_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_approval_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_attendance_log`
--

DROP TABLE IF EXISTS `ge_erp_attendance_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_attendance_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(10) unsigned NOT NULL,
  `log_date` date NOT NULL,
  `check_in` time DEFAULT NULL,
  `check_out` time DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'present',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ge_erp_attendance_emp_date` (`employee_id`,`log_date`),
  CONSTRAINT `fk_ge_erp_attendance_emp` FOREIGN KEY (`employee_id`) REFERENCES `ge_erp_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_attendance_log`
--

LOCK TABLES `ge_erp_attendance_log` WRITE;
/*!40000 ALTER TABLE `ge_erp_attendance_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_attendance_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_budget_expense`
--

DROP TABLE IF EXISTS `ge_erp_budget_expense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_budget_expense` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(10) unsigned NOT NULL,
  `category` varchar(80) NOT NULL,
  `amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `expense_date` date NOT NULL,
  `approver` varchar(120) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_ge_erp_budget_exp_project` (`project_id`),
  CONSTRAINT `fk_ge_erp_budget_exp_project` FOREIGN KEY (`project_id`) REFERENCES `ge_erp_project` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_budget_expense`
--

LOCK TABLES `ge_erp_budget_expense` WRITE;
/*!40000 ALTER TABLE `ge_erp_budget_expense` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_budget_expense` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_credit_note`
--

DROP TABLE IF EXISTS `ge_erp_credit_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_credit_note` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `credit_note_no` varchar(40) NOT NULL,
  `invoice_id` int(10) unsigned DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `created_by` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ge_erp_cn_no` (`credit_note_no`),
  KEY `fk_ge_erp_cn_invoice` (`invoice_id`),
  CONSTRAINT `fk_ge_erp_cn_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `ge_erp_invoice` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_credit_note`
--

LOCK TABLES `ge_erp_credit_note` WRITE;
/*!40000 ALTER TABLE `ge_erp_credit_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_credit_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_customer`
--

DROP TABLE IF EXISTS `ge_erp_customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_customer` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company` varchar(200) NOT NULL,
  `contact` varchar(120) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_by` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_customer`
--

LOCK TABLES `ge_erp_customer` WRITE;
/*!40000 ALTER TABLE `ge_erp_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_customer_contact`
--

DROP TABLE IF EXISTS `ge_erp_customer_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_customer_contact` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) unsigned NOT NULL,
  `contact_date` date NOT NULL,
  `channel` varchar(40) DEFAULT NULL,
  `topic` varchar(200) DEFAULT NULL,
  `owner_name` varchar(120) DEFAULT NULL,
  `next_step` varchar(200) DEFAULT NULL,
  `created_by` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ge_erp_cust_contact` (`customer_id`),
  CONSTRAINT `fk_ge_erp_cust_contact` FOREIGN KEY (`customer_id`) REFERENCES `ge_erp_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_customer_contact`
--

LOCK TABLES `ge_erp_customer_contact` WRITE;
/*!40000 ALTER TABLE `ge_erp_customer_contact` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_customer_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_daily_work_report`
--

DROP TABLE IF EXISTS `ge_erp_daily_work_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_daily_work_report` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `report_date` date NOT NULL,
  `department_id` int(10) unsigned NOT NULL,
  `employee_id` int(10) unsigned DEFAULT NULL,
  `reporter_name` varchar(120) DEFAULT NULL,
  `work_summary` text NOT NULL,
  `hours_worked` decimal(5,2) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'submitted',
  `created_by` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ge_erp_daily_report_date` (`report_date`),
  KEY `idx_ge_erp_daily_report_dept` (`department_id`),
  KEY `idx_ge_erp_daily_report_emp` (`employee_id`),
  CONSTRAINT `fk_ge_erp_daily_report_dept` FOREIGN KEY (`department_id`) REFERENCES `ge_erp_department` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_ge_erp_daily_report_emp` FOREIGN KEY (`employee_id`) REFERENCES `ge_erp_employee` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_daily_work_report`
--

LOCK TABLES `ge_erp_daily_work_report` WRITE;
/*!40000 ALTER TABLE `ge_erp_daily_work_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_daily_work_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_department`
--

DROP TABLE IF EXISTS `ge_erp_department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_department` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(40) NOT NULL,
  `name_th` varchar(120) NOT NULL,
  `name_en` varchar(120) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ge_erp_dept_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=12919 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_department`
--

LOCK TABLES `ge_erp_department` WRITE;
/*!40000 ALTER TABLE `ge_erp_department` DISABLE KEYS */;
INSERT INTO `ge_erp_department` VALUES
(1,'executive','ฝ่ายผู้บริหาร','Executive',0,'2026-05-27 20:45:27'),
(2,'production','ฝ่ายผลิต','Production',1,'2026-05-27 20:45:27'),
(3,'marketing','ฝ่ายการตลาด','Marketing',2,'2026-05-27 20:45:27'),
(4,'accounting','ฝ่ายบัญชี','Accounting',3,'2026-05-27 20:45:27'),
(5,'hr','ฝ่ายทรัพยากรบุคคล','Human Resources',4,'2026-05-27 20:45:27'),
(6,'rnd','ฝ่ายวิจัยและพัฒนา','R&D',5,'2026-05-27 20:45:27');
/*!40000 ALTER TABLE `ge_erp_department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_document_request`
--

DROP TABLE IF EXISTS `ge_erp_document_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_document_request` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(10) unsigned NOT NULL,
  `document_type` varchar(80) NOT NULL,
  `purpose` text DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_ge_erp_doc_req_emp` (`employee_id`),
  CONSTRAINT `fk_ge_erp_doc_req_emp` FOREIGN KEY (`employee_id`) REFERENCES `ge_erp_employee` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_document_request`
--

LOCK TABLES `ge_erp_document_request` WRITE;
/*!40000 ALTER TABLE `ge_erp_document_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_document_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_employee`
--

DROP TABLE IF EXISTS `ge_erp_employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_employee` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `employee_code` varchar(40) NOT NULL,
  `user_id` varchar(191) DEFAULT NULL,
  `full_name` varchar(120) NOT NULL,
  `department_id` int(10) unsigned DEFAULT NULL,
  `position` varchar(80) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `hire_date` date DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'active',
  `created_by` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ge_erp_employee_code` (`employee_code`),
  KEY `idx_ge_erp_employee_user` (`user_id`),
  KEY `idx_ge_erp_employee_dept` (`department_id`),
  CONSTRAINT `fk_ge_erp_employee_dept` FOREIGN KEY (`department_id`) REFERENCES `ge_erp_department` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_employee`
--

LOCK TABLES `ge_erp_employee` WRITE;
/*!40000 ALTER TABLE `ge_erp_employee` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_employee_face`
--

DROP TABLE IF EXISTS `ge_erp_employee_face`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_employee_face` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(10) unsigned NOT NULL,
  `face_descriptor` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '128-d float array from face-api' CHECK (json_valid(`face_descriptor`)),
  `photo_path` varchar(512) NOT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT 1,
  `enrolled_by` varchar(191) DEFAULT NULL,
  `enrolled_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ge_erp_face_employee` (`employee_id`),
  KEY `idx_ge_erp_face_primary` (`is_primary`),
  CONSTRAINT `fk_ge_erp_face_employee` FOREIGN KEY (`employee_id`) REFERENCES `ge_erp_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_employee_face`
--

LOCK TABLES `ge_erp_employee_face` WRITE;
/*!40000 ALTER TABLE `ge_erp_employee_face` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_employee_face` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_equipment_stock`
--

DROP TABLE IF EXISTS `ge_erp_equipment_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_equipment_stock` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `warehouse_location` varchar(80) NOT NULL DEFAULT 'main',
  `quantity` int(11) NOT NULL DEFAULT 0,
  `unit` varchar(20) NOT NULL DEFAULT 'ชิ้น',
  `status` varchar(20) NOT NULL DEFAULT 'available',
  `created_by` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ge_erp_eq_stock_product` (`product_id`),
  CONSTRAINT `fk_ge_erp_eq_stock_product` FOREIGN KEY (`product_id`) REFERENCES `ge_erp_product` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_equipment_stock`
--

LOCK TABLES `ge_erp_equipment_stock` WRITE;
/*!40000 ALTER TABLE `ge_erp_equipment_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_equipment_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_expense`
--

DROP TABLE IF EXISTS `ge_erp_expense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_expense` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `expense_date` date NOT NULL,
  `category` varchar(80) NOT NULL,
  `payee` varchar(120) DEFAULT NULL,
  `amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `note` text DEFAULT NULL,
  `created_by` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_expense`
--

LOCK TABLES `ge_erp_expense` WRITE;
/*!40000 ALTER TABLE `ge_erp_expense` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_expense` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_expense_reimbursement`
--

DROP TABLE IF EXISTS `ge_erp_expense_reimbursement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_expense_reimbursement` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(10) unsigned NOT NULL,
  `expense_date` date NOT NULL,
  `amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `purpose` text DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_ge_erp_reimb_emp` (`employee_id`),
  CONSTRAINT `fk_ge_erp_reimb_emp` FOREIGN KEY (`employee_id`) REFERENCES `ge_erp_employee` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_expense_reimbursement`
--

LOCK TABLES `ge_erp_expense_reimbursement` WRITE;
/*!40000 ALTER TABLE `ge_erp_expense_reimbursement` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_expense_reimbursement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_face_attendance`
--

DROP TABLE IF EXISTS `ge_erp_face_attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_face_attendance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(10) unsigned NOT NULL,
  `event_type` enum('check_in','check_out') NOT NULL,
  `captured_at` datetime NOT NULL,
  `photo_path` varchar(512) NOT NULL,
  `match_score` decimal(8,5) NOT NULL COMMENT 'lower = better match',
  `face_id` int(10) unsigned DEFAULT NULL,
  `device_note` varchar(255) DEFAULT NULL,
  `created_by` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ge_erp_face_att_emp` (`employee_id`),
  KEY `idx_ge_erp_face_att_time` (`captured_at`),
  KEY `idx_ge_erp_face_att_type` (`event_type`),
  KEY `fk_ge_erp_face_att_face` (`face_id`),
  CONSTRAINT `fk_ge_erp_face_att_employee` FOREIGN KEY (`employee_id`) REFERENCES `ge_erp_employee` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_ge_erp_face_att_face` FOREIGN KEY (`face_id`) REFERENCES `ge_erp_employee_face` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_face_attendance`
--

LOCK TABLES `ge_erp_face_attendance` WRITE;
/*!40000 ALTER TABLE `ge_erp_face_attendance` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_face_attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_grant_income`
--

DROP TABLE IF EXISTS `ge_erp_grant_income`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_grant_income` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(10) unsigned NOT NULL,
  `grant_no` varchar(40) NOT NULL,
  `sponsor` varchar(120) DEFAULT NULL,
  `amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `received_date` date DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_ge_erp_grant_project` (`project_id`),
  CONSTRAINT `fk_ge_erp_grant_project` FOREIGN KEY (`project_id`) REFERENCES `ge_erp_project` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_grant_income`
--

LOCK TABLES `ge_erp_grant_income` WRITE;
/*!40000 ALTER TABLE `ge_erp_grant_income` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_grant_income` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_hr_purchase_request`
--

DROP TABLE IF EXISTS `ge_erp_hr_purchase_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_hr_purchase_request` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(10) unsigned NOT NULL,
  `item_desc` varchar(200) NOT NULL,
  `amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `purpose` text DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_ge_erp_hr_pr_emp` (`employee_id`),
  CONSTRAINT `fk_ge_erp_hr_pr_emp` FOREIGN KEY (`employee_id`) REFERENCES `ge_erp_employee` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_hr_purchase_request`
--

LOCK TABLES `ge_erp_hr_purchase_request` WRITE;
/*!40000 ALTER TABLE `ge_erp_hr_purchase_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_hr_purchase_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_invoice`
--

DROP TABLE IF EXISTS `ge_erp_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_invoice` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(40) NOT NULL,
  `customer_id` int(10) unsigned NOT NULL,
  `sales_order_id` int(10) unsigned DEFAULT NULL,
  `amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `due_date` date DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'draft',
  `created_by` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ge_erp_invoice_no` (`invoice_no`),
  KEY `idx_ge_erp_invoice_customer` (`customer_id`),
  KEY `fk_ge_erp_invoice_sales` (`sales_order_id`),
  CONSTRAINT `fk_ge_erp_invoice_customer` FOREIGN KEY (`customer_id`) REFERENCES `ge_erp_customer` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_ge_erp_invoice_sales` FOREIGN KEY (`sales_order_id`) REFERENCES `ge_erp_sales_order` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_invoice`
--

LOCK TABLES `ge_erp_invoice` WRITE;
/*!40000 ALTER TABLE `ge_erp_invoice` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_ip_patent`
--

DROP TABLE IF EXISTS `ge_erp_ip_patent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_ip_patent` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(10) unsigned DEFAULT NULL,
  `ip_no` varchar(40) NOT NULL,
  `title` varchar(200) NOT NULL,
  `ip_type` varchar(40) DEFAULT NULL,
  `filed_date` date DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_ge_erp_ip_project` (`project_id`),
  CONSTRAINT `fk_ge_erp_ip_project` FOREIGN KEY (`project_id`) REFERENCES `ge_erp_project` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_ip_patent`
--

LOCK TABLES `ge_erp_ip_patent` WRITE;
/*!40000 ALTER TABLE `ge_erp_ip_patent` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_ip_patent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_issue_report`
--

DROP TABLE IF EXISTS `ge_erp_issue_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_issue_report` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ticket_no` varchar(40) NOT NULL,
  `page_key` varchar(80) DEFAULT NULL,
  `module_name` varchar(80) DEFAULT NULL,
  `severity` varchar(20) NOT NULL DEFAULT 'normal',
  `reporter_id` int(10) unsigned DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'open',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ge_erp_issue_ticket` (`ticket_no`),
  KEY `fk_ge_erp_issue_page` (`page_key`),
  KEY `fk_ge_erp_issue_reporter` (`reporter_id`),
  CONSTRAINT `fk_ge_erp_issue_page` FOREIGN KEY (`page_key`) REFERENCES `ge_erp_page` (`page_key`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_ge_erp_issue_reporter` FOREIGN KEY (`reporter_id`) REFERENCES `ge_erp_employee` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_issue_report`
--

LOCK TABLES `ge_erp_issue_report` WRITE;
/*!40000 ALTER TABLE `ge_erp_issue_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_issue_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_kpi_snapshot`
--

DROP TABLE IF EXISTS `ge_erp_kpi_snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_kpi_snapshot` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `department_id` int(10) unsigned DEFAULT NULL COMMENT 'NULL = company-wide total',
  `period_key` varchar(12) NOT NULL COMMENT 'YYYY-MM or YYYY-Qn',
  `metric_key` varchar(40) NOT NULL,
  `metric_label` varchar(120) DEFAULT NULL,
  `metric_value` decimal(16,4) NOT NULL DEFAULT 0.0000,
  `unit` varchar(24) DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ge_erp_kpi_period` (`department_id`,`period_key`,`metric_key`),
  KEY `idx_ge_erp_kpi_dept` (`department_id`),
  KEY `idx_ge_erp_kpi_period` (`period_key`),
  CONSTRAINT `fk_ge_erp_kpi_dept` FOREIGN KEY (`department_id`) REFERENCES `ge_erp_department` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=526 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_kpi_snapshot`
--

LOCK TABLES `ge_erp_kpi_snapshot` WRITE;
/*!40000 ALTER TABLE `ge_erp_kpi_snapshot` DISABLE KEYS */;
INSERT INTO `ge_erp_kpi_snapshot` VALUES
(1,2,'2026-05','output_orders','Production orders',0.0000,'orders','2026-05-31 16:42:06'),
(2,2,'2026-05','quality_pass_rate','QC pass rate',0.0000,'%','2026-05-31 16:42:06'),
(3,3,'2026-05','sales_value','Sales value',0.0000,'KRW','2026-05-31 16:42:06'),
(4,3,'2026-05','sales_orders','Sales orders',0.0000,'orders','2026-05-31 16:42:07'),
(5,4,'2026-05','invoiced','Invoiced',0.0000,'KRW','2026-05-31 16:42:07'),
(6,4,'2026-05','expenses','Expenses',0.0000,'KRW','2026-05-31 16:42:07'),
(7,5,'2026-05','headcount','Headcount',0.0000,'people','2026-05-31 16:42:07'),
(8,5,'2026-05','pending_hr_items','Pending HR items',0.0000,'items','2026-05-31 16:42:07'),
(9,6,'2026-05','active_projects','Active projects',0.0000,'projects','2026-05-31 16:42:07'),
(505,NULL,'2026-05','total_revenue','Total revenue (invoiced)',0.0000,'KRW','2026-05-31 16:42:07'),
(506,NULL,'2026-05','total_expenses','Total expenses',0.0000,'KRW','2026-05-31 16:42:07'),
(507,NULL,'2026-05','net_indicator','Net (revenue − expenses)',0.0000,'KRW','2026-05-31 16:42:07'),
(508,NULL,'2026-05','sales_pipeline','Sales pipeline value',0.0000,'KRW','2026-05-31 16:42:07'),
(509,NULL,'2026-05','pending_approvals','Pending approvals',0.0000,'items','2026-05-31 16:42:07'),
(510,NULL,'2026-05','company_headcount','Headcount',0.0000,'people','2026-05-31 16:42:07'),
(511,2,'2026-06','output_orders','Production orders',0.0000,'orders','2026-06-03 10:25:09'),
(512,2,'2026-06','quality_pass_rate','QC pass rate',0.0000,'%','2026-06-03 10:25:09'),
(513,3,'2026-06','sales_value','Sales value',0.0000,'KRW','2026-06-03 10:25:09'),
(514,3,'2026-06','sales_orders','Sales orders',0.0000,'orders','2026-06-03 10:25:09'),
(515,4,'2026-06','invoiced','Invoiced',0.0000,'KRW','2026-06-03 10:25:09'),
(516,4,'2026-06','expenses','Expenses',0.0000,'KRW','2026-06-03 10:25:09'),
(517,5,'2026-06','headcount','Headcount',0.0000,'people','2026-06-03 10:25:09'),
(518,5,'2026-06','pending_hr_items','Pending HR items',0.0000,'items','2026-06-03 10:25:09'),
(519,6,'2026-06','active_projects','Active projects',0.0000,'projects','2026-06-03 10:25:09'),
(520,NULL,'2026-06','total_revenue','Total revenue (invoiced)',0.0000,'KRW','2026-06-03 10:25:09'),
(521,NULL,'2026-06','total_expenses','Total expenses',0.0000,'KRW','2026-06-03 10:25:10'),
(522,NULL,'2026-06','net_indicator','Net (revenue − expenses)',0.0000,'KRW','2026-06-03 10:25:10'),
(523,NULL,'2026-06','sales_pipeline','Sales pipeline value',0.0000,'KRW','2026-06-03 10:25:10'),
(524,NULL,'2026-06','pending_approvals','Pending approvals',0.0000,'items','2026-06-03 10:25:10'),
(525,NULL,'2026-06','company_headcount','Headcount',0.0000,'people','2026-06-03 10:25:10');
/*!40000 ALTER TABLE `ge_erp_kpi_snapshot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_leave_request`
--

DROP TABLE IF EXISTS `ge_erp_leave_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_leave_request` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(10) unsigned NOT NULL,
  `leave_type` varchar(40) NOT NULL,
  `leave_from` date NOT NULL,
  `leave_to` date NOT NULL,
  `reason` text DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `created_by` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ge_erp_leave_emp` (`employee_id`),
  CONSTRAINT `fk_ge_erp_leave_emp` FOREIGN KEY (`employee_id`) REFERENCES `ge_erp_employee` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_leave_request`
--

LOCK TABLES `ge_erp_leave_request` WRITE;
/*!40000 ALTER TABLE `ge_erp_leave_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_leave_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_manual_doc`
--

DROP TABLE IF EXISTS `ge_erp_manual_doc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_manual_doc` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `doc_key` varchar(40) NOT NULL,
  `title` varchar(200) NOT NULL,
  `file_url` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ge_erp_manual_doc_key` (`doc_key`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_manual_doc`
--

LOCK TABLES `ge_erp_manual_doc` WRITE;
/*!40000 ALTER TABLE `ge_erp_manual_doc` DISABLE KEYS */;
INSERT INTO `ge_erp_manual_doc` VALUES
(1,'sop','sop',NULL,'2026-05-27 20:45:29'),
(2,'safety','safety',NULL,'2026-05-27 20:45:29'),
(3,'equipment','equipment',NULL,'2026-05-27 20:45:29'),
(4,'training','training',NULL,'2026-05-27 20:45:29');
/*!40000 ALTER TABLE `ge_erp_manual_doc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_marketing_campaign`
--

DROP TABLE IF EXISTS `ge_erp_marketing_campaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_marketing_campaign` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `campaign` varchar(120) NOT NULL,
  `period_label` varchar(80) DEFAULT NULL,
  `channel` varchar(40) DEFAULT NULL,
  `budget` decimal(14,2) NOT NULL DEFAULT 0.00,
  `owner_name` varchar(120) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'draft',
  `created_by` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_marketing_campaign`
--

LOCK TABLES `ge_erp_marketing_campaign` WRITE;
/*!40000 ALTER TABLE `ge_erp_marketing_campaign` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_marketing_campaign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_offsite_work_request`
--

DROP TABLE IF EXISTS `ge_erp_offsite_work_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_offsite_work_request` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(10) unsigned NOT NULL,
  `work_date` date NOT NULL,
  `work_location` varchar(200) DEFAULT NULL,
  `purpose` text DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_ge_erp_offsite_emp` (`employee_id`),
  CONSTRAINT `fk_ge_erp_offsite_emp` FOREIGN KEY (`employee_id`) REFERENCES `ge_erp_employee` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_offsite_work_request`
--

LOCK TABLES `ge_erp_offsite_work_request` WRITE;
/*!40000 ALTER TABLE `ge_erp_offsite_work_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_offsite_work_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_page`
--

DROP TABLE IF EXISTS `ge_erp_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_page` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `department_id` int(10) unsigned NOT NULL,
  `page_key` varchar(80) NOT NULL,
  `ui_type` varchar(64) NOT NULL DEFAULT 'form',
  `table_name` varchar(80) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ge_erp_page_key` (`page_key`),
  KEY `idx_ge_erp_page_dept` (`department_id`),
  CONSTRAINT `fk_ge_erp_page_dept` FOREIGN KEY (`department_id`) REFERENCES `ge_erp_department` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30833 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_page`
--

LOCK TABLES `ge_erp_page` WRITE;
/*!40000 ALTER TABLE `ge_erp_page` DISABLE KEYS */;
INSERT INTO `ge_erp_page` VALUES
(1,1,'exec-dept-kpi','executive-kpi',NULL,'2026-05-27 20:45:27'),
(2,1,'exec-daily-work-calendar','work-calendar',NULL,'2026-05-27 20:45:27'),
(3,1,'exec-pending-approvals','executive-approvals',NULL,'2026-05-27 20:45:27'),
(4,1,'exec-ai-performance','executive-ai',NULL,'2026-05-27 20:45:27'),
(5,1,'exec-ai-issues','executive-ai',NULL,'2026-05-27 20:45:28'),
(6,1,'exec-ai-growth','executive-ai',NULL,'2026-05-27 20:45:28'),
(7,2,'equipment-stock','table','ge_erp_equipment_stock','2026-05-27 20:45:28'),
(8,2,'add-product','form','ge_erp_product','2026-05-27 20:45:28'),
(9,2,'production-run','table','ge_erp_production_order','2026-05-27 20:45:28'),
(10,2,'quality-check','table','ge_erp_quality_check','2026-05-27 20:45:28'),
(11,2,'shipping','table','ge_erp_shipment','2026-05-27 20:45:28'),
(12,3,'add-customer','form','ge_erp_customer','2026-05-27 20:45:28'),
(13,3,'customer-contact-report','table','ge_erp_customer_contact','2026-05-27 20:45:28'),
(14,3,'marketing-plan','table','ge_erp_marketing_campaign','2026-05-27 20:45:28'),
(15,3,'create-sales-order','form','ge_erp_sales_order','2026-05-27 20:45:28'),
(16,3,'sales-report','report',NULL,'2026-05-27 20:45:28'),
(17,4,'create-purchase-order','form','ge_erp_purchase_order','2026-05-27 20:45:28'),
(18,4,'create-invoice','form','ge_erp_invoice','2026-05-27 20:45:28'),
(19,4,'create-tax-invoice','form','ge_erp_tax_invoice','2026-05-27 20:45:28'),
(20,4,'create-credit-note','form','ge_erp_credit_note','2026-05-27 20:45:28'),
(21,4,'expense-record','form','ge_erp_expense','2026-05-27 20:45:28'),
(22,4,'balance-sheet-report','report',NULL,'2026-05-27 20:45:28'),
(23,4,'profit-loss-report','report',NULL,'2026-05-27 20:45:28'),
(24,4,'vat-report','report',NULL,'2026-05-27 20:45:28'),
(25,4,'corporate-tax-report','report',NULL,'2026-05-27 20:45:28'),
(26,5,'create-leave','form','ge_erp_leave_request','2026-05-27 20:45:28'),
(27,5,'attendance-log','table','ge_erp_attendance_log','2026-05-27 20:45:28'),
(28,5,'payroll-record','form','ge_erp_payroll_record','2026-05-27 20:45:28'),
(29,5,'employee-profile','form','ge_erp_employee','2026-05-27 20:45:28'),
(30,5,'document-request','form','ge_erp_document_request','2026-05-27 20:45:28'),
(31,5,'offsite-work-request','form','ge_erp_offsite_work_request','2026-05-27 20:45:28'),
(32,5,'hr-purchase-request','form','ge_erp_hr_purchase_request','2026-05-27 20:45:28'),
(33,5,'suggestion-idea','form','ge_erp_suggestion','2026-05-27 20:45:28'),
(34,5,'expense-reimbursement','form','ge_erp_expense_reimbursement','2026-05-27 20:45:28'),
(35,5,'hr-department-report','report',NULL,'2026-05-27 20:45:28'),
(36,6,'create-project','form','ge_erp_project','2026-05-27 20:45:29'),
(37,6,'update-research','form','ge_erp_research_update','2026-05-27 20:45:29'),
(38,6,'budget-expense','table','ge_erp_budget_expense','2026-05-27 20:45:29'),
(39,6,'research-budget-request','form','ge_erp_research_budget_request','2026-05-27 20:45:29'),
(40,6,'grant-income','table','ge_erp_grant_income','2026-05-27 20:45:29'),
(41,6,'manuals','cards','ge_erp_manual_doc','2026-05-27 20:45:29'),
(42,6,'software','cards','ge_erp_software_asset','2026-05-27 20:45:29'),
(43,6,'ip-patents','table','ge_erp_ip_patent','2026-05-27 20:45:29'),
(44,6,'issue-report','table','ge_erp_issue_report','2026-05-27 20:45:29'),
(45,6,'developers','developers-hub',NULL,'2026-05-27 20:45:29'),
(46,6,'erp-page-access','erp-page-access',NULL,'2026-05-27 20:45:29'),
(47,6,'erp-user-create','erp-user-create',NULL,'2026-05-27 20:45:29'),
(30113,6,'dept-daily-report','dept-daily',NULL,'2026-05-28 21:59:14'),
(30114,6,'dept-monthly-summary','dept-monthly',NULL,'2026-05-28 21:59:14'),
(30125,3,'after-sales-chat-live','chat-live',NULL,'2026-05-28 21:59:14'),
(30502,5,'face-attendance-scan','face-attendance',NULL,'2026-05-31 15:22:19');
/*!40000 ALTER TABLE `ge_erp_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_page_permissions`
--

DROP TABLE IF EXISTS `ge_erp_page_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_page_permissions` (
  `user_id` varchar(191) NOT NULL,
  `page_id` varchar(80) NOT NULL,
  `is_allowed` tinyint(1) NOT NULL DEFAULT 1,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`user_id`,`page_id`),
  KEY `idx_ge_erp_perm_user` (`user_id`),
  KEY `fk_ge_erp_perm_page` (`page_id`),
  CONSTRAINT `fk_ge_erp_perm_page` FOREIGN KEY (`page_id`) REFERENCES `ge_erp_page` (`page_key`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_page_permissions`
--

LOCK TABLES `ge_erp_page_permissions` WRITE;
/*!40000 ALTER TABLE `ge_erp_page_permissions` DISABLE KEYS */;
INSERT INTO `ge_erp_page_permissions` VALUES
('c43585d0ad80aeca6ea58f153','add-customer',0,'2026-05-28 22:40:23'),
('c43585d0ad80aeca6ea58f153','add-product',0,'2026-05-28 22:40:22'),
('c43585d0ad80aeca6ea58f153','after-sales-chat-live',0,'2026-05-28 22:40:23'),
('c43585d0ad80aeca6ea58f153','attendance-log',0,'2026-05-28 22:40:24'),
('c43585d0ad80aeca6ea58f153','balance-sheet-report',0,'2026-05-28 22:40:24'),
('c43585d0ad80aeca6ea58f153','budget-expense',0,'2026-05-28 22:40:26'),
('c43585d0ad80aeca6ea58f153','corporate-tax-report',0,'2026-05-28 22:40:24'),
('c43585d0ad80aeca6ea58f153','create-credit-note',0,'2026-05-28 22:40:24'),
('c43585d0ad80aeca6ea58f153','create-invoice',0,'2026-05-28 22:40:24'),
('c43585d0ad80aeca6ea58f153','create-leave',0,'2026-05-28 22:40:24'),
('c43585d0ad80aeca6ea58f153','create-project',0,'2026-05-28 22:40:25'),
('c43585d0ad80aeca6ea58f153','create-purchase-order',0,'2026-05-28 22:40:24'),
('c43585d0ad80aeca6ea58f153','create-sales-order',0,'2026-05-28 22:40:23'),
('c43585d0ad80aeca6ea58f153','create-tax-invoice',0,'2026-05-28 22:40:24'),
('c43585d0ad80aeca6ea58f153','customer-contact-report',0,'2026-05-28 22:40:23'),
('c43585d0ad80aeca6ea58f153','dept-daily-report',0,'2026-05-28 22:40:26'),
('c43585d0ad80aeca6ea58f153','dept-monthly-summary',0,'2026-05-28 22:40:26'),
('c43585d0ad80aeca6ea58f153','document-request',0,'2026-05-28 22:40:25'),
('c43585d0ad80aeca6ea58f153','employee-profile',0,'2026-05-28 22:40:24'),
('c43585d0ad80aeca6ea58f153','equipment-stock',0,'2026-05-28 22:40:22'),
('c43585d0ad80aeca6ea58f153','exec-ai-growth',0,'2026-05-28 22:40:22'),
('c43585d0ad80aeca6ea58f153','exec-ai-issues',0,'2026-05-28 22:40:22'),
('c43585d0ad80aeca6ea58f153','exec-ai-performance',0,'2026-05-28 22:40:22'),
('c43585d0ad80aeca6ea58f153','exec-daily-work-calendar',0,'2026-05-28 22:40:22'),
('c43585d0ad80aeca6ea58f153','exec-dept-kpi',0,'2026-05-28 22:40:22'),
('c43585d0ad80aeca6ea58f153','exec-pending-approvals',0,'2026-05-28 22:40:22'),
('c43585d0ad80aeca6ea58f153','expense-record',0,'2026-05-28 22:40:24'),
('c43585d0ad80aeca6ea58f153','expense-reimbursement',0,'2026-05-28 22:40:25'),
('c43585d0ad80aeca6ea58f153','grant-income',0,'2026-05-28 22:40:26'),
('c43585d0ad80aeca6ea58f153','hr-department-report',0,'2026-05-28 22:40:25'),
('c43585d0ad80aeca6ea58f153','hr-purchase-request',0,'2026-05-28 22:40:25'),
('c43585d0ad80aeca6ea58f153','ip-patents',0,'2026-05-28 22:40:26'),
('c43585d0ad80aeca6ea58f153','issue-report',0,'2026-05-28 22:40:26'),
('c43585d0ad80aeca6ea58f153','manuals',0,'2026-05-28 22:40:26'),
('c43585d0ad80aeca6ea58f153','marketing-plan',0,'2026-05-28 22:40:23'),
('c43585d0ad80aeca6ea58f153','offsite-work-request',0,'2026-05-28 22:40:25'),
('c43585d0ad80aeca6ea58f153','payroll-record',0,'2026-05-28 22:40:24'),
('c43585d0ad80aeca6ea58f153','production-run',0,'2026-05-28 22:40:22'),
('c43585d0ad80aeca6ea58f153','profit-loss-report',0,'2026-05-28 22:40:24'),
('c43585d0ad80aeca6ea58f153','quality-check',0,'2026-05-28 22:40:23'),
('c43585d0ad80aeca6ea58f153','research-budget-request',0,'2026-05-28 22:40:26'),
('c43585d0ad80aeca6ea58f153','sales-report',0,'2026-05-28 22:40:23'),
('c43585d0ad80aeca6ea58f153','shipping',0,'2026-05-28 22:40:23'),
('c43585d0ad80aeca6ea58f153','software',0,'2026-05-28 22:40:26'),
('c43585d0ad80aeca6ea58f153','suggestion-idea',0,'2026-05-28 22:40:25'),
('c43585d0ad80aeca6ea58f153','update-research',0,'2026-05-28 22:40:25'),
('c43585d0ad80aeca6ea58f153','vat-report',0,'2026-05-28 22:40:24'),
('cmpl94xec0001jhxxkns7vwwh','add-customer',0,'2026-05-28 22:39:57'),
('cmpl94xec0001jhxxkns7vwwh','add-product',0,'2026-05-28 22:39:56'),
('cmpl94xec0001jhxxkns7vwwh','after-sales-chat-live',0,'2026-05-28 22:39:57'),
('cmpl94xec0001jhxxkns7vwwh','attendance-log',0,'2026-05-28 22:39:58'),
('cmpl94xec0001jhxxkns7vwwh','balance-sheet-report',0,'2026-05-28 22:39:57'),
('cmpl94xec0001jhxxkns7vwwh','budget-expense',0,'2026-05-28 22:39:59'),
('cmpl94xec0001jhxxkns7vwwh','corporate-tax-report',0,'2026-05-28 22:39:58'),
('cmpl94xec0001jhxxkns7vwwh','create-credit-note',0,'2026-05-28 22:39:57'),
('cmpl94xec0001jhxxkns7vwwh','create-invoice',0,'2026-05-28 22:39:57'),
('cmpl94xec0001jhxxkns7vwwh','create-leave',0,'2026-05-28 22:39:58'),
('cmpl94xec0001jhxxkns7vwwh','create-project',0,'2026-05-28 22:39:59'),
('cmpl94xec0001jhxxkns7vwwh','create-purchase-order',0,'2026-05-28 22:39:57'),
('cmpl94xec0001jhxxkns7vwwh','create-sales-order',0,'2026-05-28 22:39:57'),
('cmpl94xec0001jhxxkns7vwwh','create-tax-invoice',0,'2026-05-28 22:39:57'),
('cmpl94xec0001jhxxkns7vwwh','customer-contact-report',0,'2026-05-28 22:39:57'),
('cmpl94xec0001jhxxkns7vwwh','dept-daily-report',0,'2026-05-28 22:39:59'),
('cmpl94xec0001jhxxkns7vwwh','dept-monthly-summary',0,'2026-05-28 22:39:59'),
('cmpl94xec0001jhxxkns7vwwh','document-request',0,'2026-05-28 22:39:58'),
('cmpl94xec0001jhxxkns7vwwh','employee-profile',0,'2026-05-28 22:39:58'),
('cmpl94xec0001jhxxkns7vwwh','equipment-stock',0,'2026-05-28 22:39:56'),
('cmpl94xec0001jhxxkns7vwwh','exec-ai-growth',0,'2026-05-28 22:39:56'),
('cmpl94xec0001jhxxkns7vwwh','exec-ai-issues',0,'2026-05-28 22:39:56'),
('cmpl94xec0001jhxxkns7vwwh','exec-ai-performance',0,'2026-05-28 22:39:55'),
('cmpl94xec0001jhxxkns7vwwh','exec-daily-work-calendar',0,'2026-05-28 22:39:55'),
('cmpl94xec0001jhxxkns7vwwh','exec-dept-kpi',0,'2026-05-28 22:39:55'),
('cmpl94xec0001jhxxkns7vwwh','exec-pending-approvals',0,'2026-05-28 22:39:55'),
('cmpl94xec0001jhxxkns7vwwh','expense-record',0,'2026-05-28 22:39:57'),
('cmpl94xec0001jhxxkns7vwwh','expense-reimbursement',0,'2026-05-28 22:39:58'),
('cmpl94xec0001jhxxkns7vwwh','grant-income',0,'2026-05-28 22:39:59'),
('cmpl94xec0001jhxxkns7vwwh','hr-department-report',0,'2026-05-28 22:39:59'),
('cmpl94xec0001jhxxkns7vwwh','hr-purchase-request',0,'2026-05-28 22:39:58'),
('cmpl94xec0001jhxxkns7vwwh','ip-patents',0,'2026-05-28 22:39:59'),
('cmpl94xec0001jhxxkns7vwwh','issue-report',0,'2026-05-28 22:39:59'),
('cmpl94xec0001jhxxkns7vwwh','manuals',0,'2026-05-28 22:39:59'),
('cmpl94xec0001jhxxkns7vwwh','marketing-plan',0,'2026-05-28 22:39:57'),
('cmpl94xec0001jhxxkns7vwwh','offsite-work-request',0,'2026-05-28 22:39:58'),
('cmpl94xec0001jhxxkns7vwwh','payroll-record',0,'2026-05-28 22:39:58'),
('cmpl94xec0001jhxxkns7vwwh','production-run',0,'2026-05-28 22:39:56'),
('cmpl94xec0001jhxxkns7vwwh','profit-loss-report',0,'2026-05-28 22:39:58'),
('cmpl94xec0001jhxxkns7vwwh','quality-check',0,'2026-05-28 22:39:56'),
('cmpl94xec0001jhxxkns7vwwh','research-budget-request',0,'2026-05-28 22:39:59'),
('cmpl94xec0001jhxxkns7vwwh','sales-report',0,'2026-05-28 22:39:57'),
('cmpl94xec0001jhxxkns7vwwh','shipping',0,'2026-05-28 22:39:57'),
('cmpl94xec0001jhxxkns7vwwh','software',0,'2026-05-28 22:39:59'),
('cmpl94xec0001jhxxkns7vwwh','suggestion-idea',0,'2026-05-28 22:39:58'),
('cmpl94xec0001jhxxkns7vwwh','update-research',0,'2026-05-28 22:39:59'),
('cmpl94xec0001jhxxkns7vwwh','vat-report',0,'2026-05-28 22:39:58'),
('cmporvcjo0000jhbx9vdkcsjq','add-customer',1,'2026-05-28 09:46:09'),
('cmporvcjo0000jhbx9vdkcsjq','add-product',1,'2026-05-28 09:46:09'),
('cmporvcjo0000jhbx9vdkcsjq','customer-contact-report',1,'2026-05-28 09:46:09'),
('cmporvcjo0000jhbx9vdkcsjq','equipment-stock',1,'2026-05-28 09:46:09'),
('cmporvcjo0000jhbx9vdkcsjq','exec-ai-growth',1,'2026-05-28 09:46:09'),
('cmporvcjo0000jhbx9vdkcsjq','exec-ai-issues',1,'2026-05-28 09:46:09'),
('cmporvcjo0000jhbx9vdkcsjq','exec-ai-performance',1,'2026-05-28 09:46:09'),
('cmporvcjo0000jhbx9vdkcsjq','exec-daily-work-calendar',1,'2026-05-28 09:46:09'),
('cmporvcjo0000jhbx9vdkcsjq','exec-dept-kpi',1,'2026-05-28 09:46:09'),
('cmporvcjo0000jhbx9vdkcsjq','exec-pending-approvals',1,'2026-05-28 09:46:09'),
('cmporvcjo0000jhbx9vdkcsjq','marketing-plan',1,'2026-05-28 09:46:09'),
('cmporvcjo0000jhbx9vdkcsjq','production-run',1,'2026-05-28 09:46:09'),
('cmporvcjo0000jhbx9vdkcsjq','quality-check',1,'2026-05-28 09:46:09'),
('cmporvcjo0000jhbx9vdkcsjq','shipping',1,'2026-05-28 09:46:09'),
('momoge01','add-customer',0,'2026-05-28 22:41:43'),
('momoge01','add-product',0,'2026-05-28 22:41:43'),
('momoge01','after-sales-chat-live',0,'2026-05-28 22:41:43'),
('momoge01','attendance-log',0,'2026-05-28 22:41:44'),
('momoge01','balance-sheet-report',0,'2026-05-28 22:41:44'),
('momoge01','budget-expense',0,'2026-05-28 22:41:45'),
('momoge01','corporate-tax-report',0,'2026-05-28 22:41:44'),
('momoge01','create-credit-note',0,'2026-05-28 22:41:44'),
('momoge01','create-invoice',0,'2026-05-28 22:41:44'),
('momoge01','create-leave',0,'2026-05-28 22:41:44'),
('momoge01','create-project',0,'2026-05-28 22:41:45'),
('momoge01','create-purchase-order',0,'2026-05-28 22:41:44'),
('momoge01','create-sales-order',0,'2026-05-28 22:41:43'),
('momoge01','create-tax-invoice',0,'2026-05-28 22:41:44'),
('momoge01','customer-contact-report',0,'2026-05-28 22:41:43'),
('momoge01','dept-daily-report',0,'2026-05-28 22:41:46'),
('momoge01','dept-monthly-summary',0,'2026-05-28 22:41:46'),
('momoge01','document-request',0,'2026-05-28 22:41:44'),
('momoge01','employee-profile',0,'2026-05-28 22:41:44'),
('momoge01','equipment-stock',0,'2026-05-28 22:41:42'),
('momoge01','exec-ai-growth',0,'2026-05-28 22:41:42'),
('momoge01','exec-ai-issues',0,'2026-05-28 22:41:42'),
('momoge01','exec-ai-performance',0,'2026-05-28 22:41:42'),
('momoge01','exec-daily-work-calendar',0,'2026-05-28 22:41:42'),
('momoge01','exec-dept-kpi',0,'2026-05-28 22:41:42'),
('momoge01','exec-pending-approvals',0,'2026-05-28 22:41:42'),
('momoge01','expense-record',0,'2026-05-28 22:41:44'),
('momoge01','expense-reimbursement',0,'2026-05-28 22:41:45'),
('momoge01','grant-income',0,'2026-05-28 22:41:45'),
('momoge01','hr-department-report',0,'2026-05-28 22:41:45'),
('momoge01','hr-purchase-request',0,'2026-05-28 22:41:45'),
('momoge01','ip-patents',0,'2026-05-28 22:41:46'),
('momoge01','issue-report',0,'2026-05-28 22:41:46'),
('momoge01','manuals',0,'2026-05-28 22:41:45'),
('momoge01','marketing-plan',0,'2026-05-28 22:41:43'),
('momoge01','offsite-work-request',0,'2026-05-28 22:41:44'),
('momoge01','payroll-record',0,'2026-05-28 22:41:44'),
('momoge01','production-run',0,'2026-05-28 22:41:43'),
('momoge01','profit-loss-report',0,'2026-05-28 22:41:44'),
('momoge01','quality-check',0,'2026-05-28 22:41:43'),
('momoge01','research-budget-request',0,'2026-05-28 22:41:45'),
('momoge01','sales-report',0,'2026-05-28 22:41:43'),
('momoge01','shipping',0,'2026-05-28 22:41:43'),
('momoge01','software',0,'2026-05-28 22:41:46'),
('momoge01','suggestion-idea',0,'2026-05-28 22:41:45'),
('momoge01','update-research',0,'2026-05-28 22:41:45'),
('momoge01','vat-report',0,'2026-05-28 22:41:44');
/*!40000 ALTER TABLE `ge_erp_page_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_payroll_record`
--

DROP TABLE IF EXISTS `ge_erp_payroll_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_payroll_record` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(10) unsigned NOT NULL,
  `salary_month` char(7) NOT NULL COMMENT 'YYYY-MM',
  `base_salary` decimal(14,2) NOT NULL DEFAULT 0.00,
  `note` text DEFAULT NULL,
  `created_by` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ge_erp_payroll_emp` (`employee_id`),
  CONSTRAINT `fk_ge_erp_payroll_emp` FOREIGN KEY (`employee_id`) REFERENCES `ge_erp_employee` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_payroll_record`
--

LOCK TABLES `ge_erp_payroll_record` WRITE;
/*!40000 ALTER TABLE `ge_erp_payroll_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_payroll_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_product`
--

DROP TABLE IF EXISTS `ge_erp_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_product` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sku` varchar(60) NOT NULL,
  `name` varchar(200) NOT NULL,
  `category` varchar(80) DEFAULT NULL,
  `unit` varchar(20) NOT NULL DEFAULT 'ชิ้น',
  `price` decimal(14,2) NOT NULL DEFAULT 0.00,
  `stock_qty` int(11) NOT NULL DEFAULT 0,
  `status` varchar(20) NOT NULL DEFAULT 'active',
  `created_by` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ge_erp_product_sku` (`sku`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_product`
--

LOCK TABLES `ge_erp_product` WRITE;
/*!40000 ALTER TABLE `ge_erp_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_production_order`
--

DROP TABLE IF EXISTS `ge_erp_production_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_production_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_no` varchar(40) NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 0,
  `line_name` varchar(80) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'planned',
  `created_by` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ge_erp_prod_order_no` (`order_no`),
  KEY `idx_ge_erp_prod_order_product` (`product_id`),
  CONSTRAINT `fk_ge_erp_prod_order_product` FOREIGN KEY (`product_id`) REFERENCES `ge_erp_product` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_production_order`
--

LOCK TABLES `ge_erp_production_order` WRITE;
/*!40000 ALTER TABLE `ge_erp_production_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_production_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_project`
--

DROP TABLE IF EXISTS `ge_erp_project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_project` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_code` varchar(40) NOT NULL,
  `project_name` varchar(200) NOT NULL,
  `lead_name` varchar(120) DEFAULT NULL,
  `budget` decimal(14,2) NOT NULL DEFAULT 0.00,
  `start_date` date DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'active',
  `created_by` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ge_erp_project_code` (`project_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_project`
--

LOCK TABLES `ge_erp_project` WRITE;
/*!40000 ALTER TABLE `ge_erp_project` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_purchase_order`
--

DROP TABLE IF EXISTS `ge_erp_purchase_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_purchase_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `po_no` varchar(40) NOT NULL,
  `vendor_id` int(10) unsigned NOT NULL,
  `item_desc` varchar(200) DEFAULT NULL,
  `amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `due_date` date DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'open',
  `created_by` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ge_erp_po_no` (`po_no`),
  KEY `idx_ge_erp_po_vendor` (`vendor_id`),
  CONSTRAINT `fk_ge_erp_po_vendor` FOREIGN KEY (`vendor_id`) REFERENCES `ge_erp_vendor` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_purchase_order`
--

LOCK TABLES `ge_erp_purchase_order` WRITE;
/*!40000 ALTER TABLE `ge_erp_purchase_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_purchase_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_quality_check`
--

DROP TABLE IF EXISTS `ge_erp_quality_check`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_quality_check` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `production_order_id` int(10) unsigned NOT NULL,
  `batch_no` varchar(40) NOT NULL,
  `inspector_name` varchar(120) DEFAULT NULL,
  `result_status` varchar(20) NOT NULL DEFAULT 'pass',
  `checked_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ge_erp_qc_order` (`production_order_id`),
  CONSTRAINT `fk_ge_erp_qc_order` FOREIGN KEY (`production_order_id`) REFERENCES `ge_erp_production_order` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_quality_check`
--

LOCK TABLES `ge_erp_quality_check` WRITE;
/*!40000 ALTER TABLE `ge_erp_quality_check` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_quality_check` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_research_budget_request`
--

DROP TABLE IF EXISTS `ge_erp_research_budget_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_research_budget_request` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(10) unsigned NOT NULL,
  `requested_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `purpose` text DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_ge_erp_rb_req_project` (`project_id`),
  CONSTRAINT `fk_ge_erp_rb_req_project` FOREIGN KEY (`project_id`) REFERENCES `ge_erp_project` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_research_budget_request`
--

LOCK TABLES `ge_erp_research_budget_request` WRITE;
/*!40000 ALTER TABLE `ge_erp_research_budget_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_research_budget_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_research_update`
--

DROP TABLE IF EXISTS `ge_erp_research_update`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_research_update` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(10) unsigned NOT NULL,
  `milestone` varchar(120) DEFAULT NULL,
  `progress_pct` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `summary` text DEFAULT NULL,
  `created_by` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_ge_erp_research_project` (`project_id`),
  CONSTRAINT `fk_ge_erp_research_project` FOREIGN KEY (`project_id`) REFERENCES `ge_erp_project` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_research_update`
--

LOCK TABLES `ge_erp_research_update` WRITE;
/*!40000 ALTER TABLE `ge_erp_research_update` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_research_update` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_sales_order`
--

DROP TABLE IF EXISTS `ge_erp_sales_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_sales_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_no` varchar(40) NOT NULL,
  `customer_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `due_date` date DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'open',
  `created_by` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ge_erp_sales_order_no` (`order_no`),
  KEY `idx_ge_erp_sales_customer` (`customer_id`),
  KEY `idx_ge_erp_sales_product` (`product_id`),
  CONSTRAINT `fk_ge_erp_sales_customer` FOREIGN KEY (`customer_id`) REFERENCES `ge_erp_customer` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_ge_erp_sales_product` FOREIGN KEY (`product_id`) REFERENCES `ge_erp_product` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_sales_order`
--

LOCK TABLES `ge_erp_sales_order` WRITE;
/*!40000 ALTER TABLE `ge_erp_sales_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_sales_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_shipment`
--

DROP TABLE IF EXISTS `ge_erp_shipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_shipment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `shipment_no` varchar(40) NOT NULL,
  `production_order_id` int(10) unsigned DEFAULT NULL,
  `sales_order_id` int(10) unsigned DEFAULT NULL,
  `customer_id` int(10) unsigned DEFAULT NULL,
  `carrier` varchar(80) DEFAULT NULL,
  `ship_date` date DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `created_by` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ge_erp_shipment_no` (`shipment_no`),
  KEY `idx_ge_erp_shipment_prod` (`production_order_id`),
  KEY `idx_ge_erp_shipment_sales` (`sales_order_id`),
  KEY `idx_ge_erp_shipment_customer` (`customer_id`),
  CONSTRAINT `fk_ge_erp_shipment_customer` FOREIGN KEY (`customer_id`) REFERENCES `ge_erp_customer` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_ge_erp_shipment_prod` FOREIGN KEY (`production_order_id`) REFERENCES `ge_erp_production_order` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_ge_erp_shipment_sales` FOREIGN KEY (`sales_order_id`) REFERENCES `ge_erp_sales_order` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_shipment`
--

LOCK TABLES `ge_erp_shipment` WRITE;
/*!40000 ALTER TABLE `ge_erp_shipment` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_shipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_software_asset`
--

DROP TABLE IF EXISTS `ge_erp_software_asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_software_asset` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_key` varchar(40) NOT NULL,
  `name` varchar(200) NOT NULL,
  `license_no` varchar(80) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ge_erp_software_asset_key` (`asset_key`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_software_asset`
--

LOCK TABLES `ge_erp_software_asset` WRITE;
/*!40000 ALTER TABLE `ge_erp_software_asset` DISABLE KEYS */;
INSERT INTO `ge_erp_software_asset` VALUES
(1,'cad','cad',NULL,'2026-05-27 20:45:29'),
(2,'simulation','simulation',NULL,'2026-05-27 20:45:29'),
(3,'data','data',NULL,'2026-05-27 20:45:29'),
(4,'license','license',NULL,'2026-05-27 20:45:29');
/*!40000 ALTER TABLE `ge_erp_software_asset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_suggestion`
--

DROP TABLE IF EXISTS `ge_erp_suggestion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_suggestion` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(10) unsigned NOT NULL,
  `idea_title` varchar(200) NOT NULL,
  `idea_detail` text DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'submitted',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_ge_erp_suggestion_emp` (`employee_id`),
  CONSTRAINT `fk_ge_erp_suggestion_emp` FOREIGN KEY (`employee_id`) REFERENCES `ge_erp_employee` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_suggestion`
--

LOCK TABLES `ge_erp_suggestion` WRITE;
/*!40000 ALTER TABLE `ge_erp_suggestion` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_suggestion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_tax_invoice`
--

DROP TABLE IF EXISTS `ge_erp_tax_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_tax_invoice` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tax_invoice_no` varchar(40) NOT NULL,
  `customer_id` int(10) unsigned NOT NULL,
  `invoice_id` int(10) unsigned DEFAULT NULL,
  `tax_id` varchar(20) DEFAULT NULL,
  `vat_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `created_by` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ge_erp_tax_inv_no` (`tax_invoice_no`),
  KEY `fk_ge_erp_tax_inv_customer` (`customer_id`),
  KEY `fk_ge_erp_tax_inv_invoice` (`invoice_id`),
  CONSTRAINT `fk_ge_erp_tax_inv_customer` FOREIGN KEY (`customer_id`) REFERENCES `ge_erp_customer` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_ge_erp_tax_inv_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `ge_erp_invoice` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_tax_invoice`
--

LOCK TABLES `ge_erp_tax_invoice` WRITE;
/*!40000 ALTER TABLE `ge_erp_tax_invoice` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_tax_invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_erp_vendor`
--

DROP TABLE IF EXISTS `ge_erp_vendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_erp_vendor` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `tax_id` varchar(20) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_erp_vendor`
--

LOCK TABLES `ge_erp_vendor` WRITE;
/*!40000 ALTER TABLE `ge_erp_vendor` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_erp_vendor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ge_meter_bill_history`
--

DROP TABLE IF EXISTS `ge_meter_bill_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ge_meter_bill_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `site` varchar(32) DEFAULT NULL,
  `bill_month` date NOT NULL,
  `energy_kwh` decimal(14,2) DEFAULT NULL,
  `bill_cost` decimal(16,2) DEFAULT NULL,
  `peak_kw` decimal(14,2) DEFAULT NULL,
  `peak_cost` decimal(16,2) DEFAULT NULL,
  `breaker_size_amp` int(11) DEFAULT NULL,
  `note` varchar(500) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_meter_month` (`device_id`,`bill_month`),
  KEY `idx_bill_customer` (`customer_id`),
  KEY `idx_bill_site` (`site`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ge_meter_bill_history`
--

LOCK TABLES `ge_meter_bill_history` WRITE;
/*!40000 ALTER TABLE `ge_meter_bill_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `ge_meter_bill_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geet_meter_order`
--

DROP TABLE IF EXISTS `geet_meter_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `geet_meter_order` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_no` varchar(32) NOT NULL,
  `buyer_name` varchar(200) NOT NULL,
  `ship_address` text NOT NULL,
  `email` varchar(191) NOT NULL,
  `phone` varchar(40) NOT NULL,
  `breaker_amps` varchar(40) NOT NULL,
  `machine_kva` varchar(40) NOT NULL,
  `quantity` int(10) unsigned NOT NULL DEFAULT 1,
  `unit_price` int(10) unsigned NOT NULL DEFAULT 0,
  `total_price` int(10) unsigned NOT NULL DEFAULT 0,
  `lang` varchar(10) NOT NULL DEFAULT 'th',
  `product_code` varchar(80) NOT NULL DEFAULT 'smart-meter',
  `payment_status` varchar(30) NOT NULL DEFAULT 'pending',
  `shipment_status` varchar(30) NOT NULL DEFAULT 'pending',
  `site_photo_path` varchar(500) DEFAULT NULL,
  `payment_slip_path` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_geet_meter_order_no` (`order_no`),
  KEY `idx_geet_meter_order_email` (`email`),
  KEY `idx_geet_meter_order_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geet_meter_order`
--

LOCK TABLES `geet_meter_order` WRITE;
/*!40000 ALTER TABLE `geet_meter_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `geet_meter_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `momoge_cus`
--

DROP TABLE IF EXISTS `momoge_cus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `momoge_cus` (
  `mmgID` int(10) NOT NULL AUTO_INCREMENT,
  `meterID` varchar(255) DEFAULT NULL,
  `LocationID` varchar(255) DEFAULT NULL,
  `serailID` varchar(255) DEFAULT NULL,
  `device_id` int(11) DEFAULT NULL,
  `nameTH` varchar(255) DEFAULT NULL,
  `nameEN` varchar(255) DEFAULT NULL,
  `nameKR` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `user_id` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`mmgID`),
  KEY `idx_momoge_cus_device` (`device_id`),
  KEY `idx_momoge_cus_meter` (`meterID`),
  KEY `idx_momoge_cus_location` (`LocationID`),
  KEY `fk_momoge_cus_user_id` (`user_id`),
  CONSTRAINT `fk_momoge_cus_device` FOREIGN KEY (`device_id`) REFERENCES `devices` (`deviceID`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_momoge_cus_location` FOREIGN KEY (`LocationID`) REFERENCES `carbon_locations` (`locationID`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_momoge_cus_meter` FOREIGN KEY (`meterID`) REFERENCES `carbon_meters` (`meterID`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_momoge_cus_user_id` FOREIGN KEY (`user_id`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `momoge_cus`
--

LOCK TABLES `momoge_cus` WRITE;
/*!40000 ALTER TABLE `momoge_cus` DISABLE KEYS */;
INSERT INTO `momoge_cus` VALUES
(1,NULL,NULL,NULL,NULL,'home mart','home mart','home mart','000','000',0.00000000,0.00000000,'2026-06-06 07:48:31','2026-06-06 07:48:31',NULL),
(2,NULL,NULL,'00000',5,'home mart','home mart','home mart','000','000',0.00000000,0.00000000,'2026-06-06 07:48:35','2026-06-06 07:48:35',NULL),
(3,NULL,NULL,NULL,3,'Thaimart',NULL,NULL,'02-555-1199',NULL,NULL,NULL,'2026-06-06 07:49:00','2026-06-06 08:01:37',NULL);
/*!40000 ALTER TABLE `momoge_cus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mqtt_settings`
--

DROP TABLE IF EXISTS `mqtt_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mqtt_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `device_id` int(11) DEFAULT NULL,
  `site` varchar(20) NOT NULL DEFAULT 'thailand',
  `host` varchar(255) NOT NULL,
  `port` int(11) NOT NULL DEFAULT 1883,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(512) DEFAULT NULL,
  `topic` varchar(255) DEFAULT NULL,
  `topic_prefix` varchar(255) DEFAULT 'ge',
  `interval` int(11) NOT NULL DEFAULT 30,
  `gateway_model` varchar(50) DEFAULT 'T310',
  `serial_port` varchar(100) DEFAULT '/dev/ttyS1',
  `baud_rate` int(11) NOT NULL DEFAULT 9600,
  `parity` varchar(10) NOT NULL DEFAULT 'none',
  `data_bits` tinyint(4) NOT NULL DEFAULT 8,
  `stop_bits` tinyint(4) NOT NULL DEFAULT 1,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_mqtt_user_site` (`user_id`,`site`),
  KEY `idx_mqtt_settings_device` (`device_id`),
  CONSTRAINT `fk_mqtt_settings_device` FOREIGN KEY (`device_id`) REFERENCES `devices` (`deviceID`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mqtt_settings`
--

LOCK TABLES `mqtt_settings` WRITE;
/*!40000 ALTER TABLE `mqtt_settings` DISABLE KEYS */;
INSERT INTO `mqtt_settings` VALUES
(1,1,NULL,'thailand','127.0.0.1',1883,'geent','MTA4ODczNDIxOA==','ge/#','ge',30,'T310','/dev/ttyS1',9600,'none',8,1,'2026-06-13 21:35:13');
/*!40000 ALTER TABLE `mqtt_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('alert','warning','info','success') NOT NULL DEFAULT 'info',
  `category` varchar(100) NOT NULL DEFAULT 'System',
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `device_id` int(11) DEFAULT NULL,
  `site` varchar(50) DEFAULT NULL,
  `metadata` text DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `read_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_notifications_device` (`device_id`),
  KEY `idx_notifications_site` (`site`),
  KEY `idx_notifications_is_read` (`is_read`),
  KEY `idx_notifications_created` (`created_at`),
  CONSTRAINT `fk_notifications_device` FOREIGN KEY (`device_id`) REFERENCES `devices` (`deviceID`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `power_records`
--

DROP TABLE IF EXISTS `power_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `power_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(11) NOT NULL,
  `before_meter_no` varchar(255) DEFAULT NULL,
  `metrics_meter_no` varchar(255) DEFAULT NULL,
  `record_time` datetime NOT NULL,
  `before_L1` decimal(10,2) DEFAULT NULL,
  `before_L2` decimal(10,2) DEFAULT NULL,
  `before_L3` decimal(10,2) DEFAULT NULL,
  `before_current_L1` decimal(10,2) DEFAULT NULL,
  `before_current_L2` decimal(10,2) DEFAULT NULL,
  `before_current_L3` decimal(10,2) DEFAULT NULL,
  `before_kWh` decimal(12,3) DEFAULT NULL,
  `before_P` decimal(12,3) DEFAULT NULL,
  `before_Q` decimal(12,3) DEFAULT NULL,
  `before_S` decimal(12,3) DEFAULT NULL,
  `before_PF` decimal(6,3) DEFAULT NULL,
  `before_THD` decimal(8,3) DEFAULT NULL,
  `before_F` decimal(8,3) DEFAULT NULL,
  `metrics_L1` decimal(10,2) DEFAULT NULL,
  `metrics_L2` decimal(10,2) DEFAULT NULL,
  `metrics_L3` decimal(10,2) DEFAULT NULL,
  `metrics_current_L1` decimal(10,2) DEFAULT NULL,
  `metrics_current_L2` decimal(10,2) DEFAULT NULL,
  `metrics_current_L3` decimal(10,2) DEFAULT NULL,
  `metrics_kWh` decimal(12,3) DEFAULT NULL,
  `metrics_P` decimal(12,3) DEFAULT NULL,
  `metrics_Q` decimal(12,3) DEFAULT NULL,
  `metrics_S` decimal(12,3) DEFAULT NULL,
  `metrics_PF` decimal(6,3) DEFAULT NULL,
  `metrics_THD` decimal(8,3) DEFAULT NULL,
  `metrics_F` decimal(8,3) DEFAULT NULL,
  `energy_reduction` decimal(12,3) GENERATED ALWAYS AS (`before_kWh` - `metrics_kWh`) STORED,
  `co2_reduction` decimal(12,4) GENERATED ALWAYS AS ((`before_kWh` - `metrics_kWh`) * 0.5135) STORED,
  `created_at` datetime(6) DEFAULT current_timestamp(6),
  `updated_at` datetime(6) DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  `created_by` varchar(100) NOT NULL DEFAULT 'Auto ge-monitor',
  `deviceID` int(11) DEFAULT NULL,
  `series_no` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_power_records_device_id` (`device_id`),
  KEY `idx_power_records_record_time` (`record_time`),
  CONSTRAINT `fk_power_records_device` FOREIGN KEY (`device_id`) REFERENCES `devices` (`deviceID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2641 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `power_records`
--

LOCK TABLES `power_records` WRITE;
/*!40000 ALTER TABLE `power_records` DISABLE KEYS */;
INSERT INTO `power_records` VALUES
(1,1,NULL,NULL,'2025-06-15 12:00:00',220.00,NULL,NULL,30.51,26.71,26.21,9360.000,17.340,8.398,19.267,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,7114.000,NULL,NULL,NULL,NULL,NULL,NULL,2246.000,1153.3210,'2026-05-23 13:56:56.567026','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(2,1,NULL,NULL,'2025-07-15 12:00:00',220.00,NULL,NULL,27.42,24.21,22.43,9240.000,15.393,7.455,17.103,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6838.000,NULL,NULL,NULL,NULL,NULL,NULL,2402.000,1233.4270,'2026-05-23 13:56:56.579283','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(3,1,NULL,NULL,'2025-08-15 12:00:00',220.00,NULL,NULL,24.46,22.27,21.02,9120.000,14.081,6.820,15.646,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6566.000,NULL,NULL,NULL,NULL,NULL,NULL,2554.000,1311.4790,'2026-05-23 13:56:56.622443','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(4,1,NULL,NULL,'2025-09-15 12:00:00',220.00,NULL,NULL,32.90,28.40,27.93,9000.000,18.546,8.982,20.607,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6840.000,NULL,NULL,NULL,NULL,NULL,NULL,2160.000,1109.1600,'2026-05-23 13:56:56.655891','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(5,1,NULL,NULL,'2025-10-15 12:00:00',220.00,NULL,NULL,31.62,28.98,25.15,8880.000,17.822,8.632,19.802,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6571.000,NULL,NULL,NULL,NULL,NULL,NULL,2309.000,1185.6715,'2026-05-23 13:56:56.711706','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(6,1,NULL,NULL,'2025-11-15 12:00:00',220.00,NULL,NULL,24.22,22.04,20.56,8760.000,13.888,6.726,15.431,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6307.000,NULL,NULL,NULL,NULL,NULL,NULL,2453.000,1259.6155,'2026-05-23 13:56:56.730212','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(7,1,NULL,NULL,'2025-12-15 12:00:00',220.00,NULL,NULL,31.07,21.35,25.93,8640.000,16.284,7.887,18.093,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6566.000,NULL,NULL,NULL,NULL,NULL,NULL,2074.000,1064.9990,'2026-05-23 13:56:56.742174','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(8,1,NULL,NULL,'2026-01-15 12:00:00',220.00,NULL,NULL,23.00,23.30,20.91,8520.000,13.969,6.765,15.521,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6305.000,NULL,NULL,NULL,NULL,NULL,NULL,2215.000,1137.4025,'2026-05-23 13:56:56.754046','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(9,1,NULL,NULL,'2026-02-15 12:00:00',220.00,NULL,NULL,28.93,29.03,23.60,8400.000,16.951,8.210,18.834,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6048.000,NULL,NULL,NULL,NULL,NULL,NULL,2352.000,1207.7520,'2026-05-23 13:56:56.767611','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(10,1,NULL,NULL,'2026-03-15 12:00:00',220.00,NULL,NULL,25.48,23.36,23.55,8280.000,15.046,7.287,16.718,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6293.000,NULL,NULL,NULL,NULL,NULL,NULL,1987.000,1020.3245,'2026-05-23 13:56:56.779890','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(11,1,NULL,NULL,'2026-04-15 12:00:00',220.00,NULL,NULL,23.36,23.04,27.69,8160.000,15.399,7.458,17.110,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6038.000,NULL,NULL,NULL,NULL,NULL,NULL,2122.000,1089.6470,'2026-05-23 13:56:56.789783','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(12,1,NULL,NULL,'2026-05-15 12:00:00',220.00,NULL,NULL,27.43,29.01,27.51,8040.000,17.448,8.450,19.387,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,5789.000,NULL,NULL,NULL,NULL,NULL,NULL,2251.000,1155.8885,'2026-05-23 13:56:56.810125','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(13,2,NULL,NULL,'2025-06-15 12:00:00',220.00,NULL,NULL,72.24,63.43,56.91,9400.000,40.026,19.385,44.473,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,7144.000,NULL,NULL,NULL,NULL,NULL,NULL,2256.000,1158.4560,'2026-05-23 13:56:56.825499','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(14,2,NULL,NULL,'2025-07-15 12:00:00',220.00,NULL,NULL,64.54,69.12,60.78,9280.000,40.412,19.572,44.902,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6867.000,NULL,NULL,NULL,NULL,NULL,NULL,2413.000,1239.0755,'2026-05-23 13:56:56.836588','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(15,2,NULL,NULL,'2025-08-15 12:00:00',220.00,NULL,NULL,68.34,74.62,54.88,9160.000,41.119,19.915,45.688,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6595.000,NULL,NULL,NULL,NULL,NULL,NULL,2565.000,1317.1275,'2026-05-23 13:56:56.848495','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(16,2,NULL,NULL,'2025-09-15 12:00:00',220.00,NULL,NULL,66.34,61.03,61.28,9040.000,39.209,18.990,43.566,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6870.000,NULL,NULL,NULL,NULL,NULL,NULL,2170.000,1114.2950,'2026-05-23 13:56:56.858006','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(17,2,NULL,NULL,'2025-10-15 12:00:00',220.00,NULL,NULL,72.50,69.55,63.32,8920.000,42.684,20.673,47.427,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6601.000,NULL,NULL,NULL,NULL,NULL,NULL,2319.000,1190.8065,'2026-05-23 13:56:56.870424','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(18,2,NULL,NULL,'2025-11-15 12:00:00',220.00,NULL,NULL,56.87,58.59,53.31,8800.000,35.077,16.989,38.974,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6336.000,NULL,NULL,NULL,NULL,NULL,NULL,2464.000,1265.2640,'2026-05-23 13:56:56.880699','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(19,2,NULL,NULL,'2025-12-15 12:00:00',220.00,NULL,NULL,59.57,57.25,61.49,8680.000,37.060,17.949,41.178,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6597.000,NULL,NULL,NULL,NULL,NULL,NULL,2083.000,1069.6205,'2026-05-23 13:56:56.896027','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(20,2,NULL,NULL,'2026-01-15 12:00:00',220.00,NULL,NULL,61.22,61.89,57.26,8560.000,37.488,18.156,41.653,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6334.000,NULL,NULL,NULL,NULL,NULL,NULL,2226.000,1143.0510,'2026-05-23 13:56:56.909867','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(21,2,NULL,NULL,'2026-02-15 12:00:00',220.00,NULL,NULL,71.42,54.33,59.62,8440.000,38.527,18.659,42.808,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6077.000,NULL,NULL,NULL,NULL,NULL,NULL,2363.000,1213.4005,'2026-05-23 13:56:56.982331','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(22,2,NULL,NULL,'2026-03-15 12:00:00',220.00,NULL,NULL,59.94,61.85,60.44,8320.000,37.875,18.344,42.083,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6323.000,NULL,NULL,NULL,NULL,NULL,NULL,1997.000,1025.4595,'2026-05-23 13:56:56.997272','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(23,2,NULL,NULL,'2026-04-15 12:00:00',220.00,NULL,NULL,65.13,60.61,62.51,8200.000,39.126,18.950,43.473,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6068.000,NULL,NULL,NULL,NULL,NULL,NULL,2132.000,1094.7820,'2026-05-23 13:56:57.019805','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(24,2,NULL,NULL,'2026-05-15 12:00:00',220.00,NULL,NULL,56.32,58.61,54.82,8080.000,35.281,17.087,39.201,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,5818.000,NULL,NULL,NULL,NULL,NULL,NULL,2262.000,1161.5370,'2026-05-23 13:56:57.058365','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(25,3,NULL,NULL,'2025-06-15 12:00:00',220.00,NULL,NULL,118.00,131.31,97.29,9440.000,72.037,34.889,80.041,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,7174.000,NULL,NULL,NULL,NULL,NULL,NULL,2266.000,1163.5910,'2026-05-23 13:56:57.074193','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(26,3,NULL,NULL,'2025-07-15 12:00:00',220.00,NULL,NULL,118.91,119.32,115.62,9320.000,73.544,35.619,81.716,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6897.000,NULL,NULL,NULL,NULL,NULL,NULL,2423.000,1244.2105,'2026-05-23 13:56:57.084442','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(27,3,NULL,NULL,'2025-08-15 12:00:00',220.00,NULL,NULL,129.95,113.17,95.74,9200.000,70.429,34.110,78.254,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6624.000,NULL,NULL,NULL,NULL,NULL,NULL,2576.000,1322.7760,'2026-05-23 13:56:57.092585','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(28,3,NULL,NULL,'2025-09-15 12:00:00',220.00,NULL,NULL,124.31,108.90,90.79,9080.000,67.340,32.614,74.822,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6901.000,NULL,NULL,NULL,NULL,NULL,NULL,2179.000,1118.9165,'2026-05-23 13:56:57.102690','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(29,3,NULL,NULL,'2025-10-15 12:00:00',220.00,NULL,NULL,109.99,97.75,115.30,8960.000,67.141,32.518,74.601,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6630.000,NULL,NULL,NULL,NULL,NULL,NULL,2330.000,1196.4550,'2026-05-23 13:56:57.112117','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(30,3,NULL,NULL,'2025-11-15 12:00:00',220.00,NULL,NULL,109.85,100.81,91.54,8840.000,62.809,30.420,69.788,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6365.000,NULL,NULL,NULL,NULL,NULL,NULL,2475.000,1270.9125,'2026-05-23 13:56:57.122021','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(31,3,NULL,NULL,'2025-12-15 12:00:00',220.00,NULL,NULL,139.74,113.54,109.81,8720.000,75.465,36.549,83.850,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6627.000,NULL,NULL,NULL,NULL,NULL,NULL,2093.000,1074.7555,'2026-05-23 13:56:57.131670','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(32,3,NULL,NULL,'2026-01-15 12:00:00',220.00,NULL,NULL,115.61,104.70,94.33,8600.000,65.395,31.672,72.661,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6364.000,NULL,NULL,NULL,NULL,NULL,NULL,2236.000,1148.1860,'2026-05-23 13:56:57.155416','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(33,3,NULL,NULL,'2026-02-15 12:00:00',220.00,NULL,NULL,99.95,120.81,96.30,8480.000,65.898,31.916,73.220,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6106.000,NULL,NULL,NULL,NULL,NULL,NULL,2374.000,1219.0490,'2026-05-23 13:56:57.167558','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(34,3,NULL,NULL,'2026-03-15 12:00:00',220.00,NULL,NULL,103.30,130.42,93.93,8360.000,68.099,32.982,75.666,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6354.000,NULL,NULL,NULL,NULL,NULL,NULL,2006.000,1030.0810,'2026-05-23 13:56:57.178234','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(35,3,NULL,NULL,'2026-04-15 12:00:00',220.00,NULL,NULL,102.83,94.77,120.44,8240.000,66.101,32.014,73.446,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,6098.000,NULL,NULL,NULL,NULL,NULL,NULL,2142.000,1099.9170,'2026-05-23 13:56:57.189071','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(36,3,NULL,NULL,'2026-05-15 12:00:00',220.00,NULL,NULL,104.90,101.91,109.92,8120.000,65.829,31.882,73.143,NULL,NULL,NULL,45.00,NULL,NULL,NULL,NULL,NULL,5846.000,NULL,NULL,NULL,NULL,NULL,NULL,2274.000,1167.6990,'2026-05-23 13:56:57.198602','2026-06-06 08:56:00.755286','seed',NULL,NULL),
(1765,1,NULL,NULL,'2026-06-04 13:32:35',399.05,401.48,399.58,27.26,28.78,26.85,12050.000,17.343,8.103,19.142,0.906,10.249,50.037,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.488310','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1766,1,NULL,NULL,'2026-06-04 13:37:35',399.94,400.93,399.57,24.33,26.59,24.17,12050.005,15.728,7.303,17.341,0.907,9.643,50.028,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.495931','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1767,1,NULL,NULL,'2026-06-04 13:42:35',400.03,401.30,399.00,26.49,26.24,25.70,12050.010,16.391,7.705,18.112,0.905,9.871,49.986,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.502914','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1768,1,NULL,NULL,'2026-06-04 13:47:35',399.63,400.43,398.06,26.10,29.03,22.15,12050.015,15.901,8.102,17.846,0.891,10.142,49.966,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.512606','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1769,1,NULL,NULL,'2026-06-04 13:52:35',400.03,401.07,399.89,27.48,27.79,21.50,12050.020,15.850,7.944,17.729,0.894,10.123,49.980,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.519806','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1770,1,NULL,NULL,'2026-06-04 13:57:35',400.89,401.66,399.64,27.81,22.00,28.78,12050.025,16.443,7.682,18.149,0.906,9.764,50.005,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.526190','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1771,1,NULL,NULL,'2026-06-04 14:02:35',400.50,401.01,399.22,26.79,22.65,25.62,12050.030,15.583,7.591,17.334,0.899,9.177,50.000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.536539','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1772,1,NULL,NULL,'2026-06-04 14:07:35',399.49,401.00,398.22,27.20,25.00,26.85,12050.035,16.320,8.179,18.255,0.894,9.318,50.020,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.544727','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1773,1,NULL,NULL,'2026-06-04 14:12:35',399.15,400.43,398.63,26.49,27.24,21.53,12050.040,15.590,7.683,17.380,0.897,9.714,49.995,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.553080','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1774,1,NULL,NULL,'2026-06-04 14:17:35',400.96,400.47,399.83,29.72,21.44,20.97,12050.045,15.025,7.192,16.657,0.902,10.205,49.981,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.560604','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1775,1,NULL,NULL,'2026-06-04 14:22:35',399.98,400.03,399.63,25.20,30.27,21.51,12050.050,16.000,7.749,17.778,0.900,10.257,50.008,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.570528','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1776,1,NULL,NULL,'2026-06-04 14:27:35',400.85,401.24,398.70,29.92,22.43,25.20,12050.055,15.921,8.201,17.909,0.889,10.375,50.000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.576916','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1777,1,NULL,NULL,'2026-06-04 14:32:35',400.42,400.87,398.95,25.54,27.97,27.58,12050.060,16.666,8.538,18.726,0.890,9.086,50.013,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.585972','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1778,1,NULL,NULL,'2026-06-04 14:37:35',400.19,400.34,398.19,31.04,27.39,28.02,12050.065,18.028,8.578,19.965,0.903,10.393,49.990,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.592254','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1779,1,NULL,NULL,'2026-06-04 14:42:35',400.15,400.50,398.63,25.31,27.51,25.94,12050.070,16.188,8.293,18.189,0.890,10.435,50.001,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.599364','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1780,1,NULL,NULL,'2026-06-04 14:47:35',400.15,401.78,399.69,23.34,24.83,27.37,12050.075,15.561,7.886,17.445,0.892,9.082,49.991,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.606748','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1781,1,NULL,NULL,'2026-06-04 14:52:35',400.21,401.26,399.23,29.92,22.86,27.27,12050.080,16.785,7.745,18.486,0.908,9.146,50.029,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.614573','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1782,1,NULL,NULL,'2026-06-04 14:57:35',399.60,401.29,399.58,25.63,21.97,25.47,12050.085,15.018,7.694,16.874,0.890,9.949,50.005,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.623998','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1783,1,NULL,NULL,'2026-06-04 15:02:35',399.81,401.61,398.89,28.52,22.28,28.22,12050.090,16.369,8.066,18.249,0.897,9.598,49.988,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.631739','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1784,1,NULL,NULL,'2026-06-04 15:07:35',400.61,400.24,399.96,32.84,24.39,26.80,12050.095,17.368,8.656,19.406,0.895,10.131,50.017,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.640648','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1785,1,NULL,NULL,'2026-06-04 15:12:35',399.96,401.75,398.54,28.18,25.88,28.45,12050.100,17.244,8.106,19.054,0.905,9.949,49.968,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.649529','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1786,1,NULL,NULL,'2026-06-04 15:17:35',399.15,401.30,399.03,32.58,22.45,27.17,12050.105,17.009,8.430,18.983,0.896,9.486,50.023,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.658639','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1787,1,NULL,NULL,'2026-06-04 15:22:35',399.47,401.79,399.20,26.41,25.88,24.19,12050.110,15.878,7.735,17.662,0.899,9.291,50.026,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.665873','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1788,1,NULL,NULL,'2026-06-04 15:27:35',399.69,401.31,399.78,28.89,27.98,27.63,12050.115,17.406,8.821,19.513,0.892,9.528,49.961,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.674482','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1789,1,NULL,NULL,'2026-06-04 15:32:35',399.55,400.44,399.07,31.29,28.39,23.19,12050.120,17.147,8.498,19.137,0.896,9.656,50.006,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.684083','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1790,1,NULL,NULL,'2026-06-04 15:37:35',399.05,401.54,398.53,25.27,23.66,25.56,12050.125,15.327,7.810,17.202,0.891,9.187,49.997,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.691783','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1791,1,NULL,NULL,'2026-06-04 15:42:35',399.27,401.39,398.19,23.57,27.07,28.54,12050.130,16.347,8.193,18.285,0.894,10.312,50.026,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.698172','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1792,1,NULL,NULL,'2026-06-04 15:47:35',400.20,400.77,399.08,29.21,25.28,22.80,12050.135,16.118,7.669,17.849,0.903,10.360,49.992,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.705753','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1793,1,NULL,NULL,'2026-06-04 15:52:35',399.99,400.52,399.20,23.04,23.85,23.48,12050.140,14.609,7.117,16.250,0.899,9.978,50.024,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.711819','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1794,1,NULL,NULL,'2026-06-04 15:57:35',399.63,401.96,398.96,31.46,23.42,25.83,12050.145,16.924,7.809,18.639,0.908,10.336,50.025,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.718927','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1795,1,NULL,NULL,'2026-06-04 16:02:35',399.01,401.73,398.72,25.86,27.52,24.53,12050.150,16.211,7.805,17.992,0.901,10.523,50.015,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.725027','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1796,1,NULL,NULL,'2026-06-04 16:07:35',400.37,400.56,399.46,25.51,29.93,28.08,12050.155,17.147,8.832,19.288,0.889,9.978,49.988,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.731837','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1797,1,NULL,NULL,'2026-06-04 16:12:35',400.07,400.38,398.04,27.49,28.05,22.75,12050.160,16.236,7.955,18.080,0.898,9.668,49.972,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.738925','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1798,1,NULL,NULL,'2026-06-04 16:17:35',400.55,400.69,398.06,23.90,28.00,23.09,12050.165,15.638,7.440,17.318,0.903,9.860,50.003,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.744862','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1799,1,NULL,NULL,'2026-06-04 16:22:35',400.92,401.80,398.95,25.99,27.30,23.15,12050.170,15.781,7.909,17.652,0.894,9.414,50.035,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.752113','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1800,1,NULL,NULL,'2026-06-04 16:27:35',400.42,401.43,399.77,28.56,29.67,27.65,12050.175,17.988,8.352,19.832,0.907,9.594,50.012,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.759978','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1801,1,NULL,NULL,'2026-06-04 16:32:35',400.90,401.08,398.32,25.97,22.32,26.24,12050.180,15.559,7.358,17.211,0.904,9.287,49.971,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.766482','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1802,1,NULL,NULL,'2026-06-04 16:37:35',399.57,400.04,398.09,31.74,25.43,25.75,12050.185,17.081,8.656,19.149,0.892,9.962,50.028,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.773542','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1803,1,NULL,NULL,'2026-06-04 16:42:35',399.64,400.34,399.56,29.00,23.61,24.34,12050.190,15.976,7.783,17.771,0.899,9.685,49.971,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.780445','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1804,1,NULL,NULL,'2026-06-04 16:47:35',399.01,400.57,399.09,27.00,28.07,24.15,12050.195,16.355,8.197,18.294,0.894,9.300,50.037,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.788765','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1805,1,NULL,NULL,'2026-06-04 16:52:35',400.65,401.64,399.56,31.66,22.24,28.63,12050.200,17.039,8.540,19.059,0.894,9.718,50.024,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.795816','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1806,1,NULL,NULL,'2026-06-04 16:57:35',399.12,400.09,399.66,25.19,25.03,23.38,12050.205,15.314,7.373,16.997,0.901,10.543,50.018,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.802893','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1807,1,NULL,NULL,'2026-06-04 17:02:35',399.91,400.45,398.86,27.09,22.16,22.47,12050.126,14.708,7.616,16.563,0.888,11.498,49.992,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.810649','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1808,1,NULL,NULL,'2026-06-04 17:07:35',399.17,400.24,398.55,31.27,25.69,28.24,12050.129,17.393,9.198,19.675,0.884,11.114,49.981,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.824237','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1809,1,NULL,NULL,'2026-06-04 17:12:35',399.52,401.95,398.50,32.01,29.85,28.26,12050.132,18.543,9.448,20.811,0.891,10.496,50.036,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.834474','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1810,1,NULL,NULL,'2026-06-04 17:17:35',399.28,401.75,399.81,28.77,24.10,27.30,12050.135,16.440,8.513,18.514,0.888,11.173,50.032,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.847740','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1811,1,NULL,NULL,'2026-06-04 17:22:35',400.47,400.66,399.89,31.90,22.91,22.16,12050.138,15.677,8.376,17.774,0.882,11.025,49.994,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.859026','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1812,1,NULL,NULL,'2026-06-04 17:27:35',399.93,401.60,398.49,27.16,26.26,24.02,12050.141,15.898,8.189,17.883,0.889,11.486,49.996,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.868658','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1813,1,NULL,NULL,'2026-06-04 17:32:35',400.28,401.18,399.20,26.72,27.77,23.45,12050.144,15.983,8.277,17.999,0.888,10.746,50.002,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.878662','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1814,1,NULL,NULL,'2026-06-04 17:37:35',399.28,401.21,398.20,28.72,29.51,26.42,12050.147,17.398,8.913,19.548,0.890,10.392,49.963,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.890932','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1815,1,NULL,NULL,'2026-06-04 17:42:35',399.36,400.59,399.37,29.67,24.66,27.55,12050.150,16.923,8.434,18.908,0.895,11.071,50.000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.902609','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1816,1,NULL,NULL,'2026-06-04 17:47:35',400.38,401.97,398.53,31.52,29.68,28.80,12050.153,18.311,9.833,20.784,0.881,10.607,49.985,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.910706','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1817,1,NULL,NULL,'2026-06-04 17:52:35',400.20,401.25,399.28,32.31,29.49,25.73,12050.156,18.010,9.177,20.213,0.891,10.547,50.018,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.919091','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1818,1,NULL,NULL,'2026-06-04 17:57:35',400.41,400.13,399.49,25.86,27.83,26.01,12050.159,16.473,8.210,18.406,0.895,11.049,50.007,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.927504','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1819,1,NULL,NULL,'2026-06-04 18:02:35',400.50,401.44,399.11,32.78,21.66,22.82,12050.162,15.844,8.205,17.842,0.888,10.722,50.038,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.938008','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1820,1,NULL,NULL,'2026-06-04 18:07:35',399.55,401.89,398.57,24.78,22.54,21.50,12050.165,13.970,7.578,15.893,0.879,10.386,49.999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.947020','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1821,1,NULL,NULL,'2026-06-04 18:12:35',399.80,400.66,398.17,24.62,25.91,29.10,12050.168,16.477,8.166,18.390,0.896,10.076,49.972,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.955535','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1822,1,NULL,NULL,'2026-06-04 18:17:35',399.51,400.10,399.96,26.07,27.65,24.59,12050.171,15.914,8.589,18.084,0.880,10.428,49.999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.963906','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1823,1,NULL,NULL,'2026-06-04 18:22:35',400.74,400.03,398.03,25.42,29.35,25.49,12050.232,16.329,8.769,18.535,0.881,11.225,50.015,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.972705','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1824,1,NULL,NULL,'2026-06-04 18:27:35',399.34,400.15,399.65,24.97,24.46,21.19,12050.236,14.580,7.307,16.309,0.894,11.037,49.967,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.981595','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1825,1,NULL,NULL,'2026-06-04 18:32:35',399.61,401.15,399.13,26.77,27.50,22.02,12050.240,15.750,7.894,17.617,0.894,10.632,50.014,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:35.992301','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1826,1,NULL,NULL,'2026-06-04 18:37:35',400.98,401.51,398.83,31.66,28.87,24.50,12050.244,17.614,8.680,19.637,0.897,10.375,50.025,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.000192','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1827,1,NULL,NULL,'2026-06-04 18:42:35',400.66,400.87,399.36,31.04,27.66,29.32,12050.248,17.949,9.541,20.327,0.883,9.944,50.020,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.009003','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1828,1,NULL,NULL,'2026-06-04 18:47:35',400.06,401.68,399.24,31.69,25.00,23.79,12050.252,16.541,8.474,18.585,0.890,10.132,49.986,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.019541','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1829,1,NULL,NULL,'2026-06-04 18:52:35',400.92,400.65,398.99,29.52,22.76,27.88,12050.256,16.401,8.583,18.511,0.886,11.360,49.985,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.027909','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1830,1,NULL,NULL,'2026-06-04 18:57:35',399.70,400.36,399.21,29.37,28.08,26.84,12050.260,17.227,9.063,19.466,0.885,9.929,50.013,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.039426','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1831,1,NULL,NULL,'2026-06-04 19:02:35',400.88,400.55,399.37,26.53,27.45,22.44,12050.264,15.848,7.765,17.648,0.898,10.564,50.002,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.048041','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1832,1,NULL,NULL,'2026-06-04 19:07:35',399.93,401.02,398.78,24.09,29.86,22.53,12050.268,15.648,8.189,17.661,0.886,11.114,49.995,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.056546','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1833,1,NULL,NULL,'2026-06-04 19:12:35',400.91,402.00,399.04,26.88,23.85,22.14,12050.272,14.994,7.640,16.828,0.891,10.873,49.962,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.067681','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1834,1,NULL,NULL,'2026-06-04 19:17:35',399.29,400.74,399.16,24.01,30.40,25.37,12050.276,16.250,8.682,18.424,0.882,10.084,50.030,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.078806','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1835,1,NULL,NULL,'2026-06-04 19:22:35',399.84,400.77,398.32,30.98,24.64,23.98,12050.280,16.305,8.488,18.382,0.887,10.643,50.038,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.085683','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1836,1,NULL,NULL,'2026-06-04 19:27:35',399.57,401.08,399.57,31.72,23.05,23.34,12050.284,16.090,8.154,18.038,0.892,10.666,49.968,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.094802','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1837,1,NULL,NULL,'2026-06-04 19:32:35',400.05,400.46,398.20,23.23,23.05,28.11,12050.288,15.221,7.966,17.179,0.886,10.207,50.035,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.100855','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1838,1,NULL,NULL,'2026-06-04 19:37:35',400.39,401.47,399.51,29.73,29.02,21.40,12050.292,16.658,8.068,18.509,0.900,9.965,49.982,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.110169','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1839,1,NULL,NULL,'2026-06-04 19:42:35',399.39,400.46,398.17,23.27,29.32,22.14,12050.296,15.221,8.133,17.257,0.882,10.899,49.998,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.117830','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1840,1,NULL,NULL,'2026-06-04 19:47:35',400.37,400.37,398.81,26.46,23.10,28.68,12050.300,16.243,7.913,18.068,0.899,9.962,50.020,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.126527','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1841,1,NULL,NULL,'2026-06-04 19:52:35',399.87,401.58,399.76,32.77,22.61,27.44,12050.304,17.213,8.337,19.126,0.900,10.387,50.033,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.133571','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1842,1,NULL,NULL,'2026-06-04 19:57:35',399.97,401.85,398.88,27.42,29.71,21.92,12050.308,16.138,8.534,18.256,0.884,10.915,50.010,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.142415','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1843,1,NULL,NULL,'2026-06-04 20:02:35',399.67,401.72,399.65,23.93,21.41,27.31,12050.156,14.730,8.030,16.777,0.878,11.596,50.014,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.149663','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1844,1,NULL,NULL,'2026-06-04 20:07:35',400.10,401.77,399.12,30.60,26.16,23.31,12050.158,16.069,9.150,18.491,0.869,11.876,50.007,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.157407','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1845,1,NULL,NULL,'2026-06-04 20:12:35',400.12,401.47,398.20,23.06,22.38,25.33,12050.160,14.480,7.578,16.343,0.886,11.371,49.963,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.164733','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1846,1,NULL,NULL,'2026-06-04 20:17:35',400.58,400.22,398.41,26.43,22.36,25.22,12050.162,14.852,8.457,17.091,0.869,11.123,50.035,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.173191','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1847,1,NULL,NULL,'2026-06-04 20:22:35',399.60,400.53,398.22,25.85,29.39,24.54,12050.164,16.305,8.578,18.424,0.885,11.970,49.985,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.182500','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1848,1,NULL,NULL,'2026-06-04 20:27:35',400.98,400.85,398.62,29.62,30.26,27.64,12050.166,17.705,9.748,20.211,0.876,11.174,50.037,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.192318','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1849,1,NULL,NULL,'2026-06-04 20:32:35',399.89,401.63,399.92,23.97,22.47,23.34,12050.168,14.068,7.859,16.115,0.873,12.127,50.018,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.199172','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1850,1,NULL,NULL,'2026-06-04 20:37:35',399.81,401.58,398.23,25.04,22.13,27.82,12050.170,15.240,8.226,17.318,0.880,11.983,50.030,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.207793','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1851,1,NULL,NULL,'2026-06-04 20:42:35',400.24,401.20,398.42,31.08,26.81,25.16,12050.172,16.878,9.110,19.180,0.880,11.807,50.020,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.216479','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1852,1,NULL,NULL,'2026-06-04 20:47:35',400.08,401.07,398.31,31.33,26.93,25.03,12050.174,16.676,9.585,19.234,0.867,11.619,49.984,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.226966','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1853,1,NULL,NULL,'2026-06-04 20:52:35',400.51,401.19,398.59,30.22,22.15,23.08,12050.176,15.089,8.713,17.424,0.866,11.706,49.995,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.234907','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1854,1,NULL,NULL,'2026-06-04 20:57:35',399.82,400.82,398.14,24.61,30.31,23.29,12050.178,15.677,8.968,18.061,0.868,11.229,49.990,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.242995','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1855,1,NULL,NULL,'2026-06-04 21:02:35',400.24,401.86,399.26,29.70,25.19,21.07,12050.180,15.437,8.332,17.542,0.880,12.462,50.005,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.250339','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1856,1,NULL,NULL,'2026-06-04 21:07:35',399.73,400.28,398.22,23.70,22.99,26.54,12050.182,14.747,8.278,16.912,0.872,11.001,49.969,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.258801','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1857,1,NULL,NULL,'2026-06-04 21:12:35',399.17,400.65,399.52,31.23,22.14,29.31,12050.184,16.802,9.069,19.093,0.880,12.481,49.985,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.265935','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1858,1,NULL,NULL,'2026-06-04 21:17:35',400.87,401.67,399.83,29.31,23.31,22.07,12050.186,15.144,8.256,17.248,0.878,11.407,49.972,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.273938','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1859,1,NULL,NULL,'2026-06-04 21:22:35',399.71,401.17,399.86,25.33,27.44,25.55,12050.188,15.754,8.886,18.087,0.871,12.102,50.030,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.280827','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1860,1,NULL,NULL,'2026-06-04 21:27:35',400.22,400.49,399.76,31.45,26.29,21.63,12050.190,15.891,9.133,18.329,0.867,11.758,49.963,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.290311','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1861,1,NULL,NULL,'2026-06-04 21:32:35',399.46,400.96,399.46,23.34,28.90,28.95,12050.192,16.443,9.009,18.749,0.877,12.314,50.011,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.300096','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1862,1,NULL,NULL,'2026-06-04 21:37:35',401.00,401.99,398.06,25.60,25.93,26.61,12050.194,15.880,8.571,18.045,0.880,11.355,50.007,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.309109','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1863,1,NULL,NULL,'2026-06-04 21:42:35',399.69,400.99,398.38,32.18,26.34,28.96,12050.196,17.596,9.925,20.202,0.871,11.936,50.007,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.321782','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1864,1,NULL,NULL,'2026-06-04 21:47:35',399.06,400.04,399.40,23.84,27.13,28.04,12050.198,15.874,8.996,18.246,0.870,11.066,50.008,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.336628','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1865,1,NULL,NULL,'2026-06-04 21:52:35',400.76,401.49,398.60,26.29,22.62,26.80,12050.200,15.368,8.337,17.484,0.879,11.658,50.012,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.348474','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1866,1,NULL,NULL,'2026-06-04 21:57:35',399.36,400.89,399.47,23.84,24.44,24.17,12050.202,14.656,8.069,16.731,0.876,11.291,49.970,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.358057','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1867,1,NULL,NULL,'2026-06-04 22:02:35',399.64,400.06,399.24,23.34,30.36,26.94,12050.204,16.369,8.880,18.622,0.879,11.092,50.024,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.372291','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1868,1,NULL,NULL,'2026-06-04 22:07:35',400.71,400.13,399.36,29.82,23.72,22.67,12050.206,15.523,8.294,17.600,0.882,11.703,50.029,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.385306','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1869,1,NULL,NULL,'2026-06-04 22:12:35',399.72,400.45,398.68,27.36,25.60,29.29,12050.208,16.601,9.230,18.994,0.874,12.031,49.993,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.395566','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1870,1,NULL,NULL,'2026-06-04 22:17:35',400.53,401.37,399.61,28.10,27.15,25.73,12050.210,16.476,8.848,18.701,0.881,11.433,50.013,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.405130','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1871,1,NULL,NULL,'2026-06-04 22:22:35',400.12,401.38,399.29,23.36,25.57,21.88,12050.212,14.210,8.091,16.352,0.869,11.752,49.980,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.415922','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1872,1,NULL,NULL,'2026-06-04 22:27:35',399.08,401.01,399.04,27.00,26.44,25.29,12050.214,15.836,8.932,18.181,0.871,11.391,50.021,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.426040','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1873,1,NULL,NULL,'2026-06-04 22:32:35',400.51,401.32,398.64,23.16,26.03,24.59,12050.216,14.891,8.279,17.038,0.874,11.998,50.014,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.432989','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1874,1,NULL,NULL,'2026-06-04 22:37:35',400.94,401.59,399.42,30.67,25.63,20.56,12050.218,15.708,8.264,17.749,0.885,11.054,49.985,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.446840','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1875,1,NULL,NULL,'2026-06-04 22:42:35',399.23,400.54,399.66,29.54,23.62,22.92,12050.220,15.338,8.569,17.569,0.873,12.487,49.961,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.455543','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1876,1,NULL,NULL,'2026-06-04 22:47:35',400.53,401.23,399.62,29.06,23.38,23.05,12050.222,15.393,8.182,17.433,0.883,11.971,49.993,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.470836','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1877,1,NULL,NULL,'2026-06-04 22:52:35',399.01,400.30,399.67,30.61,30.14,24.42,12050.224,17.210,9.522,19.669,0.875,11.663,49.978,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.480052','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1878,1,NULL,NULL,'2026-06-04 22:57:35',399.95,401.88,399.89,26.51,25.57,22.44,12050.226,14.938,8.546,17.210,0.868,11.113,50.003,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.488371','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1879,1,NULL,NULL,'2026-06-04 23:02:35',400.33,400.39,398.50,30.15,29.95,24.72,12050.228,17.139,9.483,19.587,0.875,12.078,50.036,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.500358','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1880,1,NULL,NULL,'2026-06-04 23:07:35',399.22,401.96,398.09,28.80,25.91,26.90,12050.230,16.510,9.090,18.847,0.876,11.109,50.018,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.511125','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1881,1,NULL,NULL,'2026-06-04 23:12:35',399.39,400.59,399.90,23.84,24.13,22.66,12050.232,14.174,8.071,16.311,0.869,11.508,50.004,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.520931','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1882,1,NULL,NULL,'2026-06-04 23:17:35',400.98,400.63,399.70,26.00,28.67,20.71,12050.234,15.284,8.332,17.408,0.878,11.943,49.967,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.530247','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1883,1,NULL,NULL,'2026-06-04 23:22:35',399.25,401.67,398.04,30.62,28.16,23.86,12050.236,16.661,9.308,19.085,0.873,12.277,49.975,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.537481','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1884,1,NULL,NULL,'2026-06-04 23:27:35',400.98,401.09,399.77,29.78,23.75,22.93,12050.238,15.556,8.354,17.657,0.881,11.911,50.001,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.546863','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1885,1,NULL,NULL,'2026-06-04 23:32:35',400.24,401.64,398.82,28.73,21.81,25.39,12050.240,15.501,8.197,17.535,0.884,11.755,49.981,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.554728','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1886,1,NULL,NULL,'2026-06-04 23:37:35',399.40,400.79,399.00,28.61,22.91,22.04,12050.242,14.881,8.193,16.987,0.876,11.837,49.994,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.564408','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1887,1,NULL,NULL,'2026-06-04 23:42:35',399.39,400.85,399.46,26.44,23.30,20.71,12050.244,14.187,7.964,16.269,0.872,12.130,49.974,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.573717','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1888,1,NULL,NULL,'2026-06-04 23:47:35',400.81,401.97,398.66,27.83,24.56,23.04,12050.246,15.103,8.680,17.420,0.867,11.740,49.978,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.585113','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1889,1,NULL,NULL,'2026-06-04 23:52:35',399.06,400.98,398.33,26.69,21.36,28.68,12050.248,15.575,8.449,17.719,0.879,12.331,50.017,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.597022','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1890,1,NULL,NULL,'2026-06-04 23:57:35',399.96,401.90,398.26,28.34,30.15,21.54,12050.250,16.227,8.846,18.482,0.878,11.779,49.983,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.616126','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1891,1,NULL,NULL,'2026-06-05 00:02:35',399.86,401.37,398.24,30.48,24.90,26.56,12050.252,16.709,8.882,18.923,0.883,12.209,49.995,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.627974','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1892,1,NULL,NULL,'2026-06-05 00:07:35',400.09,401.54,399.65,25.20,22.18,27.61,12050.254,15.170,8.352,17.317,0.876,12.198,50.036,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.637372','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1893,1,NULL,NULL,'2026-06-05 00:12:35',399.72,401.14,398.94,29.76,21.35,29.42,12050.256,16.161,9.202,18.597,0.869,12.343,49.988,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.648111','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1894,1,NULL,NULL,'2026-06-05 00:17:35',400.53,400.64,399.22,32.52,28.49,29.36,12050.258,18.177,10.253,20.869,0.871,11.807,50.031,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.657333','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1895,1,NULL,NULL,'2026-06-05 00:22:35',399.30,401.54,399.60,29.24,22.85,29.03,12050.260,16.542,8.793,18.734,0.883,12.026,50.035,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.667102','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1896,1,NULL,NULL,'2026-06-05 00:27:35',400.35,401.61,399.66,25.46,25.03,22.66,12050.262,14.781,8.178,16.893,0.875,11.215,49.988,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.679319','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1897,1,NULL,NULL,'2026-06-05 00:32:35',399.70,400.37,399.29,23.05,24.36,25.89,12050.264,14.981,7.881,16.928,0.885,11.573,49.972,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.689084','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1898,1,NULL,NULL,'2026-06-05 00:37:35',399.16,400.96,398.00,23.17,24.17,24.66,12050.266,14.516,8.110,16.628,0.873,11.444,50.024,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.698943','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1899,1,NULL,NULL,'2026-06-05 00:42:35',400.06,400.14,398.65,26.96,26.93,27.76,12050.268,16.725,8.707,18.856,0.887,11.977,50.026,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.707505','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1900,1,NULL,NULL,'2026-06-05 00:47:35',400.21,401.87,398.10,25.30,28.27,20.62,12050.270,14.957,8.356,17.133,0.873,11.989,49.967,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.720516','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1901,1,NULL,NULL,'2026-06-05 00:52:35',400.91,401.62,398.65,31.46,22.95,23.56,12050.272,15.845,8.552,18.006,0.880,11.691,50.027,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.731966','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1902,1,NULL,NULL,'2026-06-05 00:57:35',399.77,401.42,398.31,24.75,29.43,27.72,12050.274,16.644,8.983,18.914,0.880,10.975,50.017,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.744919','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1903,1,NULL,NULL,'2026-06-05 01:02:35',400.51,400.29,398.08,27.08,27.31,29.26,12050.276,17.057,9.067,19.317,0.883,12.040,49.981,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.754330','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1904,1,NULL,NULL,'2026-06-05 01:07:35',399.73,401.00,399.33,32.51,28.95,22.59,12050.278,17.042,9.291,19.410,0.878,11.463,50.008,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.764757','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1905,1,NULL,NULL,'2026-06-05 01:12:35',399.63,400.85,399.30,30.20,29.70,23.41,12050.280,16.988,9.030,19.239,0.883,11.021,49.981,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.775576','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1906,1,NULL,NULL,'2026-06-05 01:17:35',400.33,400.52,398.01,32.30,27.55,25.41,12050.282,17.346,9.315,19.689,0.881,11.531,49.979,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.785720','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1907,1,NULL,NULL,'2026-06-05 01:22:35',400.80,401.99,399.23,30.35,21.57,28.92,12050.284,16.410,8.902,18.669,0.879,11.607,49.964,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.799542','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1908,1,NULL,NULL,'2026-06-05 01:27:35',399.47,400.19,399.54,28.96,22.94,21.20,12050.286,14.704,8.294,16.882,0.871,10.932,50.017,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.810586','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1909,1,NULL,NULL,'2026-06-05 01:32:35',400.10,400.87,399.38,31.73,22.40,29.21,12050.288,16.821,9.352,19.246,0.874,11.131,50.002,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.826284','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1910,1,NULL,NULL,'2026-06-05 01:37:35',400.32,400.17,398.97,27.94,26.61,23.61,12050.290,15.703,8.899,18.049,0.870,11.549,49.961,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.840159','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1911,1,NULL,NULL,'2026-06-05 01:42:35',400.97,400.59,398.18,23.26,22.37,24.76,12050.292,14.305,7.721,16.256,0.880,11.089,49.965,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.850584','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1912,1,NULL,NULL,'2026-06-05 01:47:35',400.34,400.18,398.13,23.25,28.09,25.27,12050.294,15.586,8.370,17.691,0.881,11.763,49.967,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.863458','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1913,1,NULL,NULL,'2026-06-05 01:52:35',400.99,401.70,399.72,27.81,28.95,26.19,12050.296,16.704,9.377,19.156,0.872,12.048,49.963,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.874976','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1914,1,NULL,NULL,'2026-06-05 01:57:35',400.96,401.48,398.39,30.18,27.72,22.94,12050.298,16.503,8.727,18.669,0.884,10.809,50.008,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.883754','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1915,1,NULL,NULL,'2026-06-05 02:02:35',400.79,400.36,398.87,26.05,28.02,26.45,12050.300,16.494,8.587,18.595,0.887,11.493,49.971,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.895363','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1916,1,NULL,NULL,'2026-06-05 02:07:35',399.37,400.89,398.96,24.53,28.77,25.13,12050.302,16.047,8.398,18.112,0.886,11.838,50.031,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.907573','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1917,1,NULL,NULL,'2026-06-05 02:12:35',400.65,400.36,399.08,24.80,24.79,23.24,12050.304,14.851,7.894,16.819,0.883,11.171,50.037,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.917595','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1918,1,NULL,NULL,'2026-06-05 02:17:35',400.55,401.24,399.41,27.09,22.60,24.61,12050.306,15.134,8.086,17.159,0.882,12.257,49.991,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.929982','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1919,1,NULL,NULL,'2026-06-05 02:22:35',399.79,401.74,398.60,31.73,30.49,23.10,12050.308,17.418,9.211,19.704,0.884,11.755,50.008,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.950171','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1920,1,NULL,NULL,'2026-06-05 02:27:35',400.52,401.25,399.79,28.06,27.52,27.66,12050.310,16.935,9.094,19.222,0.881,11.201,49.977,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.961954','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1921,1,NULL,NULL,'2026-06-05 02:32:35',399.22,401.44,399.00,32.91,26.49,27.70,12050.312,17.801,9.365,20.114,0.885,11.051,50.036,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.973288','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1922,1,NULL,NULL,'2026-06-05 02:37:35',400.43,401.15,398.76,26.39,24.15,24.91,12050.314,15.176,8.560,17.424,0.871,12.144,50.005,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.982149','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1923,1,NULL,NULL,'2026-06-05 02:42:35',399.04,400.96,398.51,28.46,23.73,26.34,12050.316,15.759,8.973,18.135,0.869,11.788,49.989,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.990485','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1924,1,NULL,NULL,'2026-06-05 02:47:35',399.49,401.24,398.68,27.71,25.16,26.25,12050.318,16.170,8.507,18.271,0.885,11.340,49.969,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:36.998216','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1925,1,NULL,NULL,'2026-06-05 02:52:35',400.59,401.07,398.32,32.67,29.74,25.97,12050.320,17.818,9.954,20.410,0.873,11.270,50.036,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.007858','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1926,1,NULL,NULL,'2026-06-05 02:57:35',399.81,400.82,398.47,26.37,29.46,23.49,12050.322,15.955,8.999,18.318,0.871,11.068,50.022,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.015996','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1927,1,NULL,NULL,'2026-06-05 03:02:35',399.77,401.46,399.72,23.48,23.76,21.85,12050.324,13.897,7.839,15.955,0.871,11.682,50.020,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.026515','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1928,1,NULL,NULL,'2026-06-05 03:07:35',400.57,400.21,398.04,32.72,24.98,20.96,12050.326,15.858,8.859,18.165,0.873,11.617,50.009,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.034810','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1929,1,NULL,NULL,'2026-06-05 03:12:35',400.12,400.69,398.62,23.79,23.74,20.92,12050.328,13.926,7.479,15.807,0.881,11.409,50.010,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.044488','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1930,1,NULL,NULL,'2026-06-05 03:17:35',399.64,401.29,399.30,27.57,22.70,23.80,12050.330,15.035,8.156,17.105,0.879,10.814,49.984,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.052985','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1931,1,NULL,NULL,'2026-06-05 03:22:35',399.22,400.57,399.20,26.88,29.22,21.00,12050.332,15.633,8.523,17.805,0.878,12.208,50.017,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.065127','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1932,1,NULL,NULL,'2026-06-05 03:27:35',400.77,400.86,398.63,30.47,26.54,25.50,12050.334,16.901,8.799,19.054,0.887,11.668,49.988,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.075092','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1933,1,NULL,NULL,'2026-06-05 03:32:35',399.68,401.76,399.64,23.98,29.20,28.64,12050.336,16.646,8.939,18.894,0.881,11.317,50.036,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.082207','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1934,1,NULL,NULL,'2026-06-05 03:37:35',399.06,401.52,399.35,33.03,23.95,24.18,12050.338,16.325,9.208,18.743,0.871,11.197,50.002,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.090592','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1935,1,NULL,NULL,'2026-06-05 03:42:35',400.42,400.69,398.15,24.98,28.56,22.90,12050.340,15.340,8.735,17.652,0.869,10.796,49.977,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.098324','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1936,1,NULL,NULL,'2026-06-05 03:47:35',399.44,401.25,399.22,23.09,23.81,23.13,12050.342,14.345,7.468,16.172,0.887,12.097,49.970,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.108126','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1937,1,NULL,NULL,'2026-06-05 03:52:35',400.37,400.94,398.87,29.63,25.36,22.07,12050.344,15.803,8.183,17.796,0.888,11.263,50.027,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.116024','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1938,1,NULL,NULL,'2026-06-05 03:57:35',399.12,400.90,398.50,28.77,24.67,21.04,12050.346,15.016,8.389,17.200,0.873,12.130,50.005,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.125073','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1939,1,NULL,NULL,'2026-06-05 04:02:35',400.06,401.35,399.18,25.24,30.21,21.15,12050.348,15.390,8.722,17.690,0.870,12.206,49.998,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.133641','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1940,1,NULL,NULL,'2026-06-05 04:07:35',399.42,401.80,399.20,28.13,24.56,22.24,12050.350,15.349,7.991,17.304,0.887,11.452,49.961,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.142982','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1941,1,NULL,NULL,'2026-06-05 04:12:35',399.83,400.67,398.74,32.30,21.82,24.89,12050.352,16.038,8.700,18.246,0.879,11.764,50.032,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.151228','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1942,1,NULL,NULL,'2026-06-05 04:17:35',399.75,401.29,398.18,25.79,30.09,28.09,12050.354,16.890,9.527,19.392,0.871,11.376,50.014,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.160936','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1943,1,NULL,NULL,'2026-06-05 04:22:35',399.03,400.11,398.69,27.04,25.94,22.80,12050.356,15.330,8.440,17.500,0.876,11.664,49.995,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.170156','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1944,1,NULL,NULL,'2026-06-05 04:27:35',399.34,400.70,399.65,30.96,23.24,26.30,12050.358,16.508,8.549,18.590,0.888,11.590,50.022,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.192906','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1945,1,NULL,NULL,'2026-06-05 04:32:35',399.59,401.36,399.89,29.09,22.31,26.85,12050.360,15.902,8.583,18.070,0.880,11.722,50.027,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.201328','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1946,1,NULL,NULL,'2026-06-05 04:37:35',399.55,401.45,398.08,25.06,30.00,20.60,12050.362,15.516,8.035,17.473,0.888,11.765,50.009,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.210881','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1947,1,NULL,NULL,'2026-06-05 04:42:35',400.36,400.06,399.69,25.72,24.47,28.22,12050.364,16.043,8.396,18.107,0.886,11.262,50.013,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.218906','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1948,1,NULL,NULL,'2026-06-05 04:47:35',400.03,400.65,399.53,25.82,29.20,23.73,12050.366,15.931,8.771,18.186,0.876,11.264,50.029,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.227851','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1949,1,NULL,NULL,'2026-06-05 04:52:35',399.69,401.47,398.94,25.65,23.76,25.02,12050.368,15.126,8.164,17.189,0.880,11.680,50.003,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.237133','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1950,1,NULL,NULL,'2026-06-05 04:57:35',399.42,401.14,398.97,30.33,22.68,25.32,12050.370,16.027,8.388,18.089,0.886,11.108,49.966,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.246215','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1951,1,NULL,NULL,'2026-06-05 05:02:35',399.17,401.50,399.57,25.39,26.94,23.01,12050.372,15.172,8.517,17.399,0.872,11.451,49.993,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.257144','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1952,1,NULL,NULL,'2026-06-05 05:07:35',400.82,400.68,399.47,28.91,22.41,27.80,12050.374,16.189,8.472,18.272,0.886,11.358,49.983,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.265325','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1953,1,NULL,NULL,'2026-06-05 05:12:35',400.39,401.84,398.62,30.07,22.22,23.77,12050.376,15.580,8.111,17.565,0.887,11.743,49.991,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.274276','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1954,1,NULL,NULL,'2026-06-05 05:17:35',400.02,400.80,399.11,28.28,26.44,21.90,12050.378,15.571,8.404,17.694,0.880,11.086,50.001,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.281024','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1955,1,NULL,NULL,'2026-06-05 05:22:35',399.25,401.51,398.30,24.30,23.19,25.89,12050.380,14.760,8.325,16.946,0.871,11.519,49.983,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.291101','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1956,1,NULL,NULL,'2026-06-05 05:27:35',399.21,400.71,399.59,26.96,23.06,27.14,12050.382,15.770,8.296,17.819,0.885,10.998,49.961,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.300164','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1957,1,NULL,NULL,'2026-06-05 05:32:35',400.41,400.61,398.11,24.29,25.51,28.07,12050.384,15.645,8.866,17.983,0.870,11.251,50.004,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.311058','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1958,1,NULL,NULL,'2026-06-05 05:37:35',399.23,401.99,398.15,31.66,28.75,23.91,12050.386,17.077,9.356,19.472,0.877,12.181,50.039,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.320026','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1959,1,NULL,NULL,'2026-06-05 05:42:35',399.48,400.26,398.51,28.11,25.24,25.56,12050.388,16.018,8.689,18.223,0.879,11.840,49.998,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.328767','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1960,1,NULL,NULL,'2026-06-05 05:47:35',399.64,401.78,399.77,28.54,22.09,27.26,12050.390,15.865,8.477,17.988,0.882,11.640,49.999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.343250','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1961,1,NULL,NULL,'2026-06-05 05:52:35',399.33,400.52,398.91,28.06,23.94,28.42,12050.392,16.436,8.647,18.572,0.885,11.262,49.968,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.353085','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1962,1,NULL,NULL,'2026-06-05 05:57:35',399.18,401.92,398.88,28.61,22.85,21.73,12050.394,14.722,8.304,16.902,0.871,11.684,50.001,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.361906','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1963,1,NULL,NULL,'2026-06-05 06:02:35',399.53,400.76,398.98,24.90,26.48,22.12,12050.594,14.886,8.156,16.974,0.877,11.527,50.003,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.370197','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1964,1,NULL,NULL,'2026-06-05 06:07:35',399.81,401.05,398.65,25.45,27.80,26.99,12050.597,16.288,8.836,18.530,0.879,11.249,49.985,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.378288','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1965,1,NULL,NULL,'2026-06-05 06:12:35',399.35,400.20,398.10,28.32,25.93,28.31,12050.600,16.702,9.196,19.066,0.876,11.332,49.968,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.385768','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1966,1,NULL,NULL,'2026-06-05 06:17:35',399.17,401.81,398.79,31.63,27.86,28.71,12050.603,18.169,9.207,20.369,0.892,11.820,50.033,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.396327','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1967,1,NULL,NULL,'2026-06-05 06:22:35',399.42,400.03,399.08,27.66,26.86,25.57,12050.606,16.239,8.853,18.495,0.878,11.339,49.970,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.410745','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1968,1,NULL,NULL,'2026-06-05 06:27:35',399.66,401.33,399.41,23.38,26.16,24.64,12050.609,15.212,7.877,17.131,0.888,10.820,50.025,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.418423','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1969,1,NULL,NULL,'2026-06-05 06:32:35',399.41,401.17,399.73,30.52,24.80,25.95,12050.612,16.422,9.086,18.768,0.875,11.078,49.964,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.426501','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1970,1,NULL,NULL,'2026-06-05 06:37:35',399.50,400.72,398.98,32.19,28.44,20.99,12050.615,16.549,9.022,18.849,0.878,11.344,50.008,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.434295','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1971,1,NULL,NULL,'2026-06-05 06:42:35',399.96,400.20,398.78,32.96,28.76,29.50,12050.618,18.538,10.006,21.066,0.880,10.944,49.976,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.443694','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1972,1,NULL,NULL,'2026-06-05 06:47:35',399.20,401.69,399.58,29.15,21.98,25.08,12050.621,15.646,8.059,17.600,0.889,11.689,50.030,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.450670','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1973,1,NULL,NULL,'2026-06-05 06:52:35',400.28,400.38,398.78,26.32,22.64,26.82,12050.624,15.663,7.806,17.501,0.895,11.246,50.015,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.459765','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1974,1,NULL,NULL,'2026-06-05 06:57:35',399.76,400.69,399.69,23.88,24.58,24.71,12050.627,14.887,7.995,16.898,0.881,10.702,50.001,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.465841','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1975,1,NULL,NULL,'2026-06-05 07:02:35',400.90,400.81,399.49,25.90,21.86,24.22,12050.630,14.678,7.802,16.623,0.883,11.011,50.033,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.473467','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1976,1,NULL,NULL,'2026-06-05 07:07:35',399.76,401.94,399.83,31.96,23.41,24.44,12050.633,16.440,8.331,18.430,0.892,10.892,49.977,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.479456','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1977,1,NULL,NULL,'2026-06-05 07:12:35',399.58,400.53,398.66,28.20,23.99,28.31,12050.636,16.359,8.830,18.590,0.880,10.093,50.021,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.486233','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1978,1,NULL,NULL,'2026-06-05 07:17:35',400.86,401.24,398.56,27.80,28.82,25.57,12050.639,16.836,8.765,18.981,0.887,10.551,50.027,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.493302','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1979,1,NULL,NULL,'2026-06-05 07:22:35',399.24,401.69,398.89,27.14,24.89,26.46,12050.642,16.168,8.193,18.126,0.892,10.092,50.011,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.499305','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1980,1,NULL,NULL,'2026-06-05 07:27:35',399.16,400.86,399.06,24.65,29.29,27.30,12050.645,16.772,8.406,18.761,0.894,11.451,50.032,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.509061','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1981,1,NULL,NULL,'2026-06-05 07:32:35',400.65,401.78,399.45,25.23,29.34,25.99,12050.864,16.651,8.299,18.604,0.895,10.009,49.989,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.517424','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1982,1,NULL,NULL,'2026-06-05 07:37:35',399.94,401.63,398.71,27.79,26.60,23.96,12050.868,16.121,8.214,18.093,0.891,11.114,49.964,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.526613','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1983,1,NULL,NULL,'2026-06-05 07:42:35',399.87,400.37,398.07,25.28,30.64,23.12,12050.872,16.355,8.105,18.253,0.896,10.862,49.986,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.534785','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1984,1,NULL,NULL,'2026-06-05 07:47:35',400.55,401.55,398.93,27.68,25.68,28.82,12050.876,16.720,8.979,18.978,0.881,10.241,49.992,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.544806','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1985,1,NULL,NULL,'2026-06-05 07:52:35',399.63,400.90,398.48,25.22,24.59,21.17,12050.880,14.736,7.179,16.392,0.899,9.980,50.012,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.553778','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1986,1,NULL,NULL,'2026-06-05 07:57:35',399.78,401.89,399.91,26.23,25.05,20.67,12050.884,14.888,7.378,16.616,0.896,11.253,50.035,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.561572','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1987,1,NULL,NULL,'2026-06-05 08:02:35',399.85,400.55,399.61,32.03,25.47,25.15,12050.888,17.063,8.552,19.086,0.894,10.079,50.019,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.569200','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1988,1,NULL,NULL,'2026-06-05 08:07:35',399.69,400.30,398.10,25.51,28.00,27.78,12050.892,16.801,8.374,18.772,0.895,9.367,49.961,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.602157','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1989,1,NULL,NULL,'2026-06-05 08:12:35',399.38,400.36,399.61,32.06,22.16,27.16,12051.120,16.801,8.421,18.793,0.894,10.464,49.960,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.630570','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1990,1,NULL,NULL,'2026-06-05 08:17:35',399.24,400.18,398.34,27.31,30.09,24.01,12051.125,16.657,8.717,18.800,0.886,10.592,50.021,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.640145','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1991,1,NULL,NULL,'2026-06-05 08:22:35',400.66,400.85,398.35,24.37,26.28,22.58,12051.130,15.305,7.194,16.912,0.905,9.447,49.982,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.648225','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1992,1,NULL,NULL,'2026-06-05 08:27:35',400.93,401.80,398.66,28.66,22.59,29.30,12051.135,16.742,8.109,18.602,0.900,10.729,49.975,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.655724','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1993,1,NULL,NULL,'2026-06-05 08:32:35',399.73,400.50,399.73,27.85,25.93,20.57,12051.140,15.436,7.520,17.170,0.899,9.304,50.035,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.662972','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1994,1,NULL,NULL,'2026-06-05 08:37:35',400.87,400.21,399.77,28.60,28.58,22.31,12051.145,16.631,7.770,18.357,0.906,9.331,49.994,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.669351','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1995,1,NULL,NULL,'2026-06-05 08:42:35',400.67,400.07,399.83,29.77,28.59,28.20,12051.150,17.971,8.755,19.990,0.899,9.246,50.011,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.677853','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1996,1,NULL,NULL,'2026-06-05 08:47:35',400.08,400.77,399.58,32.50,22.89,29.48,12051.155,17.718,8.379,19.600,0.904,10.186,50.016,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.686204','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1997,1,NULL,NULL,'2026-06-05 08:52:35',400.04,401.09,399.64,27.85,25.37,26.89,12051.160,16.687,7.987,18.500,0.902,9.499,49.983,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.698426','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1998,1,NULL,NULL,'2026-06-05 08:57:35',399.38,400.88,399.62,25.48,22.44,28.14,12051.165,15.668,7.940,17.565,0.892,9.630,49.999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.705859','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(1999,1,NULL,NULL,'2026-06-05 09:02:35',400.97,400.55,399.55,31.86,29.47,26.83,12051.170,18.405,8.704,20.360,0.904,10.072,49.964,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.714545','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2000,1,NULL,NULL,'2026-06-05 09:07:35',399.15,401.36,399.33,32.07,25.16,23.57,12051.175,16.943,7.818,18.660,0.908,9.219,50.038,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.723734','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2001,1,NULL,NULL,'2026-06-05 09:12:35',399.48,400.12,399.74,27.71,24.47,22.90,12051.180,15.414,7.939,17.339,0.889,9.452,50.008,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.734729','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2002,1,NULL,NULL,'2026-06-05 09:17:35',400.36,400.21,398.94,26.21,28.94,21.42,12051.185,15.808,7.923,17.682,0.894,10.379,50.025,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.744253','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2003,1,NULL,NULL,'2026-06-05 09:22:35',400.63,401.19,398.43,23.67,21.75,20.67,12051.190,13.736,6.653,15.262,0.900,9.783,49.981,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.754256','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2004,1,NULL,NULL,'2026-06-05 09:27:35',399.37,401.58,398.02,32.58,28.04,27.02,12051.195,18.094,9.069,20.239,0.894,9.789,49.967,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.762499','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2005,1,NULL,NULL,'2026-06-05 09:32:35',399.44,401.97,399.50,27.70,22.97,24.72,12051.200,15.547,7.835,17.410,0.893,10.631,49.989,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.770944','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2006,1,NULL,NULL,'2026-06-05 09:37:35',400.94,401.10,399.70,31.21,27.71,29.13,12051.205,18.117,9.231,20.333,0.891,9.533,50.003,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.780866','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2007,1,NULL,NULL,'2026-06-05 09:42:35',400.59,400.80,399.20,30.50,29.38,21.06,12051.210,16.692,8.412,18.692,0.893,9.275,49.980,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.788374','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2008,1,NULL,NULL,'2026-06-05 09:47:35',400.72,401.46,398.70,30.29,25.54,21.17,12051.215,15.968,7.824,17.782,0.898,10.354,49.966,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.796626','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2009,1,NULL,NULL,'2026-06-05 09:52:35',400.62,400.37,399.21,23.13,29.40,22.89,12051.220,15.588,7.769,17.417,0.895,9.452,50.010,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.806483','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2010,1,NULL,NULL,'2026-06-05 09:57:35',400.96,401.28,398.37,30.37,29.57,22.30,12051.225,17.226,7.998,18.992,0.907,10.419,49.963,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.815269','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2011,1,NULL,NULL,'2026-06-05 10:02:35',399.10,401.84,399.53,26.53,22.94,27.74,12051.230,16.119,7.623,17.831,0.904,9.664,50.002,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.823127','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2012,1,NULL,NULL,'2026-06-05 10:07:35',399.88,401.58,399.61,28.02,22.21,29.22,12051.235,16.329,8.366,18.347,0.890,10.255,49.970,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.834828','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2013,1,NULL,NULL,'2026-06-05 10:12:35',400.12,401.40,399.49,28.58,29.60,27.23,12051.240,17.535,9.032,19.724,0.889,9.994,50.007,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.847600','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2014,1,NULL,NULL,'2026-06-05 10:17:35',399.42,401.91,399.68,23.81,23.00,26.28,12051.245,15.208,7.322,16.879,0.901,9.157,50.025,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.858537','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2015,1,NULL,NULL,'2026-06-05 10:22:35',399.21,401.02,398.83,29.77,25.52,22.48,12051.250,16.182,7.791,17.960,0.901,9.908,49.999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.866094','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2016,1,NULL,NULL,'2026-06-05 10:27:35',400.53,400.12,398.48,30.55,22.30,22.87,12051.255,15.843,7.402,17.487,0.906,9.880,50.011,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.875844','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2017,1,NULL,NULL,'2026-06-05 10:32:35',400.00,401.98,398.98,22.99,23.43,21.56,12051.260,14.066,6.971,15.699,0.896,9.269,50.022,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.882279','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2018,1,NULL,NULL,'2026-06-05 10:37:35',399.53,400.64,398.45,32.17,23.34,23.51,12051.265,16.551,7.685,18.248,0.907,9.874,50.031,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.892113','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2019,1,NULL,NULL,'2026-06-05 10:42:35',400.89,401.15,399.82,23.24,22.60,25.87,12051.270,14.772,7.486,16.561,0.892,9.741,49.970,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.898899','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2020,1,NULL,NULL,'2026-06-05 10:47:35',399.93,401.93,398.86,28.77,22.16,26.97,12051.275,16.029,8.167,17.990,0.891,9.706,50.008,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.906244','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2021,1,NULL,NULL,'2026-06-05 10:52:35',400.40,400.10,399.38,26.27,25.85,24.42,12051.280,15.943,7.631,17.675,0.902,9.253,50.026,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.913918','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2022,1,NULL,NULL,'2026-06-05 10:57:35',399.53,400.58,398.90,30.25,24.22,23.91,12051.285,16.164,8.146,18.101,0.893,10.565,50.023,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.921198','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2023,1,NULL,NULL,'2026-06-05 11:02:35',400.60,401.16,399.93,32.70,27.81,25.63,12051.290,17.923,8.630,19.892,0.901,10.265,49.975,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.929784','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2024,1,NULL,NULL,'2026-06-05 11:07:35',399.37,401.12,399.13,30.71,22.57,23.75,12051.295,15.796,8.180,17.788,0.888,10.410,50.035,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.938949','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2025,1,NULL,NULL,'2026-06-05 11:12:35',400.27,401.34,398.63,27.04,30.12,24.86,12051.300,17.085,8.178,18.941,0.902,10.266,49.984,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.946478','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2026,1,NULL,NULL,'2026-06-05 11:17:35',399.54,401.75,399.40,29.06,26.67,20.87,12051.305,15.708,8.134,17.689,0.888,9.516,50.038,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.954471','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2027,1,NULL,NULL,'2026-06-05 11:22:35',399.59,400.00,398.12,27.90,24.38,21.98,12051.310,15.280,7.786,17.149,0.891,10.623,50.013,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.963093','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2028,1,NULL,NULL,'2026-06-05 11:27:35',400.77,400.24,399.26,31.47,28.11,21.36,12051.315,16.785,8.224,18.692,0.898,10.211,50.002,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.970347','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2029,1,NULL,NULL,'2026-06-05 11:32:35',400.27,400.13,399.45,26.00,23.37,22.24,12051.320,14.983,7.000,16.538,0.906,9.564,50.017,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.976961','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2030,1,NULL,NULL,'2026-06-05 11:37:35',400.05,401.84,399.10,26.07,30.34,28.54,12051.325,17.460,8.945,19.618,0.890,9.481,50.006,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.987638','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2031,1,NULL,NULL,'2026-06-05 11:42:35',400.31,401.84,398.95,28.74,23.07,22.44,12051.330,15.398,7.545,17.147,0.898,9.972,50.011,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:37.995499','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2032,1,NULL,NULL,'2026-06-05 11:47:35',400.98,400.23,398.41,28.17,30.11,21.79,12051.068,16.401,8.538,18.490,0.887,10.478,49.987,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.002662','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2033,1,NULL,NULL,'2026-06-05 11:52:35',399.93,401.49,399.05,32.05,22.03,26.56,12051.340,16.518,8.599,18.622,0.887,10.703,50.023,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.010729','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2034,1,NULL,NULL,'2026-06-05 11:57:35',400.72,400.74,399.51,24.36,27.65,29.16,12051.345,16.945,8.014,18.744,0.904,10.497,49.996,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.017212','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2035,1,NULL,NULL,'2026-06-05 12:02:35',399.50,400.98,398.11,30.85,21.58,27.62,12050.540,16.305,8.712,18.486,0.882,10.947,50.020,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.027956','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2036,1,NULL,NULL,'2026-06-05 12:07:35',399.49,401.84,399.82,31.73,30.46,22.98,12050.542,17.328,9.306,19.669,0.881,11.853,50.005,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.036017','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2037,1,NULL,NULL,'2026-06-05 12:12:35',400.80,400.67,399.50,27.47,25.17,26.92,12050.544,15.985,9.059,18.374,0.870,10.997,50.031,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.044920','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2038,1,NULL,NULL,'2026-06-05 12:17:35',399.13,400.12,398.61,26.33,26.29,26.38,12050.546,15.890,8.963,18.243,0.871,11.694,49.979,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.051984','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2039,1,NULL,NULL,'2026-06-05 12:22:35',400.74,400.10,399.91,29.74,25.10,20.51,12050.548,15.208,8.455,17.400,0.874,11.197,50.005,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.063729','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2040,1,NULL,NULL,'2026-06-05 12:27:35',399.61,400.37,398.59,30.98,30.44,24.85,12050.550,17.532,9.463,19.923,0.880,12.221,49.962,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.071914','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2041,1,NULL,NULL,'2026-06-05 12:32:35',399.32,401.91,399.78,27.94,21.50,26.04,12050.552,15.391,8.181,17.430,0.883,11.655,50.002,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.079957','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2042,1,NULL,NULL,'2026-06-05 12:37:35',400.44,400.48,398.09,23.14,23.61,22.02,12050.554,13.801,7.858,15.881,0.869,11.983,49.992,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.087520','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2043,1,NULL,NULL,'2026-06-05 12:42:35',399.06,401.34,399.32,24.07,21.75,28.58,12050.556,14.965,8.441,17.181,0.871,11.194,50.023,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.094175','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2044,1,NULL,NULL,'2026-06-05 12:47:35',399.38,400.46,399.42,26.50,21.89,22.79,12050.558,14.383,7.958,16.438,0.875,11.836,50.018,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.102208','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2045,1,NULL,NULL,'2026-06-05 12:52:35',400.62,401.06,398.54,23.84,27.63,21.49,12050.560,14.793,8.065,16.849,0.878,12.035,50.003,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.110661','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2046,1,NULL,NULL,'2026-06-05 12:57:35',400.32,400.08,398.17,28.29,24.23,29.24,12050.562,16.540,9.107,18.881,0.876,12.013,49.973,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.116687','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2047,1,NULL,NULL,'2026-06-05 13:02:35',400.86,401.47,399.28,32.25,27.83,26.91,12051.410,17.899,9.120,20.089,0.891,10.209,49.982,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.126750','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2048,1,NULL,NULL,'2026-06-05 13:07:35',400.61,400.27,399.50,27.72,23.45,26.98,12051.415,16.062,8.229,18.047,0.890,9.469,49.971,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.134799','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2049,1,NULL,NULL,'2026-06-05 13:12:35',399.32,400.31,398.89,32.22,25.37,24.17,12051.420,16.861,8.498,18.881,0.893,9.426,49.960,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.147805','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2050,1,NULL,NULL,'2026-06-05 13:17:35',400.40,400.04,398.99,30.44,25.86,22.31,12051.425,16.447,7.684,18.153,0.906,9.625,49.980,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.159640','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2051,1,NULL,NULL,'2026-06-05 13:22:35',399.88,400.75,399.47,28.50,22.68,21.18,12051.430,14.922,7.520,16.710,0.893,9.991,49.964,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.167516','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2052,1,NULL,NULL,'2026-06-05 13:27:35',400.46,400.97,399.18,32.47,25.93,26.17,12051.435,17.597,8.473,19.531,0.901,10.116,49.996,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.175147','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2053,2,NULL,NULL,'2026-06-04 13:32:38',399.18,400.12,398.97,68.08,69.45,52.91,12100.000,39.273,19.793,43.979,0.893,9.889,49.967,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.232043','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2054,2,NULL,NULL,'2026-06-04 13:37:38',400.19,400.58,398.01,71.67,69.41,64.81,12100.005,42.935,20.428,47.547,0.903,9.206,50.038,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.240753','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2055,2,NULL,NULL,'2026-06-04 13:42:38',400.25,401.45,398.73,65.81,72.86,53.32,12100.010,39.682,19.777,44.337,0.895,9.452,49.994,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.252209','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2056,2,NULL,NULL,'2026-06-04 13:47:38',399.53,401.56,398.68,63.13,73.95,65.56,12100.015,41.836,20.968,46.796,0.894,9.387,50.006,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.262544','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2057,2,NULL,NULL,'2026-06-04 13:52:38',400.31,401.74,399.75,80.00,68.11,58.31,12100.020,42.855,20.877,47.670,0.899,9.795,50.022,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.270276','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2058,2,NULL,NULL,'2026-06-04 13:57:38',399.28,400.33,398.82,57.57,54.90,55.75,12100.025,34.924,17.013,38.848,0.899,9.637,50.021,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.279285','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2059,2,NULL,NULL,'2026-06-04 14:02:38',400.89,401.64,398.34,60.66,54.57,67.65,12100.030,38.263,17.876,42.233,0.906,10.359,50.030,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.286862','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2060,2,NULL,NULL,'2026-06-04 14:07:38',399.44,401.68,399.80,80.18,62.27,52.07,12100.035,40.654,19.110,44.922,0.905,10.437,49.999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.294041','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2061,2,NULL,NULL,'2026-06-04 14:12:38',400.88,400.48,399.74,65.28,65.04,61.31,12100.040,39.740,19.472,44.254,0.898,9.396,50.007,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.302211','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2062,2,NULL,NULL,'2026-06-04 14:17:38',399.25,400.14,399.96,59.83,55.94,54.63,12100.045,35.613,16.741,39.351,0.905,10.300,49.967,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.312700','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2063,2,NULL,NULL,'2026-06-04 14:22:38',399.05,400.02,399.53,75.52,58.98,70.57,12100.050,42.811,20.247,47.357,0.904,10.091,50.038,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.322809','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2064,2,NULL,NULL,'2026-06-04 14:27:38',399.76,400.57,398.08,58.20,64.71,56.86,12100.055,37.239,18.351,41.515,0.897,10.421,50.021,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.333786','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2065,2,NULL,NULL,'2026-06-04 14:32:38',400.42,400.12,398.95,60.20,71.88,63.59,12100.060,40.713,19.603,45.186,0.901,10.159,49.976,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.343730','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2066,2,NULL,NULL,'2026-06-04 14:37:38',400.63,401.23,399.54,75.48,53.16,64.97,12100.065,40.285,19.397,44.711,0.901,10.384,49.997,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.352468','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2067,2,NULL,NULL,'2026-06-04 14:42:38',400.77,401.28,398.21,69.51,66.74,58.06,12100.070,39.982,20.373,44.873,0.891,9.074,50.009,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.363788','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2068,2,NULL,NULL,'2026-06-04 14:47:38',399.21,400.43,398.44,60.49,69.44,51.36,12100.075,38.014,17.540,41.866,0.908,9.264,49.991,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.373310','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2069,2,NULL,NULL,'2026-06-04 14:52:38',400.60,401.08,398.12,62.89,56.10,68.89,12100.080,39.396,18.178,43.388,0.908,10.320,50.005,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.382664','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2070,2,NULL,NULL,'2026-06-04 14:57:38',400.66,401.24,399.24,57.88,68.56,54.18,12100.085,37.332,18.606,41.712,0.895,9.297,49.986,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.391148','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2071,2,NULL,NULL,'2026-06-04 15:02:38',400.25,400.79,399.66,57.20,66.36,67.25,12100.090,39.922,18.651,44.064,0.906,10.143,50.028,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.400040','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2072,2,NULL,NULL,'2026-06-04 15:07:38',399.53,400.43,398.26,64.84,60.50,62.76,12100.095,38.747,19.636,43.438,0.892,9.423,49.991,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.407581','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2073,2,NULL,NULL,'2026-06-04 15:12:38',399.71,401.98,398.74,58.09,66.12,63.75,12100.100,38.935,19.187,43.406,0.897,9.640,50.008,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.415077','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2074,2,NULL,NULL,'2026-06-04 15:17:38',399.56,400.17,398.35,70.29,74.27,69.68,12100.105,44.429,21.769,49.476,0.898,9.397,49.995,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.425160','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2075,2,NULL,NULL,'2026-06-04 15:22:38',400.42,400.36,399.86,77.88,68.00,63.39,12100.110,43.688,20.662,48.327,0.904,10.388,50.012,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.434912','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2076,2,NULL,NULL,'2026-06-04 15:27:38',400.33,401.72,398.60,62.23,60.54,69.87,12100.115,40.172,19.114,44.487,0.903,10.185,50.003,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.442026','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2077,2,NULL,NULL,'2026-06-04 15:32:38',400.46,401.80,399.46,73.75,70.98,66.72,12100.120,43.557,22.073,48.831,0.892,9.915,49.982,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.450815','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2078,2,NULL,NULL,'2026-06-04 15:37:38',400.13,400.99,399.16,71.59,70.92,50.52,12100.125,40.431,18.773,44.577,0.907,10.220,49.999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.458108','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2079,2,NULL,NULL,'2026-06-04 15:42:38',400.49,401.41,398.61,77.89,60.24,70.21,12100.130,42.820,21.937,48.112,0.890,9.735,49.969,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.464712','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2080,2,NULL,NULL,'2026-06-04 15:47:38',399.59,401.20,398.21,76.61,60.34,52.47,12100.135,39.500,18.794,43.743,0.903,9.679,50.039,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.472977','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2081,2,NULL,NULL,'2026-06-04 15:52:38',400.53,400.89,399.57,73.70,57.31,67.57,12100.140,41.502,19.509,45.859,0.905,9.478,49.995,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.482433','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2082,2,NULL,NULL,'2026-06-04 15:57:38',399.94,401.37,398.80,71.00,65.41,69.46,12100.145,42.978,20.326,47.542,0.904,10.387,50.032,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.489497','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2083,2,NULL,NULL,'2026-06-04 16:02:38',399.16,400.94,399.15,55.91,57.47,50.60,12100.150,33.817,17.043,37.869,0.893,9.182,50.014,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.497549','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2084,2,NULL,NULL,'2026-06-04 16:07:38',399.19,400.70,398.07,72.28,56.61,68.03,12100.155,41.292,19.053,45.476,0.908,10.168,50.039,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.506639','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2085,2,NULL,NULL,'2026-06-04 16:12:38',399.23,401.14,399.99,75.88,63.85,49.24,12100.160,39.101,19.378,43.640,0.896,10.186,50.021,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.513423','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2086,2,NULL,NULL,'2026-06-04 16:17:38',399.56,401.78,399.70,68.70,67.15,62.14,12100.165,40.967,20.303,45.722,0.896,10.037,49.977,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.522387','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2087,2,NULL,NULL,'2026-06-04 16:22:38',399.77,401.92,399.75,57.82,66.85,67.92,12100.170,40.339,18.730,44.475,0.907,9.137,49.969,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.528951','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2088,2,NULL,NULL,'2026-06-04 16:27:38',400.33,401.18,399.19,67.05,68.76,52.41,12100.175,38.642,19.904,43.467,0.889,10.272,49.962,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.536989','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2089,2,NULL,NULL,'2026-06-04 16:32:38',399.14,401.48,398.22,71.02,67.95,59.73,12100.180,40.793,21.012,45.886,0.889,9.395,49.994,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.544000','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2090,2,NULL,NULL,'2026-06-04 16:37:38',400.81,400.41,399.21,66.10,67.47,70.48,12100.185,42.551,20.245,47.122,0.903,10.173,50.024,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.551316','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2091,2,NULL,NULL,'2026-06-04 16:42:38',399.95,400.09,398.14,79.59,73.48,62.98,12100.190,44.405,22.749,49.893,0.890,10.279,49.981,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.558078','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2092,2,NULL,NULL,'2026-06-04 16:47:38',400.74,401.06,399.20,66.89,60.77,58.58,12100.195,38.493,19.185,43.009,0.895,9.437,49.978,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.565972','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2093,2,NULL,NULL,'2026-06-04 16:52:38',399.79,401.81,398.87,58.01,56.10,60.20,12100.200,36.470,17.039,40.254,0.906,10.567,49.987,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.572957','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2094,2,NULL,NULL,'2026-06-04 16:57:38',399.30,400.81,398.88,57.63,72.13,49.96,12100.205,37.561,17.656,41.504,0.905,9.764,49.971,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.580849','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2095,2,NULL,NULL,'2026-06-04 17:02:38',399.39,401.41,399.01,70.88,75.12,50.51,12100.126,40.525,20.424,45.381,0.893,11.518,50.037,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.587277','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2096,2,NULL,NULL,'2026-06-04 17:07:38',399.24,400.14,398.30,64.47,66.21,68.92,12100.129,41.024,21.017,46.094,0.890,10.493,50.022,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.593328','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2097,2,NULL,NULL,'2026-06-04 17:12:38',400.47,401.44,398.09,74.76,55.77,57.54,12100.132,38.220,20.629,43.432,0.880,11.161,49.998,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.601442','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2098,2,NULL,NULL,'2026-06-04 17:17:38',399.03,401.07,399.32,68.04,60.54,54.46,12100.135,37.705,19.108,42.270,0.892,10.580,49.978,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.611957','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2099,2,NULL,NULL,'2026-06-04 17:22:38',400.81,400.61,399.99,59.87,55.00,50.12,12100.138,33.682,17.812,38.102,0.884,10.932,49.995,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.619526','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2100,2,NULL,NULL,'2026-06-04 17:27:38',399.45,401.27,398.56,77.45,59.43,67.59,12100.141,41.553,22.428,47.219,0.880,10.851,49.971,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.625595','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2101,2,NULL,NULL,'2026-06-04 17:32:38',400.42,400.45,399.23,64.34,57.04,69.48,12100.144,39.492,19.572,44.076,0.896,10.998,50.011,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.633971','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2102,2,NULL,NULL,'2026-06-04 17:37:38',399.13,400.53,398.20,58.22,68.27,51.93,12100.147,36.588,18.947,41.203,0.888,10.325,49.980,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.641288','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2103,2,NULL,NULL,'2026-06-04 17:42:38',399.87,401.19,399.58,69.83,63.88,65.41,12100.150,40.741,21.322,45.983,0.886,11.494,50.013,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.650387','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2104,2,NULL,NULL,'2026-06-04 17:47:38',399.22,400.02,398.91,62.30,54.43,62.63,12100.153,36.450,19.674,41.420,0.880,11.033,49.988,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.657820','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2105,2,NULL,NULL,'2026-06-04 17:52:38',400.63,401.03,399.52,76.69,61.91,59.59,12100.156,40.551,21.222,45.769,0.886,10.221,49.963,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.666230','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2106,2,NULL,NULL,'2026-06-04 17:57:38',400.14,401.55,398.10,60.11,62.72,64.12,12100.159,38.467,19.601,43.173,0.891,10.338,50.009,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.674560','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2107,2,NULL,NULL,'2026-06-04 18:02:38',400.71,400.61,399.21,58.69,64.60,55.06,12100.162,36.739,18.618,41.187,0.892,11.207,50.010,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.684529','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2108,2,NULL,NULL,'2026-06-04 18:07:38',400.53,401.88,399.36,74.82,54.31,50.54,12100.165,36.803,19.160,41.492,0.887,11.277,49.987,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.691750','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2109,2,NULL,NULL,'2026-06-04 18:12:38',400.80,400.13,399.24,57.48,56.30,62.54,12100.168,35.995,19.035,40.718,0.884,10.869,50.010,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.699897','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2110,2,NULL,NULL,'2026-06-04 18:17:38',399.28,400.11,399.43,70.21,54.75,64.80,12100.228,39.264,19.459,43.821,0.896,10.416,50.025,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.707240','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2111,2,NULL,NULL,'2026-06-04 18:22:38',399.15,401.32,398.06,63.50,62.01,51.78,12100.232,36.275,18.984,40.942,0.886,9.968,49.985,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.715444','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2112,2,NULL,NULL,'2026-06-04 18:27:38',399.76,400.33,399.51,64.47,62.19,50.06,12100.236,36.525,18.204,40.810,0.895,11.265,49.981,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.724143','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2113,2,NULL,NULL,'2026-06-04 18:32:38',400.80,401.23,398.13,78.65,65.29,70.26,12100.240,43.629,23.311,49.466,0.882,11.189,50.018,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.733945','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2114,2,NULL,NULL,'2026-06-04 18:37:38',399.93,401.87,399.64,60.81,54.94,68.96,12100.244,37.708,19.941,42.656,0.884,10.819,50.035,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.741906','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2115,2,NULL,NULL,'2026-06-04 18:42:38',400.86,401.94,399.64,61.99,64.65,68.13,12100.248,39.806,20.942,44.979,0.885,10.150,49.964,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.750090','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2116,2,NULL,NULL,'2026-06-04 18:47:38',400.03,401.58,398.83,75.28,60.72,57.77,12100.252,40.049,19.960,44.747,0.895,10.337,50.010,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.758530','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2117,2,NULL,NULL,'2026-06-04 18:52:38',400.26,400.97,399.42,78.06,60.89,51.17,12100.256,39.471,19.228,43.905,0.899,10.462,49.994,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.766587','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2118,2,NULL,NULL,'2026-06-04 18:57:38',399.56,401.32,398.59,64.58,64.66,61.34,12100.260,39.390,19.632,44.011,0.895,11.152,49.984,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.775024','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2119,2,NULL,NULL,'2026-06-04 19:02:38',399.30,401.82,399.86,61.27,62.59,60.40,12100.264,37.914,19.319,42.552,0.891,10.600,49.988,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.783330','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2120,2,NULL,NULL,'2026-06-04 19:07:38',400.65,400.77,399.19,62.53,71.55,55.86,12100.268,38.688,20.671,43.864,0.882,10.592,49.994,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.791169','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2121,2,NULL,NULL,'2026-06-04 19:12:38',399.71,401.55,399.81,57.18,60.88,63.24,12100.272,37.430,18.760,41.868,0.894,11.288,50.018,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.799081','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2122,2,NULL,NULL,'2026-06-04 19:17:38',399.11,400.94,399.41,59.60,71.68,64.24,12100.276,40.185,20.587,45.152,0.890,10.780,49.993,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.806153','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2123,2,NULL,NULL,'2026-06-04 19:22:38',399.17,401.63,399.15,79.80,71.38,52.55,12100.280,41.590,21.994,47.048,0.884,10.943,49.964,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.815358','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2124,2,NULL,NULL,'2026-06-04 19:27:38',400.17,400.68,398.07,63.47,55.02,62.28,12100.284,36.987,19.357,41.746,0.886,10.953,49.998,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.822049','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2125,2,NULL,NULL,'2026-06-04 19:32:38',399.66,401.86,399.91,72.84,67.96,54.97,12100.288,40.146,20.789,45.209,0.888,10.312,50.010,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.828875','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2126,2,NULL,NULL,'2026-06-04 19:37:38',400.35,401.92,398.16,63.56,70.72,49.26,12100.292,37.935,18.907,42.385,0.895,11.073,50.022,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.836948','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2127,2,NULL,NULL,'2026-06-04 19:42:38',399.57,401.88,399.54,71.38,56.70,49.24,12100.296,36.076,19.374,40.949,0.881,10.960,50.003,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.846483','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2128,2,NULL,NULL,'2026-06-04 19:47:38',399.13,400.88,399.73,66.99,59.13,50.66,12100.300,36.375,18.535,40.825,0.891,11.090,49.996,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.853765','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2129,2,NULL,NULL,'2026-06-04 19:52:38',399.66,400.70,399.65,67.31,56.07,57.06,12100.304,37.544,18.077,41.669,0.901,11.061,50.031,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.860498','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2130,2,NULL,NULL,'2026-06-04 19:57:38',399.67,401.16,399.10,64.39,67.95,55.66,12100.308,39.074,18.924,43.416,0.900,10.085,50.008,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.867636','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2131,2,NULL,NULL,'2026-06-04 20:02:38',400.33,401.55,399.11,67.53,64.17,51.25,12100.156,36.799,20.756,42.249,0.871,11.337,50.034,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.874697','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2132,2,NULL,NULL,'2026-06-04 20:07:38',400.00,401.92,398.85,79.05,63.35,60.11,12100.158,40.874,22.725,46.767,0.874,12.177,50.019,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.882688','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2133,2,NULL,NULL,'2026-06-04 20:12:38',399.98,400.68,398.97,58.44,53.24,67.27,12100.160,35.912,20.448,41.326,0.869,11.031,49.968,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.889752','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2134,2,NULL,NULL,'2026-06-04 20:17:38',399.95,401.15,399.11,57.79,73.32,55.15,12100.162,37.508,21.055,43.014,0.872,12.078,49.986,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.896817','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2135,2,NULL,NULL,'2026-06-04 20:22:38',400.62,401.28,399.79,71.98,63.69,58.82,12100.164,38.941,22.381,44.915,0.867,12.307,50.032,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.904627','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2136,2,NULL,NULL,'2026-06-04 20:27:38',399.35,400.82,399.93,74.54,64.00,53.49,12100.166,38.448,22.098,44.346,0.867,11.402,49.981,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.911662','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2137,2,NULL,NULL,'2026-06-04 20:32:38',399.33,401.87,399.09,67.82,72.46,67.73,12100.168,42.128,23.081,48.036,0.877,12.195,49.962,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.918024','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2138,2,NULL,NULL,'2026-06-04 20:37:38',399.30,400.34,399.94,72.60,72.44,55.00,12100.170,40.329,22.531,46.196,0.873,11.159,49.986,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.925487','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2139,2,NULL,NULL,'2026-06-04 20:42:38',399.11,400.24,399.17,73.96,73.47,56.20,12100.172,41.429,22.248,47.025,0.881,12.028,50.015,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.932954','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2140,2,NULL,NULL,'2026-06-04 20:47:38',399.59,401.86,398.76,77.50,63.28,63.87,12100.174,41.495,22.622,47.261,0.878,11.699,49.972,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.940815','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2141,2,NULL,NULL,'2026-06-04 20:52:38',399.01,401.73,398.48,80.00,73.52,62.06,12100.176,43.313,24.547,49.785,0.870,12.460,50.010,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.947437','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2142,2,NULL,NULL,'2026-06-04 20:57:38',399.35,401.56,398.70,61.58,61.74,55.62,12100.178,36.447,19.473,41.323,0.882,11.243,49.986,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.960221','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2143,2,NULL,NULL,'2026-06-04 21:02:38',400.03,401.88,398.38,62.61,64.17,64.28,12100.180,38.827,20.957,44.122,0.880,11.309,49.970,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.965902','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2144,2,NULL,NULL,'2026-06-04 21:07:38',399.84,400.46,398.42,79.48,69.74,67.34,12100.182,43.960,23.847,50.011,0.879,11.113,50.017,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.973309','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2145,2,NULL,NULL,'2026-06-04 21:12:38',399.42,401.87,398.10,79.05,57.96,56.43,12100.184,39.088,21.627,44.672,0.875,12.304,49.968,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.978989','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2146,2,NULL,NULL,'2026-06-04 21:17:38',400.29,400.38,399.48,79.25,70.77,51.17,12100.186,40.282,23.152,46.461,0.867,11.913,50.026,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.984435','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2147,2,NULL,NULL,'2026-06-04 21:22:38',399.44,401.20,399.39,57.59,54.78,55.12,12100.188,33.805,18.795,38.678,0.874,11.555,50.018,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.991757','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2148,2,NULL,NULL,'2026-06-04 21:27:38',399.35,401.32,398.74,57.51,64.81,59.17,12100.190,36.631,20.366,41.912,0.874,11.047,49.989,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:38.997846','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2149,2,NULL,NULL,'2026-06-04 21:32:38',399.97,401.10,399.31,72.97,55.48,60.89,12100.192,38.303,21.089,43.725,0.876,11.228,50.037,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.006595','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2150,2,NULL,NULL,'2026-06-04 21:37:38',399.22,401.02,398.76,63.48,74.45,66.94,12100.194,41.019,23.576,47.311,0.867,11.718,50.001,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.012093','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2151,2,NULL,NULL,'2026-06-04 21:42:38',400.52,400.06,399.90,61.76,70.06,50.90,12100.196,37.090,20.120,42.196,0.879,11.146,49.980,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.018124','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2152,2,NULL,NULL,'2026-06-04 21:47:38',399.47,401.67,399.97,58.31,59.06,51.70,12100.198,34.007,19.181,39.044,0.871,12.404,49.981,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.025459','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2153,2,NULL,NULL,'2026-06-04 21:52:38',400.68,401.65,399.98,73.43,58.51,52.30,12100.200,36.931,21.127,42.547,0.868,12.245,50.000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.030979','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2154,2,NULL,NULL,'2026-06-04 21:57:38',399.80,400.31,399.14,78.60,57.86,57.15,12100.202,39.122,21.646,44.711,0.875,11.040,50.023,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.038759','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2155,2,NULL,NULL,'2026-06-04 22:02:38',399.64,400.49,399.80,59.20,66.25,61.46,12100.204,37.811,20.818,43.163,0.876,12.284,50.011,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.044769','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2156,2,NULL,NULL,'2026-06-04 22:07:38',400.17,401.62,398.81,56.84,64.40,59.03,12100.206,36.551,19.927,41.630,0.878,11.787,49.995,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.050855','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2157,2,NULL,NULL,'2026-06-04 22:12:38',399.36,401.49,399.67,73.47,58.30,51.19,12100.208,37.266,19.911,42.252,0.882,12.139,49.986,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.059604','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2158,2,NULL,NULL,'2026-06-04 22:17:38',400.96,400.64,399.84,72.98,58.01,51.16,12100.210,36.933,20.135,42.065,0.878,12.425,49.993,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.065269','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2159,2,NULL,NULL,'2026-06-04 22:22:38',400.23,400.18,398.60,73.71,61.54,65.78,12100.212,40.900,21.964,46.425,0.881,11.268,50.034,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.074551','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2160,2,NULL,NULL,'2026-06-04 22:27:38',399.32,400.36,399.00,71.85,75.16,69.70,12100.214,43.640,24.498,50.046,0.872,12.288,49.964,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.080937','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2161,2,NULL,NULL,'2026-06-04 22:32:38',400.47,400.89,398.68,75.15,55.11,53.38,12100.216,37.150,20.454,42.409,0.876,12.352,49.999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.090163','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2162,2,NULL,NULL,'2026-06-04 22:37:38',399.23,401.17,399.99,71.06,65.04,67.56,12100.218,40.965,23.106,47.032,0.871,11.073,49.974,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.095588','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2163,2,NULL,NULL,'2026-06-04 22:42:38',399.95,401.38,398.67,70.82,64.60,66.14,12100.220,41.147,21.760,46.546,0.884,11.453,50.026,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.102394','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2164,2,NULL,NULL,'2026-06-04 22:47:38',399.59,400.34,398.62,64.18,60.91,66.44,12100.222,39.011,20.843,44.230,0.882,11.488,50.004,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.108926','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2165,2,NULL,NULL,'2026-06-04 22:52:38',399.68,401.78,398.32,77.61,54.07,63.60,12100.224,39.550,21.669,45.097,0.877,11.655,50.014,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.115754','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2166,2,NULL,NULL,'2026-06-04 22:57:38',400.49,401.97,399.22,58.84,66.98,65.82,12100.226,38.547,21.742,44.256,0.871,11.433,50.004,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.122964','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2167,2,NULL,NULL,'2026-06-04 23:02:38',400.28,400.14,398.11,79.26,63.81,61.70,12100.228,41.566,22.548,47.288,0.879,11.855,50.029,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.129140','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2168,2,NULL,NULL,'2026-06-04 23:07:38',400.56,401.23,399.77,65.99,60.62,60.28,12100.230,37.894,20.659,43.159,0.878,11.745,50.007,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.139131','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2169,2,NULL,NULL,'2026-06-04 23:12:38',400.91,400.71,399.00,68.13,75.24,58.34,12100.232,40.340,23.293,46.582,0.866,11.039,50.023,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.150465','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2170,2,NULL,NULL,'2026-06-04 23:17:38',399.72,401.50,399.33,59.46,63.71,70.45,12100.234,39.079,21.727,44.713,0.874,11.218,50.038,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.160032','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2171,2,NULL,NULL,'2026-06-04 23:22:38',400.92,400.16,399.37,66.92,60.05,55.15,12100.236,36.842,20.285,42.057,0.876,11.359,50.021,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.168547','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2172,2,NULL,NULL,'2026-06-04 23:27:38',400.61,401.03,398.82,65.36,55.57,59.87,12100.238,36.784,19.754,41.753,0.881,11.045,50.037,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.181679','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2173,2,NULL,NULL,'2026-06-04 23:32:38',399.84,400.55,398.60,57.43,72.25,51.06,12100.240,36.188,20.799,41.739,0.867,12.307,50.008,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.193142','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2174,2,NULL,NULL,'2026-06-04 23:37:38',399.29,400.41,398.42,76.72,53.00,60.94,12100.242,38.614,21.156,44.030,0.877,12.188,50.022,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.201147','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2175,2,NULL,NULL,'2026-06-04 23:42:38',400.77,400.26,398.83,71.70,66.88,52.90,12100.244,39.178,20.504,44.219,0.886,11.519,50.019,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.210379','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2176,2,NULL,NULL,'2026-06-04 23:47:38',400.01,401.72,398.60,79.80,61.59,49.88,12100.246,38.914,20.898,44.170,0.881,11.818,50.034,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.215907','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2177,2,NULL,NULL,'2026-06-04 23:52:38',400.83,401.47,398.95,79.52,69.97,68.28,12100.248,43.903,24.527,50.290,0.873,12.396,50.010,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.224810','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2178,2,NULL,NULL,'2026-06-04 23:57:38',399.67,401.57,398.13,59.16,53.50,66.58,12100.250,36.343,19.813,41.393,0.878,10.949,49.976,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.231914','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2179,2,NULL,NULL,'2026-06-05 00:02:38',399.69,401.92,399.10,77.58,53.44,60.77,12100.252,38.489,21.916,44.291,0.869,11.390,49.977,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.238970','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2180,2,NULL,NULL,'2026-06-05 00:07:38',400.51,400.09,399.52,69.28,56.06,51.80,12100.254,36.285,18.890,40.908,0.887,11.877,50.009,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.245647','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2181,2,NULL,NULL,'2026-06-05 00:12:38',400.21,401.77,399.11,59.08,59.80,53.09,12100.256,35.186,18.414,39.713,0.886,11.401,50.006,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.255798','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2182,2,NULL,NULL,'2026-06-05 00:17:38',400.09,400.14,399.20,78.96,57.07,52.50,12100.258,37.878,21.466,43.538,0.870,11.801,49.979,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.262456','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2183,2,NULL,NULL,'2026-06-05 00:22:38',400.49,400.94,398.73,59.82,61.01,56.84,12100.260,35.983,19.714,41.030,0.877,12.144,49.996,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.269936','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2184,2,NULL,NULL,'2026-06-05 00:27:38',399.80,400.60,398.71,71.88,57.80,53.08,12100.262,37.014,20.279,42.205,0.877,12.184,49.968,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.277287','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2185,2,NULL,NULL,'2026-06-05 00:32:38',399.61,400.78,399.57,60.77,63.63,66.61,12100.264,38.464,21.592,44.110,0.872,12.014,49.998,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.283401','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2186,2,NULL,NULL,'2026-06-05 00:37:38',400.36,401.63,399.95,69.92,63.41,62.97,12100.266,39.983,21.363,45.332,0.882,10.864,50.017,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.292441','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2187,2,NULL,NULL,'2026-06-05 00:42:38',400.42,401.18,398.62,74.44,73.30,54.13,12100.268,40.884,22.400,46.618,0.877,11.842,49.989,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.298487','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2188,2,NULL,NULL,'2026-06-05 00:47:38',400.76,401.65,398.68,66.32,63.34,50.55,12100.270,36.914,19.217,41.617,0.887,11.745,50.039,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.307961','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2189,2,NULL,NULL,'2026-06-05 00:52:38',399.32,401.58,398.95,77.77,59.55,67.31,12100.272,41.821,22.002,47.255,0.885,11.552,50.012,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.314951','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2190,2,NULL,NULL,'2026-06-05 00:57:38',400.01,400.09,398.48,62.37,71.75,57.21,12100.274,39.103,20.572,44.184,0.885,11.006,50.014,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.322483','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2191,2,NULL,NULL,'2026-06-05 01:02:38',399.02,400.07,399.29,64.23,66.68,50.16,12100.276,37.048,19.389,41.815,0.886,11.303,49.976,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.329518','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2192,2,NULL,NULL,'2026-06-05 01:07:38',400.15,400.98,398.22,64.90,69.39,61.05,12100.278,39.336,22.082,45.110,0.872,11.629,50.033,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.337639','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2193,2,NULL,NULL,'2026-06-05 01:12:38',400.74,400.24,398.91,69.00,53.85,63.78,12100.280,37.798,20.709,43.099,0.877,11.370,49.998,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.347108','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2194,2,NULL,NULL,'2026-06-05 01:17:38',399.12,401.84,399.81,60.57,74.53,53.43,12100.282,38.226,20.840,43.538,0.878,12.152,49.999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.354431','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2195,2,NULL,NULL,'2026-06-05 01:22:38',399.45,401.60,399.28,58.42,74.49,58.94,12100.284,38.678,21.608,44.305,0.873,11.272,50.036,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.362317','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2196,2,NULL,NULL,'2026-06-05 01:27:38',399.26,400.83,399.98,65.26,66.01,65.90,12100.286,39.796,22.126,45.533,0.874,10.996,49.977,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.368601','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2197,2,NULL,NULL,'2026-06-05 01:32:38',399.45,400.32,399.93,58.31,57.11,64.16,12100.288,36.702,19.309,41.471,0.885,10.823,49.963,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.378656','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2198,2,NULL,NULL,'2026-06-05 01:37:38',400.06,401.27,398.05,76.81,57.57,60.55,12100.290,39.929,20.787,45.016,0.887,11.377,49.992,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.384491','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2199,2,NULL,NULL,'2026-06-05 01:42:38',399.27,400.10,399.20,79.37,58.16,56.52,12100.292,38.987,22.095,44.813,0.870,11.405,49.986,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.393568','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2200,2,NULL,NULL,'2026-06-05 01:47:38',399.82,400.14,398.99,79.12,69.87,68.88,12100.294,43.873,24.629,50.313,0.872,12.176,50.031,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.400443','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2201,2,NULL,NULL,'2026-06-05 01:52:38',400.47,400.47,398.31,62.91,69.20,65.46,12100.296,39.968,22.006,45.626,0.876,11.984,50.004,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.410362','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2202,2,NULL,NULL,'2026-06-05 01:57:38',399.12,400.91,399.29,70.13,68.05,62.58,12100.298,40.660,22.277,46.363,0.877,11.366,50.009,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.418917','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2203,2,NULL,NULL,'2026-06-05 02:02:38',400.82,400.56,399.13,57.43,63.62,53.80,12100.300,35.170,19.837,40.379,0.871,11.486,50.026,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.427563','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2204,2,NULL,NULL,'2026-06-05 02:07:38',399.27,401.11,399.71,70.81,62.49,56.29,12100.302,38.178,21.432,43.782,0.872,11.156,50.017,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.436276','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2205,2,NULL,NULL,'2026-06-05 02:12:38',399.83,401.23,398.97,64.04,68.73,60.28,12100.304,39.410,20.841,44.581,0.884,10.922,49.977,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.445651','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2206,2,NULL,NULL,'2026-06-05 02:17:38',399.41,400.31,399.43,66.73,68.64,52.70,12100.306,38.567,19.972,43.431,0.888,11.121,49.972,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.453116','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2207,2,NULL,NULL,'2026-06-05 02:22:38',400.99,400.79,398.03,73.06,53.59,51.78,12100.308,35.972,20.097,41.205,0.873,11.655,50.004,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.460650','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2208,2,NULL,NULL,'2026-06-05 02:27:38',400.35,401.06,398.88,66.87,73.44,53.25,12100.310,39.201,21.477,44.699,0.877,12.021,49.962,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.466466','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2209,2,NULL,NULL,'2026-06-05 02:32:38',399.03,400.66,398.73,60.84,63.44,65.51,12100.312,38.482,20.979,43.829,0.878,11.982,49.963,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.475073','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2210,2,NULL,NULL,'2026-06-05 02:37:38',400.77,401.65,399.25,64.32,63.58,56.98,12100.314,37.230,20.899,42.695,0.872,11.732,49.974,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.481498','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2211,2,NULL,NULL,'2026-06-05 02:42:38',399.68,401.44,399.48,64.47,68.58,58.40,12100.316,39.039,20.752,44.212,0.883,11.163,49.979,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.490463','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2212,2,NULL,NULL,'2026-06-05 02:47:38',400.69,400.99,399.27,56.58,72.98,56.70,12100.318,37.508,21.055,43.014,0.872,12.175,49.984,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.496244','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2213,2,NULL,NULL,'2026-06-05 02:52:38',400.75,401.11,399.97,57.43,59.36,55.45,12100.320,35.162,18.595,39.776,0.884,11.091,49.972,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.502801','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2214,2,NULL,NULL,'2026-06-05 02:57:38',399.28,401.60,398.74,69.23,72.84,65.78,12100.322,42.432,22.439,48.000,0.884,11.536,50.036,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.510284','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2215,2,NULL,NULL,'2026-06-05 03:02:38',399.52,401.27,398.56,60.33,67.03,62.09,12100.324,38.325,21.101,43.750,0.876,11.447,50.035,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.518250','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2216,2,NULL,NULL,'2026-06-05 03:07:38',400.19,400.15,399.94,57.93,67.53,49.22,12100.326,35.660,18.858,40.339,0.884,11.250,49.961,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.527656','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2217,2,NULL,NULL,'2026-06-05 03:12:38',400.04,400.07,399.70,56.84,57.49,69.82,12100.328,37.338,20.356,42.526,0.878,11.345,50.008,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.533061','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2218,2,NULL,NULL,'2026-06-05 03:17:38',399.34,400.98,398.67,58.72,69.54,56.55,12100.330,37.643,20.113,42.679,0.882,11.235,50.035,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.540762','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2219,2,NULL,NULL,'2026-06-05 03:22:38',399.45,400.41,399.98,67.50,61.16,58.80,12100.332,37.620,21.421,43.291,0.869,11.097,50.028,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.546482','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2220,2,NULL,NULL,'2026-06-05 03:27:38',400.23,401.31,399.29,58.04,55.50,57.35,12100.334,35.005,18.223,39.464,0.887,11.608,50.032,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.553316','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2221,2,NULL,NULL,'2026-06-05 03:32:38',400.66,400.06,399.63,67.82,60.13,53.12,12100.336,36.421,20.543,41.815,0.871,11.221,50.036,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.560308','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2222,2,NULL,NULL,'2026-06-05 03:37:38',399.94,401.37,399.47,78.07,52.78,56.33,12100.338,38.255,20.126,43.226,0.885,12.252,49.997,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.566358','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2223,2,NULL,NULL,'2026-06-05 03:42:38',400.64,401.34,399.63,70.74,54.09,60.29,12100.340,37.663,20.226,42.750,0.881,11.289,49.985,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.574558','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2224,2,NULL,NULL,'2026-06-05 03:47:38',400.01,400.83,399.30,64.49,58.07,52.32,12100.342,35.862,18.571,40.385,0.888,12.159,49.999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.581287','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2225,2,NULL,NULL,'2026-06-05 03:52:38',399.96,401.51,398.61,80.11,64.90,64.58,12100.344,42.980,22.257,48.401,0.888,12.183,50.015,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.589177','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2226,2,NULL,NULL,'2026-06-05 03:57:38',400.29,401.29,398.12,78.85,65.84,50.71,12100.346,40.025,20.837,45.124,0.887,11.000,50.020,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.596924','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2227,2,NULL,NULL,'2026-06-05 04:02:38',400.93,400.66,398.71,70.67,71.75,56.86,12100.348,40.820,21.251,46.020,0.887,10.870,49.965,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.605922','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2228,2,NULL,NULL,'2026-06-05 04:07:38',400.94,400.99,399.22,62.23,58.39,59.79,12100.350,36.663,19.789,41.663,0.880,11.715,50.036,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.613965','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2229,2,NULL,NULL,'2026-06-05 04:12:38',399.92,400.51,398.47,72.45,74.10,63.18,12100.352,42.476,23.272,48.433,0.877,11.136,50.002,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.621740','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2230,2,NULL,NULL,'2026-06-05 04:17:38',399.46,400.35,398.09,66.03,56.10,60.59,12100.354,36.753,20.730,42.196,0.871,11.455,49.970,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.630182','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2231,2,NULL,NULL,'2026-06-05 04:22:38',400.94,400.60,398.77,59.81,58.13,64.97,12100.356,37.340,19.747,42.240,0.884,11.417,49.974,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.637706','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2232,2,NULL,NULL,'2026-06-05 04:27:38',399.40,400.57,398.30,78.16,61.33,53.00,12100.358,38.674,21.918,44.453,0.870,11.372,50.011,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.644962','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2233,2,NULL,NULL,'2026-06-05 04:32:38',399.52,401.53,398.93,73.56,54.96,56.89,12100.360,37.380,20.883,42.818,0.873,11.286,50.017,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.652660','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2234,2,NULL,NULL,'2026-06-05 04:37:38',399.76,401.32,399.83,66.97,57.60,65.12,12100.362,38.856,20.228,43.806,0.887,11.733,50.027,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.661906','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2235,2,NULL,NULL,'2026-06-05 04:42:38',399.66,401.67,398.18,56.22,72.81,56.87,12100.364,37.865,20.231,42.931,0.882,12.007,49.983,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.670229','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2236,2,NULL,NULL,'2026-06-05 04:47:38',400.85,400.25,398.32,58.89,65.71,59.74,12100.366,37.079,20.914,42.571,0.871,11.795,50.011,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.678617','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2237,2,NULL,NULL,'2026-06-05 04:52:38',400.98,401.17,399.83,73.30,55.24,58.90,12100.368,38.135,20.479,43.286,0.881,11.740,50.010,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.685510','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2238,2,NULL,NULL,'2026-06-05 04:57:38',399.00,400.52,398.44,77.44,54.36,65.40,12100.370,40.303,21.203,45.540,0.885,11.796,49.992,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.697664','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2239,2,NULL,NULL,'2026-06-05 05:02:38',400.86,400.89,398.31,68.12,58.83,67.85,12100.372,39.543,21.450,44.986,0.879,11.570,49.993,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.704169','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2240,2,NULL,NULL,'2026-06-05 05:07:38',400.19,401.16,398.97,67.77,72.35,67.33,12100.374,41.871,23.279,47.907,0.874,11.535,50.004,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.711988','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2241,2,NULL,NULL,'2026-06-05 05:12:38',400.63,401.66,398.27,70.71,64.79,67.35,12100.376,40.708,23.179,46.845,0.869,11.793,49.964,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.718551','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2242,2,NULL,NULL,'2026-06-05 05:17:38',400.65,401.87,399.23,70.41,63.35,61.38,12100.378,39.251,22.139,45.064,0.871,11.472,50.016,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.726464','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2243,2,NULL,NULL,'2026-06-05 05:22:38',399.83,400.33,399.49,65.66,60.07,58.58,12100.380,37.669,19.817,42.564,0.885,10.850,50.039,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.732754','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2244,2,NULL,NULL,'2026-06-05 05:27:38',400.96,400.99,398.83,60.24,66.60,60.33,12100.382,37.994,20.610,43.224,0.879,12.086,50.003,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.742565','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2245,2,NULL,NULL,'2026-06-05 05:32:38',399.90,400.14,398.65,73.83,55.79,60.09,12100.384,38.290,21.288,43.810,0.874,11.546,49.968,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.751197','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2246,2,NULL,NULL,'2026-06-05 05:37:38',400.58,401.30,398.95,57.98,74.15,58.52,12100.386,38.744,20.912,44.027,0.880,11.759,50.018,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.759511','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2247,2,NULL,NULL,'2026-06-05 05:42:38',399.50,400.40,398.19,63.97,61.28,68.72,12100.388,39.240,21.605,44.795,0.876,11.839,49.987,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.765286','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2248,2,NULL,NULL,'2026-06-05 05:47:38',399.49,400.94,399.64,64.90,56.07,63.44,12100.390,37.561,20.069,42.586,0.882,12.321,49.986,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.772585','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2249,2,NULL,NULL,'2026-06-05 05:52:38',399.85,401.41,398.10,76.03,56.25,56.38,12100.392,38.427,20.531,43.568,0.882,11.181,50.008,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.778648','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2250,2,NULL,NULL,'2026-06-05 05:57:38',400.98,400.95,398.45,59.99,72.41,66.66,12100.394,40.637,21.490,45.969,0.884,10.856,49.999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.785282','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2251,2,NULL,NULL,'2026-06-05 06:02:38',400.30,401.62,399.04,66.67,71.00,63.92,12100.594,41.433,21.227,46.554,0.890,11.340,50.010,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.794783','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2252,2,NULL,NULL,'2026-06-05 06:07:38',399.44,401.76,399.45,80.13,74.00,63.94,12100.597,44.316,23.919,50.359,0.880,10.493,49.969,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.801079','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2253,2,NULL,NULL,'2026-06-05 06:12:38',400.17,401.52,399.50,70.72,52.68,53.74,12100.600,36.203,19.046,40.907,0.885,11.735,50.016,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.808598','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2254,2,NULL,NULL,'2026-06-05 06:17:38',399.52,401.67,398.11,56.36,63.80,57.49,12100.603,36.595,18.545,41.026,0.892,11.326,50.030,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.817457','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2255,2,NULL,NULL,'2026-06-05 06:22:38',399.79,401.49,399.53,66.65,54.16,49.85,12100.606,34.642,18.792,39.411,0.879,10.836,50.027,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.825982','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2256,2,NULL,NULL,'2026-06-05 06:27:38',399.51,401.54,398.63,78.56,65.55,50.12,12100.609,39.831,20.626,44.855,0.888,11.581,50.028,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.835741','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2257,2,NULL,NULL,'2026-06-05 06:32:38',400.66,400.43,398.02,68.27,62.31,62.17,12100.612,39.304,20.893,44.512,0.883,11.576,49.982,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.842493','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2258,2,NULL,NULL,'2026-06-05 06:37:38',400.57,401.24,398.17,73.44,71.16,68.34,12100.615,43.913,22.131,49.175,0.893,11.289,49.998,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.848279','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2259,2,NULL,NULL,'2026-06-05 06:42:38',399.63,401.96,399.49,80.19,60.14,63.62,12100.618,41.541,22.195,47.099,0.882,10.676,50.022,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.855308','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2260,2,NULL,NULL,'2026-06-05 06:47:38',400.77,401.47,398.71,64.12,68.71,59.94,12100.621,39.086,21.309,44.517,0.878,11.025,49.969,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.861873','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2261,2,NULL,NULL,'2026-06-05 06:52:38',399.70,400.69,399.41,64.89,61.06,65.27,12100.624,39.169,20.391,44.159,0.887,10.432,50.004,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.868235','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2262,2,NULL,NULL,'2026-06-05 06:57:38',399.07,401.29,399.80,70.53,70.54,51.56,12100.627,39.324,20.796,44.484,0.884,11.252,49.998,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.875594','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2263,2,NULL,NULL,'2026-06-05 07:02:38',400.32,401.54,399.06,60.51,67.31,62.92,12100.630,39.071,20.340,44.048,0.887,10.636,49.977,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.882303','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2264,2,NULL,NULL,'2026-06-05 07:07:38',400.86,400.98,399.29,61.78,59.94,68.22,12100.633,38.644,20.753,43.864,0.881,10.322,50.032,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.889165','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2265,2,NULL,NULL,'2026-06-05 07:12:38',400.29,400.06,399.49,66.32,64.35,55.29,12100.636,38.049,19.913,42.945,0.886,10.344,49.968,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.896655','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2266,2,NULL,NULL,'2026-06-05 07:17:38',399.48,400.92,398.72,76.94,63.52,66.48,12100.639,42.007,22.787,47.790,0.879,10.917,49.969,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.903410','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2267,2,NULL,NULL,'2026-06-05 07:22:38',399.82,400.91,398.04,69.52,61.97,57.23,12100.642,38.875,19.701,43.582,0.892,11.413,49.973,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.912658','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2268,2,NULL,NULL,'2026-06-05 07:27:38',400.86,400.63,398.06,71.02,52.54,52.27,12100.645,36.301,18.194,40.605,0.894,10.884,50.029,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.922009','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2269,2,NULL,NULL,'2026-06-05 07:32:38',399.97,401.93,399.36,72.96,54.48,56.25,12100.864,37.415,19.991,42.421,0.882,11.288,50.026,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.928795','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2270,2,NULL,NULL,'2026-06-05 07:37:38',399.12,400.95,398.25,64.86,72.73,55.22,12100.868,39.940,19.682,44.526,0.897,10.439,49.986,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.936277','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2271,2,NULL,NULL,'2026-06-05 07:42:38',399.54,400.66,399.14,74.32,74.46,59.92,12100.872,43.039,21.691,48.196,0.893,11.338,50.030,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.944185','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2272,2,NULL,NULL,'2026-06-05 07:47:38',400.45,401.37,399.59,70.91,66.43,52.90,12100.876,38.705,20.785,43.933,0.881,9.950,49.969,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.949607','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2273,2,NULL,NULL,'2026-06-05 07:52:38',400.96,400.80,399.08,56.76,68.36,56.18,12100.880,36.886,19.809,41.868,0.881,10.254,49.994,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.956804','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2274,2,NULL,NULL,'2026-06-05 07:57:38',399.65,401.44,398.64,69.17,70.22,53.67,12100.884,39.412,20.842,44.584,0.884,10.692,50.023,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.963393','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2275,2,NULL,NULL,'2026-06-05 08:02:38',399.56,400.43,398.32,73.49,75.52,67.07,12101.110,44.710,22.158,49.900,0.896,9.601,50.019,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.972924','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2276,2,NULL,NULL,'2026-06-05 08:07:38',400.68,401.09,399.86,59.11,57.16,62.25,12101.115,37.021,18.139,41.226,0.898,10.820,50.025,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.979546','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2277,2,NULL,NULL,'2026-06-05 08:12:38',399.24,401.95,399.26,65.82,58.06,70.34,12101.120,40.591,19.081,44.852,0.905,10.590,49.994,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.985807','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2278,2,NULL,NULL,'2026-06-05 08:17:38',399.90,400.67,398.38,59.82,73.08,70.21,12101.125,42.449,19.954,46.905,0.905,10.557,50.021,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:39.993010','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2279,2,NULL,NULL,'2026-06-05 08:22:38',400.25,401.40,399.15,60.21,75.28,57.91,12101.130,39.839,20.189,44.663,0.892,10.552,50.024,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.001986','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2280,2,NULL,NULL,'2026-06-05 08:27:38',400.82,400.76,399.15,56.92,53.10,70.63,12101.135,37.338,18.609,41.718,0.895,9.407,50.032,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.010226','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2281,2,NULL,NULL,'2026-06-05 08:32:38',400.42,400.84,399.08,77.32,62.32,59.84,12101.140,41.184,20.641,46.067,0.894,9.739,49.962,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.017593','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2282,2,NULL,NULL,'2026-06-05 08:37:38',399.05,400.96,399.75,60.24,62.53,62.86,12101.145,38.581,18.686,42.868,0.900,9.720,50.039,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.025882','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2283,2,NULL,NULL,'2026-06-05 08:42:38',399.11,401.74,399.14,76.65,60.99,55.41,12101.150,40.034,19.616,44.581,0.898,10.251,49.976,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.035864','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2284,2,NULL,NULL,'2026-06-05 08:47:38',400.70,400.65,399.56,63.82,70.53,69.29,12101.155,42.183,20.787,47.027,0.897,9.337,50.013,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.046448','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2285,2,NULL,NULL,'2026-06-05 08:52:38',400.45,401.17,398.40,63.12,68.90,63.47,12101.160,40.902,19.109,45.146,0.906,10.584,49.980,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.053636','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2286,2,NULL,NULL,'2026-06-05 08:57:38',400.66,401.60,399.72,59.84,72.07,65.44,12101.165,41.200,19.485,45.575,0.904,9.742,49.986,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.061864','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2287,2,NULL,NULL,'2026-06-05 09:02:38',399.30,401.56,398.68,60.85,70.56,55.65,12101.170,38.619,19.356,43.198,0.894,10.437,50.027,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.068893','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2288,2,NULL,NULL,'2026-06-05 09:07:38',399.87,400.63,398.95,59.19,71.02,62.20,12101.175,39.990,19.368,44.433,0.900,10.410,49.981,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.078653','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2289,2,NULL,NULL,'2026-06-05 09:12:38',400.93,400.35,399.31,70.36,56.54,51.18,12101.180,36.765,18.426,41.124,0.894,9.703,50.040,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.086436','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2290,2,NULL,NULL,'2026-06-05 09:17:38',400.25,400.34,399.61,78.53,61.11,51.00,12101.185,39.887,18.635,44.025,0.906,9.236,49.979,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.093375','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2291,2,NULL,NULL,'2026-06-05 09:22:38',399.75,401.31,399.53,62.95,57.50,53.70,12101.190,35.994,17.939,40.217,0.895,9.310,49.976,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.099808','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2292,2,NULL,NULL,'2026-06-05 09:27:38',399.60,401.98,399.47,65.27,59.79,58.28,12101.195,37.809,19.055,42.339,0.893,9.650,49.965,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.107690','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2293,2,NULL,NULL,'2026-06-05 09:32:38',400.09,400.59,399.20,59.43,63.75,70.72,12101.200,40.524,19.049,44.778,0.905,9.647,50.000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.117860','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2294,2,NULL,NULL,'2026-06-05 09:37:38',400.97,400.72,398.28,68.31,65.74,56.52,12101.205,39.740,18.908,44.009,0.903,9.210,50.038,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.126262','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2295,2,NULL,NULL,'2026-06-05 09:42:38',400.83,400.24,399.09,79.44,71.37,53.49,12101.210,42.745,19.970,47.180,0.906,10.015,49.960,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.132430','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2296,2,NULL,NULL,'2026-06-05 09:47:38',400.66,401.73,398.01,68.81,54.07,65.30,12101.215,38.938,19.298,43.458,0.896,9.955,50.038,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.139180','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2297,2,NULL,NULL,'2026-06-05 09:52:38',399.44,400.70,399.79,68.48,60.83,54.66,12101.220,38.109,18.780,42.485,0.897,9.506,50.001,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.145928','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2298,2,NULL,NULL,'2026-06-05 09:57:38',400.11,401.24,398.65,60.10,55.45,51.60,12101.225,34.740,16.825,38.600,0.900,9.500,49.968,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.153398','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2299,2,NULL,NULL,'2026-06-05 10:02:38',400.16,400.05,398.79,59.93,64.41,50.89,12101.230,36.460,17.555,40.466,0.901,9.754,49.963,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.161071','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2300,2,NULL,NULL,'2026-06-05 10:07:38',399.30,400.11,399.50,76.28,74.49,54.87,12101.235,42.598,20.992,47.489,0.897,9.317,50.026,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.168294','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2301,2,NULL,NULL,'2026-06-05 10:12:38',400.31,400.86,399.70,66.68,62.69,68.15,12101.240,41.326,19.307,45.614,0.906,10.366,50.032,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.176365','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2302,2,NULL,NULL,'2026-06-05 10:17:38',400.12,400.56,398.23,57.17,67.59,51.52,12101.245,36.231,18.562,40.709,0.890,9.861,50.024,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.183076','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2303,2,NULL,NULL,'2026-06-05 10:22:38',400.52,401.53,399.70,69.66,64.41,68.34,12101.250,42.209,20.083,46.743,0.903,10.480,49.971,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.190247','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2304,2,NULL,NULL,'2026-06-05 10:27:38',400.48,400.60,399.80,77.20,69.10,70.35,12101.255,45.129,21.601,50.032,0.902,9.573,50.016,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.197944','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2305,2,NULL,NULL,'2026-06-05 10:32:38',399.79,401.80,398.84,73.70,69.20,58.51,12101.260,41.768,20.465,46.512,0.898,10.189,50.008,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.205420','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2306,2,NULL,NULL,'2026-06-05 10:37:38',399.42,400.63,398.73,79.68,66.13,49.88,12101.265,40.265,20.517,45.191,0.891,10.431,49.989,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.213556','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2307,2,NULL,NULL,'2026-06-05 10:42:38',400.00,400.57,399.68,65.08,71.10,68.63,12101.270,42.899,19.919,47.298,0.907,9.872,50.004,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.221107','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2308,2,NULL,NULL,'2026-06-05 10:47:38',399.35,400.77,399.19,57.52,67.72,51.19,12101.275,36.914,17.246,40.744,0.906,10.045,50.037,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.229858','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2309,2,NULL,NULL,'2026-06-05 10:52:38',400.10,401.78,399.87,67.41,54.86,51.12,12101.280,35.917,17.699,40.041,0.897,10.663,49.973,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.237665','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2310,2,NULL,NULL,'2026-06-05 10:57:38',400.05,400.39,399.41,59.05,61.81,62.64,12101.285,37.927,18.903,42.377,0.895,9.973,49.969,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.244996','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2311,2,NULL,NULL,'2026-06-05 11:02:38',400.24,400.89,398.01,77.67,66.52,57.00,12101.290,41.908,20.059,46.461,0.902,9.235,50.038,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.252387','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2312,2,NULL,NULL,'2026-06-05 11:07:38',399.84,400.35,398.37,79.68,70.99,51.04,12101.295,41.411,21.330,46.582,0.889,9.626,49.996,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.261308','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2313,2,NULL,NULL,'2026-06-05 11:12:38',400.84,401.69,398.70,56.15,71.45,50.70,12101.300,37.017,18.033,41.176,0.899,10.483,49.993,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.269140','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2314,2,NULL,NULL,'2026-06-05 11:17:38',400.36,400.86,399.25,77.25,56.65,55.07,12101.305,39.363,18.841,43.640,0.902,9.592,49.974,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.277084','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2315,2,NULL,NULL,'2026-06-05 11:22:38',400.74,401.11,398.65,75.71,58.45,67.58,12101.310,42.209,19.720,46.588,0.906,9.732,50.013,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.283879','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2316,2,NULL,NULL,'2026-06-05 11:27:38',399.29,401.54,398.94,67.45,71.71,65.20,12101.315,41.955,21.610,47.193,0.889,9.493,49.970,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.290845','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2317,2,NULL,NULL,'2026-06-05 11:32:38',400.37,401.76,399.95,60.65,70.39,55.39,12101.320,38.834,18.588,43.053,0.902,9.409,49.973,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.300445','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2318,2,NULL,NULL,'2026-06-05 11:37:38',400.07,401.79,398.26,58.22,67.28,68.87,12101.325,40.084,20.202,44.887,0.893,9.780,50.003,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.307848','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2319,2,NULL,NULL,'2026-06-05 11:42:38',399.13,400.41,398.83,71.07,61.60,51.42,12101.064,37.666,19.712,42.512,0.886,9.358,50.033,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.315242','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2320,2,NULL,NULL,'2026-06-05 11:47:38',401.00,401.75,398.76,63.77,60.04,63.40,12101.068,38.564,19.543,43.233,0.892,9.778,49.982,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.322041','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2321,2,NULL,NULL,'2026-06-05 11:52:38',400.93,400.92,398.01,63.20,65.06,66.90,12101.072,40.742,19.268,45.069,0.904,10.394,50.001,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.329737','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2322,2,NULL,NULL,'2026-06-05 11:57:38',400.77,400.75,398.94,66.98,71.70,66.39,12101.076,42.764,20.347,47.358,0.903,9.701,50.036,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.336613','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2323,2,NULL,NULL,'2026-06-05 12:02:38',400.17,400.10,399.49,67.41,75.34,60.72,12100.540,40.833,23.250,46.988,0.869,11.652,50.018,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.343591','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2324,2,NULL,NULL,'2026-06-05 12:07:38',399.32,401.62,398.70,72.66,72.10,53.24,12100.542,39.918,22.301,45.725,0.873,12.315,50.009,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.349682','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2325,2,NULL,NULL,'2026-06-05 12:12:38',399.23,400.15,398.90,65.08,60.35,61.44,12100.544,37.501,21.353,43.154,0.869,12.056,50.014,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.364569','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2326,2,NULL,NULL,'2026-06-05 12:17:38',399.51,400.23,399.51,75.53,60.28,55.04,12100.546,38.961,20.604,44.074,0.884,11.601,49.993,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.371321','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2327,2,NULL,NULL,'2026-06-05 12:22:38',399.55,400.48,398.96,64.01,72.58,56.79,12100.548,39.120,21.539,44.658,0.876,11.507,50.008,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.380235','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2328,2,NULL,NULL,'2026-06-05 12:27:38',400.65,400.67,398.09,59.18,67.34,66.60,12100.550,39.291,21.100,44.598,0.881,12.291,50.020,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.386610','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2329,2,NULL,NULL,'2026-06-05 12:32:38',400.81,400.73,398.66,58.02,53.53,69.73,12100.552,36.840,19.884,41.864,0.880,10.917,49.976,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.396478','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2330,2,NULL,NULL,'2026-06-05 12:37:38',400.37,401.06,399.17,70.81,57.64,55.13,12100.554,37.435,19.899,42.395,0.883,11.036,49.993,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.403403','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2331,2,NULL,NULL,'2026-06-05 12:42:38',400.68,401.12,399.43,72.91,68.12,55.55,12100.556,40.222,21.050,45.397,0.886,12.319,49.998,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.411333','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2332,2,NULL,NULL,'2026-06-05 12:47:38',400.94,401.04,398.08,66.33,58.87,51.20,12100.558,35.359,20.228,40.736,0.868,11.588,49.990,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.417933','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2333,2,NULL,NULL,'2026-06-05 12:52:38',400.61,400.19,398.45,71.17,72.53,59.18,12100.560,41.323,22.079,46.851,0.882,12.249,50.020,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.426385','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2334,2,NULL,NULL,'2026-06-05 12:57:38',400.84,401.03,398.55,72.91,55.15,59.52,12100.562,37.687,21.358,43.318,0.870,12.226,49.963,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.433888','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2335,2,NULL,NULL,'2026-06-05 13:02:38',400.99,400.10,399.26,56.78,70.32,65.32,12101.410,39.726,19.910,44.436,0.894,10.714,49.982,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.442135','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2336,2,NULL,NULL,'2026-06-05 13:07:38',399.78,400.55,398.77,65.80,71.15,66.94,12101.415,41.906,21.469,47.085,0.890,10.196,49.982,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.450136','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2337,2,NULL,NULL,'2026-06-05 13:12:38',399.05,400.34,399.59,72.30,73.54,60.96,12101.420,43.077,20.619,47.757,0.902,10.616,50.005,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.459723','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2338,2,NULL,NULL,'2026-06-05 13:17:38',399.71,401.48,399.37,79.72,58.48,57.11,12101.425,40.323,20.210,45.104,0.894,9.401,49.999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.467258','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2339,2,NULL,NULL,'2026-06-05 13:22:38',400.84,401.32,399.74,57.00,56.02,62.52,12101.430,36.363,17.919,40.538,0.897,10.221,50.023,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.475961','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2340,2,NULL,NULL,'2026-06-05 13:27:38',399.34,401.67,398.97,71.00,58.55,58.89,12101.435,39.209,18.879,43.517,0.901,9.344,50.008,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.483339','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2341,3,NULL,NULL,'2026-06-04 13:32:41',399.58,401.59,399.74,109.73,117.46,92.91,12150.000,66.530,32.222,73.922,0.900,10.151,49.988,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.542789','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2342,3,NULL,NULL,'2026-06-04 13:37:41',400.51,400.44,399.32,138.10,101.36,95.55,12150.005,69.861,33.239,77.365,0.903,10.350,49.982,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.579599','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2343,3,NULL,NULL,'2026-06-04 13:42:41',399.90,401.21,399.22,117.34,117.43,110.96,12150.010,70.978,36.559,79.840,0.889,10.357,50.021,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.592622','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2344,3,NULL,NULL,'2026-06-04 13:47:41',400.96,401.76,398.84,109.78,114.37,116.79,12150.015,70.152,35.745,78.734,0.891,9.827,49.980,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.601438','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2345,3,NULL,NULL,'2026-06-04 13:52:41',399.61,400.48,398.22,108.95,132.83,90.09,12150.020,69.436,32.440,76.640,0.906,10.081,50.028,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.610993','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2346,3,NULL,NULL,'2026-06-04 13:57:41',400.77,401.16,398.26,116.91,132.86,107.45,12150.025,74.327,35.787,82.494,0.901,9.649,50.003,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.620772','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2347,3,NULL,NULL,'2026-06-04 14:02:41',400.56,400.92,398.85,127.80,129.10,99.19,12150.030,74.256,35.330,82.233,0.903,9.770,49.976,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.631463','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2348,3,NULL,NULL,'2026-06-04 14:07:41',400.22,400.85,399.28,136.54,114.91,124.82,12150.035,78.812,36.593,86.893,0.907,10.410,50.035,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.640396','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2349,3,NULL,NULL,'2026-06-04 14:12:41',399.13,401.62,399.03,109.05,107.62,125.63,12150.040,70.432,35.888,79.048,0.891,10.035,50.002,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.648832','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2350,3,NULL,NULL,'2026-06-04 14:17:41',399.11,400.58,399.16,136.61,112.83,114.84,12150.045,76.048,35.966,84.124,0.904,10.342,50.004,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.659419','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2351,3,NULL,NULL,'2026-06-04 14:22:41',399.08,400.94,398.47,102.85,110.11,115.33,12150.050,68.687,32.090,75.813,0.906,9.379,49.964,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.669734','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2352,3,NULL,NULL,'2026-06-04 14:27:41',400.30,401.44,398.73,114.20,121.40,99.47,12150.055,69.486,34.046,77.379,0.898,9.423,50.011,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.679070','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2353,3,NULL,NULL,'2026-06-04 14:32:41',399.52,401.55,398.98,119.21,113.77,88.79,12150.060,66.134,33.881,74.308,0.890,9.286,49.974,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.688747','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2354,3,NULL,NULL,'2026-06-04 14:37:41',399.07,400.89,399.49,126.62,101.05,124.82,12150.065,73.343,35.314,81.402,0.901,10.459,50.035,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.696133','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2355,3,NULL,NULL,'2026-06-04 14:42:41',399.17,400.86,398.79,109.63,110.39,98.53,12150.070,66.722,30.980,73.563,0.907,10.148,50.033,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.704303','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2356,3,NULL,NULL,'2026-06-04 14:47:41',399.56,401.34,398.76,105.48,133.70,103.45,12150.075,70.896,35.136,79.125,0.896,10.153,50.007,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.714687','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2357,3,NULL,NULL,'2026-06-04 14:52:41',399.90,400.84,399.20,102.67,104.59,89.93,12150.080,62.111,29.196,68.631,0.905,9.210,49.971,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.727380','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2358,3,NULL,NULL,'2026-06-04 14:57:41',399.97,400.29,399.46,118.80,101.30,108.37,12150.085,67.587,34.439,75.855,0.891,10.060,50.040,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.735612','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2359,3,NULL,NULL,'2026-06-04 15:02:41',399.64,401.56,399.65,103.02,131.57,100.04,12150.090,69.009,34.779,77.278,0.893,9.433,49.997,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.745824','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2360,3,NULL,NULL,'2026-06-04 15:07:41',400.31,401.76,398.04,133.50,97.76,90.97,12150.095,67.642,31.015,74.414,0.909,9.068,49.977,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.757282','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2361,3,NULL,NULL,'2026-06-04 15:12:41',400.44,401.14,399.49,103.00,105.00,90.98,12150.100,61.519,31.347,69.045,0.891,9.275,50.015,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.771410','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2362,3,NULL,NULL,'2026-06-04 15:17:41',400.64,400.47,399.13,123.37,119.67,105.33,12150.105,72.003,35.886,80.450,0.895,9.984,50.032,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.798173','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2363,3,NULL,NULL,'2026-06-04 15:22:41',399.77,400.80,398.93,114.31,112.84,97.53,12150.110,68.156,31.251,74.979,0.909,10.019,49.976,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.808368','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2364,3,NULL,NULL,'2026-06-04 15:27:41',399.16,400.74,398.28,135.34,114.54,87.76,12150.115,70.175,33.987,77.972,0.900,9.911,50.014,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.817568','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2365,3,NULL,NULL,'2026-06-04 15:32:41',400.85,400.11,398.71,118.40,106.35,94.63,12150.120,65.864,33.194,73.756,0.893,10.331,49.960,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.828358','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2366,3,NULL,NULL,'2026-06-04 15:37:41',400.64,400.32,398.79,139.57,102.89,98.81,12150.125,70.614,34.996,78.810,0.896,10.372,50.029,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.838667','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2367,3,NULL,NULL,'2026-06-04 15:42:41',400.97,401.78,399.50,130.74,129.62,93.82,12150.130,73.940,34.969,81.792,0.904,9.867,50.024,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.847289','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2368,3,NULL,NULL,'2026-06-04 15:47:41',400.01,400.45,399.76,104.74,104.18,120.99,12150.135,67.883,34.589,76.187,0.891,10.422,49.973,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.859966','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2369,3,NULL,NULL,'2026-06-04 15:52:41',400.54,401.76,398.87,121.44,96.66,118.08,12150.140,69.095,35.398,77.635,0.890,10.415,50.028,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.872388','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2370,3,NULL,NULL,'2026-06-04 15:57:41',400.82,400.53,399.28,128.88,100.23,114.94,12150.145,71.428,34.796,79.453,0.899,9.187,49.971,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.881621','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2371,3,NULL,NULL,'2026-06-04 16:02:41',399.70,401.01,398.59,100.02,96.31,96.69,12150.150,60.901,29.496,67.668,0.900,10.070,49.960,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.890698','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2372,3,NULL,NULL,'2026-06-04 16:07:41',400.18,401.48,399.14,139.64,96.60,107.65,12150.155,70.680,36.210,79.416,0.890,10.359,50.038,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.899362','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2373,3,NULL,NULL,'2026-06-04 16:12:41',399.15,400.53,399.74,113.78,102.87,90.70,12150.160,63.667,31.374,70.978,0.897,9.300,49.960,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.910901','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2374,3,NULL,NULL,'2026-06-04 16:17:41',400.23,400.53,398.53,128.54,104.05,95.25,12150.165,68.744,31.720,75.709,0.908,9.837,49.998,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.921113','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2375,3,NULL,NULL,'2026-06-04 16:22:41',400.25,401.98,398.87,107.15,111.03,108.16,12150.170,67.977,32.537,75.363,0.902,10.496,50.022,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.932902','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2376,3,NULL,NULL,'2026-06-04 16:27:41',400.91,401.73,399.43,114.31,103.77,93.46,12150.175,64.391,32.092,71.945,0.895,9.670,50.011,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.944172','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2377,3,NULL,NULL,'2026-06-04 16:32:41',399.76,400.13,398.22,141.20,114.32,109.59,12150.180,76.053,36.402,84.316,0.902,9.824,50.010,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.952242','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2378,3,NULL,NULL,'2026-06-04 16:37:41',400.03,400.88,399.36,111.91,128.86,102.07,12150.185,71.414,34.182,79.173,0.902,9.505,49.974,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.960458','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2379,3,NULL,NULL,'2026-06-04 16:42:41',399.33,400.75,398.40,110.22,103.81,104.62,12150.190,66.523,31.461,73.587,0.904,9.591,50.032,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.969104','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2380,3,NULL,NULL,'2026-06-04 16:47:41',400.41,401.79,398.88,117.23,128.97,88.35,12150.195,70.151,32.369,77.259,0.908,10.407,50.007,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.980922','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2381,3,NULL,NULL,'2026-06-04 16:52:41',400.42,400.97,399.34,119.36,109.02,104.59,12150.200,68.589,34.759,76.893,0.892,10.049,50.034,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.992558','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2382,3,NULL,NULL,'2026-06-04 16:57:41',399.66,400.51,399.07,100.64,132.32,109.94,12150.205,70.793,35.481,79.187,0.894,10.529,50.023,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:40.999610','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2383,3,NULL,NULL,'2026-06-04 17:02:41',400.96,400.72,398.80,100.22,113.27,98.70,12150.126,64.237,32.732,72.095,0.891,10.529,49.972,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.014504','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2384,3,NULL,NULL,'2026-06-04 17:07:41',400.73,400.21,398.23,140.59,94.65,95.97,12150.129,68.074,34.875,76.488,0.890,10.271,49.993,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.025350','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2385,3,NULL,NULL,'2026-06-04 17:12:41',399.87,401.82,398.62,140.82,104.50,103.05,12150.132,70.716,38.361,80.451,0.879,10.486,50.005,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.033806','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2386,3,NULL,NULL,'2026-06-04 17:17:41',400.95,400.97,399.25,106.26,122.89,89.21,12150.135,64.918,34.508,73.520,0.883,10.669,50.022,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.043344','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2387,3,NULL,NULL,'2026-06-04 17:22:41',399.57,400.40,399.33,100.13,97.03,99.75,12150.138,60.338,32.567,68.566,0.880,10.180,50.005,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.049585','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2388,3,NULL,NULL,'2026-06-04 17:27:41',400.00,400.87,399.35,111.33,116.52,122.74,12150.141,72.138,36.757,80.963,0.891,10.359,50.014,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.058083','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2389,3,NULL,NULL,'2026-06-04 17:32:41',400.28,400.40,399.78,135.53,116.94,98.53,12150.144,72.303,36.641,81.057,0.892,10.566,49.974,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.067056','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2390,3,NULL,NULL,'2026-06-04 17:37:41',400.95,401.03,399.30,127.98,117.44,121.06,12150.147,74.900,39.404,84.633,0.885,10.136,50.031,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.075509','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2391,3,NULL,NULL,'2026-06-04 17:42:41',399.86,401.73,399.11,123.19,104.74,112.76,12150.150,69.865,36.179,78.677,0.888,10.637,50.019,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.082151','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2392,3,NULL,NULL,'2026-06-04 17:47:41',399.24,401.49,399.85,116.75,100.67,110.93,12150.153,67.410,34.722,75.827,0.889,11.289,49.979,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.088805','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2393,3,NULL,NULL,'2026-06-04 17:52:41',399.72,401.82,399.77,119.34,118.82,112.13,12150.156,71.914,37.042,80.893,0.889,11.381,49.961,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.097877','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2394,3,NULL,NULL,'2026-06-04 17:57:41',400.79,401.85,398.71,111.96,120.97,103.41,12150.159,68.507,36.603,77.672,0.882,10.748,49.989,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.105575','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2395,3,NULL,NULL,'2026-06-04 18:02:41',400.85,401.36,398.04,99.47,130.57,104.85,12150.162,68.057,36.733,77.338,0.880,11.353,49.984,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.112200','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2396,3,NULL,NULL,'2026-06-04 18:07:41',399.17,400.81,398.10,120.44,102.42,109.25,12150.165,68.335,34.820,76.695,0.891,10.816,49.988,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.118035','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2397,3,NULL,NULL,'2026-06-04 18:12:41',399.95,401.52,399.66,104.41,94.31,114.08,12150.224,64.723,32.076,72.235,0.896,10.462,50.014,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.127744','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2398,3,NULL,NULL,'2026-06-04 18:17:41',399.98,400.57,398.79,113.89,123.89,111.98,12150.228,72.452,35.703,80.771,0.897,11.055,49.969,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.134444','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2399,3,NULL,NULL,'2026-06-04 18:22:41',399.47,400.90,399.17,138.31,123.48,121.79,12150.232,79.103,39.867,88.581,0.893,10.880,50.008,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.141908','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2400,3,NULL,NULL,'2026-06-04 18:27:41',400.53,401.01,398.57,108.17,113.13,115.31,12150.177,68.795,36.192,77.734,0.885,10.279,49.977,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.148633','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2401,3,NULL,NULL,'2026-06-04 18:32:41',400.57,401.15,398.87,104.55,116.67,103.06,12150.240,67.099,33.254,74.887,0.896,10.927,50.024,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.156125','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2402,3,NULL,NULL,'2026-06-04 18:37:41',399.70,400.43,399.16,111.10,104.81,106.93,12150.183,65.832,34.994,74.555,0.883,10.482,50.012,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.162977','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2403,3,NULL,NULL,'2026-06-04 18:42:41',400.02,400.20,399.66,127.06,127.23,92.43,12150.248,71.422,36.194,80.070,0.892,10.749,50.012,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.170154','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2404,3,NULL,NULL,'2026-06-04 18:47:41',399.04,401.04,399.27,104.51,107.53,98.79,12150.252,63.598,33.284,71.781,0.886,10.016,49.980,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.180138','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2405,3,NULL,NULL,'2026-06-04 18:52:41',400.55,401.15,398.68,116.00,100.72,113.17,12150.256,67.422,35.470,76.183,0.885,11.079,50.022,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.188427','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2406,3,NULL,NULL,'2026-06-04 18:57:41',400.25,401.46,398.65,131.75,129.55,90.76,12150.260,73.091,35.606,81.303,0.899,10.396,50.003,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.197894','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2407,3,NULL,NULL,'2026-06-04 19:02:41',399.12,400.48,399.09,131.04,115.75,104.94,12150.264,71.560,38.429,81.226,0.881,9.880,50.007,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.206114','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2408,3,NULL,NULL,'2026-06-04 19:07:41',399.94,401.23,398.97,124.52,121.54,111.02,12150.268,72.979,38.394,82.462,0.885,10.649,49.971,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.213046','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2409,3,NULL,NULL,'2026-06-04 19:12:41',400.43,400.28,398.30,140.34,95.16,99.00,12150.272,68.441,35.818,77.247,0.886,11.318,49.971,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.221555','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2410,3,NULL,NULL,'2026-06-04 19:17:41',400.04,401.00,399.78,113.05,127.07,90.61,12150.276,68.052,34.675,76.377,0.891,9.969,49.980,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.230992','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2411,3,NULL,NULL,'2026-06-04 19:22:41',399.16,400.49,398.06,138.04,108.44,90.44,12150.280,68.703,36.520,77.806,0.883,10.222,50.006,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.238400','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2412,3,NULL,NULL,'2026-06-04 19:27:41',400.82,400.90,398.94,109.48,96.43,110.47,12150.284,65.610,32.147,73.062,0.898,11.084,49.989,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.248004','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2413,3,NULL,NULL,'2026-06-04 19:32:41',399.60,400.91,399.46,130.14,130.54,99.74,12150.288,73.578,38.910,83.233,0.884,10.216,49.998,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.258117','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2414,3,NULL,NULL,'2026-06-04 19:37:41',399.15,400.28,399.33,135.05,106.11,126.01,12150.292,76.143,37.308,84.792,0.898,10.982,50.001,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.265166','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2415,3,NULL,NULL,'2026-06-04 19:42:41',400.48,401.45,398.44,100.31,103.36,90.48,12150.296,60.796,30.301,67.928,0.895,10.518,50.022,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.274447','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2416,3,NULL,NULL,'2026-06-04 19:47:41',399.63,400.37,399.26,125.74,132.53,120.83,12150.300,78.179,39.401,87.546,0.893,10.325,50.024,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.280310','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2417,3,NULL,NULL,'2026-06-04 19:52:41',399.59,401.58,399.76,117.40,119.04,118.35,12150.304,73.002,37.198,81.933,0.891,9.821,49.991,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.288484','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2418,3,NULL,NULL,'2026-06-04 19:57:41',400.17,401.41,398.20,102.93,99.22,102.58,12150.308,63.335,30.675,70.372,0.900,10.302,50.025,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.295712','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2419,3,NULL,NULL,'2026-06-04 20:02:41',400.27,401.98,398.69,120.26,108.87,101.49,12150.156,67.265,36.123,76.351,0.881,12.385,50.014,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.303013','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2420,3,NULL,NULL,'2026-06-04 20:07:41',400.85,400.48,399.36,126.89,102.79,93.75,12150.158,66.027,34.917,74.691,0.884,11.122,49.988,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.311594','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2421,3,NULL,NULL,'2026-06-04 20:12:41',399.78,400.90,398.03,102.70,94.67,120.35,12150.160,64.861,34.301,73.372,0.884,11.733,50.001,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.319803','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2422,3,NULL,NULL,'2026-06-04 20:17:41',399.24,401.65,398.61,104.73,101.37,107.84,12150.162,64.017,34.029,72.499,0.883,11.387,50.024,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.327547','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2423,3,NULL,NULL,'2026-06-04 20:22:41',400.53,400.39,398.57,99.81,118.00,122.01,12150.164,69.530,36.388,78.476,0.886,11.453,50.014,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.334660','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2424,3,NULL,NULL,'2026-06-04 20:27:41',399.55,400.69,398.49,126.74,118.54,91.01,12150.166,68.497,36.598,77.661,0.882,12.357,49.990,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.342227','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2425,3,NULL,NULL,'2026-06-04 20:32:41',400.33,401.84,399.14,124.00,122.56,117.22,12150.168,73.256,41.123,84.009,0.872,10.996,49.972,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.348532','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2426,3,NULL,NULL,'2026-06-04 20:37:41',399.45,400.72,398.41,128.69,102.06,124.03,12150.170,71.525,39.959,81.930,0.873,11.038,50.033,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.355302','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2427,3,NULL,NULL,'2026-06-04 20:42:41',400.86,401.53,398.49,102.01,117.73,114.87,12150.172,68.309,36.124,77.273,0.884,11.442,50.006,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.363279','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2428,3,NULL,NULL,'2026-06-04 20:47:41',400.69,400.53,398.35,130.75,119.40,122.84,12150.174,75.197,42.010,86.136,0.873,11.024,49.969,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.370431','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2429,3,NULL,NULL,'2026-06-04 20:52:41',400.33,401.12,398.69,126.98,117.05,121.88,12150.176,73.854,41.061,84.501,0.874,12.395,50.033,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.379500','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2430,3,NULL,NULL,'2026-06-04 20:57:41',399.31,401.73,398.60,129.03,129.83,99.36,12150.178,72.053,40.641,82.724,0.871,11.833,49.963,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.386084','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2431,3,NULL,NULL,'2026-06-04 21:02:41',399.77,400.47,398.05,135.19,107.94,95.74,12150.180,67.848,38.996,78.256,0.867,11.749,50.008,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.393536','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2432,3,NULL,NULL,'2026-06-04 21:07:41',400.11,401.68,398.55,140.77,105.00,105.51,12150.182,71.063,39.126,81.122,0.876,12.252,50.026,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.400361','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2433,3,NULL,NULL,'2026-06-04 21:12:41',399.76,402.00,399.64,118.45,131.94,99.03,12150.184,70.122,39.928,80.693,0.869,11.122,50.001,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.408016','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2434,3,NULL,NULL,'2026-06-04 21:17:41',399.13,401.71,399.00,126.65,109.52,125.94,12150.186,72.418,41.815,83.624,0.866,11.443,49.995,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.414240','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2435,3,NULL,NULL,'2026-06-04 21:22:41',399.61,400.87,399.43,132.37,132.73,104.03,12150.188,74.163,42.030,85.245,0.870,12.057,49.996,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.421631','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2436,3,NULL,NULL,'2026-06-04 21:27:41',400.16,401.62,399.25,108.99,132.76,89.69,12150.190,66.284,38.274,76.540,0.866,11.517,49.979,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.428474','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2437,3,NULL,NULL,'2026-06-04 21:32:41',400.39,401.53,399.27,114.87,124.46,112.03,12150.192,70.430,40.291,81.141,0.868,12.457,49.972,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.434233','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2438,3,NULL,NULL,'2026-06-04 21:37:41',400.65,401.65,399.43,136.78,116.06,91.05,12150.194,69.012,39.296,79.415,0.869,12.165,50.008,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.442848','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2439,3,NULL,NULL,'2026-06-04 21:42:41',399.91,400.95,398.61,132.03,119.52,120.01,12150.196,75.080,41.541,85.806,0.875,11.426,50.004,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.450114','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2440,3,NULL,NULL,'2026-06-04 21:47:41',400.81,400.48,398.87,110.71,130.90,114.87,12150.198,71.786,40.298,82.323,0.872,11.231,49.996,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.457935','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2441,3,NULL,NULL,'2026-06-04 21:52:41',399.79,400.07,399.23,132.34,126.93,115.41,12150.200,75.883,41.575,86.526,0.877,11.528,49.999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.466682','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2442,3,NULL,NULL,'2026-06-04 21:57:41',400.02,400.47,399.01,104.75,117.28,105.41,12150.202,66.543,35.916,75.617,0.880,12.331,49.977,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.475569','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2443,3,NULL,NULL,'2026-06-04 22:02:41',400.21,400.31,398.66,122.33,109.62,99.46,12150.204,66.431,38.004,76.533,0.868,11.636,50.021,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.483762','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2444,3,NULL,NULL,'2026-06-04 22:07:41',399.11,401.86,398.51,113.17,126.17,124.60,12150.206,73.708,40.383,84.046,0.877,11.191,50.026,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.492419','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2445,3,NULL,NULL,'2026-06-04 22:12:41',400.66,400.28,398.54,115.46,97.72,100.55,12150.208,63.829,34.278,72.451,0.881,11.342,50.025,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.498775','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2446,3,NULL,NULL,'2026-06-04 22:17:41',399.88,401.19,399.46,113.64,124.92,117.47,12150.210,71.284,40.970,82.219,0.867,11.839,50.002,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.506730','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2447,3,NULL,NULL,'2026-06-04 22:22:41',399.90,401.84,399.13,122.65,113.64,117.46,12150.212,72.380,37.880,81.693,0.886,12.406,49.977,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.513474','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2448,3,NULL,NULL,'2026-06-04 22:27:41',399.84,400.68,398.61,115.01,118.43,121.87,12150.214,72.535,38.359,82.053,0.884,11.650,50.023,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.519833','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2449,3,NULL,NULL,'2026-06-04 22:32:41',399.80,401.16,398.95,124.58,108.75,89.37,12150.216,65.132,36.212,74.522,0.874,11.136,50.014,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.531093','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2450,3,NULL,NULL,'2026-06-04 22:37:41',399.82,400.74,399.40,102.51,107.78,105.36,12150.218,64.074,34.758,72.894,0.879,11.088,50.026,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.538011','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2451,3,NULL,NULL,'2026-06-04 22:42:41',401.00,401.42,398.18,108.84,127.78,105.24,12150.220,69.473,37.498,78.947,0.880,12.261,49.993,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.545794','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2452,3,NULL,NULL,'2026-06-04 22:47:41',400.86,400.90,399.49,131.40,112.22,125.92,12150.222,75.269,40.216,85.339,0.882,11.094,49.970,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.554449','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2453,3,NULL,NULL,'2026-06-04 22:52:41',399.70,401.00,399.57,123.74,132.85,89.16,12150.224,69.545,39.226,79.845,0.871,11.907,50.004,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.562142','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2454,3,NULL,NULL,'2026-06-04 22:57:41',399.08,400.37,399.78,111.63,110.76,94.91,12150.226,64.042,35.606,73.275,0.874,11.663,49.969,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.569495','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2455,3,NULL,NULL,'2026-06-04 23:02:41',400.26,400.04,399.10,127.22,125.39,121.89,12150.228,76.452,40.430,86.484,0.884,12.263,50.008,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.576493','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2456,3,NULL,NULL,'2026-06-04 23:07:41',399.83,400.75,399.50,102.70,127.88,122.11,12150.230,71.756,38.535,81.448,0.881,11.081,50.028,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.583616','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2457,3,NULL,NULL,'2026-06-04 23:12:41',399.13,401.49,399.99,139.28,95.75,104.58,12150.232,69.408,36.515,78.427,0.885,11.406,50.014,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.591137','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2458,3,NULL,NULL,'2026-06-04 23:17:41',399.50,401.34,398.14,99.28,125.90,122.00,12150.234,70.635,37.933,80.176,0.881,12.389,50.036,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.597803','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2459,3,NULL,NULL,'2026-06-04 23:22:41',400.55,400.95,398.64,101.70,122.79,100.91,12150.236,65.302,37.183,75.146,0.869,11.542,49.997,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.605211','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2460,3,NULL,NULL,'2026-06-04 23:27:41',400.04,400.94,399.65,122.89,126.67,100.93,12150.238,70.822,39.185,80.939,0.875,11.242,50.029,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.613031','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2461,3,NULL,NULL,'2026-06-04 23:32:41',399.92,401.88,398.35,110.79,110.14,94.27,12150.240,63.255,36.018,72.791,0.869,11.543,50.035,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.622012','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2462,3,NULL,NULL,'2026-06-04 23:37:41',399.99,400.70,399.44,125.60,119.72,99.63,12150.242,69.703,38.566,79.661,0.875,11.352,50.008,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.630576','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2463,3,NULL,NULL,'2026-06-04 23:42:41',400.57,401.55,398.63,125.38,101.58,92.09,12150.244,64.322,35.935,73.679,0.873,12.355,50.000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.637596','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2464,3,NULL,NULL,'2026-06-04 23:47:41',400.80,400.25,398.90,140.43,115.06,115.08,12150.246,75.479,40.328,85.577,0.882,12.442,49.995,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.645985','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2465,3,NULL,NULL,'2026-06-04 23:52:41',400.08,401.51,398.64,140.38,123.40,115.87,12150.248,76.013,43.688,87.674,0.867,11.037,50.001,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.652004','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2466,3,NULL,NULL,'2026-06-04 23:57:41',399.78,401.07,398.88,118.44,98.76,97.43,12150.250,64.012,34.376,72.658,0.881,11.995,49.971,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.664026','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2467,3,NULL,NULL,'2026-06-05 00:02:41',399.50,401.77,398.20,136.05,118.24,103.24,12150.252,72.493,39.521,82.566,0.878,11.884,49.990,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.671711','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2468,3,NULL,NULL,'2026-06-05 00:07:41',400.05,400.71,399.98,107.10,126.32,103.00,12150.254,67.591,38.306,77.691,0.870,11.679,50.022,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.678275','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2469,3,NULL,NULL,'2026-06-05 00:12:41',399.41,401.85,399.37,123.49,122.85,119.94,12150.256,73.844,41.255,84.586,0.873,11.962,50.016,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.684052','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2470,3,NULL,NULL,'2026-06-05 00:17:41',400.23,401.21,399.08,99.79,120.31,94.36,12150.258,63.324,35.548,72.619,0.872,11.730,49.988,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.693029','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2471,3,NULL,NULL,'2026-06-05 00:22:41',400.36,401.52,399.09,137.22,133.58,95.04,12150.260,74.178,40.440,84.485,0.878,12.265,50.021,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.700201','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2472,3,NULL,NULL,'2026-06-05 00:27:41',399.76,401.55,399.83,99.10,114.53,107.61,12150.262,65.654,34.540,74.185,0.885,11.607,49.968,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.707780','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2473,3,NULL,NULL,'2026-06-05 00:32:41',399.88,401.41,398.65,100.14,120.32,93.46,12150.264,63.288,35.357,72.495,0.873,11.298,49.969,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.714644','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2474,3,NULL,NULL,'2026-06-05 00:37:41',400.01,400.30,398.34,132.16,112.41,124.79,12150.266,74.721,41.140,85.298,0.876,10.949,50.011,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.721021','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2475,3,NULL,NULL,'2026-06-05 00:42:41',399.41,401.42,398.09,116.78,103.39,123.62,12150.268,69.389,38.579,79.392,0.874,10.867,49.970,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.729022','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2476,3,NULL,NULL,'2026-06-05 00:47:41',400.81,401.44,398.30,138.69,129.15,108.83,12150.270,76.982,40.500,86.985,0.885,11.960,49.973,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.734514','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2477,3,NULL,NULL,'2026-06-05 00:52:41',400.15,400.94,399.27,104.01,93.76,112.57,12150.272,63.641,32.956,71.668,0.888,11.890,50.009,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.742238','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2478,3,NULL,NULL,'2026-06-05 00:57:41',400.20,401.37,399.58,107.17,96.81,118.41,12150.274,64.772,36.708,74.451,0.870,11.006,49.987,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.748255','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2479,3,NULL,NULL,'2026-06-05 01:02:41',399.31,401.61,399.41,130.28,105.85,99.01,12150.276,67.953,37.046,77.395,0.878,11.151,49.975,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.756568','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2480,3,NULL,NULL,'2026-06-05 01:07:41',400.48,401.00,398.87,122.53,131.03,122.40,12150.278,76.056,41.875,86.822,0.876,12.075,49.962,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.761864','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2481,3,NULL,NULL,'2026-06-05 01:12:41',400.68,401.34,398.27,130.97,96.35,91.12,12150.280,64.052,36.128,73.538,0.871,10.893,49.982,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.767833','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2482,3,NULL,NULL,'2026-06-05 01:17:41',399.99,401.24,398.49,108.31,129.75,115.89,12150.282,72.257,38.212,81.739,0.884,12.058,50.010,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.776071','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2483,3,NULL,NULL,'2026-06-05 01:22:41',400.27,400.32,398.93,98.51,127.13,91.31,12150.284,63.752,35.959,73.194,0.871,11.181,50.031,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.782013','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2484,3,NULL,NULL,'2026-06-05 01:27:41',399.60,400.74,399.12,98.55,123.83,114.22,12150.286,68.948,35.894,77.732,0.887,11.013,50.001,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.789500','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2485,3,NULL,NULL,'2026-06-05 01:32:41',400.03,401.02,398.51,107.82,94.64,106.52,12150.288,63.291,32.949,71.354,0.887,11.446,49.969,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.797143','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2486,3,NULL,NULL,'2026-06-05 01:37:41',399.85,401.83,399.84,113.61,105.73,104.52,12150.290,64.993,37.007,74.791,0.869,11.740,49.994,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.804752','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2487,3,NULL,NULL,'2026-06-05 01:42:41',400.04,401.69,399.21,110.63,97.93,114.45,12150.292,65.419,35.842,74.594,0.877,12.057,49.983,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.813145','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2488,3,NULL,NULL,'2026-06-05 01:47:41',400.96,400.98,399.72,104.50,119.17,114.95,12150.294,68.424,37.858,78.199,0.875,11.535,49.989,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.823188','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2489,3,NULL,NULL,'2026-06-05 01:52:41',399.40,400.54,398.68,126.67,99.72,118.46,12150.296,69.922,38.119,79.638,0.878,10.859,49.973,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.829749','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2490,3,NULL,NULL,'2026-06-05 01:57:41',400.37,401.01,399.95,121.36,104.36,115.91,12150.298,69.979,36.431,78.894,0.887,11.548,50.012,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.839054','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2491,3,NULL,NULL,'2026-06-05 02:02:41',399.76,400.53,399.74,135.59,98.00,125.02,12150.300,72.463,40.093,82.815,0.875,10.943,50.002,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.846523','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2492,3,NULL,NULL,'2026-06-05 02:07:41',400.69,400.21,398.38,120.39,119.81,113.95,12150.302,71.562,39.594,81.785,0.875,10.974,49.970,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.855312','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2493,3,NULL,NULL,'2026-06-05 02:12:41',400.14,401.72,398.88,119.05,107.78,99.60,12150.304,66.413,35.665,75.384,0.881,11.393,49.982,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.862059','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2494,3,NULL,NULL,'2026-06-05 02:17:41',400.51,401.22,398.84,119.77,116.04,97.93,12150.306,67.361,37.451,77.072,0.874,11.383,50.000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.869599','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2495,3,NULL,NULL,'2026-06-05 02:22:41',399.24,401.69,399.57,127.50,117.05,120.50,12150.308,74.186,40.041,84.302,0.880,12.072,50.035,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.876875','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2496,3,NULL,NULL,'2026-06-05 02:27:41',399.59,400.43,399.07,121.29,97.50,122.39,12150.310,68.941,38.144,78.790,0.875,10.969,50.000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.884058','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2497,3,NULL,NULL,'2026-06-05 02:32:41',399.67,401.71,399.84,107.24,106.80,88.06,12150.312,60.835,34.150,69.765,0.872,11.170,49.977,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.893854','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2498,3,NULL,NULL,'2026-06-05 02:37:41',400.23,401.80,398.03,101.36,106.52,102.47,12150.314,63.213,33.774,71.670,0.882,11.245,49.997,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.902794','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2499,3,NULL,NULL,'2026-06-05 02:42:41',400.91,400.92,398.69,139.85,120.16,102.07,12150.316,72.913,40.930,83.616,0.872,11.081,49.983,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.911476','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2500,3,NULL,NULL,'2026-06-05 02:47:41',399.54,400.28,399.46,137.71,111.27,104.60,12150.318,71.855,38.783,81.653,0.880,11.454,50.028,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.922593','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2501,3,NULL,NULL,'2026-06-05 02:52:41',400.76,401.39,399.65,136.76,98.67,125.04,12150.320,73.255,39.539,83.244,0.880,11.034,50.010,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.931195','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2502,3,NULL,NULL,'2026-06-05 02:57:41',400.61,401.32,399.10,118.37,110.15,112.57,12150.322,68.529,38.837,78.769,0.870,10.932,50.024,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.939048','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2503,3,NULL,NULL,'2026-06-05 03:02:41',400.46,401.89,398.10,98.57,97.02,103.91,12150.324,60.450,33.609,69.165,0.874,12.110,50.000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.945285','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2504,3,NULL,NULL,'2026-06-05 03:07:41',399.92,401.97,398.06,134.67,132.02,94.53,12150.326,73.574,39.310,83.417,0.882,11.019,50.007,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.954221','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2505,3,NULL,NULL,'2026-06-05 03:12:41',399.62,401.10,398.49,101.15,125.91,117.01,12150.328,70.399,36.843,79.457,0.886,12.152,49.996,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.961449','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2506,3,NULL,NULL,'2026-06-05 03:17:41',399.93,401.86,399.33,116.90,128.84,88.64,12150.330,68.571,35.509,77.220,0.888,11.525,49.966,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.967924','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2507,3,NULL,NULL,'2026-06-05 03:22:41',400.13,401.11,398.86,121.37,117.65,101.20,12150.332,69.690,36.280,78.568,0.887,12.199,50.014,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.976148','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2508,3,NULL,NULL,'2026-06-05 03:27:41',399.95,400.96,398.27,140.76,128.53,100.39,12150.334,75.468,39.910,85.371,0.884,11.793,50.021,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.983275','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2509,3,NULL,NULL,'2026-06-05 03:32:41',400.20,400.66,399.41,101.84,110.46,119.69,12150.336,67.697,35.985,76.667,0.883,11.252,50.037,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.993025','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2510,3,NULL,NULL,'2026-06-05 03:37:41',399.61,401.39,398.98,137.55,95.25,106.86,12150.338,69.654,36.070,78.439,0.888,11.409,49.970,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:41.998920','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2511,3,NULL,NULL,'2026-06-05 03:42:41',400.47,401.76,398.03,113.65,104.79,100.01,12150.340,63.980,36.259,73.540,0.870,11.997,50.013,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.008223','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2512,3,NULL,NULL,'2026-06-05 03:47:41',400.77,400.37,398.82,131.49,129.36,90.59,12150.342,71.907,37.632,81.159,0.886,11.580,49.960,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.015917','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2513,3,NULL,NULL,'2026-06-05 03:52:41',400.56,401.41,399.89,130.66,114.49,100.03,12150.344,69.829,38.447,79.713,0.876,12.065,50.038,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.024000','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2514,3,NULL,NULL,'2026-06-05 03:57:41',400.60,400.88,398.39,100.98,107.48,108.01,12150.346,64.094,35.116,73.083,0.877,12.235,50.038,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.031166','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2515,3,NULL,NULL,'2026-06-05 04:02:41',399.62,400.55,399.86,124.67,112.42,106.35,12150.348,69.081,38.965,79.312,0.871,11.280,49.966,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.040609','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2516,3,NULL,NULL,'2026-06-05 04:07:41',400.68,400.04,398.89,99.74,122.44,104.51,12150.350,66.013,36.524,75.443,0.875,10.880,50.012,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.046593','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2517,3,NULL,NULL,'2026-06-05 04:12:41',400.57,400.61,399.66,100.99,134.27,118.17,12150.352,72.151,38.156,81.619,0.884,12.231,49.991,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.054198','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2518,3,NULL,NULL,'2026-06-05 04:17:41',399.04,400.90,399.14,140.20,112.68,104.56,12150.354,72.970,38.589,82.545,0.884,11.987,49.963,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.061180','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2519,3,NULL,NULL,'2026-06-05 04:22:41',399.67,401.14,399.11,132.07,117.59,110.80,12150.356,73.087,39.845,83.243,0.878,11.018,50.019,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.069004','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2520,3,NULL,NULL,'2026-06-05 04:27:41',399.72,400.60,398.59,108.40,108.29,91.97,12150.358,63.011,33.322,71.279,0.884,12.258,50.018,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.079670','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2521,3,NULL,NULL,'2026-06-05 04:32:41',400.25,400.25,399.92,118.57,93.67,111.73,12150.360,65.912,35.396,74.815,0.881,11.015,50.008,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.088087','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2522,3,NULL,NULL,'2026-06-05 04:37:41',400.12,401.68,398.60,102.71,119.37,120.66,12150.362,69.098,38.603,79.150,0.873,11.836,49.979,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.095786','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2523,3,NULL,NULL,'2026-06-05 04:42:41',400.01,400.05,398.86,114.83,107.33,108.81,12150.364,67.260,36.303,76.432,0.880,12.261,50.010,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.104743','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2524,3,NULL,NULL,'2026-06-05 04:47:41',399.68,400.58,398.66,129.63,133.41,114.54,12150.366,76.471,41.897,87.196,0.877,12.165,49.998,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.113852','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2525,3,NULL,NULL,'2026-06-05 04:52:41',399.44,401.00,399.37,122.61,122.83,122.18,12150.368,74.369,40.946,84.896,0.876,11.404,50.015,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.121546','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2526,3,NULL,NULL,'2026-06-05 04:57:41',399.60,400.27,399.03,112.42,132.09,115.88,12150.370,73.489,39.064,83.227,0.883,11.151,49.993,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.128302','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2527,3,NULL,NULL,'2026-06-05 05:02:41',400.32,400.82,399.79,134.27,132.88,99.63,12150.372,74.199,40.853,84.702,0.876,11.263,50.032,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.135460','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2528,3,NULL,NULL,'2026-06-05 05:07:41',400.31,400.02,398.69,127.06,109.55,125.01,12150.374,73.155,40.278,83.510,0.876,11.048,50.007,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.143079','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2529,3,NULL,NULL,'2026-06-05 05:12:41',399.96,400.25,398.48,127.05,110.43,90.67,12150.376,67.293,34.847,75.780,0.888,11.701,49.989,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.148865','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2530,3,NULL,NULL,'2026-06-05 05:17:41',399.75,401.96,399.09,104.47,112.94,124.33,12150.378,69.922,36.593,78.919,0.886,11.850,50.011,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.158521','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2531,3,NULL,NULL,'2026-06-05 05:22:41',400.64,401.66,399.49,112.50,125.59,123.68,12150.380,73.185,40.294,83.545,0.876,12.003,50.028,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.166012','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2532,3,NULL,NULL,'2026-06-05 05:27:41',400.27,400.42,399.31,112.15,125.98,87.93,12150.382,66.187,35.904,75.298,0.879,11.089,49.977,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.173796','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2533,3,NULL,NULL,'2026-06-05 05:32:41',401.00,400.51,398.96,126.41,102.81,95.14,12150.384,66.291,34.875,74.905,0.885,11.701,50.007,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.183894','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2534,3,NULL,NULL,'2026-06-05 05:37:41',400.40,401.71,398.70,110.39,126.82,96.54,12150.386,67.979,36.321,77.074,0.882,11.366,50.021,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.192836','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2535,3,NULL,NULL,'2026-06-05 05:42:41',400.31,401.57,399.82,128.86,127.98,91.13,12150.388,71.117,37.414,80.358,0.885,11.977,50.018,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.199803','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2536,3,NULL,NULL,'2026-06-05 05:47:41',399.33,400.61,398.22,138.06,106.87,121.51,12150.390,73.961,41.121,84.624,0.874,12.296,50.036,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.209568','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2537,3,NULL,NULL,'2026-06-05 05:52:41',400.59,400.50,398.46,115.91,109.74,117.22,12150.392,70.312,36.410,79.180,0.888,12.039,49.973,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.217393','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2538,3,NULL,NULL,'2026-06-05 05:57:41',400.17,400.59,398.81,125.96,130.15,109.06,12150.394,74.548,39.423,84.330,0.884,11.397,49.993,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.226109','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2539,3,NULL,NULL,'2026-06-05 06:02:41',399.50,400.07,398.15,102.18,125.36,111.66,12150.594,68.384,38.204,78.332,0.873,11.910,49.973,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.231722','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2540,3,NULL,NULL,'2026-06-05 06:07:41',400.52,400.16,399.98,131.89,94.02,116.23,12150.597,68.977,38.535,79.011,0.873,11.903,50.029,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.242218','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2541,3,NULL,NULL,'2026-06-05 06:12:41',399.33,401.62,398.13,126.87,96.59,103.23,12150.600,66.918,34.837,75.443,0.887,10.432,50.005,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.250199','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2542,3,NULL,NULL,'2026-06-05 06:17:41',399.38,400.12,400.00,132.25,122.66,95.60,12150.603,71.474,37.993,80.945,0.883,11.425,50.036,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.258321','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2543,3,NULL,NULL,'2026-06-05 06:22:41',400.45,401.42,398.15,136.75,127.39,105.78,12150.606,75.774,39.448,85.427,0.887,10.807,49.983,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.266347','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2544,3,NULL,NULL,'2026-06-05 06:27:41',400.55,401.98,399.76,135.69,130.86,124.89,12150.609,79.278,43.435,90.397,0.877,11.050,49.980,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.276317','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2545,3,NULL,NULL,'2026-06-05 06:32:41',400.37,400.18,399.11,102.30,116.35,107.61,12150.612,67.132,34.207,75.345,0.891,11.612,49.974,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.283663','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2546,3,NULL,NULL,'2026-06-05 06:37:41',400.88,401.08,399.65,137.58,133.99,96.01,12150.615,74.615,40.476,84.886,0.879,11.124,49.994,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.291815','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2547,3,NULL,NULL,'2026-06-05 06:42:41',400.39,401.81,399.77,103.28,131.24,97.80,12150.618,67.151,37.154,76.744,0.875,10.265,49.966,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.300629','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2548,3,NULL,NULL,'2026-06-05 06:47:41',400.48,400.24,400.00,121.99,132.33,91.42,12150.621,71.459,35.615,79.842,0.895,10.457,49.997,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.309385','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2549,3,NULL,NULL,'2026-06-05 06:52:41',400.09,400.73,398.36,125.94,130.47,110.61,12150.624,75.773,37.977,84.757,0.894,11.321,49.993,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.318082','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2550,3,NULL,NULL,'2026-06-05 06:57:41',400.60,400.42,398.69,109.83,115.73,123.05,12150.627,71.328,37.329,80.506,0.886,11.004,49.996,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.326340','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2551,3,NULL,NULL,'2026-06-05 07:02:41',399.65,401.99,398.70,139.73,94.85,99.17,12150.630,68.827,34.688,77.074,0.893,10.268,50.039,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.333137','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2552,3,NULL,NULL,'2026-06-05 07:07:41',400.40,401.99,398.22,114.97,94.60,125.74,12150.633,68.529,36.053,77.434,0.885,10.271,49.976,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.342817','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2553,3,NULL,NULL,'2026-06-05 07:12:41',400.71,401.81,398.18,135.11,105.38,122.42,12150.636,75.176,37.046,83.808,0.897,10.432,49.981,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.349419','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2554,3,NULL,NULL,'2026-06-05 07:17:41',399.72,400.84,398.41,125.69,112.27,102.91,12150.639,69.666,36.651,78.719,0.885,11.458,50.032,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.360605','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2555,3,NULL,NULL,'2026-06-05 07:22:41',399.16,400.71,399.91,124.12,126.15,95.19,12150.642,71.162,36.062,79.778,0.892,10.247,50.001,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.366892','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2556,3,NULL,NULL,'2026-06-05 07:27:41',400.64,401.95,399.07,123.42,106.42,120.05,12150.860,71.913,36.842,80.801,0.890,10.904,49.962,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.375952','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2557,3,NULL,NULL,'2026-06-05 07:32:41',400.12,401.94,398.87,109.14,123.29,121.87,12150.864,73.556,35.833,81.820,0.899,11.371,49.975,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.382472','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2558,3,NULL,NULL,'2026-06-05 07:37:41',400.65,400.18,399.54,109.26,118.03,96.89,12150.868,66.554,34.281,74.864,0.889,11.284,50.019,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.391149','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2559,3,NULL,NULL,'2026-06-05 07:42:41',400.14,401.82,398.26,115.37,103.79,90.75,12150.872,62.980,33.993,71.568,0.880,10.801,50.024,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.399910','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2560,3,NULL,NULL,'2026-06-05 07:47:41',399.43,401.93,398.09,125.91,132.45,119.99,12150.876,78.462,38.444,87.374,0.898,10.728,49.971,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.410530','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2561,3,NULL,NULL,'2026-06-05 07:52:41',400.38,401.77,399.42,113.00,100.79,121.52,12150.880,68.684,35.757,77.434,0.887,10.045,50.007,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.417594','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2562,3,NULL,NULL,'2026-06-05 07:57:41',399.81,400.79,399.00,135.13,118.93,108.94,12150.884,73.853,39.661,83.829,0.881,9.908,49.976,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.426812','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2563,3,NULL,NULL,'2026-06-05 08:02:41',399.31,401.30,398.69,136.90,126.53,101.33,12151.110,76.149,36.013,84.236,0.904,9.881,49.988,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.433115','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2564,3,NULL,NULL,'2026-06-05 08:07:41',400.14,401.14,399.59,113.43,121.43,101.65,12150.892,70.018,33.713,77.711,0.901,10.013,49.986,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.443414','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2565,3,NULL,NULL,'2026-06-05 08:12:41',400.28,400.38,399.54,131.35,123.46,101.78,12150.896,74.525,35.032,82.348,0.905,10.712,50.019,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.450598','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2566,3,NULL,NULL,'2026-06-05 08:17:41',400.70,400.34,399.30,125.63,95.87,103.16,12151.125,67.177,33.293,74.974,0.896,10.056,50.009,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.460890','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2567,3,NULL,NULL,'2026-06-05 08:22:41',400.48,401.73,399.25,134.13,131.84,95.14,12151.130,75.136,36.177,83.392,0.901,10.011,49.991,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.470365','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2568,3,NULL,NULL,'2026-06-05 08:27:41',399.61,400.02,399.37,105.17,101.98,109.53,12151.135,65.087,33.345,73.131,0.890,9.505,50.013,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.481362','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2569,3,NULL,NULL,'2026-06-05 08:32:41',400.58,401.38,398.56,107.35,107.38,90.52,12151.140,62.809,32.004,70.493,0.891,9.733,50.005,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.495726','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2570,3,NULL,NULL,'2026-06-05 08:37:41',399.66,401.62,398.92,113.30,114.31,107.13,12151.145,68.954,34.944,77.303,0.892,9.381,49.990,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.506246','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2571,3,NULL,NULL,'2026-06-05 08:42:41',400.86,400.04,399.28,141.37,112.47,100.45,12151.150,73.145,36.660,81.818,0.894,9.905,49.999,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.515367','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2572,3,NULL,NULL,'2026-06-05 08:47:41',399.76,401.85,398.83,109.67,106.40,118.24,12151.155,69.174,34.282,77.203,0.896,9.716,49.987,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.525055','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2573,3,NULL,NULL,'2026-06-05 08:52:41',399.67,401.19,399.41,99.00,121.98,104.31,12151.160,66.782,34.398,75.120,0.889,10.140,50.014,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.534035','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2574,3,NULL,NULL,'2026-06-05 08:57:41',400.00,401.75,399.13,101.34,95.52,89.43,12151.165,59.833,28.126,66.114,0.905,9.223,50.014,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.543805','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2575,3,NULL,NULL,'2026-06-05 09:02:41',400.10,401.42,399.02,101.46,102.59,122.31,12151.170,67.303,33.920,75.367,0.893,9.329,50.018,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.550767','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2576,3,NULL,NULL,'2026-06-05 09:07:41',399.37,401.77,398.81,133.87,110.43,110.94,12151.175,73.997,35.418,82.037,0.902,9.936,49.975,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.561007','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2577,3,NULL,NULL,'2026-06-05 09:12:41',399.94,400.33,398.79,131.74,95.63,124.22,12151.180,72.344,36.862,81.194,0.891,10.144,50.030,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.569090','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2578,3,NULL,NULL,'2026-06-05 09:17:41',400.65,400.65,399.32,123.36,95.46,107.28,12151.185,68.304,31.714,75.308,0.907,9.773,49.961,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.579025','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2579,3,NULL,NULL,'2026-06-05 09:22:41',399.65,401.01,398.93,115.30,111.34,87.80,12151.190,64.918,32.536,72.615,0.894,9.491,50.039,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.586602','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2580,3,NULL,NULL,'2026-06-05 09:27:41',400.45,401.02,398.34,128.74,114.27,104.16,12151.195,72.156,34.947,80.173,0.900,9.604,50.036,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.596985','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2581,3,NULL,NULL,'2026-06-05 09:32:41',399.70,401.71,398.67,124.83,125.51,90.32,12151.200,70.645,34.614,78.669,0.898,9.888,50.005,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.605351','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2582,3,NULL,NULL,'2026-06-05 09:37:41',400.30,400.26,399.96,141.32,124.95,120.61,12151.205,80.320,39.128,89.344,0.899,9.821,49.983,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.613685','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2583,3,NULL,NULL,'2026-06-05 09:42:41',400.02,400.62,399.90,140.15,104.66,105.55,12151.210,73.142,34.591,80.909,0.904,9.367,49.985,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.622341','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2584,3,NULL,NULL,'2026-06-05 09:47:41',399.21,400.56,398.86,119.77,97.03,124.27,12151.215,70.652,34.816,78.765,0.897,10.027,50.019,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.629894','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2585,3,NULL,NULL,'2026-06-05 09:52:41',400.97,400.12,398.36,119.24,116.75,102.66,12151.220,71.011,32.766,78.206,0.908,9.281,50.002,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.639514','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2586,3,NULL,NULL,'2026-06-05 09:57:41',399.69,400.83,399.48,108.60,94.25,102.56,12151.225,63.900,29.854,70.530,0.906,10.226,49.996,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.646283','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2587,3,NULL,NULL,'2026-06-05 10:02:41',399.91,400.27,398.77,135.89,101.09,100.17,12151.230,69.528,35.041,77.859,0.893,9.320,49.965,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.653956','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2588,3,NULL,NULL,'2026-06-05 10:07:41',400.08,400.02,399.94,100.90,106.66,104.39,12151.235,64.980,31.102,72.040,0.902,9.167,50.014,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.665443','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2589,3,NULL,NULL,'2026-06-05 10:12:41',400.00,400.42,398.38,106.95,121.90,121.20,12151.240,73.401,33.869,80.838,0.908,10.390,50.018,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.675392','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2590,3,NULL,NULL,'2026-06-05 10:17:41',399.29,401.27,398.30,109.90,123.24,119.58,12151.245,73.961,34.127,81.455,0.908,9.350,49.974,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.682300','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2591,3,NULL,NULL,'2026-06-05 10:22:41',399.83,401.72,398.14,139.77,106.14,113.53,12151.250,74.623,36.353,83.007,0.899,9.243,49.984,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.690503','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2592,3,NULL,NULL,'2026-06-05 10:27:41',400.85,400.83,399.69,116.62,97.59,96.82,12151.255,64.573,31.457,71.828,0.899,9.670,50.007,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.698484','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2593,3,NULL,NULL,'2026-06-05 10:32:41',400.33,401.92,399.47,136.35,121.57,118.08,12151.260,78.756,36.567,86.831,0.907,10.100,50.039,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.707810','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2594,3,NULL,NULL,'2026-06-05 10:37:41',400.91,401.36,399.68,136.59,95.86,112.31,12151.265,71.575,34.868,79.616,0.899,9.942,50.020,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.714608','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2595,3,NULL,NULL,'2026-06-05 10:42:41',399.27,400.38,399.96,99.06,100.18,117.39,12151.270,66.320,30.793,73.120,0.907,10.491,49.989,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.722835','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2596,3,NULL,NULL,'2026-06-05 10:47:41',399.67,401.52,399.94,113.90,113.38,101.15,12151.275,68.413,32.745,75.846,0.902,9.223,49.988,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.729822','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2597,3,NULL,NULL,'2026-06-05 10:52:41',399.49,401.71,398.12,110.77,109.36,90.64,12151.280,63.729,33.002,71.767,0.888,10.347,49.988,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.740086','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2598,3,NULL,NULL,'2026-06-05 10:57:41',400.34,400.03,398.55,107.74,128.55,111.80,12151.285,72.106,35.533,80.386,0.897,10.238,50.005,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.748499','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2599,3,NULL,NULL,'2026-06-05 11:02:41',400.45,401.25,399.18,122.56,131.35,123.80,12151.290,78.765,37.476,87.226,0.903,9.506,50.020,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.758661','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2600,3,NULL,NULL,'2026-06-05 11:07:41',399.21,400.43,398.95,137.81,124.36,88.73,12151.295,73.498,34.126,81.034,0.907,10.290,50.011,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.767175','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2601,3,NULL,NULL,'2026-06-05 11:12:41',400.11,400.44,399.71,136.03,104.89,117.66,12151.300,74.030,37.103,82.808,0.894,10.325,50.021,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.776187','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2602,3,NULL,NULL,'2026-06-05 11:17:41',399.47,401.56,399.84,100.57,131.27,105.20,12151.305,69.350,35.337,77.834,0.891,10.552,50.028,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.782722','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2603,3,NULL,NULL,'2026-06-05 11:22:41',400.69,400.11,398.24,120.15,99.94,98.43,12151.310,66.422,31.603,73.557,0.903,10.444,49.997,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.792429','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2604,3,NULL,NULL,'2026-06-05 11:27:41',399.89,401.88,399.20,137.91,123.86,124.62,12151.315,79.683,40.159,89.231,0.893,9.350,49.970,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.799194','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2605,3,NULL,NULL,'2026-06-05 11:32:41',400.39,400.03,399.39,122.86,132.84,91.47,12151.320,71.194,36.867,80.173,0.888,10.746,49.989,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.807785','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2606,3,NULL,NULL,'2026-06-05 11:37:41',399.69,401.08,399.19,124.61,123.99,122.30,12151.325,77.002,37.512,85.653,0.899,10.694,49.970,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.815083','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2607,3,NULL,NULL,'2026-06-05 11:42:41',400.65,400.97,399.27,109.43,117.51,93.95,12151.330,66.397,32.906,74.104,0.896,9.654,50.008,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.825166','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2608,3,NULL,NULL,'2026-06-05 11:47:41',400.46,401.79,398.79,100.54,124.83,113.58,12151.068,69.743,35.537,78.275,0.891,10.381,50.030,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.842597','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2609,3,NULL,NULL,'2026-06-05 11:52:41',399.12,400.54,399.23,101.09,105.75,99.60,12151.072,63.195,31.849,70.767,0.893,10.815,49.967,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.851766','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2610,3,NULL,NULL,'2026-06-05 11:57:41',399.49,400.71,399.71,126.14,105.28,107.43,12151.076,69.801,35.373,78.252,0.892,9.864,50.005,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.862230','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2611,3,NULL,NULL,'2026-06-05 12:02:41',400.42,401.47,398.77,128.36,131.81,110.42,12150.540,75.397,40.490,85.581,0.881,11.434,50.003,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.870525','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2612,3,NULL,NULL,'2026-06-05 12:07:41',399.58,400.19,398.97,104.55,132.28,99.29,12150.542,68.850,35.843,77.621,0.887,11.345,50.002,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.879638','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2613,3,NULL,NULL,'2026-06-05 12:12:41',400.46,400.31,399.65,127.05,110.55,91.22,12150.544,66.064,37.440,75.936,0.870,11.860,50.027,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.887722','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2614,3,NULL,NULL,'2026-06-05 12:17:41',400.76,401.96,399.63,107.23,124.30,93.20,12150.546,66.367,34.915,74.991,0.885,12.295,49.975,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.895433','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2615,3,NULL,NULL,'2026-06-05 12:22:41',399.70,401.22,398.04,118.07,128.42,122.04,12150.548,74.553,41.048,85.106,0.876,11.657,50.010,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.902272','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2616,3,NULL,NULL,'2026-06-05 12:27:41',400.14,400.54,398.51,137.24,127.27,103.92,12150.550,74.788,40.569,85.083,0.879,11.903,49.980,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.915205','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2617,3,NULL,NULL,'2026-06-05 12:32:41',399.25,401.42,399.34,125.60,129.93,109.00,12150.552,73.996,40.140,84.182,0.879,11.588,49.985,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.924585','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2618,3,NULL,NULL,'2026-06-05 12:37:41',400.73,401.28,399.83,102.52,127.19,119.33,12150.554,70.529,39.023,80.605,0.875,12.050,49.985,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.933020','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2619,3,NULL,NULL,'2026-06-05 12:42:41',399.83,400.92,398.04,125.89,123.09,114.63,12150.556,72.886,41.697,83.970,0.868,11.113,50.004,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.946568','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2620,3,NULL,NULL,'2026-06-05 12:47:41',400.32,400.13,399.82,112.49,115.51,114.93,12150.558,69.374,38.196,79.194,0.876,11.544,49.968,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.955654','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2621,3,NULL,NULL,'2026-06-05 12:52:41',399.19,400.94,399.30,138.08,112.97,111.59,12150.560,73.947,39.308,83.745,0.883,11.859,49.988,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.963902','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2622,3,NULL,NULL,'2026-06-05 12:57:41',399.56,401.91,399.83,127.38,113.89,105.98,12150.562,70.007,39.111,80.191,0.873,12.164,49.998,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.974195','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2623,3,NULL,NULL,'2026-06-05 13:02:41',400.20,401.18,398.20,136.25,132.86,94.28,12151.410,74.856,37.934,83.919,0.892,10.175,50.012,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.981882','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2624,3,NULL,NULL,'2026-06-05 13:07:41',399.50,401.73,398.90,140.29,107.41,118.08,12151.415,76.193,36.469,84.471,0.902,9.812,50.028,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.990444','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2625,3,NULL,NULL,'2026-06-05 13:12:41',399.39,400.95,398.14,138.18,103.35,104.70,12151.420,71.641,35.505,79.956,0.896,9.300,50.017,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:42.998778','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2626,3,NULL,NULL,'2026-06-05 13:17:41',399.52,400.35,398.05,119.12,96.65,124.22,12151.425,70.821,33.898,78.516,0.902,9.490,49.972,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:43.007603','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2627,3,NULL,NULL,'2026-06-05 13:22:41',400.12,401.97,399.78,120.15,121.25,121.35,12151.430,75.478,36.342,83.771,0.901,9.467,50.033,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:43.014407','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2628,3,NULL,NULL,'2026-06-05 13:27:41',400.18,400.61,398.83,112.79,95.45,96.99,12151.435,63.932,29.684,70.487,0.907,10.321,49.989,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-05 13:27:43.023079','2026-06-06 08:56:00.755286','eq-report-seed',NULL,NULL),
(2629,3,NULL,NULL,'2026-06-06 10:48:38',220.00,NULL,NULL,NULL,NULL,NULL,100.000,1100.000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-06 19:48:38.472856','2026-06-06 19:48:38.472856','Auto ge-monitor',NULL,'GE2024010007'),
(2630,3,NULL,NULL,'2026-06-06 11:01:26',220.00,221.00,219.00,5.20,5.10,5.30,100.000,1100.000,250.000,1128.000,0.980,2.500,50.000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-06 20:01:26.742390','2026-06-06 20:01:26.742390','Auto ge-monitor',NULL,'GE2024010007'),
(2631,3,NULL,NULL,'2026-06-06 11:03:23',220.00,221.00,219.00,5.20,5.10,5.30,100.000,1100.000,250.000,1128.000,0.980,2.500,50.000,218.00,219.00,217.00,NULL,NULL,NULL,80.000,890.000,180.000,908.000,0.990,1.800,50.000,20.000,10.2700,'2026-06-06 20:03:23.939288','2026-06-06 20:03:23.939288','Auto ge-monitor',NULL,'GE2024010007'),
(2632,4,NULL,NULL,'2026-06-06 11:12:34',228.00,227.00,229.00,8.50,8.20,8.70,1250.000,1850.000,420.000,1900.000,0.970,3.100,50.020,220.00,221.00,219.00,NULL,NULL,NULL,980.000,1320.000,NULL,NULL,NULL,1.900,NULL,270.000,138.6450,'2026-06-06 20:12:34.456405','2026-06-06 20:12:34.456405','Auto ge-monitor',NULL,NULL),
(2633,5,NULL,NULL,'2026-06-06 11:12:47',215.00,216.00,214.00,12.50,12.10,12.30,3420.000,2650.000,680.000,2730.000,0.940,4.800,49.980,218.00,219.00,217.00,NULL,NULL,NULL,2810.000,1940.000,NULL,NULL,NULL,2.200,NULL,610.000,313.2350,'2026-06-06 20:12:47.127869','2026-06-06 20:12:47.127869','Auto ge-monitor',NULL,'00000'),
(2634,3,NULL,NULL,'2026-06-06 11:12:55',220.00,221.00,219.00,5.20,5.10,5.30,100.000,1100.000,250.000,1128.000,0.980,2.500,50.000,218.00,219.00,217.00,NULL,NULL,NULL,80.000,890.000,NULL,NULL,NULL,1.800,NULL,20.000,10.2700,'2026-06-06 20:12:55.078704','2026-06-06 20:12:55.078704','Auto ge-monitor',NULL,'GE2024010007'),
(2635,2,NULL,NULL,'2026-06-06 11:26:58',229.00,228.00,230.00,8.10,7.90,8.20,12450.000,3050.000,1000.000,3210.000,0.950,2.400,50.000,229.00,228.00,230.00,NULL,NULL,NULL,12450.000,3050.000,1000.000,3210.000,0.950,2.400,50.000,0.000,0.0000,'2026-06-06 20:26:58.753718','2026-06-06 20:26:58.753718','Auto ge-monitor',NULL,'GE2024010002'),
(2636,3,NULL,NULL,'2026-06-06 11:35:20',248.00,235.00,221.00,12.80,8.50,6.20,12450.000,4200.000,2100.000,4700.000,0.890,8.500,50.180,229.00,228.00,230.00,NULL,NULL,NULL,12450.000,3050.000,1000.000,3210.000,0.950,2.400,50.000,0.000,0.0000,'2026-06-06 20:35:20.450738','2026-06-06 20:35:20.450738','Auto ge-monitor',NULL,'GE2024010007'),
(2637,5,NULL,NULL,'2026-06-06 15:47:18',229.00,228.00,230.00,8.10,7.90,8.20,12450.000,3050.000,1000.000,3210.000,0.950,2.400,50.000,229.00,228.00,230.00,NULL,NULL,NULL,12450.000,3050.000,1000.000,3210.000,0.950,2.400,50.000,0.000,0.0000,'2026-06-07 00:47:18.107273','2026-06-07 00:47:18.107273','Auto ge-monitor',NULL,'00000'),
(2638,5,NULL,NULL,'2026-06-06 15:52:13',229.00,228.00,230.00,8.10,7.90,8.20,12450.000,3050.000,1000.000,3210.000,0.950,2.400,50.000,229.00,228.00,230.00,NULL,NULL,NULL,12450.000,3050.000,1000.000,3210.000,0.950,2.400,50.000,0.000,0.0000,'2026-06-07 00:52:13.500353','2026-06-07 00:52:13.500353','Auto ge-monitor',NULL,'00000'),
(2639,5,NULL,NULL,'2026-06-06 16:00:57',229.00,228.00,230.00,8.10,7.90,8.20,12450.000,3050.000,1000.000,3210.000,0.950,2.400,50.000,229.00,228.00,230.00,8.10,7.90,8.20,12450.000,3050.000,1000.000,3210.000,0.950,2.400,50.000,0.000,0.0000,'2026-06-07 01:00:57.609008','2026-06-07 01:00:57.609008','Auto ge-monitor',NULL,'00000'),
(2640,5,NULL,NULL,'2026-06-07 07:50:59',231.50,NULL,NULL,9.90,NULL,NULL,13100.000,NULL,NULL,NULL,NULL,2.100,NULL,NULL,NULL,NULL,9.90,NULL,NULL,13100.000,NULL,NULL,NULL,NULL,NULL,NULL,0.000,0.0000,'2026-06-07 16:50:59.166337','2026-06-07 16:50:59.166337','Auto ge-monitor',NULL,'00000');
/*!40000 ALTER TABLE `power_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `power_records_preinstall`
--

DROP TABLE IF EXISTS `power_records_preinstall`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `power_records_preinstall` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(11) NOT NULL,
  `record_time` datetime NOT NULL,
  `before_L1` decimal(10,2) DEFAULT NULL,
  `before_L2` decimal(10,2) DEFAULT NULL,
  `before_L3` decimal(10,2) DEFAULT NULL,
  `before_current_L1` decimal(10,2) DEFAULT NULL,
  `before_current_L2` decimal(10,2) DEFAULT NULL,
  `before_current_L3` decimal(10,2) DEFAULT NULL,
  `before_kWh` decimal(12,3) DEFAULT NULL,
  `metrics_kWh` decimal(12,3) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT current_timestamp(6),
  `before_P` decimal(12,3) DEFAULT NULL,
  `before_Q` decimal(12,3) DEFAULT NULL,
  `before_S` decimal(12,3) DEFAULT NULL,
  `before_PF` decimal(6,3) DEFAULT NULL,
  `before_THD` decimal(8,3) DEFAULT NULL,
  `before_F` decimal(8,3) DEFAULT NULL,
  `metrics_current_L1` decimal(10,2) DEFAULT NULL,
  `metrics_current_L2` decimal(10,2) DEFAULT NULL,
  `metrics_current_L3` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_preinstall_device` (`device_id`),
  CONSTRAINT `fk_power_records_preinstall_device` FOREIGN KEY (`device_id`) REFERENCES `devices` (`deviceID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1804 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `power_records_preinstall`
--

LOCK TABLES `power_records_preinstall` WRITE;
/*!40000 ALTER TABLE `power_records_preinstall` DISABLE KEYS */;
INSERT INTO `power_records_preinstall` VALUES
(1,4,'2026-04-21 00:00:00',366.40,357.90,358.10,366.40,357.90,358.10,NULL,NULL,'2026-06-05 14:58:05.697850',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(2,4,'2026-04-21 00:01:00',326.40,279.50,261.10,326.40,279.50,261.10,NULL,NULL,'2026-06-05 14:58:05.708388',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(3,4,'2026-04-21 00:02:00',416.40,401.10,376.80,416.40,401.10,376.80,NULL,NULL,'2026-06-05 14:58:05.728796',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4,4,'2026-04-21 00:03:00',451.40,375.40,379.00,451.40,375.40,379.00,NULL,NULL,'2026-06-05 14:58:05.749971',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(5,4,'2026-04-21 00:05:00',367.50,384.60,352.00,367.50,384.60,352.00,NULL,NULL,'2026-06-05 14:58:05.765799',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(6,4,'2026-04-21 00:06:00',386.20,422.90,380.00,386.20,422.90,380.00,NULL,NULL,'2026-06-05 14:58:05.781302',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(7,4,'2026-04-21 00:07:00',365.90,354.50,319.70,365.90,354.50,319.70,NULL,NULL,'2026-06-05 14:58:05.797724',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(8,4,'2026-04-21 00:09:00',338.90,317.30,321.00,338.90,317.30,321.00,NULL,NULL,'2026-06-05 14:58:05.808334',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(9,4,'2026-04-21 00:11:00',460.10,388.70,402.50,460.10,388.70,402.50,NULL,NULL,'2026-06-05 14:58:05.822427',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(10,4,'2026-04-21 00:12:00',401.30,391.90,362.00,401.30,391.90,362.00,NULL,NULL,'2026-06-05 14:58:05.833986',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(11,4,'2026-04-21 00:13:00',404.90,395.20,339.30,404.90,395.20,339.30,NULL,NULL,'2026-06-05 14:58:05.861912',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(12,4,'2026-04-21 00:15:00',374.00,377.10,367.40,374.00,377.10,367.40,NULL,NULL,'2026-06-05 14:58:05.875341',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(13,4,'2026-04-21 00:16:00',392.70,403.30,354.20,392.70,403.30,354.20,NULL,NULL,'2026-06-05 14:58:05.888833',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(14,4,'2026-04-21 00:17:00',414.60,370.40,359.40,414.60,370.40,359.40,NULL,NULL,'2026-06-05 14:58:05.902371',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(15,4,'2026-04-21 00:19:00',392.20,380.70,358.60,392.20,380.70,358.60,NULL,NULL,'2026-06-05 14:58:05.917760',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(16,4,'2026-04-21 00:20:00',385.30,339.70,337.70,385.30,339.70,337.70,NULL,NULL,'2026-06-05 14:58:05.938720',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(17,4,'2026-04-21 00:21:00',455.80,440.10,439.10,455.80,440.10,439.10,NULL,NULL,'2026-06-05 14:58:05.971294',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(18,4,'2026-04-21 00:22:00',351.20,371.40,315.00,351.20,371.40,315.00,NULL,NULL,'2026-06-05 14:58:05.990535',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(19,4,'2026-04-21 00:24:00',312.80,323.00,264.20,312.80,323.00,264.20,NULL,NULL,'2026-06-05 14:58:06.008277',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(20,4,'2026-04-21 00:25:00',415.20,454.50,387.40,415.20,454.50,387.40,NULL,NULL,'2026-06-05 14:58:06.023317',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(21,4,'2026-04-21 00:26:00',441.00,384.10,397.30,441.00,384.10,397.30,NULL,NULL,'2026-06-05 14:58:06.033439',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(22,4,'2026-04-21 00:28:00',416.00,371.70,389.50,416.00,371.70,389.50,NULL,NULL,'2026-06-05 14:58:06.049967',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(23,4,'2026-04-21 00:29:00',404.60,378.90,383.10,404.60,378.90,383.10,NULL,NULL,'2026-06-05 14:58:06.061748',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(24,4,'2026-04-21 00:30:00',454.80,451.40,387.50,454.80,451.40,387.50,NULL,NULL,'2026-06-05 14:58:06.071924',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(25,4,'2026-04-21 00:32:00',413.50,457.10,400.50,413.50,457.10,400.50,NULL,NULL,'2026-06-05 14:58:06.082205',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(26,4,'2026-04-21 00:33:00',395.30,391.80,363.90,395.30,391.80,363.90,NULL,NULL,'2026-06-05 14:58:06.092552',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(27,4,'2026-04-21 00:34:00',356.20,371.50,358.70,356.20,371.50,358.70,NULL,NULL,'2026-06-05 14:58:06.106888',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(28,4,'2026-04-21 00:35:00',381.30,401.30,367.20,381.30,401.30,367.20,NULL,NULL,'2026-06-05 14:58:06.116742',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(29,4,'2026-04-21 00:36:00',407.60,376.40,318.70,407.60,376.40,318.70,NULL,NULL,'2026-06-05 14:58:06.128394',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(30,4,'2026-04-21 00:38:00',422.70,414.80,355.00,422.70,414.80,355.00,NULL,NULL,'2026-06-05 14:58:06.143427',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(31,4,'2026-04-21 00:39:00',442.10,411.50,366.10,442.10,411.50,366.10,NULL,NULL,'2026-06-05 14:58:06.157771',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(32,4,'2026-04-21 00:40:00',280.50,280.00,245.80,280.50,280.00,245.80,NULL,NULL,'2026-06-05 14:58:06.170000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(33,4,'2026-04-21 00:41:00',401.40,394.00,396.60,401.40,394.00,396.60,NULL,NULL,'2026-06-05 14:58:06.180465',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(34,4,'2026-04-21 00:43:00',398.70,414.70,416.00,398.70,414.70,416.00,NULL,NULL,'2026-06-05 14:58:06.190286',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(35,4,'2026-04-21 00:44:00',409.10,389.10,369.10,409.10,389.10,369.10,NULL,NULL,'2026-06-05 14:58:06.199535',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(36,4,'2026-04-21 00:45:00',387.00,358.50,311.70,387.00,358.50,311.70,NULL,NULL,'2026-06-05 14:58:06.209504',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(37,4,'2026-04-21 00:47:00',431.60,409.40,370.60,431.60,409.40,370.60,NULL,NULL,'2026-06-05 14:58:06.218342',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(38,4,'2026-04-21 00:48:00',433.30,415.30,401.10,433.30,415.30,401.10,NULL,NULL,'2026-06-05 14:58:06.228334',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(39,4,'2026-04-21 00:49:00',407.50,467.40,439.10,407.50,467.40,439.10,NULL,NULL,'2026-06-05 14:58:06.240860',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(40,4,'2026-04-21 00:51:00',310.60,317.10,296.70,310.60,317.10,296.70,NULL,NULL,'2026-06-05 14:58:06.253627',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(41,4,'2026-04-21 00:52:00',411.90,402.10,382.30,411.90,402.10,382.30,NULL,NULL,'2026-06-05 14:58:06.265908',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(42,4,'2026-04-21 00:53:00',408.60,453.40,442.50,408.60,453.40,442.50,NULL,NULL,'2026-06-05 14:58:06.275182',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(43,4,'2026-04-21 00:55:00',400.80,381.50,384.80,400.80,381.50,384.80,NULL,NULL,'2026-06-05 14:58:06.284332',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(44,4,'2026-04-21 00:56:00',323.10,324.20,266.60,323.10,324.20,266.60,NULL,NULL,'2026-06-05 14:58:06.296765',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(45,4,'2026-04-21 00:57:00',407.90,446.10,405.10,407.90,446.10,405.10,NULL,NULL,'2026-06-05 14:58:06.309986',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(46,4,'2026-04-21 00:59:00',420.70,403.30,412.50,420.70,403.30,412.50,NULL,NULL,'2026-06-05 14:58:06.321000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(47,4,'2026-04-21 01:00:00',345.90,338.10,364.00,345.90,338.10,364.00,NULL,NULL,'2026-06-05 14:58:06.333873',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(48,4,'2026-04-21 01:01:00',343.00,375.60,330.40,343.00,375.60,330.40,NULL,NULL,'2026-06-05 14:58:06.350589',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(49,4,'2026-04-21 01:03:00',451.40,423.70,383.80,451.40,423.70,383.80,NULL,NULL,'2026-06-05 14:58:06.359985',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(50,4,'2026-04-21 01:04:00',403.90,414.60,394.90,403.90,414.60,394.90,NULL,NULL,'2026-06-05 14:58:06.369040',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(51,4,'2026-04-21 01:05:00',398.20,402.80,373.50,398.20,402.80,373.50,NULL,NULL,'2026-06-05 14:58:06.381073',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(52,4,'2026-04-21 01:06:00',287.30,290.30,302.40,287.30,290.30,302.40,NULL,NULL,'2026-06-05 14:58:06.390997',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(53,4,'2026-04-21 01:08:00',399.60,412.10,386.70,399.60,412.10,386.70,NULL,NULL,'2026-06-05 14:58:06.400319',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(54,4,'2026-04-21 01:09:00',408.90,430.20,401.50,408.90,430.20,401.50,NULL,NULL,'2026-06-05 14:58:06.413477',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(55,4,'2026-04-21 01:10:00',307.80,345.80,321.10,307.80,345.80,321.10,NULL,NULL,'2026-06-05 14:58:06.424853',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(56,4,'2026-04-21 01:12:00',406.60,406.30,378.00,406.60,406.30,378.00,NULL,NULL,'2026-06-05 14:58:06.436401',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(57,4,'2026-04-21 01:13:00',419.90,432.10,401.30,419.90,432.10,401.30,NULL,NULL,'2026-06-05 14:58:06.448989',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(58,4,'2026-04-21 01:14:00',415.50,403.70,415.90,415.50,403.70,415.90,NULL,NULL,'2026-06-05 14:58:06.459395',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(59,4,'2026-04-21 01:15:00',405.60,388.40,348.00,405.60,388.40,348.00,NULL,NULL,'2026-06-05 14:58:06.468068',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(60,4,'2026-04-21 01:17:00',357.70,389.60,337.50,357.70,389.60,337.50,NULL,NULL,'2026-06-05 14:58:06.481144',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(61,4,'2026-04-21 01:18:00',411.50,418.30,414.80,411.50,418.30,414.80,NULL,NULL,'2026-06-05 14:58:06.493520',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(62,4,'2026-04-21 01:19:00',369.10,385.20,377.80,369.10,385.20,377.80,NULL,NULL,'2026-06-05 14:58:06.503900',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(63,4,'2026-04-21 01:21:00',406.40,408.90,370.30,406.40,408.90,370.30,NULL,NULL,'2026-06-05 14:58:06.513794',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(64,4,'2026-04-21 01:22:00',387.20,383.00,351.50,387.20,383.00,351.50,NULL,NULL,'2026-06-05 14:58:06.524388',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(65,4,'2026-04-21 01:23:00',392.40,410.00,393.40,392.40,410.00,393.40,NULL,NULL,'2026-06-05 14:58:06.536748',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(66,4,'2026-04-21 01:25:00',388.00,375.40,315.10,388.00,375.40,315.10,NULL,NULL,'2026-06-05 14:58:06.547798',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(67,4,'2026-04-21 01:26:00',345.30,347.60,322.70,345.30,347.60,322.70,NULL,NULL,'2026-06-05 14:58:06.556866',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(68,4,'2026-04-21 01:27:00',315.70,327.80,324.10,315.70,327.80,324.10,NULL,NULL,'2026-06-05 14:58:06.569126',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(69,4,'2026-04-21 01:29:00',322.70,304.40,305.90,322.70,304.40,305.90,NULL,NULL,'2026-06-05 14:58:06.578326',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(70,4,'2026-04-21 01:30:00',403.30,419.80,405.80,403.30,419.80,405.80,NULL,NULL,'2026-06-05 14:58:06.588474',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(71,4,'2026-04-21 01:31:00',386.50,358.80,313.10,386.50,358.80,313.10,NULL,NULL,'2026-06-05 14:58:06.598135',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(72,4,'2026-04-21 01:33:00',407.10,410.50,349.50,407.10,410.50,349.50,NULL,NULL,'2026-06-05 14:58:06.606535',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(73,4,'2026-04-21 01:34:00',417.10,366.70,382.90,417.10,366.70,382.90,NULL,NULL,'2026-06-05 14:58:06.616408',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(74,4,'2026-04-21 01:35:00',264.80,283.90,269.60,264.80,283.90,269.60,NULL,NULL,'2026-06-05 14:58:06.627536',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(75,4,'2026-04-21 01:37:00',366.60,410.50,354.40,366.60,410.50,354.40,NULL,NULL,'2026-06-05 14:58:06.636630',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(76,4,'2026-04-21 01:38:00',388.30,420.80,413.00,388.30,420.80,413.00,NULL,NULL,'2026-06-05 14:58:06.647475',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(77,4,'2026-04-21 01:39:00',393.90,414.30,380.40,393.90,414.30,380.40,NULL,NULL,'2026-06-05 14:58:06.657582',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(78,4,'2026-04-21 01:41:00',326.10,297.60,266.70,326.10,297.60,266.70,NULL,NULL,'2026-06-05 14:58:06.665759',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(79,4,'2026-04-21 01:42:00',427.20,396.50,384.70,427.20,396.50,384.70,NULL,NULL,'2026-06-05 14:58:06.676710',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(80,4,'2026-04-21 01:43:00',410.40,385.30,392.40,410.40,385.30,392.40,NULL,NULL,'2026-06-05 14:58:06.687980',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(81,4,'2026-04-21 01:45:00',369.80,383.70,372.90,369.80,383.70,372.90,NULL,NULL,'2026-06-05 14:58:06.697859',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(82,4,'2026-04-21 01:46:00',358.60,405.80,339.50,358.60,405.80,339.50,NULL,NULL,'2026-06-05 14:58:06.706219',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(83,4,'2026-04-21 01:47:00',323.40,338.60,312.20,323.40,338.60,312.20,NULL,NULL,'2026-06-05 14:58:06.717443',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(84,4,'2026-04-21 01:48:00',404.80,442.80,384.30,404.80,442.80,384.30,NULL,NULL,'2026-06-05 14:58:06.729559',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(85,4,'2026-04-21 01:50:00',362.00,348.80,349.00,362.00,348.80,349.00,NULL,NULL,'2026-06-05 14:58:06.738708',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(86,4,'2026-04-21 01:51:00',426.20,376.40,408.90,426.20,376.40,408.90,NULL,NULL,'2026-06-05 14:58:06.748439',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(87,4,'2026-04-21 01:52:00',300.60,343.50,306.90,300.60,343.50,306.90,NULL,NULL,'2026-06-05 14:58:06.758012',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(88,4,'2026-04-21 01:54:00',404.70,434.70,379.60,404.70,434.70,379.60,NULL,NULL,'2026-06-05 14:58:06.766704',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(89,4,'2026-04-21 01:55:00',357.60,374.80,327.10,357.60,374.80,327.10,NULL,NULL,'2026-06-05 14:58:06.777395',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(90,4,'2026-04-21 01:56:00',367.20,407.80,393.10,367.20,407.80,393.10,NULL,NULL,'2026-06-05 14:58:06.785914',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(91,4,'2026-04-21 01:58:00',446.00,418.20,387.40,446.00,418.20,387.40,NULL,NULL,'2026-06-05 14:58:06.795270',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(92,4,'2026-04-21 01:59:00',284.40,269.80,250.40,284.40,269.80,250.40,NULL,NULL,'2026-06-05 14:58:06.803197',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(93,4,'2026-04-21 02:00:00',301.80,269.20,287.10,301.80,269.20,287.10,NULL,NULL,'2026-06-05 14:58:06.813014',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(94,4,'2026-04-21 02:02:00',443.70,432.20,422.70,443.70,432.20,422.70,NULL,NULL,'2026-06-05 14:58:06.821104',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(95,4,'2026-04-21 02:03:00',337.40,378.70,345.70,337.40,378.70,345.70,NULL,NULL,'2026-06-05 14:58:06.830316',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(96,4,'2026-04-21 02:04:00',416.80,440.60,378.90,416.80,440.60,378.90,NULL,NULL,'2026-06-05 14:58:06.841598',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(97,4,'2026-04-21 02:06:00',398.90,398.80,405.60,398.90,398.80,405.60,NULL,NULL,'2026-06-05 14:58:06.852486',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(98,4,'2026-04-21 02:07:00',386.60,400.10,387.90,386.60,400.10,387.90,NULL,NULL,'2026-06-05 14:58:06.863900',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(99,4,'2026-04-21 02:08:00',342.20,310.20,306.80,342.20,310.20,306.80,NULL,NULL,'2026-06-05 14:58:06.872303',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(100,4,'2026-04-21 02:10:00',402.00,382.30,384.40,402.00,382.30,384.40,NULL,NULL,'2026-06-05 14:58:06.882401',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(101,4,'2026-04-21 02:11:00',316.20,341.80,322.50,316.20,341.80,322.50,NULL,NULL,'2026-06-05 14:58:06.891959',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(102,4,'2026-04-21 02:13:00',412.00,432.70,392.30,412.00,432.70,392.30,NULL,NULL,'2026-06-05 14:58:06.899916',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(103,4,'2026-04-21 02:14:00',374.10,416.00,367.50,374.10,416.00,367.50,NULL,NULL,'2026-06-05 14:58:06.909543',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(104,4,'2026-04-21 02:15:00',417.80,385.80,382.90,417.80,385.80,382.90,NULL,NULL,'2026-06-05 14:58:06.920418',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(105,4,'2026-04-21 02:17:00',352.60,358.60,374.60,352.60,358.60,374.60,NULL,NULL,'2026-06-05 14:58:06.931744',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(106,4,'2026-04-21 02:18:00',308.30,340.90,315.20,308.30,340.90,315.20,NULL,NULL,'2026-06-05 14:58:06.942077',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(107,4,'2026-04-21 02:19:00',463.30,432.10,415.90,463.30,432.10,415.90,NULL,NULL,'2026-06-05 14:58:06.951320',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(108,4,'2026-04-21 02:21:00',378.60,446.70,369.10,378.60,446.70,369.10,NULL,NULL,'2026-06-05 14:58:06.963240',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(109,4,'2026-04-21 02:22:00',360.20,366.10,392.20,360.20,366.10,392.20,NULL,NULL,'2026-06-05 14:58:06.973886',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(110,4,'2026-04-21 02:23:00',449.00,412.30,421.60,449.00,412.30,421.60,NULL,NULL,'2026-06-05 14:58:06.983872',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(111,4,'2026-04-21 02:25:00',361.10,328.80,323.70,361.10,328.80,323.70,NULL,NULL,'2026-06-05 14:58:07.003053',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(112,4,'2026-04-21 02:26:00',398.60,363.60,333.20,398.60,363.60,333.20,NULL,NULL,'2026-06-05 14:58:07.013930',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(113,4,'2026-04-21 02:27:00',358.00,378.70,327.20,358.00,378.70,327.20,NULL,NULL,'2026-06-05 14:58:07.025147',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(114,4,'2026-04-21 02:28:00',441.20,444.80,415.20,441.20,444.80,415.20,NULL,NULL,'2026-06-05 14:58:07.039791',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(115,4,'2026-04-21 02:30:00',386.30,393.80,376.30,386.30,393.80,376.30,NULL,NULL,'2026-06-05 14:58:07.055164',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(116,4,'2026-04-21 02:31:00',370.10,410.40,387.90,370.10,410.40,387.90,NULL,NULL,'2026-06-05 14:58:07.066256',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(117,4,'2026-04-21 02:32:00',376.40,384.10,353.80,376.40,384.10,353.80,NULL,NULL,'2026-06-05 14:58:07.080537',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(118,4,'2026-04-21 02:34:00',413.80,410.50,381.00,413.80,410.50,381.00,NULL,NULL,'2026-06-05 14:58:07.101690',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(119,4,'2026-04-21 02:35:00',417.60,374.30,382.80,417.60,374.30,382.80,NULL,NULL,'2026-06-05 14:58:07.113951',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(120,4,'2026-04-21 02:36:00',310.60,309.00,317.80,310.60,309.00,317.80,NULL,NULL,'2026-06-05 14:58:07.124999',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(121,4,'2026-04-21 02:37:00',276.40,301.60,239.40,276.40,301.60,239.40,NULL,NULL,'2026-06-05 14:58:07.140039',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(122,4,'2026-04-21 02:39:00',416.20,420.10,388.40,416.20,420.10,388.40,NULL,NULL,'2026-06-05 14:58:07.154222',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(123,4,'2026-04-21 02:40:00',363.50,407.10,369.30,363.50,407.10,369.30,NULL,NULL,'2026-06-05 14:58:07.175056',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(124,4,'2026-04-21 02:41:00',399.70,372.10,371.00,399.70,372.10,371.00,NULL,NULL,'2026-06-05 14:58:07.195325',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(125,4,'2026-04-21 02:43:00',456.30,419.40,399.50,456.30,419.40,399.50,NULL,NULL,'2026-06-05 14:58:07.206753',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(126,4,'2026-04-21 02:44:00',391.60,402.60,353.80,391.60,402.60,353.80,NULL,NULL,'2026-06-05 14:58:07.223027',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(127,4,'2026-04-21 02:46:00',368.50,354.50,326.00,368.50,354.50,326.00,NULL,NULL,'2026-06-05 14:58:07.238643',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(128,4,'2026-04-21 02:47:00',419.00,459.90,422.40,419.00,459.90,422.40,NULL,NULL,'2026-06-05 14:58:07.264077',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(129,4,'2026-04-21 02:48:00',401.20,448.20,405.60,401.20,448.20,405.60,NULL,NULL,'2026-06-05 14:58:07.277389',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(130,4,'2026-04-21 02:49:00',381.20,368.40,325.00,381.20,368.40,325.00,NULL,NULL,'2026-06-05 14:58:07.289031',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(131,4,'2026-04-21 02:51:00',424.10,420.10,422.50,424.10,420.10,422.50,NULL,NULL,'2026-06-05 14:58:07.308921',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(132,4,'2026-04-21 02:52:00',414.30,373.50,383.60,414.30,373.50,383.60,NULL,NULL,'2026-06-05 14:58:07.320761',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(133,4,'2026-04-21 02:53:00',454.80,434.70,416.30,454.80,434.70,416.30,NULL,NULL,'2026-06-05 14:58:07.338383',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(134,4,'2026-04-21 02:55:00',360.60,411.80,358.30,360.60,411.80,358.30,NULL,NULL,'2026-06-05 14:58:07.356329',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(135,4,'2026-04-21 02:56:00',395.90,394.10,362.80,395.90,394.10,362.80,NULL,NULL,'2026-06-05 14:58:07.368114',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(136,4,'2026-04-21 02:57:00',393.00,448.40,409.20,393.00,448.40,409.20,NULL,NULL,'2026-06-05 14:58:07.385715',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(137,4,'2026-04-21 02:58:00',349.90,367.70,349.50,349.90,367.70,349.50,NULL,NULL,'2026-06-05 14:58:07.399546',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(138,4,'2026-04-21 03:00:00',316.00,285.70,259.10,316.00,285.70,259.10,NULL,NULL,'2026-06-05 14:58:07.416233',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(139,4,'2026-04-21 03:01:00',423.50,407.90,376.50,423.50,407.90,376.50,NULL,NULL,'2026-06-05 14:58:07.430700',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(140,4,'2026-04-21 03:02:00',473.90,414.30,417.00,473.90,414.30,417.00,NULL,NULL,'2026-06-05 14:58:07.442956',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(141,4,'2026-04-21 03:04:00',410.70,422.30,395.00,410.70,422.30,395.00,NULL,NULL,'2026-06-05 14:58:07.465562',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(142,4,'2026-04-21 03:05:00',380.40,421.40,381.20,380.40,421.40,381.20,NULL,NULL,'2026-06-05 14:58:07.488627',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(143,4,'2026-04-21 03:06:00',417.40,393.10,361.50,417.40,393.10,361.50,NULL,NULL,'2026-06-05 14:58:07.509704',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(144,4,'2026-04-21 03:08:00',309.20,327.10,338.40,309.20,327.10,338.40,NULL,NULL,'2026-06-05 14:58:07.520734',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(145,4,'2026-04-21 03:09:00',417.50,399.80,400.80,417.50,399.80,400.80,NULL,NULL,'2026-06-05 14:58:07.538317',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(146,4,'2026-04-21 03:10:00',463.90,422.80,402.60,463.90,422.80,402.60,NULL,NULL,'2026-06-05 14:58:07.555789',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(147,4,'2026-04-21 03:11:00',424.80,450.80,411.00,424.80,450.80,411.00,NULL,NULL,'2026-06-05 14:58:07.573075',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(148,4,'2026-04-21 03:13:00',416.00,448.20,391.90,416.00,448.20,391.90,NULL,NULL,'2026-06-05 14:58:07.586920',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(149,4,'2026-04-21 03:14:00',251.60,308.60,291.70,251.60,308.60,291.70,NULL,NULL,'2026-06-05 14:58:07.605553',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(150,4,'2026-04-21 03:16:00',316.30,373.10,353.20,316.30,373.10,353.20,NULL,NULL,'2026-06-05 14:58:07.629315',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(151,4,'2026-04-21 03:17:00',472.20,471.60,450.10,472.20,471.60,450.10,NULL,NULL,'2026-06-05 14:58:07.645295',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(152,4,'2026-04-21 03:18:00',415.00,443.10,414.20,415.00,443.10,414.20,NULL,NULL,'2026-06-05 14:58:07.658954',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(153,4,'2026-04-21 03:19:00',393.70,412.30,362.80,393.70,412.30,362.80,NULL,NULL,'2026-06-05 14:58:07.670185',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(154,4,'2026-04-21 03:21:00',469.80,438.80,443.90,469.80,438.80,443.90,NULL,NULL,'2026-06-05 14:58:07.682090',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(155,4,'2026-04-21 03:22:00',306.70,338.40,363.10,306.70,338.40,363.10,NULL,NULL,'2026-06-05 14:58:07.692885',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(156,4,'2026-04-21 03:23:00',419.80,392.20,406.60,419.80,392.20,406.60,NULL,NULL,'2026-06-05 14:58:07.704182',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(157,4,'2026-04-21 03:24:00',355.80,385.00,340.90,355.80,385.00,340.90,NULL,NULL,'2026-06-05 14:58:07.719647',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(158,4,'2026-04-21 03:26:00',423.80,451.30,398.10,423.80,451.30,398.10,NULL,NULL,'2026-06-05 14:58:07.735154',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(159,4,'2026-04-21 03:27:00',434.90,424.40,379.40,434.90,424.40,379.40,NULL,NULL,'2026-06-05 14:58:07.745957',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(160,4,'2026-04-21 03:28:00',314.90,327.00,324.70,314.90,327.00,324.70,NULL,NULL,'2026-06-05 14:58:07.758391',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(161,4,'2026-04-21 03:30:00',414.30,369.70,368.10,414.30,369.70,368.10,NULL,NULL,'2026-06-05 14:58:07.770158',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(162,4,'2026-04-21 03:31:00',421.90,423.80,400.90,421.90,423.80,400.90,NULL,NULL,'2026-06-05 14:58:07.781605',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(163,4,'2026-04-21 03:33:00',348.20,375.40,340.60,348.20,375.40,340.60,NULL,NULL,'2026-06-05 14:58:07.794252',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(164,4,'2026-04-21 03:34:00',402.30,423.70,417.10,402.30,423.70,417.10,NULL,NULL,'2026-06-05 14:58:07.806243',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(165,4,'2026-04-21 03:35:00',392.70,371.70,327.50,392.70,371.70,327.50,NULL,NULL,'2026-06-05 14:58:07.816806',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(166,4,'2026-04-21 03:36:00',431.70,431.60,383.40,431.70,431.60,383.40,NULL,NULL,'2026-06-05 14:58:07.831952',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(167,4,'2026-04-21 03:38:00',394.80,355.30,391.70,394.80,355.30,391.70,NULL,NULL,'2026-06-05 14:58:07.848172',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(168,4,'2026-04-21 03:39:00',372.00,382.20,387.90,372.00,382.20,387.90,NULL,NULL,'2026-06-05 14:58:07.863612',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(169,4,'2026-04-21 03:40:00',403.70,394.90,414.00,403.70,394.90,414.00,NULL,NULL,'2026-06-05 14:58:07.878228',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(170,4,'2026-04-21 03:42:00',376.10,396.50,345.40,376.10,396.50,345.40,NULL,NULL,'2026-06-05 14:58:07.894547',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(171,4,'2026-04-21 03:43:00',331.40,374.20,318.00,331.40,374.20,318.00,NULL,NULL,'2026-06-05 14:58:07.904400',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(172,4,'2026-04-21 03:44:00',376.00,356.70,331.10,376.00,356.70,331.10,NULL,NULL,'2026-06-05 14:58:07.918640',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(173,4,'2026-04-21 03:45:00',417.20,405.40,384.30,417.20,405.40,384.30,NULL,NULL,'2026-06-05 14:58:07.932295',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(174,4,'2026-04-21 03:47:00',362.90,349.30,303.40,362.90,349.30,303.40,NULL,NULL,'2026-06-05 14:58:07.959823',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(175,4,'2026-04-21 03:48:00',350.30,321.70,302.80,350.30,321.70,302.80,NULL,NULL,'2026-06-05 14:58:07.972060',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(176,4,'2026-04-21 03:50:00',387.40,415.40,361.60,387.40,415.40,361.60,NULL,NULL,'2026-06-05 14:58:07.986060',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(177,4,'2026-04-21 03:51:00',275.60,303.40,246.50,275.60,303.40,246.50,NULL,NULL,'2026-06-05 14:58:07.998632',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(178,4,'2026-04-21 03:52:00',396.60,379.50,331.90,396.60,379.50,331.90,NULL,NULL,'2026-06-05 14:58:08.010722',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(179,4,'2026-04-21 03:54:00',389.90,392.00,387.90,389.90,392.00,387.90,NULL,NULL,'2026-06-05 14:58:08.025133',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(180,4,'2026-04-21 03:55:00',370.50,324.80,323.60,370.50,324.80,323.60,NULL,NULL,'2026-06-05 14:58:08.035482',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(181,4,'2026-04-21 03:56:00',405.00,383.30,394.10,405.00,383.30,394.10,NULL,NULL,'2026-06-05 14:58:08.047909',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(182,4,'2026-04-21 03:57:00',375.60,355.00,360.20,375.60,355.00,360.20,NULL,NULL,'2026-06-05 14:58:08.060434',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(183,4,'2026-04-21 03:59:00',325.10,325.60,304.10,325.10,325.60,304.10,NULL,NULL,'2026-06-05 14:58:08.070115',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(184,4,'2026-04-21 04:00:00',395.60,429.70,359.80,395.60,429.70,359.80,NULL,NULL,'2026-06-05 14:58:08.079445',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(185,4,'2026-04-21 04:01:00',412.70,389.60,369.10,412.70,389.60,369.10,NULL,NULL,'2026-06-05 14:58:08.090938',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(186,4,'2026-04-21 04:03:00',335.60,350.70,325.00,335.60,350.70,325.00,NULL,NULL,'2026-06-05 14:58:08.102016',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(187,4,'2026-04-21 04:04:00',432.80,422.40,368.90,432.80,422.40,368.90,NULL,NULL,'2026-06-05 14:58:08.112162',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(188,4,'2026-04-21 04:05:00',383.80,358.90,358.70,383.80,358.90,358.70,NULL,NULL,'2026-06-05 14:58:08.123158',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(189,4,'2026-04-21 04:06:00',264.50,303.00,298.70,264.50,303.00,298.70,NULL,NULL,'2026-06-05 14:58:08.136139',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(190,4,'2026-04-21 04:08:00',416.90,396.10,401.10,416.90,396.10,401.10,NULL,NULL,'2026-06-05 14:58:08.147028',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(191,4,'2026-04-21 04:09:00',388.10,443.00,381.20,388.10,443.00,381.20,NULL,NULL,'2026-06-05 14:58:08.159168',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(192,4,'2026-04-21 04:10:00',312.00,326.30,263.20,312.00,326.30,263.20,NULL,NULL,'2026-06-05 14:58:08.169301',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(193,4,'2026-04-21 04:12:00',449.90,432.20,436.50,449.90,432.20,436.50,NULL,NULL,'2026-06-05 14:58:08.181623',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(194,4,'2026-04-21 04:13:00',421.00,414.90,417.00,421.00,414.90,417.00,NULL,NULL,'2026-06-05 14:58:08.195424',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(195,4,'2026-04-21 04:14:00',308.40,290.90,282.20,308.40,290.90,282.20,NULL,NULL,'2026-06-05 14:58:08.208663',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(196,4,'2026-04-21 04:16:00',353.10,374.50,337.50,353.10,374.50,337.50,NULL,NULL,'2026-06-05 14:58:08.218514',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(197,4,'2026-04-21 04:17:00',418.70,421.50,417.20,418.70,421.50,417.20,NULL,NULL,'2026-06-05 14:58:08.229055',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(198,4,'2026-04-21 04:18:00',328.40,380.30,353.50,328.40,380.30,353.50,NULL,NULL,'2026-06-05 14:58:08.244684',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(199,4,'2026-04-21 04:20:00',410.30,396.30,344.90,410.30,396.30,344.90,NULL,NULL,'2026-06-05 14:58:08.255814',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(200,4,'2026-04-21 04:21:00',360.30,387.80,353.70,360.30,387.80,353.70,NULL,NULL,'2026-06-05 14:58:08.266333',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(201,4,'2026-04-21 04:22:00',394.90,427.50,360.10,394.90,427.50,360.10,NULL,NULL,'2026-06-05 14:58:08.279855',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(202,4,'2026-04-21 04:24:00',358.90,371.20,367.00,358.90,371.20,367.00,NULL,NULL,'2026-06-05 14:58:08.292509',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(203,4,'2026-04-21 04:25:00',353.30,369.00,349.60,353.30,369.00,349.60,NULL,NULL,'2026-06-05 14:58:08.302153',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(204,4,'2026-04-21 04:26:00',401.80,420.90,389.90,401.80,420.90,389.90,NULL,NULL,'2026-06-05 14:58:08.313552',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(205,4,'2026-04-21 04:28:00',412.70,382.70,364.90,412.70,382.70,364.90,NULL,NULL,'2026-06-05 14:58:08.327654',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(206,4,'2026-04-21 04:29:00',381.60,386.60,367.70,381.60,386.60,367.70,NULL,NULL,'2026-06-05 14:58:08.338441',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(207,4,'2026-04-21 04:30:00',443.30,414.00,365.10,443.30,414.00,365.10,NULL,NULL,'2026-06-05 14:58:08.350088',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(208,4,'2026-04-21 04:31:00',350.60,367.40,314.10,350.60,367.40,314.10,NULL,NULL,'2026-06-05 14:58:08.364238',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(209,4,'2026-04-21 04:33:00',352.90,375.30,361.40,352.90,375.30,361.40,NULL,NULL,'2026-06-05 14:58:08.378739',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(210,4,'2026-04-21 04:34:00',361.60,365.90,367.40,361.60,365.90,367.40,NULL,NULL,'2026-06-05 14:58:08.393552',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(211,4,'2026-04-21 04:35:00',373.40,360.20,354.70,373.40,360.20,354.70,NULL,NULL,'2026-06-05 14:58:08.403715',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(212,4,'2026-04-21 04:37:00',398.40,404.60,368.90,398.40,404.60,368.90,NULL,NULL,'2026-06-05 14:58:08.432089',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(213,4,'2026-04-21 04:38:00',385.90,400.10,354.10,385.90,400.10,354.10,NULL,NULL,'2026-06-05 14:58:08.448649',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(214,4,'2026-04-21 04:39:00',447.30,419.80,396.40,447.30,419.80,396.40,NULL,NULL,'2026-06-05 14:58:08.482166',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(215,4,'2026-04-21 04:41:00',422.70,429.90,413.90,422.70,429.90,413.90,NULL,NULL,'2026-06-05 14:58:08.493602',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(216,4,'2026-04-21 04:42:00',359.00,358.20,316.00,359.00,358.20,316.00,NULL,NULL,'2026-06-05 14:58:08.509713',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(217,4,'2026-04-21 04:43:00',324.80,341.20,335.70,324.80,341.20,335.70,NULL,NULL,'2026-06-05 14:58:08.520352',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(218,4,'2026-04-21 04:44:00',360.10,350.50,315.90,360.10,350.50,315.90,NULL,NULL,'2026-06-05 14:58:08.533195',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(219,4,'2026-04-21 04:46:00',438.00,399.40,393.00,438.00,399.40,393.00,NULL,NULL,'2026-06-05 14:58:08.545037',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(220,4,'2026-04-21 04:47:00',353.90,377.80,314.50,353.90,377.80,314.50,NULL,NULL,'2026-06-05 14:58:08.562727',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(221,4,'2026-04-21 04:48:00',305.00,304.90,246.50,305.00,304.90,246.50,NULL,NULL,'2026-06-05 14:58:08.575129',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(222,4,'2026-04-21 04:50:00',405.50,419.00,393.80,405.50,419.00,393.80,NULL,NULL,'2026-06-05 14:58:08.587008',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(223,4,'2026-04-21 04:51:00',387.70,413.40,398.00,387.70,413.40,398.00,NULL,NULL,'2026-06-05 14:58:08.597380',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(224,4,'2026-04-21 04:52:00',361.90,345.00,315.70,361.90,345.00,315.70,NULL,NULL,'2026-06-05 14:58:08.607721',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(225,4,'2026-04-21 04:54:00',377.20,341.20,323.10,377.20,341.20,323.10,NULL,NULL,'2026-06-05 14:58:08.622061',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(226,4,'2026-04-21 04:55:00',454.20,391.30,373.00,454.20,391.30,373.00,NULL,NULL,'2026-06-05 14:58:08.634176',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(227,4,'2026-04-21 04:56:00',408.90,371.20,351.60,408.90,371.20,351.60,NULL,NULL,'2026-06-05 14:58:08.645807',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(228,4,'2026-04-21 04:58:00',336.40,336.40,292.40,336.40,336.40,292.40,NULL,NULL,'2026-06-05 14:58:08.659533',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(229,4,'2026-04-21 04:59:00',439.90,431.00,393.60,439.90,431.00,393.60,NULL,NULL,'2026-06-05 14:58:08.670871',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(230,4,'2026-04-21 05:00:00',376.70,418.70,356.80,376.70,418.70,356.80,NULL,NULL,'2026-06-05 14:58:08.681340',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(231,4,'2026-04-21 05:02:00',330.60,342.20,354.00,330.60,342.20,354.00,NULL,NULL,'2026-06-05 14:58:08.692070',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(232,4,'2026-04-21 05:03:00',436.50,388.60,398.70,436.50,388.60,398.70,NULL,NULL,'2026-06-05 14:58:08.705774',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(233,4,'2026-04-21 05:04:00',412.60,391.70,400.60,412.60,391.70,400.60,NULL,NULL,'2026-06-05 14:58:08.716621',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(234,4,'2026-04-21 05:05:00',433.10,382.30,389.50,433.10,382.30,389.50,NULL,NULL,'2026-06-05 14:58:08.727508',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(235,4,'2026-04-21 05:07:00',415.70,399.90,380.10,415.70,399.90,380.10,NULL,NULL,'2026-06-05 14:58:08.739060',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(236,4,'2026-04-21 05:09:00',294.10,271.70,247.30,294.10,271.70,247.30,NULL,NULL,'2026-06-05 14:58:08.750707',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(237,4,'2026-04-21 05:10:00',393.30,388.20,382.40,393.30,388.20,382.40,NULL,NULL,'2026-06-05 14:58:08.761515',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(238,4,'2026-04-21 05:11:00',406.90,437.40,411.60,406.90,437.40,411.60,NULL,NULL,'2026-06-05 14:58:08.775329',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(239,4,'2026-04-21 05:13:00',430.20,436.00,406.50,430.20,436.00,406.50,NULL,NULL,'2026-06-05 14:58:08.786065',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(240,4,'2026-04-21 05:14:00',399.70,382.20,326.50,399.70,382.20,326.50,NULL,NULL,'2026-06-05 14:58:08.797376',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(241,4,'2026-04-21 05:15:00',443.60,444.70,387.70,443.60,444.70,387.70,NULL,NULL,'2026-06-05 14:58:08.811248',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(242,4,'2026-04-21 05:17:00',453.10,427.80,426.10,453.10,427.80,426.10,NULL,NULL,'2026-06-05 14:58:08.822403',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(243,4,'2026-04-21 05:18:00',286.90,318.30,300.40,286.90,318.30,300.40,NULL,NULL,'2026-06-05 14:58:08.833798',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(244,4,'2026-04-21 05:19:00',357.50,357.40,364.10,357.50,357.40,364.10,NULL,NULL,'2026-06-05 14:58:08.852503',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(245,4,'2026-04-21 05:20:00',421.60,408.30,385.90,421.60,408.30,385.90,NULL,NULL,'2026-06-05 14:58:08.863652',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(246,4,'2026-04-21 05:22:00',436.30,441.20,388.80,436.30,441.20,388.80,NULL,NULL,'2026-06-05 14:58:08.876269',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(247,4,'2026-04-21 05:23:00',375.30,360.10,342.30,375.30,360.10,342.30,NULL,NULL,'2026-06-05 14:58:08.889326',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(248,4,'2026-04-21 05:24:00',389.00,401.60,373.10,389.00,401.60,373.10,NULL,NULL,'2026-06-05 14:58:08.898819',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(249,4,'2026-04-21 05:26:00',443.20,438.80,385.00,443.20,438.80,385.00,NULL,NULL,'2026-06-05 14:58:08.907877',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(250,4,'2026-04-21 05:27:00',261.10,284.60,283.80,261.10,284.60,283.80,NULL,NULL,'2026-06-05 14:58:08.919888',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(251,4,'2026-04-21 05:28:00',390.70,390.60,338.90,390.70,390.60,338.90,NULL,NULL,'2026-06-05 14:58:08.931112',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(252,4,'2026-04-21 05:29:00',339.20,356.60,364.70,339.20,356.60,364.70,NULL,NULL,'2026-06-05 14:58:08.941151',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(253,4,'2026-04-21 05:31:00',370.10,346.90,355.40,370.10,346.90,355.40,NULL,NULL,'2026-06-05 14:58:08.954674',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(254,4,'2026-04-21 05:32:00',431.60,428.70,383.40,431.60,428.70,383.40,NULL,NULL,'2026-06-05 14:58:08.965309',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(255,4,'2026-04-21 05:33:00',377.50,388.20,341.10,377.50,388.20,341.10,NULL,NULL,'2026-06-05 14:58:08.979782',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(256,4,'2026-04-21 05:35:00',417.80,439.20,408.20,417.80,439.20,408.20,NULL,NULL,'2026-06-05 14:58:09.001376',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(257,4,'2026-04-21 05:36:00',367.40,381.90,365.70,367.40,381.90,365.70,NULL,NULL,'2026-06-05 14:58:09.012117',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(258,4,'2026-04-21 05:37:00',342.20,368.40,331.80,342.20,368.40,331.80,NULL,NULL,'2026-06-05 14:58:09.025936',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(259,4,'2026-04-21 05:39:00',417.90,406.40,404.90,417.90,406.40,404.90,NULL,NULL,'2026-06-05 14:58:09.039644',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(260,4,'2026-04-21 05:40:00',434.80,447.70,420.20,434.80,447.70,420.20,NULL,NULL,'2026-06-05 14:58:09.051724',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(261,4,'2026-04-21 05:42:00',368.50,377.90,332.80,368.50,377.90,332.80,NULL,NULL,'2026-06-05 14:58:09.060952',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(262,4,'2026-04-21 05:43:00',464.50,438.00,396.40,464.50,438.00,396.40,NULL,NULL,'2026-06-05 14:58:09.074361',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(263,4,'2026-04-21 05:44:00',333.70,359.20,354.40,333.70,359.20,354.40,NULL,NULL,'2026-06-05 14:58:09.084039',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(264,4,'2026-04-21 05:46:00',394.10,392.50,341.10,394.10,392.50,341.10,NULL,NULL,'2026-06-05 14:58:09.093661',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(265,4,'2026-04-21 05:47:00',415.00,415.50,378.40,415.00,415.50,378.40,NULL,NULL,'2026-06-05 14:58:09.103389',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(266,4,'2026-04-21 05:48:00',419.40,436.00,371.30,419.40,436.00,371.30,NULL,NULL,'2026-06-05 14:58:09.114111',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(267,4,'2026-04-21 05:50:00',396.50,380.50,351.30,396.50,380.50,351.30,NULL,NULL,'2026-06-05 14:58:09.124025',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(268,4,'2026-04-21 05:51:00',387.40,317.50,314.90,387.40,317.50,314.90,NULL,NULL,'2026-06-05 14:58:09.132900',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(269,4,'2026-04-21 05:52:00',427.10,391.60,360.00,427.10,391.60,360.00,NULL,NULL,'2026-06-05 14:58:09.142599',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(270,4,'2026-04-21 05:53:00',383.50,384.80,354.90,383.50,384.80,354.90,NULL,NULL,'2026-06-05 14:58:09.153016',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(271,4,'2026-04-21 05:55:00',287.60,286.40,276.40,287.60,286.40,276.40,NULL,NULL,'2026-06-05 14:58:09.164926',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(272,4,'2026-04-21 05:56:00',333.60,374.70,341.40,333.60,374.70,341.40,NULL,NULL,'2026-06-05 14:58:09.174654',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(273,4,'2026-04-21 05:57:00',412.40,429.40,380.10,412.40,429.40,380.10,NULL,NULL,'2026-06-05 14:58:09.185978',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(274,4,'2026-04-21 05:59:00',369.60,347.30,293.40,369.60,347.30,293.40,NULL,NULL,'2026-06-05 14:58:09.207431',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(275,4,'2026-04-21 06:00:00',392.30,362.40,335.00,392.30,362.40,335.00,NULL,NULL,'2026-06-05 14:58:09.218330',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(276,4,'2026-04-21 06:01:00',333.70,366.10,345.70,333.70,366.10,345.70,NULL,NULL,'2026-06-05 14:58:09.227964',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(277,4,'2026-04-21 06:03:00',321.10,311.00,303.60,321.10,311.00,303.60,NULL,NULL,'2026-06-05 14:58:09.237848',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(278,4,'2026-04-21 06:04:00',424.70,393.20,387.00,424.70,393.20,387.00,NULL,NULL,'2026-06-05 14:58:09.249551',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(279,4,'2026-04-21 06:05:00',390.50,372.20,314.60,390.50,372.20,314.60,NULL,NULL,'2026-06-05 14:58:09.262930',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(280,4,'2026-04-21 06:07:00',341.40,343.10,317.60,341.40,343.10,317.60,NULL,NULL,'2026-06-05 14:58:09.272640',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(281,4,'2026-04-21 06:08:00',472.10,411.00,393.10,472.10,411.00,393.10,NULL,NULL,'2026-06-05 14:58:09.282053',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(282,4,'2026-04-21 06:09:00',433.90,394.50,344.70,433.90,394.50,344.70,NULL,NULL,'2026-06-05 14:58:09.293987',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(283,4,'2026-04-21 06:11:00',345.00,388.70,347.20,345.00,388.70,347.20,NULL,NULL,'2026-06-05 14:58:09.303761',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(284,4,'2026-04-21 06:12:00',409.30,397.70,386.30,409.30,397.70,386.30,NULL,NULL,'2026-06-05 14:58:09.314197',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(285,4,'2026-04-21 06:13:00',408.70,417.30,410.80,408.70,417.30,410.80,NULL,NULL,'2026-06-05 14:58:09.324443',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(286,4,'2026-04-21 06:14:00',431.10,381.40,410.10,431.10,381.40,410.10,NULL,NULL,'2026-06-05 14:58:09.337030',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(287,4,'2026-04-21 06:16:00',419.70,387.80,337.60,419.70,387.80,337.60,NULL,NULL,'2026-06-05 14:58:09.355733',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(288,4,'2026-04-21 06:17:00',428.60,432.20,376.10,428.60,432.20,376.10,NULL,NULL,'2026-06-05 14:58:09.365139',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(289,4,'2026-04-21 06:18:00',413.90,395.20,371.80,413.90,395.20,371.80,NULL,NULL,'2026-06-05 14:58:09.376904',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(290,4,'2026-04-21 06:20:00',376.30,425.30,392.00,376.30,425.30,392.00,NULL,NULL,'2026-06-05 14:58:09.386646',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(291,4,'2026-04-21 06:21:00',385.20,404.30,394.30,385.20,404.30,394.30,NULL,NULL,'2026-06-05 14:58:09.396094',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(292,4,'2026-04-21 06:22:00',445.40,410.60,383.80,445.40,410.60,383.80,NULL,NULL,'2026-06-05 14:58:09.405787',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(293,4,'2026-04-21 06:23:00',467.20,436.60,401.70,467.20,436.60,401.70,NULL,NULL,'2026-06-05 14:58:09.415367',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(294,4,'2026-04-21 06:25:00',373.70,312.90,324.20,373.70,312.90,324.20,NULL,NULL,'2026-06-05 14:58:09.424459',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(295,4,'2026-04-21 06:26:00',431.60,437.90,419.50,431.60,437.90,419.50,NULL,NULL,'2026-06-05 14:58:09.434839',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(296,4,'2026-04-21 06:27:00',451.90,471.50,423.90,451.90,471.50,423.90,NULL,NULL,'2026-06-05 14:58:09.444602',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(297,4,'2026-04-21 06:29:00',387.80,401.80,344.70,387.80,401.80,344.70,NULL,NULL,'2026-06-05 14:58:09.454170',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(298,4,'2026-04-21 06:30:00',371.00,399.20,371.50,371.00,399.20,371.50,NULL,NULL,'2026-06-05 14:58:09.465564',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(299,4,'2026-04-21 06:31:00',433.20,435.10,445.60,433.20,435.10,445.60,NULL,NULL,'2026-06-05 14:58:09.477591',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(300,4,'2026-04-21 06:33:00',472.30,429.60,411.30,472.30,429.60,411.30,NULL,NULL,'2026-06-05 14:58:09.487572',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(301,4,'2026-04-21 06:34:00',400.70,382.00,340.20,400.70,382.00,340.20,NULL,NULL,'2026-06-05 14:58:09.497372',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(302,4,'2026-04-21 06:35:00',483.60,460.40,448.30,483.60,460.40,448.30,NULL,NULL,'2026-06-05 14:58:09.508447',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(303,4,'2026-04-21 06:36:00',514.10,456.10,442.40,514.10,456.10,442.40,NULL,NULL,'2026-06-05 14:58:09.526686',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(304,4,'2026-04-21 06:38:00',415.20,417.00,369.50,415.20,417.00,369.50,NULL,NULL,'2026-06-05 14:58:09.536392',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(305,4,'2026-04-21 06:39:00',426.80,403.30,374.30,426.80,403.30,374.30,NULL,NULL,'2026-06-05 14:58:09.546663',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(306,4,'2026-04-21 06:40:00',441.10,430.20,444.10,441.10,430.20,444.10,NULL,NULL,'2026-06-05 14:58:09.557932',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(307,4,'2026-04-21 06:42:00',481.70,402.20,420.30,481.70,402.20,420.30,NULL,NULL,'2026-06-05 14:58:09.570507',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(308,4,'2026-04-21 06:43:00',462.90,390.90,414.60,462.90,390.90,414.60,NULL,NULL,'2026-06-05 14:58:09.581868',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(309,4,'2026-04-21 06:44:00',412.90,402.40,358.40,412.90,402.40,358.40,NULL,NULL,'2026-06-05 14:58:09.594017',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(310,4,'2026-04-21 06:46:00',460.10,409.20,384.90,460.10,409.20,384.90,NULL,NULL,'2026-06-05 14:58:09.603819',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(311,4,'2026-04-21 06:47:00',349.70,354.90,340.30,349.70,354.90,340.30,NULL,NULL,'2026-06-05 14:58:09.614788',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(312,4,'2026-04-21 06:48:00',400.20,424.70,399.10,400.20,424.70,399.10,NULL,NULL,'2026-06-05 14:58:09.624879',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(313,4,'2026-04-21 06:49:00',413.80,404.00,363.80,413.80,404.00,363.80,NULL,NULL,'2026-06-05 14:58:09.637064',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(314,4,'2026-04-21 06:51:00',378.00,306.50,304.10,378.00,306.50,304.10,NULL,NULL,'2026-06-05 14:58:09.647139',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(315,4,'2026-04-21 06:52:00',486.80,417.90,429.10,486.80,417.90,429.10,NULL,NULL,'2026-06-05 14:58:09.656843',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(316,4,'2026-04-21 06:53:00',404.20,355.60,390.40,404.20,355.60,390.40,NULL,NULL,'2026-06-05 14:58:09.668351',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(317,4,'2026-04-21 06:55:00',394.80,330.80,303.40,394.80,330.80,303.40,NULL,NULL,'2026-06-05 14:58:09.678964',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(318,4,'2026-04-21 06:56:00',420.60,397.50,368.60,420.60,397.50,368.60,NULL,NULL,'2026-06-05 14:58:09.695840',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(319,4,'2026-04-21 06:57:00',407.00,407.80,365.00,407.00,407.80,365.00,NULL,NULL,'2026-06-05 14:58:09.709202',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(320,4,'2026-04-21 06:58:00',351.60,339.10,332.80,351.60,339.10,332.80,NULL,NULL,'2026-06-05 14:58:09.724972',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(321,4,'2026-04-21 07:00:00',519.20,466.20,482.70,519.20,466.20,482.70,NULL,NULL,'2026-06-05 14:58:09.736505',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(322,4,'2026-04-21 07:01:00',625.90,542.20,534.50,625.90,542.20,534.50,NULL,NULL,'2026-06-05 14:58:09.746282',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(323,4,'2026-04-21 07:02:00',437.10,407.00,380.30,437.10,407.00,380.30,NULL,NULL,'2026-06-05 14:58:09.756314',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(324,4,'2026-04-21 07:04:00',477.10,408.50,410.50,477.10,408.50,410.50,NULL,NULL,'2026-06-05 14:58:09.767069',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(325,4,'2026-04-21 07:05:00',419.70,440.90,430.40,419.70,440.90,430.40,NULL,NULL,'2026-06-05 14:58:09.776487',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(326,4,'2026-04-21 07:06:00',561.70,549.10,529.60,561.70,549.10,529.60,NULL,NULL,'2026-06-05 14:58:09.786894',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(327,4,'2026-04-21 07:08:00',467.20,402.30,393.80,467.20,402.30,393.80,NULL,NULL,'2026-06-05 14:58:09.796403',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(328,4,'2026-04-21 07:09:00',461.40,411.30,444.40,461.40,411.30,444.40,NULL,NULL,'2026-06-05 14:58:09.805615',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(329,4,'2026-04-21 07:10:00',507.00,445.60,462.70,507.00,445.60,462.70,NULL,NULL,'2026-06-05 14:58:09.818662',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(330,4,'2026-04-21 07:12:00',548.50,486.60,449.20,548.50,486.60,449.20,NULL,NULL,'2026-06-05 14:58:09.830567',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(331,4,'2026-04-21 07:13:00',511.00,528.30,499.10,511.00,528.30,499.10,NULL,NULL,'2026-06-05 14:58:09.840681',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(332,4,'2026-04-21 07:14:00',373.50,395.40,369.50,373.50,395.40,369.50,NULL,NULL,'2026-06-05 14:58:09.850696',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(333,4,'2026-04-21 07:16:00',492.40,497.50,492.10,492.40,497.50,492.10,NULL,NULL,'2026-06-05 14:58:09.867410',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(334,4,'2026-04-21 07:17:00',509.60,467.50,490.80,509.60,467.50,490.80,NULL,NULL,'2026-06-05 14:58:09.877168',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(335,4,'2026-04-21 07:18:00',461.60,395.70,392.60,461.60,395.70,392.60,NULL,NULL,'2026-06-05 14:58:09.888973',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(336,4,'2026-04-21 07:20:00',479.20,455.20,455.50,479.20,455.20,455.50,NULL,NULL,'2026-06-05 14:58:09.900100',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(337,4,'2026-04-21 07:21:00',445.30,441.30,424.30,445.30,441.30,424.30,NULL,NULL,'2026-06-05 14:58:09.910146',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(338,4,'2026-04-21 07:22:00',434.50,411.40,384.50,434.50,411.40,384.50,NULL,NULL,'2026-06-05 14:58:09.922117',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(339,4,'2026-04-21 07:24:00',460.20,453.10,453.40,460.20,453.10,453.40,NULL,NULL,'2026-06-05 14:58:09.934976',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(340,4,'2026-04-21 07:25:00',447.40,418.90,439.90,447.40,418.90,439.90,NULL,NULL,'2026-06-05 14:58:09.946174',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(341,4,'2026-04-21 07:26:00',472.20,412.90,455.10,472.20,412.90,455.10,NULL,NULL,'2026-06-05 14:58:09.958384',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(342,4,'2026-04-21 07:28:00',493.10,490.80,481.30,493.10,490.80,481.30,NULL,NULL,'2026-06-05 14:58:09.976978',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(343,4,'2026-04-21 07:29:00',493.80,488.60,463.40,493.80,488.60,463.40,NULL,NULL,'2026-06-05 14:58:09.988622',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(344,4,'2026-04-21 07:30:00',517.80,488.30,496.40,517.80,488.30,496.40,NULL,NULL,'2026-06-05 14:58:09.999178',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(345,4,'2026-04-21 07:32:00',447.20,455.10,462.50,447.20,455.10,462.50,NULL,NULL,'2026-06-05 14:58:10.017557',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(346,4,'2026-04-21 07:33:00',409.60,402.70,413.90,409.60,402.70,413.90,NULL,NULL,'2026-06-05 14:58:10.028933',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(347,4,'2026-04-21 07:34:00',486.80,420.30,437.80,486.80,420.30,437.80,NULL,NULL,'2026-06-05 14:58:10.043070',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(348,4,'2026-04-21 07:35:00',454.90,424.40,443.50,454.90,424.40,443.50,NULL,NULL,'2026-06-05 14:58:10.052772',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(349,4,'2026-04-21 07:37:00',539.20,471.70,495.00,539.20,471.70,495.00,NULL,NULL,'2026-06-05 14:58:10.064758',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(350,4,'2026-04-21 07:38:00',489.60,456.70,433.50,489.60,456.70,433.50,NULL,NULL,'2026-06-05 14:58:10.076264',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(351,4,'2026-04-21 07:39:00',487.10,485.80,494.10,487.10,485.80,494.10,NULL,NULL,'2026-06-05 14:58:10.086846',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(352,4,'2026-04-21 07:41:00',520.80,495.60,484.60,520.80,495.60,484.60,NULL,NULL,'2026-06-05 14:58:10.098695',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(353,4,'2026-04-21 07:42:00',457.70,465.00,473.90,457.70,465.00,473.90,NULL,NULL,'2026-06-05 14:58:10.109007',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(354,4,'2026-04-21 07:43:00',415.30,422.10,477.30,415.30,422.10,477.30,NULL,NULL,'2026-06-05 14:58:10.120729',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(355,4,'2026-04-21 07:44:00',488.00,451.00,486.80,488.00,451.00,486.80,NULL,NULL,'2026-06-05 14:58:10.133054',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(356,4,'2026-04-21 07:46:00',451.90,424.70,417.10,451.90,424.70,417.10,NULL,NULL,'2026-06-05 14:58:10.149061',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(357,4,'2026-04-21 07:47:00',434.10,417.40,441.10,434.10,417.40,441.10,NULL,NULL,'2026-06-05 14:58:10.160510',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(358,4,'2026-04-21 07:48:00',427.40,464.20,503.40,427.40,464.20,503.40,NULL,NULL,'2026-06-05 14:58:10.289872',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(359,4,'2026-04-21 07:50:00',424.20,460.80,448.00,424.20,460.80,448.00,NULL,NULL,'2026-06-05 14:58:10.591818',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(360,4,'2026-04-21 07:51:00',480.40,458.10,494.10,480.40,458.10,494.10,NULL,NULL,'2026-06-05 14:58:10.798735',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(361,4,'2026-04-21 07:52:00',448.00,398.00,419.20,448.00,398.00,419.20,NULL,NULL,'2026-06-05 14:58:10.815934',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(362,4,'2026-04-21 07:53:00',471.80,390.20,437.20,471.80,390.20,437.20,NULL,NULL,'2026-06-05 14:58:10.832152',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(363,4,'2026-04-21 07:55:00',538.40,510.70,588.20,538.40,510.70,588.20,NULL,NULL,'2026-06-05 14:58:10.843018',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(364,4,'2026-04-21 07:56:00',458.20,401.00,422.90,458.20,401.00,422.90,NULL,NULL,'2026-06-05 14:58:10.856058',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(365,4,'2026-04-21 07:57:00',420.00,433.80,433.20,420.00,433.80,433.20,NULL,NULL,'2026-06-05 14:58:10.867581',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(366,4,'2026-04-21 07:59:00',395.70,414.80,427.90,395.70,414.80,427.90,NULL,NULL,'2026-06-05 14:58:10.878927',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(367,4,'2026-04-21 08:00:00',350.30,354.70,379.30,350.30,354.70,379.30,NULL,NULL,'2026-06-05 14:58:10.973309',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(368,4,'2026-04-21 08:01:00',489.40,462.00,489.60,489.40,462.00,489.60,NULL,NULL,'2026-06-05 14:58:11.004306',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(369,4,'2026-04-21 08:03:00',459.20,425.50,447.60,459.20,425.50,447.60,NULL,NULL,'2026-06-05 14:58:11.017625',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(370,4,'2026-04-21 08:04:00',436.10,383.00,456.80,436.10,383.00,456.80,NULL,NULL,'2026-06-05 14:58:11.030992',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(371,4,'2026-04-21 08:05:00',445.30,431.90,462.70,445.30,431.90,462.70,NULL,NULL,'2026-06-05 14:58:11.041660',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(372,4,'2026-04-21 08:07:00',411.90,418.30,415.60,411.90,418.30,415.60,NULL,NULL,'2026-06-05 14:58:11.052317',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(373,4,'2026-04-21 08:08:00',410.80,383.30,385.70,410.80,383.30,385.70,NULL,NULL,'2026-06-05 14:58:11.063756',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(374,4,'2026-04-21 08:09:00',375.80,337.90,393.60,375.80,337.90,393.60,NULL,NULL,'2026-06-05 14:58:11.074619',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(375,4,'2026-04-21 08:11:00',466.60,386.40,458.90,466.60,386.40,458.90,NULL,NULL,'2026-06-05 14:58:11.087699',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(376,4,'2026-04-21 08:12:00',441.90,399.30,433.40,441.90,399.30,433.40,NULL,NULL,'2026-06-05 14:58:11.098641',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(377,4,'2026-04-21 08:13:00',440.70,417.20,424.90,440.70,417.20,424.90,NULL,NULL,'2026-06-05 14:58:11.111201',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(378,4,'2026-04-21 08:14:00',433.90,392.40,413.30,433.90,392.40,413.30,NULL,NULL,'2026-06-05 14:58:11.123330',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(379,4,'2026-04-21 08:16:00',402.80,421.30,449.70,402.80,421.30,449.70,NULL,NULL,'2026-06-05 14:58:11.134183',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(380,4,'2026-04-21 08:17:00',428.50,427.40,463.40,428.50,427.40,463.40,NULL,NULL,'2026-06-05 14:58:11.149657',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(381,4,'2026-04-21 08:18:00',389.50,382.40,411.60,389.50,382.40,411.60,NULL,NULL,'2026-06-05 14:58:11.161106',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(382,4,'2026-04-21 08:20:00',398.70,339.50,405.70,398.70,339.50,405.70,NULL,NULL,'2026-06-05 14:58:11.175089',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(383,4,'2026-04-21 08:21:00',363.30,320.70,389.30,363.30,320.70,389.30,NULL,NULL,'2026-06-05 14:58:11.188249',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(384,4,'2026-04-21 08:22:00',424.90,422.70,451.30,424.90,422.70,451.30,NULL,NULL,'2026-06-05 14:58:11.199728',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(385,4,'2026-04-21 08:23:00',451.70,409.50,437.60,451.70,409.50,437.60,NULL,NULL,'2026-06-05 14:58:11.209826',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(386,4,'2026-04-21 08:25:00',357.00,328.70,338.10,357.00,328.70,338.10,NULL,NULL,'2026-06-05 14:58:11.222149',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(387,4,'2026-04-21 08:26:00',353.50,354.00,387.30,353.50,354.00,387.30,NULL,NULL,'2026-06-05 14:58:11.232878',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(388,4,'2026-04-21 08:27:00',435.70,392.70,461.70,435.70,392.70,461.70,NULL,NULL,'2026-06-05 14:58:11.244583',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(389,4,'2026-04-21 08:29:00',370.90,325.60,390.90,370.90,325.60,390.90,NULL,NULL,'2026-06-05 14:58:11.258430',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(390,4,'2026-04-21 08:30:00',441.90,373.90,421.10,441.90,373.90,421.10,NULL,NULL,'2026-06-05 14:58:11.269901',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(391,4,'2026-04-21 08:31:00',397.80,359.10,407.20,397.80,359.10,407.20,NULL,NULL,'2026-06-05 14:58:11.281838',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(392,4,'2026-04-21 08:32:00',382.90,378.20,417.70,382.90,378.20,417.70,NULL,NULL,'2026-06-05 14:58:11.295062',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(393,4,'2026-04-21 08:34:00',430.20,413.00,463.00,430.20,413.00,463.00,NULL,NULL,'2026-06-05 14:58:11.306271',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(394,4,'2026-04-21 08:35:00',390.70,409.70,426.60,390.70,409.70,426.60,NULL,NULL,'2026-06-05 14:58:11.318232',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(395,4,'2026-04-21 08:36:00',401.20,397.90,440.10,401.20,397.90,440.10,NULL,NULL,'2026-06-05 14:58:11.329946',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(396,4,'2026-04-21 08:37:00',447.10,385.80,468.00,447.10,385.80,468.00,NULL,NULL,'2026-06-05 14:58:11.342309',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(397,4,'2026-04-21 08:39:00',358.70,316.00,397.10,358.70,316.00,397.10,NULL,NULL,'2026-06-05 14:58:11.355487',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(398,4,'2026-04-21 08:40:00',433.80,389.20,473.00,433.80,389.20,473.00,NULL,NULL,'2026-06-05 14:58:11.369489',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(399,4,'2026-04-21 08:41:00',466.30,439.10,461.20,466.30,439.10,461.20,NULL,NULL,'2026-06-05 14:58:11.382239',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(400,4,'2026-04-21 08:42:00',281.30,316.10,333.30,281.30,316.10,333.30,NULL,NULL,'2026-06-05 14:58:11.394103',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(401,4,'2026-04-21 08:44:00',326.60,316.00,409.30,326.60,316.00,409.30,NULL,NULL,'2026-06-05 14:58:11.406729',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(402,4,'2026-04-21 08:45:00',407.30,341.10,433.60,407.30,341.10,433.60,NULL,NULL,'2026-06-05 14:58:11.419447',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(403,4,'2026-04-21 08:47:00',396.00,339.60,421.20,396.00,339.60,421.20,NULL,NULL,'2026-06-05 14:58:11.430079',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(404,4,'2026-04-21 08:48:00',391.80,323.10,406.50,391.80,323.10,406.50,NULL,NULL,'2026-06-05 14:58:11.441291',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(405,4,'2026-04-21 08:49:00',364.10,309.50,376.40,364.10,309.50,376.40,NULL,NULL,'2026-06-05 14:58:11.453881',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(406,4,'2026-04-21 08:50:00',391.40,313.60,392.00,391.40,313.60,392.00,NULL,NULL,'2026-06-05 14:58:11.464579',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(407,4,'2026-04-21 08:52:00',321.00,299.60,367.80,321.00,299.60,367.80,NULL,NULL,'2026-06-05 14:58:11.477285',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(408,4,'2026-04-21 08:53:00',359.80,310.90,399.50,359.80,310.90,399.50,NULL,NULL,'2026-06-05 14:58:11.491541',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(409,4,'2026-04-21 08:54:00',360.30,319.60,408.70,360.30,319.60,408.70,NULL,NULL,'2026-06-05 14:58:11.502577',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(410,4,'2026-04-21 08:56:00',311.40,279.40,350.40,311.40,279.40,350.40,NULL,NULL,'2026-06-05 14:58:11.516625',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(411,4,'2026-04-21 08:57:00',428.60,345.70,418.60,428.60,345.70,418.60,NULL,NULL,'2026-06-05 14:58:11.529154',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(412,4,'2026-04-21 08:58:00',384.00,338.00,395.60,384.00,338.00,395.60,NULL,NULL,'2026-06-05 14:58:11.538774',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(413,4,'2026-04-21 09:00:00',326.60,288.70,408.90,326.60,288.70,408.90,NULL,NULL,'2026-06-05 14:58:11.549716',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(414,4,'2026-04-21 09:01:00',313.80,263.60,346.30,313.80,263.60,346.30,NULL,NULL,'2026-06-05 14:58:11.559806',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(415,4,'2026-04-21 09:02:00',359.50,298.80,395.00,359.50,298.80,395.00,NULL,NULL,'2026-06-05 14:58:11.574528',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(416,4,'2026-04-21 09:04:00',347.50,293.90,365.30,347.50,293.90,365.30,NULL,NULL,'2026-06-05 14:58:11.585797',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(417,4,'2026-04-21 09:05:00',336.20,292.70,409.20,336.20,292.70,409.20,NULL,NULL,'2026-06-05 14:58:11.599950',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(418,4,'2026-04-21 09:06:00',399.90,313.00,386.60,399.90,313.00,386.60,NULL,NULL,'2026-06-05 14:58:11.609747',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(419,4,'2026-04-21 09:08:00',370.20,351.60,392.30,370.20,351.60,392.30,NULL,NULL,'2026-06-05 14:58:11.623928',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(420,4,'2026-04-21 09:09:00',326.20,303.20,352.80,326.20,303.20,352.80,NULL,NULL,'2026-06-05 14:58:11.636023',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(421,4,'2026-04-21 09:10:00',313.90,286.50,358.00,313.90,286.50,358.00,NULL,NULL,'2026-06-05 14:58:11.647017',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(422,4,'2026-04-21 09:12:00',346.10,315.10,383.90,346.10,315.10,383.90,NULL,NULL,'2026-06-05 14:58:11.658142',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(423,4,'2026-04-21 09:13:00',363.20,303.10,380.90,363.20,303.10,380.90,NULL,NULL,'2026-06-05 14:58:11.669088',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(424,4,'2026-04-21 09:14:00',242.50,192.70,262.40,242.50,192.70,262.40,NULL,NULL,'2026-06-05 14:58:11.678965',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(425,4,'2026-04-21 09:15:00',401.40,314.50,414.40,401.40,314.50,414.40,NULL,NULL,'2026-06-05 14:58:11.689412',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(426,4,'2026-04-21 09:17:00',361.70,342.10,422.10,361.70,342.10,422.10,NULL,NULL,'2026-06-05 14:58:11.700555',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(427,4,'2026-04-21 09:18:00',307.00,263.00,356.70,307.00,263.00,356.70,NULL,NULL,'2026-06-05 14:58:11.712670',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(428,4,'2026-04-21 09:19:00',348.50,280.40,369.70,348.50,280.40,369.70,NULL,NULL,'2026-06-05 14:58:11.722906',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(429,4,'2026-04-21 09:21:00',330.90,294.80,419.70,330.90,294.80,419.70,NULL,NULL,'2026-06-05 14:58:11.734631',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(430,4,'2026-04-21 09:22:00',322.60,269.60,368.90,322.60,269.60,368.90,NULL,NULL,'2026-06-05 14:58:11.745421',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(431,4,'2026-04-21 09:23:00',438.20,335.00,419.70,438.20,335.00,419.70,NULL,NULL,'2026-06-05 14:58:11.755961',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(432,4,'2026-04-21 09:24:00',368.10,313.70,405.40,368.10,313.70,405.40,NULL,NULL,'2026-06-05 14:58:11.770203',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(433,4,'2026-04-21 09:26:00',293.10,268.10,342.50,293.10,268.10,342.50,NULL,NULL,'2026-06-05 14:58:11.781183',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(434,4,'2026-04-21 09:27:00',378.80,343.10,461.30,378.80,343.10,461.30,NULL,NULL,'2026-06-05 14:58:11.798401',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(435,4,'2026-04-21 09:28:00',382.20,332.80,431.50,382.20,332.80,431.50,NULL,NULL,'2026-06-05 14:58:11.817413',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(436,4,'2026-04-21 09:30:00',256.70,249.00,322.40,256.70,249.00,322.40,NULL,NULL,'2026-06-05 14:58:11.828696',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(437,4,'2026-04-21 09:31:00',311.60,297.80,387.20,311.60,297.80,387.20,NULL,NULL,'2026-06-05 14:58:11.844313',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(438,4,'2026-04-21 09:32:00',390.00,317.40,434.00,390.00,317.40,434.00,NULL,NULL,'2026-06-05 14:58:11.855641',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(439,4,'2026-04-21 09:34:00',328.70,324.40,391.60,328.70,324.40,391.60,NULL,NULL,'2026-06-05 14:58:11.867636',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(440,4,'2026-04-21 09:35:00',304.70,272.80,354.80,304.70,272.80,354.80,NULL,NULL,'2026-06-05 14:58:11.882458',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(441,4,'2026-04-21 09:36:00',362.10,320.80,428.50,362.10,320.80,428.50,NULL,NULL,'2026-06-05 14:58:11.897809',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(442,4,'2026-04-21 09:38:00',332.70,307.80,404.90,332.70,307.80,404.90,NULL,NULL,'2026-06-05 14:58:11.912485',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(443,4,'2026-04-21 09:39:00',379.30,343.10,453.30,379.30,343.10,453.30,NULL,NULL,'2026-06-05 14:58:11.929824',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(444,4,'2026-04-21 09:40:00',281.30,287.70,359.40,281.30,287.70,359.40,NULL,NULL,'2026-06-05 14:58:11.940212',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(445,4,'2026-04-21 09:42:00',267.90,243.90,344.10,267.90,243.90,344.10,NULL,NULL,'2026-06-05 14:58:11.952149',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(446,4,'2026-04-21 09:43:00',381.90,298.20,398.10,381.90,298.20,398.10,NULL,NULL,'2026-06-05 14:58:11.964092',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(447,4,'2026-04-21 09:44:00',317.90,278.00,382.60,317.90,278.00,382.60,NULL,NULL,'2026-06-05 14:58:11.977837',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(448,4,'2026-04-21 09:46:00',275.20,232.80,335.70,275.20,232.80,335.70,NULL,NULL,'2026-06-05 14:58:11.988733',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(449,4,'2026-04-21 09:47:00',354.90,293.10,428.60,354.90,293.10,428.60,NULL,NULL,'2026-06-05 14:58:12.007239',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(450,4,'2026-04-21 09:48:00',365.20,348.40,449.40,365.20,348.40,449.40,NULL,NULL,'2026-06-05 14:58:12.017692',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(451,4,'2026-04-21 09:50:00',308.00,290.80,388.00,308.00,290.80,388.00,NULL,NULL,'2026-06-05 14:58:12.033713',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(452,4,'2026-04-21 09:51:00',305.50,252.20,373.50,305.50,252.20,373.50,NULL,NULL,'2026-06-05 14:58:12.047568',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(453,4,'2026-04-21 09:52:00',388.50,328.90,441.30,388.50,328.90,441.30,NULL,NULL,'2026-06-05 14:58:12.058716',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(454,4,'2026-04-21 09:54:00',336.50,302.60,438.80,336.50,302.60,438.80,NULL,NULL,'2026-06-05 14:58:12.072040',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(455,4,'2026-04-21 09:55:00',200.10,186.40,280.80,200.10,186.40,280.80,NULL,NULL,'2026-06-05 14:58:12.083979',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(456,4,'2026-04-21 09:56:00',274.80,288.50,368.80,274.80,288.50,368.80,NULL,NULL,'2026-06-05 14:58:12.097549',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(457,4,'2026-04-21 09:58:00',280.80,281.60,366.20,280.80,281.60,366.20,NULL,NULL,'2026-06-05 14:58:12.114074',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(458,4,'2026-04-21 09:59:00',366.80,353.50,473.10,366.80,353.50,473.10,NULL,NULL,'2026-06-05 14:58:12.128009',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(459,4,'2026-04-21 10:00:00',348.80,312.10,431.00,348.80,312.10,431.00,NULL,NULL,'2026-06-05 14:58:12.137872',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(460,4,'2026-04-21 10:02:00',260.30,253.60,340.30,260.30,253.60,340.30,NULL,NULL,'2026-06-05 14:58:12.149273',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(461,4,'2026-04-21 10:03:00',272.40,233.50,361.40,272.40,233.50,361.40,NULL,NULL,'2026-06-05 14:58:12.166156',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(462,4,'2026-04-21 10:04:00',361.60,368.00,454.90,361.60,368.00,454.90,NULL,NULL,'2026-06-05 14:58:12.180743',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(463,4,'2026-04-21 10:06:00',370.60,364.10,479.70,370.60,364.10,479.70,NULL,NULL,'2026-06-05 14:58:12.196832',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(464,4,'2026-04-21 10:07:00',343.20,315.20,452.40,343.20,315.20,452.40,NULL,NULL,'2026-06-05 14:58:12.208160',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(465,4,'2026-04-21 10:09:00',326.30,299.00,413.30,326.30,299.00,413.30,NULL,NULL,'2026-06-05 14:58:12.218843',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(466,4,'2026-04-21 10:10:00',299.90,259.50,370.70,299.90,259.50,370.70,NULL,NULL,'2026-06-05 14:58:12.231460',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(467,4,'2026-04-21 10:11:00',198.90,184.70,266.50,198.90,184.70,266.50,NULL,NULL,'2026-06-05 14:58:12.244069',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(468,4,'2026-04-21 10:12:00',284.10,257.70,387.20,284.10,257.70,387.20,NULL,NULL,'2026-06-05 14:58:12.258464',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(469,4,'2026-04-21 10:14:00',342.30,317.70,435.20,342.30,317.70,435.20,NULL,NULL,'2026-06-05 14:58:12.268542',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(470,4,'2026-04-21 10:15:00',339.20,329.40,453.90,339.20,329.40,453.90,NULL,NULL,'2026-06-05 14:58:12.281831',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(471,4,'2026-04-21 10:16:00',295.30,268.30,383.10,295.30,268.30,383.10,NULL,NULL,'2026-06-05 14:58:12.297740',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(472,4,'2026-04-21 10:18:00',266.20,226.30,342.10,266.20,226.30,342.10,NULL,NULL,'2026-06-05 14:58:12.309097',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(473,4,'2026-04-21 10:19:00',322.60,285.30,410.60,322.60,285.30,410.60,NULL,NULL,'2026-06-05 14:58:12.321870',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(474,4,'2026-04-21 10:20:00',289.70,271.80,373.40,289.70,271.80,373.40,NULL,NULL,'2026-06-05 14:58:12.333793',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(475,4,'2026-04-21 10:21:00',284.40,263.50,382.80,284.40,263.50,382.80,NULL,NULL,'2026-06-05 14:58:12.345964',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(476,4,'2026-04-21 10:23:00',280.10,254.90,373.00,280.10,254.90,373.00,NULL,NULL,'2026-06-05 14:58:12.358503',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(477,4,'2026-04-21 10:24:00',288.20,235.80,342.50,288.20,235.80,342.50,NULL,NULL,'2026-06-05 14:58:12.375176',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(478,4,'2026-04-21 10:25:00',363.70,339.40,472.20,363.70,339.40,472.20,NULL,NULL,'2026-06-05 14:58:12.387551',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(479,4,'2026-04-21 10:26:00',303.50,268.80,388.40,303.50,268.80,388.40,NULL,NULL,'2026-06-05 14:58:12.403572',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(480,4,'2026-04-21 10:28:00',376.90,300.30,427.80,376.90,300.30,427.80,NULL,NULL,'2026-06-05 14:58:12.419407',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(481,4,'2026-04-21 10:29:00',300.80,260.20,373.10,300.80,260.20,373.10,NULL,NULL,'2026-06-05 14:58:12.430983',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(482,4,'2026-04-21 10:30:00',339.70,322.70,415.60,339.70,322.70,415.60,NULL,NULL,'2026-06-05 14:58:12.446885',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(483,4,'2026-04-21 10:32:00',374.80,345.40,494.50,374.80,345.40,494.50,NULL,NULL,'2026-06-05 14:58:12.466546',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(484,4,'2026-04-21 10:33:00',361.50,324.10,437.40,361.50,324.10,437.40,NULL,NULL,'2026-06-05 14:58:12.484208',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(485,4,'2026-04-21 10:34:00',324.00,332.40,444.20,324.00,332.40,444.20,NULL,NULL,'2026-06-05 14:58:12.514245',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(486,4,'2026-04-21 10:36:00',264.90,259.30,370.20,264.90,259.30,370.20,NULL,NULL,'2026-06-05 14:58:12.533574',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(487,4,'2026-04-21 10:37:00',199.50,195.90,302.50,199.50,195.90,302.50,NULL,NULL,'2026-06-05 14:58:12.546546',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(488,4,'2026-04-21 10:38:00',231.70,205.20,325.80,231.70,205.20,325.80,NULL,NULL,'2026-06-05 14:58:12.559978',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(489,4,'2026-04-21 10:40:00',261.20,248.30,380.60,261.20,248.30,380.60,NULL,NULL,'2026-06-05 14:58:12.577866',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(490,4,'2026-04-21 10:41:00',266.10,239.70,368.20,266.10,239.70,368.20,NULL,NULL,'2026-06-05 14:58:12.587583',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(491,4,'2026-04-21 10:42:00',251.90,252.00,377.50,251.90,252.00,377.50,NULL,NULL,'2026-06-05 14:58:12.600395',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(492,4,'2026-04-21 10:43:00',170.90,164.00,301.30,170.90,164.00,301.30,NULL,NULL,'2026-06-05 14:58:12.613098',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(493,4,'2026-04-21 10:45:00',189.30,177.30,304.70,189.30,177.30,304.70,NULL,NULL,'2026-06-05 14:58:12.625911',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(494,4,'2026-04-21 10:46:00',233.80,252.30,357.90,233.80,252.30,357.90,NULL,NULL,'2026-06-05 14:58:12.636925',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(495,4,'2026-04-21 10:47:00',227.50,252.30,398.70,227.50,252.30,398.70,NULL,NULL,'2026-06-05 14:58:12.649514',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(496,4,'2026-04-21 10:49:00',257.90,213.80,363.00,257.90,213.80,363.00,NULL,NULL,'2026-06-05 14:58:12.662598',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(497,4,'2026-04-21 10:50:00',243.80,236.80,365.80,243.80,236.80,365.80,NULL,NULL,'2026-06-05 14:58:12.675938',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(498,4,'2026-04-21 10:51:00',240.70,221.90,345.10,240.70,221.90,345.10,NULL,NULL,'2026-06-05 14:58:12.686144',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(499,4,'2026-04-21 10:53:00',307.60,300.80,430.20,307.60,300.80,430.20,NULL,NULL,'2026-06-05 14:58:12.699000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(500,4,'2026-04-21 10:54:00',336.80,310.30,494.40,336.80,310.30,494.40,NULL,NULL,'2026-06-05 14:58:12.715312',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(501,4,'2026-04-21 10:55:00',282.10,267.00,396.60,282.10,267.00,396.60,NULL,NULL,'2026-06-05 14:58:12.728457',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(502,4,'2026-04-21 10:57:00',315.40,308.70,439.60,315.40,308.70,439.60,NULL,NULL,'2026-06-05 14:58:12.739917',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(503,4,'2026-04-21 10:58:00',379.50,349.70,489.10,379.50,349.70,489.10,NULL,NULL,'2026-06-05 14:58:12.751882',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(504,4,'2026-04-21 10:59:00',288.40,242.70,404.10,288.40,242.70,404.10,NULL,NULL,'2026-06-05 14:58:12.765141',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(505,4,'2026-04-21 11:01:00',376.70,353.20,528.50,376.70,353.20,528.50,NULL,NULL,'2026-06-05 14:58:12.780185',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(506,4,'2026-04-21 11:02:00',360.40,310.80,476.50,360.40,310.80,476.50,NULL,NULL,'2026-06-05 14:58:12.790270',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(507,4,'2026-04-21 11:03:00',300.20,281.90,414.10,300.20,281.90,414.10,NULL,NULL,'2026-06-05 14:58:12.802081',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(508,4,'2026-04-21 11:05:00',359.00,365.00,463.90,359.00,365.00,463.90,NULL,NULL,'2026-06-05 14:58:12.818286',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(509,4,'2026-04-21 11:06:00',340.90,320.60,444.90,340.90,320.60,444.90,NULL,NULL,'2026-06-05 14:58:12.827836',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(510,4,'2026-04-21 11:07:00',310.80,350.70,451.60,310.80,350.70,451.60,NULL,NULL,'2026-06-05 14:58:12.840596',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(511,4,'2026-04-21 11:08:00',302.00,328.50,420.20,302.00,328.50,420.20,NULL,NULL,'2026-06-05 14:58:12.851383',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(512,4,'2026-04-21 11:10:00',383.70,375.40,477.40,383.70,375.40,477.40,NULL,NULL,'2026-06-05 14:58:12.863781',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(513,4,'2026-04-21 11:11:00',363.30,350.20,470.20,363.30,350.20,470.20,NULL,NULL,'2026-06-05 14:58:12.888975',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(514,4,'2026-04-21 11:12:00',313.30,298.30,427.40,313.30,298.30,427.40,NULL,NULL,'2026-06-05 14:58:12.899893',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(515,4,'2026-04-21 11:14:00',315.00,337.60,465.90,315.00,337.60,465.90,NULL,NULL,'2026-06-05 14:58:12.919005',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(516,4,'2026-04-21 11:15:00',391.50,364.60,481.40,391.50,364.60,481.40,NULL,NULL,'2026-06-05 14:58:12.933126',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(517,4,'2026-04-21 11:16:00',251.40,268.80,362.80,251.40,268.80,362.80,NULL,NULL,'2026-06-05 14:58:12.947214',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(518,4,'2026-04-21 11:17:00',356.40,373.00,501.50,356.40,373.00,501.50,NULL,NULL,'2026-06-05 14:58:12.959865',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(519,4,'2026-04-21 11:19:00',355.30,321.40,422.90,355.30,321.40,422.90,NULL,NULL,'2026-06-05 14:58:12.969891',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(520,4,'2026-04-21 11:20:00',337.40,336.80,471.40,337.40,336.80,471.40,NULL,NULL,'2026-06-05 14:58:12.989736',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(521,4,'2026-04-21 11:21:00',364.20,351.50,513.40,364.20,351.50,513.40,NULL,NULL,'2026-06-05 14:58:13.001986',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(522,4,'2026-04-21 11:22:00',322.00,307.80,436.40,322.00,307.80,436.40,NULL,NULL,'2026-06-05 14:58:13.016700',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(523,4,'2026-04-21 11:24:00',406.60,343.90,502.40,406.60,343.90,502.40,NULL,NULL,'2026-06-05 14:58:13.031957',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(524,4,'2026-04-21 11:25:00',332.80,305.70,425.50,332.80,305.70,425.50,NULL,NULL,'2026-06-05 14:58:13.043356',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(525,4,'2026-04-21 11:26:00',310.60,310.70,437.50,310.60,310.70,437.50,NULL,NULL,'2026-06-05 14:58:13.055069',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(526,4,'2026-04-21 11:28:00',315.40,292.30,454.80,315.40,292.30,454.80,NULL,NULL,'2026-06-05 14:58:13.068403',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(527,4,'2026-04-21 11:29:00',317.00,319.90,430.10,317.00,319.90,430.10,NULL,NULL,'2026-06-05 14:58:13.084194',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(528,4,'2026-04-21 11:30:00',378.50,375.30,508.20,378.50,375.30,508.20,NULL,NULL,'2026-06-05 14:58:13.098148',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(529,4,'2026-04-21 11:32:00',206.70,166.40,294.50,206.70,166.40,294.50,NULL,NULL,'2026-06-05 14:58:13.114027',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(530,4,'2026-04-21 11:33:00',143.00,150.70,248.90,143.00,150.70,248.90,NULL,NULL,'2026-06-05 14:58:13.127669',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(531,4,'2026-04-21 11:34:00',187.70,184.00,280.50,187.70,184.00,280.50,NULL,NULL,'2026-06-05 14:58:13.144143',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(532,4,'2026-04-21 11:36:00',172.60,141.40,227.60,172.60,141.40,227.60,NULL,NULL,'2026-06-05 14:58:13.162119',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(533,4,'2026-04-21 11:37:00',168.00,169.60,228.30,168.00,169.60,228.30,NULL,NULL,'2026-06-05 14:58:13.173289',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(534,4,'2026-04-21 11:38:00',118.40,121.30,198.10,118.40,121.30,198.10,NULL,NULL,'2026-06-05 14:58:13.184446',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(535,4,'2026-04-21 11:39:00',157.60,120.80,191.50,157.60,120.80,191.50,NULL,NULL,'2026-06-05 14:58:13.199489',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(536,4,'2026-04-21 11:41:00',119.30,126.20,162.60,119.30,126.20,162.60,NULL,NULL,'2026-06-05 14:58:13.213727',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(537,4,'2026-04-21 11:42:00',124.80,134.70,184.70,124.80,134.70,184.70,NULL,NULL,'2026-06-05 14:58:13.229653',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(538,4,'2026-04-21 11:43:00',171.50,152.60,207.10,171.50,152.60,207.10,NULL,NULL,'2026-06-05 14:58:13.240296',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(539,4,'2026-04-21 11:45:00',146.50,146.60,217.50,146.50,146.60,217.50,NULL,NULL,'2026-06-05 14:58:13.252297',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(540,4,'2026-04-21 11:46:00',138.00,138.90,218.00,138.00,138.90,218.00,NULL,NULL,'2026-06-05 14:58:13.274084',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(541,4,'2026-04-21 11:47:00',132.90,115.50,166.80,132.90,115.50,166.80,NULL,NULL,'2026-06-05 14:58:13.296260',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(542,4,'2026-04-21 11:49:00',165.90,141.60,192.50,165.90,141.60,192.50,NULL,NULL,'2026-06-05 14:58:13.311642',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(543,4,'2026-04-21 11:50:00',154.90,139.10,207.70,154.90,139.10,207.70,NULL,NULL,'2026-06-05 14:58:13.328190',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(544,4,'2026-04-21 11:51:00',137.30,151.00,214.90,137.30,151.00,214.90,NULL,NULL,'2026-06-05 14:58:13.342225',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(545,4,'2026-04-21 11:53:00',124.20,128.60,204.20,124.20,128.60,204.20,NULL,NULL,'2026-06-05 14:58:13.376732',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(546,4,'2026-04-21 11:54:00',130.00,131.00,182.50,130.00,131.00,182.50,NULL,NULL,'2026-06-05 14:58:13.413000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(547,4,'2026-04-21 11:55:00',109.60,112.20,167.00,109.60,112.20,167.00,NULL,NULL,'2026-06-05 14:58:13.432805',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(548,4,'2026-04-21 11:56:00',86.30,70.50,134.90,86.30,70.50,134.90,NULL,NULL,'2026-06-05 14:58:13.461206',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(549,4,'2026-04-21 11:58:00',83.40,79.70,112.70,83.40,79.70,112.70,NULL,NULL,'2026-06-05 14:58:13.501001',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(550,4,'2026-04-21 11:59:00',112.70,106.10,151.90,112.70,106.10,151.90,NULL,NULL,'2026-06-05 14:58:13.517008',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(551,4,'2026-04-21 12:00:00',75.80,50.20,113.00,75.80,50.20,113.00,NULL,NULL,'2026-06-05 14:58:13.532018',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(552,4,'2026-04-21 12:01:00',60.30,42.60,85.30,60.30,42.60,85.30,NULL,NULL,'2026-06-05 14:58:13.543225',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(553,4,'2026-04-21 12:03:00',57.90,63.40,67.00,57.90,63.40,67.00,NULL,NULL,'2026-06-05 14:58:13.555065',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(554,4,'2026-04-21 12:04:00',90.40,76.40,89.70,90.40,76.40,89.70,NULL,NULL,'2026-06-05 14:58:13.566303',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(555,4,'2026-04-21 12:05:00',80.80,64.40,111.50,80.80,64.40,111.50,NULL,NULL,'2026-06-05 14:58:13.593096',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(556,4,'2026-04-21 12:07:00',50.40,52.70,84.90,50.40,52.70,84.90,NULL,NULL,'2026-06-05 14:58:13.613522',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(557,4,'2026-04-21 12:08:00',42.60,47.90,66.80,42.60,47.90,66.80,NULL,NULL,'2026-06-05 14:58:13.646697',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(558,4,'2026-04-21 12:09:00',76.40,43.40,70.40,76.40,43.40,70.40,NULL,NULL,'2026-06-05 14:58:13.659582',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(559,4,'2026-04-21 12:10:00',66.20,43.90,70.40,66.20,43.90,70.40,NULL,NULL,'2026-06-05 14:58:13.671835',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(560,4,'2026-04-21 12:12:00',78.40,46.80,65.20,78.40,46.80,65.20,NULL,NULL,'2026-06-05 14:58:13.690475',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(561,4,'2026-04-21 12:13:00',74.60,54.80,64.20,74.60,54.80,64.20,NULL,NULL,'2026-06-05 14:58:13.707648',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(562,4,'2026-04-21 12:15:00',75.90,53.20,121.90,75.90,53.20,121.90,NULL,NULL,'2026-06-05 14:58:13.729037',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(563,4,'2026-04-21 12:16:00',57.70,44.10,125.80,57.70,44.10,125.80,NULL,NULL,'2026-06-05 14:58:13.747502',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(564,4,'2026-04-21 12:17:00',81.40,46.90,103.30,81.40,46.90,103.30,NULL,NULL,'2026-06-05 14:58:13.759413',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(565,4,'2026-04-21 12:19:00',113.90,59.90,113.50,113.90,59.90,113.50,NULL,NULL,'2026-06-05 14:58:13.771597',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(566,4,'2026-04-21 12:20:00',93.60,42.60,96.20,93.60,42.60,96.20,NULL,NULL,'2026-06-05 14:58:13.786144',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(567,4,'2026-04-21 12:21:00',61.20,61.60,99.60,61.20,61.60,99.60,NULL,NULL,'2026-06-05 14:58:13.797792',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(568,4,'2026-04-21 12:23:00',53.20,61.50,132.60,53.20,61.50,132.60,NULL,NULL,'2026-06-05 14:58:13.814051',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(569,4,'2026-04-21 12:24:00',47.50,59.60,133.80,47.50,59.60,133.80,NULL,NULL,'2026-06-05 14:58:13.836889',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(570,4,'2026-04-21 12:25:00',67.90,54.00,89.10,67.90,54.00,89.10,NULL,NULL,'2026-06-05 14:58:13.865722',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(571,4,'2026-04-21 12:26:00',71.40,50.90,101.30,71.40,50.90,101.30,NULL,NULL,'2026-06-05 14:58:13.879876',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(572,4,'2026-04-21 12:28:00',51.90,45.30,85.50,51.90,45.30,85.50,NULL,NULL,'2026-06-05 14:58:13.898910',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(573,4,'2026-04-21 12:29:00',66.90,43.90,130.20,66.90,43.90,130.20,NULL,NULL,'2026-06-05 14:58:13.910348',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(574,4,'2026-04-21 12:30:00',56.00,44.80,126.10,56.00,44.80,126.10,NULL,NULL,'2026-06-05 14:58:13.924110',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(575,4,'2026-04-21 12:32:00',68.90,45.70,94.50,68.90,45.70,94.50,NULL,NULL,'2026-06-05 14:58:13.938900',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(576,4,'2026-04-21 12:33:00',67.60,40.40,97.50,67.60,40.40,97.50,NULL,NULL,'2026-06-05 14:58:13.951521',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(577,4,'2026-04-21 12:34:00',79.00,38.60,70.20,79.00,38.60,70.20,NULL,NULL,'2026-06-05 14:58:13.969717',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(578,4,'2026-04-21 12:35:00',40.50,34.30,48.40,40.50,34.30,48.40,NULL,NULL,'2026-06-05 14:58:13.981141',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(579,4,'2026-04-21 12:37:00',36.00,27.20,73.70,36.00,27.20,73.70,NULL,NULL,'2026-06-05 14:58:13.994413',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(580,4,'2026-04-21 12:38:00',73.30,26.70,79.40,73.30,26.70,79.40,NULL,NULL,'2026-06-05 14:58:14.007044',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(581,4,'2026-04-21 12:39:00',78.50,23.00,56.60,78.50,23.00,56.60,NULL,NULL,'2026-06-05 14:58:14.017787',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(582,4,'2026-04-21 12:41:00',41.40,31.50,72.50,41.40,31.50,72.50,NULL,NULL,'2026-06-05 14:58:14.027481',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(583,4,'2026-04-21 12:42:00',48.90,24.80,50.50,48.90,24.80,50.50,NULL,NULL,'2026-06-05 14:58:14.037124',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(584,4,'2026-04-21 12:43:00',66.20,28.00,76.90,66.20,28.00,76.90,NULL,NULL,'2026-06-05 14:58:14.046648',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(585,4,'2026-04-21 12:45:00',71.30,27.90,83.70,71.30,27.90,83.70,NULL,NULL,'2026-06-05 14:58:14.057597',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(586,4,'2026-04-21 12:46:00',68.80,29.50,82.30,68.80,29.50,82.30,NULL,NULL,'2026-06-05 14:58:14.067696',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(587,4,'2026-04-21 12:47:00',84.30,44.80,74.90,84.30,44.80,74.90,NULL,NULL,'2026-06-05 14:58:14.077623',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(588,4,'2026-04-21 12:49:00',40.90,40.50,68.60,40.90,40.50,68.60,NULL,NULL,'2026-06-05 14:58:14.091788',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(589,4,'2026-04-21 12:50:00',80.10,40.50,92.00,80.10,40.50,92.00,NULL,NULL,'2026-06-05 14:58:14.102590',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(590,4,'2026-04-21 12:51:00',105.90,30.80,122.50,105.90,30.80,122.50,NULL,NULL,'2026-06-05 14:58:14.113673',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(591,4,'2026-04-21 12:53:00',36.10,31.50,69.70,36.10,31.50,69.70,NULL,NULL,'2026-06-05 14:58:14.125004',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(592,4,'2026-04-21 12:54:00',35.70,31.50,53.50,35.70,31.50,53.50,NULL,NULL,'2026-06-05 14:58:14.137714',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(593,4,'2026-04-21 12:55:00',72.40,67.80,68.20,72.40,67.80,68.20,NULL,NULL,'2026-06-05 14:58:14.147799',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(594,4,'2026-04-21 12:57:00',73.20,57.90,92.00,73.20,57.90,92.00,NULL,NULL,'2026-06-05 14:58:14.159204',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(595,4,'2026-04-21 12:58:00',64.00,50.90,133.70,64.00,50.90,133.70,NULL,NULL,'2026-06-05 14:58:14.170493',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(596,4,'2026-04-21 12:59:00',50.00,27.80,113.30,50.00,27.80,113.30,NULL,NULL,'2026-06-05 14:58:14.179038',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(597,4,'2026-04-21 13:00:00',45.80,33.20,107.80,45.80,33.20,107.80,NULL,NULL,'2026-06-05 14:58:14.190350',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(598,4,'2026-04-21 13:02:00',109.90,93.90,119.20,109.90,93.90,119.20,NULL,NULL,'2026-06-05 14:58:14.202160',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(599,4,'2026-04-21 13:03:00',124.10,100.70,170.70,124.10,100.70,170.70,NULL,NULL,'2026-06-05 14:58:14.212525',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(600,4,'2026-04-21 13:04:00',98.60,99.30,149.60,98.60,99.30,149.60,NULL,NULL,'2026-06-05 14:58:14.230581',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(601,4,'2026-04-21 13:06:00',109.40,98.80,203.30,109.40,98.80,203.30,NULL,NULL,'2026-06-05 14:58:14.243498',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(602,4,'2026-04-21 13:07:00',131.40,118.40,219.90,131.40,118.40,219.90,NULL,NULL,'2026-06-05 14:58:14.257686',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(603,4,'2026-04-21 13:08:00',181.30,149.90,200.00,181.30,149.90,200.00,NULL,NULL,'2026-06-05 14:58:14.268300',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(604,4,'2026-04-21 13:09:00',111.60,116.70,177.50,111.60,116.70,177.50,NULL,NULL,'2026-06-05 14:58:14.282455',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(605,4,'2026-04-21 13:11:00',115.60,120.20,180.40,115.60,120.20,180.40,NULL,NULL,'2026-06-05 14:58:14.301477',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(606,4,'2026-04-21 13:12:00',95.80,106.80,171.50,95.80,106.80,171.50,NULL,NULL,'2026-06-05 14:58:14.313455',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(607,4,'2026-04-21 13:13:00',114.70,106.60,175.30,114.70,106.60,175.30,NULL,NULL,'2026-06-05 14:58:14.324489',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(608,4,'2026-04-21 13:15:00',124.30,116.10,160.60,124.30,116.10,160.60,NULL,NULL,'2026-06-05 14:58:14.340450',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(609,4,'2026-04-21 13:16:00',112.60,108.10,118.50,112.60,108.10,118.50,NULL,NULL,'2026-06-05 14:58:14.351640',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(610,4,'2026-04-21 13:17:00',43.90,37.10,60.30,43.90,37.10,60.30,NULL,NULL,'2026-06-05 14:58:14.363230',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(611,4,'2026-04-21 13:18:00',51.90,42.40,79.50,51.90,42.40,79.50,NULL,NULL,'2026-06-05 14:58:14.379773',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(612,4,'2026-04-21 13:20:00',69.30,30.00,60.50,69.30,30.00,60.50,NULL,NULL,'2026-06-05 14:58:14.402423',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(613,4,'2026-04-21 13:21:00',51.60,33.50,80.10,51.60,33.50,80.10,NULL,NULL,'2026-06-05 14:58:14.414351',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(614,4,'2026-04-21 13:22:00',43.10,42.80,75.00,43.10,42.80,75.00,NULL,NULL,'2026-06-05 14:58:14.428617',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(615,4,'2026-04-21 13:24:00',53.10,36.50,61.20,53.10,36.50,61.20,NULL,NULL,'2026-06-05 14:58:14.439851',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(616,4,'2026-04-21 13:25:00',56.60,57.90,52.40,56.60,57.90,52.40,NULL,NULL,'2026-06-05 14:58:14.451516',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(617,4,'2026-04-21 13:26:00',62.70,31.30,52.10,62.70,31.30,52.10,NULL,NULL,'2026-06-05 14:58:14.463076',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(618,4,'2026-04-21 13:27:00',84.30,35.70,77.40,84.30,35.70,77.40,NULL,NULL,'2026-06-05 14:58:14.478003',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(619,4,'2026-04-21 13:29:00',49.50,32.00,106.40,49.50,32.00,106.40,NULL,NULL,'2026-06-05 14:58:14.491272',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(620,4,'2026-04-21 13:30:00',44.60,48.90,91.50,44.60,48.90,91.50,NULL,NULL,'2026-06-05 14:58:14.504404',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(621,4,'2026-04-21 13:31:00',111.70,53.70,48.70,111.70,53.70,48.70,NULL,NULL,'2026-06-05 14:58:14.526288',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(622,4,'2026-04-21 13:33:00',67.10,41.40,107.50,67.10,41.40,107.50,NULL,NULL,'2026-06-05 14:58:14.541915',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(623,4,'2026-04-21 13:34:00',41.40,37.40,115.40,41.40,37.40,115.40,NULL,NULL,'2026-06-05 14:58:14.553378',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(624,4,'2026-04-21 13:35:00',63.90,34.90,93.50,63.90,34.90,93.50,NULL,NULL,'2026-06-05 14:58:14.565811',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(625,4,'2026-04-21 13:37:00',34.60,35.60,92.50,34.60,35.60,92.50,NULL,NULL,'2026-06-05 14:58:14.577540',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(626,4,'2026-04-21 13:38:00',70.10,30.10,82.00,70.10,30.10,82.00,NULL,NULL,'2026-06-05 14:58:14.592998',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(627,4,'2026-04-21 13:39:00',69.50,35.20,75.40,69.50,35.20,75.40,NULL,NULL,'2026-06-05 14:58:14.605870',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(628,4,'2026-04-21 13:41:00',33.80,37.60,107.50,33.80,37.60,107.50,NULL,NULL,'2026-06-05 14:58:14.620441',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(629,4,'2026-04-21 13:42:00',52.90,58.80,71.70,52.90,58.80,71.70,NULL,NULL,'2026-06-05 14:58:14.630050',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(630,4,'2026-04-21 13:43:00',101.80,45.10,68.70,101.80,45.10,68.70,NULL,NULL,'2026-06-05 14:58:14.641893',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(631,4,'2026-04-21 13:44:00',77.80,40.60,56.20,77.80,40.60,56.20,NULL,NULL,'2026-06-05 14:58:14.652908',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(632,4,'2026-04-21 13:45:00',47.40,62.20,73.00,47.40,62.20,73.00,NULL,NULL,'2026-06-05 14:58:14.667234',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(633,4,'2026-04-21 13:47:00',46.00,38.00,84.10,46.00,38.00,84.10,NULL,NULL,'2026-06-05 14:58:14.681443',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(634,4,'2026-04-21 13:48:00',55.30,34.60,81.30,55.30,34.60,81.30,NULL,NULL,'2026-06-05 14:58:14.692611',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(635,4,'2026-04-21 13:49:00',51.90,37.80,85.50,51.90,37.80,85.50,NULL,NULL,'2026-06-05 14:58:14.703535',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(636,4,'2026-04-21 13:51:00',65.20,37.30,63.30,65.20,37.30,63.30,NULL,NULL,'2026-06-05 14:58:14.714240',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(637,4,'2026-04-21 13:52:00',70.00,36.50,50.90,70.00,36.50,50.90,NULL,NULL,'2026-06-05 14:58:14.725971',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(638,4,'2026-04-21 13:53:00',71.60,33.10,52.20,71.60,33.10,52.20,NULL,NULL,'2026-06-05 14:58:14.735997',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(639,4,'2026-04-21 13:54:00',55.70,37.20,54.40,55.70,37.20,54.40,NULL,NULL,'2026-06-05 14:58:14.745304',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(640,4,'2026-04-21 13:56:00',97.40,62.10,115.40,97.40,62.10,115.40,NULL,NULL,'2026-06-05 14:58:14.758744',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(641,4,'2026-04-21 13:57:00',64.40,42.20,113.50,64.40,42.20,113.50,NULL,NULL,'2026-06-05 14:58:14.772688',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(642,4,'2026-04-21 13:58:00',42.80,36.40,81.60,42.80,36.40,81.60,NULL,NULL,'2026-06-05 14:58:14.782572',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(643,4,'2026-04-21 14:00:00',38.50,37.70,61.20,38.50,37.70,61.20,NULL,NULL,'2026-06-05 14:58:14.792058',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(644,4,'2026-04-21 14:01:00',52.50,35.10,97.40,52.50,35.10,97.40,NULL,NULL,'2026-06-05 14:58:14.802830',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(645,4,'2026-04-21 14:02:00',39.40,38.20,78.30,39.40,38.20,78.30,NULL,NULL,'2026-06-05 14:58:14.812705',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(646,4,'2026-04-21 14:03:00',48.00,44.20,112.00,48.00,44.20,112.00,NULL,NULL,'2026-06-05 14:58:14.822034',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(647,4,'2026-04-21 14:05:00',57.20,34.80,119.90,57.20,34.80,119.90,NULL,NULL,'2026-06-05 14:58:14.831901',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(648,4,'2026-04-21 14:06:00',38.10,38.30,102.30,38.10,38.30,102.30,NULL,NULL,'2026-06-05 14:58:14.840685',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(649,4,'2026-04-21 14:07:00',24.50,43.70,83.30,24.50,43.70,83.30,NULL,NULL,'2026-06-05 14:58:14.850272',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(650,4,'2026-04-21 14:08:00',33.70,43.80,74.00,33.70,43.80,74.00,NULL,NULL,'2026-06-05 14:58:14.858898',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(651,4,'2026-04-21 14:10:00',80.70,55.00,82.50,80.70,55.00,82.50,NULL,NULL,'2026-06-05 14:58:14.870483',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(652,4,'2026-04-21 14:11:00',38.70,55.00,135.20,38.70,55.00,135.20,NULL,NULL,'2026-06-05 14:58:14.884335',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(653,4,'2026-04-21 14:12:00',42.50,49.40,109.00,42.50,49.40,109.00,NULL,NULL,'2026-06-05 14:58:14.894524',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(654,4,'2026-04-21 14:14:00',35.80,45.80,114.40,35.80,45.80,114.40,NULL,NULL,'2026-06-05 14:58:14.905049',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(655,4,'2026-04-21 14:15:00',36.50,51.10,89.40,36.50,51.10,89.40,NULL,NULL,'2026-06-05 14:58:14.917334',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(656,4,'2026-04-21 14:17:00',56.40,55.00,104.00,56.40,55.00,104.00,NULL,NULL,'2026-06-05 14:58:14.930388',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(657,4,'2026-04-21 14:18:00',33.20,60.20,105.00,33.20,60.20,105.00,NULL,NULL,'2026-06-05 14:58:14.939158',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(658,4,'2026-04-21 14:19:00',68.10,72.80,114.80,68.10,72.80,114.80,NULL,NULL,'2026-06-05 14:58:14.949569',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(659,4,'2026-04-21 14:20:00',86.70,41.40,59.70,86.70,41.40,59.70,NULL,NULL,'2026-06-05 14:58:14.963486',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(660,4,'2026-04-21 14:22:00',57.20,47.70,66.40,57.20,47.70,66.40,NULL,NULL,'2026-06-05 14:58:14.972162',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(661,4,'2026-04-21 14:23:00',51.40,46.50,95.40,51.40,46.50,95.40,NULL,NULL,'2026-06-05 14:58:14.984623',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(662,4,'2026-04-21 14:24:00',80.90,59.50,81.10,80.90,59.50,81.10,NULL,NULL,'2026-06-05 14:58:14.995574',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(663,4,'2026-04-21 14:26:00',67.70,52.80,85.60,67.70,52.80,85.60,NULL,NULL,'2026-06-05 14:58:15.006132',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(664,4,'2026-04-21 14:27:00',43.20,51.50,64.40,43.20,51.50,64.40,NULL,NULL,'2026-06-05 14:58:15.016442',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(665,4,'2026-04-21 14:28:00',92.10,58.80,64.30,92.10,58.80,64.30,NULL,NULL,'2026-06-05 14:58:15.026922',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(666,4,'2026-04-21 14:29:00',59.00,42.00,77.10,59.00,42.00,77.10,NULL,NULL,'2026-06-05 14:58:15.037866',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(667,4,'2026-04-21 14:31:00',69.10,47.10,91.60,69.10,47.10,91.60,NULL,NULL,'2026-06-05 14:58:15.047229',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(668,4,'2026-04-21 14:32:00',81.20,44.40,103.60,81.20,44.40,103.60,NULL,NULL,'2026-06-05 14:58:15.056758',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(669,4,'2026-04-21 14:33:00',50.10,44.00,67.90,50.10,44.00,67.90,NULL,NULL,'2026-06-05 14:58:15.066647',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(670,4,'2026-04-21 14:34:00',60.90,44.10,101.60,60.90,44.10,101.60,NULL,NULL,'2026-06-05 14:58:15.077010',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(671,4,'2026-04-21 14:36:00',55.20,42.60,75.80,55.20,42.60,75.80,NULL,NULL,'2026-06-05 14:58:15.091117',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(672,4,'2026-04-21 14:37:00',60.90,41.00,67.30,60.90,41.00,67.30,NULL,NULL,'2026-06-05 14:58:15.100543',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(673,4,'2026-04-21 14:38:00',66.70,42.40,63.60,66.70,42.40,63.60,NULL,NULL,'2026-06-05 14:58:15.108919',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(674,4,'2026-04-21 14:39:00',66.10,47.20,58.00,66.10,47.20,58.00,NULL,NULL,'2026-06-05 14:58:15.122381',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(675,4,'2026-04-21 14:41:00',62.90,51.20,69.00,62.90,51.20,69.00,NULL,NULL,'2026-06-05 14:58:15.133140',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(676,4,'2026-04-21 14:42:00',87.90,68.00,98.00,87.90,68.00,98.00,NULL,NULL,'2026-06-05 14:58:15.146031',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(677,4,'2026-04-21 14:43:00',77.70,58.10,100.10,77.70,58.10,100.10,NULL,NULL,'2026-06-05 14:58:15.155959',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(678,4,'2026-04-21 14:45:00',51.60,72.60,74.50,51.60,72.60,74.50,NULL,NULL,'2026-06-05 14:58:15.165924',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(679,4,'2026-04-21 14:46:00',55.60,55.70,96.70,55.60,55.70,96.70,NULL,NULL,'2026-06-05 14:58:15.174778',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(680,4,'2026-04-21 14:48:00',43.70,40.90,96.50,43.70,40.90,96.50,NULL,NULL,'2026-06-05 14:58:15.185703',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(681,4,'2026-04-21 14:49:00',52.90,54.40,95.20,52.90,54.40,95.20,NULL,NULL,'2026-06-05 14:58:15.198960',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(682,4,'2026-04-21 14:50:00',71.20,51.70,94.80,71.20,51.70,94.80,NULL,NULL,'2026-06-05 14:58:15.208112',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(683,4,'2026-04-21 14:51:00',71.70,73.70,64.10,71.70,73.70,64.10,NULL,NULL,'2026-06-05 14:58:15.218780',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(684,4,'2026-04-21 14:53:00',58.00,44.90,110.00,58.00,44.90,110.00,NULL,NULL,'2026-06-05 14:58:15.228494',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(685,4,'2026-04-21 14:54:00',75.20,48.70,126.70,75.20,48.70,126.70,NULL,NULL,'2026-06-05 14:58:15.238607',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(686,4,'2026-04-21 14:55:00',55.10,45.20,127.90,55.10,45.20,127.90,NULL,NULL,'2026-06-05 14:58:15.248509',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(687,4,'2026-04-21 14:57:00',48.50,44.20,114.10,48.50,44.20,114.10,NULL,NULL,'2026-06-05 14:58:15.258514',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(688,4,'2026-04-21 14:58:00',92.90,42.70,72.00,92.90,42.70,72.00,NULL,NULL,'2026-06-05 14:58:15.268701',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(689,4,'2026-04-21 14:59:00',76.60,68.10,95.20,76.60,68.10,95.20,NULL,NULL,'2026-06-05 14:58:15.281274',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(690,4,'2026-04-21 15:00:00',53.30,62.60,97.30,53.30,62.60,97.30,NULL,NULL,'2026-06-05 14:58:15.290208',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(691,4,'2026-04-21 15:02:00',53.10,64.70,94.80,53.10,64.70,94.80,NULL,NULL,'2026-06-05 14:58:15.300565',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(692,4,'2026-04-21 15:03:00',70.70,64.20,102.70,70.70,64.20,102.70,NULL,NULL,'2026-06-05 14:58:15.308981',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(693,4,'2026-04-21 15:04:00',58.20,55.00,96.60,58.20,55.00,96.60,NULL,NULL,'2026-06-05 14:58:15.322113',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(694,4,'2026-04-21 15:06:00',52.20,40.00,90.50,52.20,40.00,90.50,NULL,NULL,'2026-06-05 14:58:15.334221',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(695,4,'2026-04-21 15:07:00',53.50,47.30,108.40,53.50,47.30,108.40,NULL,NULL,'2026-06-05 14:58:15.343236',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(696,4,'2026-04-21 15:08:00',62.90,41.60,123.80,62.90,41.60,123.80,NULL,NULL,'2026-06-05 14:58:15.352997',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(697,4,'2026-04-21 15:10:00',111.30,80.20,136.90,111.30,80.20,136.90,NULL,NULL,'2026-06-05 14:58:15.362645',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(698,4,'2026-04-21 15:11:00',77.80,55.20,134.80,77.80,55.20,134.80,NULL,NULL,'2026-06-05 14:58:15.371672',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(699,4,'2026-04-21 15:12:00',47.40,54.30,90.80,47.40,54.30,90.80,NULL,NULL,'2026-06-05 14:58:15.380676',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(700,4,'2026-04-21 15:13:00',73.50,62.80,112.20,73.50,62.80,112.20,NULL,NULL,'2026-06-05 14:58:15.390145',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(701,4,'2026-04-21 15:15:00',86.20,47.40,109.90,86.20,47.40,109.90,NULL,NULL,'2026-06-05 14:58:15.402190',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(702,4,'2026-04-21 15:16:00',88.60,69.10,102.40,88.60,69.10,102.40,NULL,NULL,'2026-06-05 14:58:15.411468',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(703,4,'2026-04-21 15:17:00',39.00,44.00,127.70,39.00,44.00,127.70,NULL,NULL,'2026-06-05 14:58:15.421449',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(704,4,'2026-04-21 15:19:00',40.50,44.30,133.00,40.50,44.30,133.00,NULL,NULL,'2026-06-05 14:58:15.430538',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(705,4,'2026-04-21 15:20:00',58.90,52.10,121.20,58.90,52.10,121.20,NULL,NULL,'2026-06-05 14:58:15.439495',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(706,4,'2026-04-21 15:21:00',83.00,59.00,85.60,83.00,59.00,85.60,NULL,NULL,'2026-06-05 14:58:15.451743',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(707,4,'2026-04-21 15:22:00',78.90,61.20,103.70,78.90,61.20,103.70,NULL,NULL,'2026-06-05 14:58:15.462834',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(708,4,'2026-04-21 15:24:00',62.20,83.20,128.40,62.20,83.20,128.40,NULL,NULL,'2026-06-05 14:58:15.471783',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(709,4,'2026-04-21 15:25:00',40.00,44.90,95.20,40.00,44.90,95.20,NULL,NULL,'2026-06-05 14:58:15.481979',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(710,4,'2026-04-21 15:27:00',47.10,39.50,96.80,47.10,39.50,96.80,NULL,NULL,'2026-06-05 14:58:15.492463',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(711,4,'2026-04-21 15:28:00',77.50,74.90,98.30,77.50,74.90,98.30,NULL,NULL,'2026-06-05 14:58:15.503645',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(712,4,'2026-04-21 15:29:00',83.50,71.50,127.70,83.50,71.50,127.70,NULL,NULL,'2026-06-05 14:58:15.512869',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(713,4,'2026-04-21 15:31:00',48.20,36.40,55.20,48.20,36.40,55.20,NULL,NULL,'2026-06-05 14:58:15.523577',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(714,4,'2026-04-21 15:32:00',57.10,51.70,63.50,57.10,51.70,63.50,NULL,NULL,'2026-06-05 14:58:15.533918',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(715,4,'2026-04-21 15:33:00',40.90,37.50,76.10,40.90,37.50,76.10,NULL,NULL,'2026-06-05 14:58:15.542959',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(716,4,'2026-04-21 15:35:00',34.30,40.60,91.90,34.30,40.60,91.90,NULL,NULL,'2026-06-05 14:58:15.553142',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(717,4,'2026-04-21 15:36:00',44.80,42.80,112.20,44.80,42.80,112.20,NULL,NULL,'2026-06-05 14:58:15.561393',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(718,4,'2026-04-21 15:37:00',112.00,45.20,99.90,112.00,45.20,99.90,NULL,NULL,'2026-06-05 14:58:15.571103',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(719,4,'2026-04-21 15:38:00',50.30,43.40,65.60,50.30,43.40,65.60,NULL,NULL,'2026-06-05 14:58:15.581580',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(720,4,'2026-04-21 15:40:00',42.80,59.90,64.70,42.80,59.90,64.70,NULL,NULL,'2026-06-05 14:58:15.591988',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(721,4,'2026-04-21 15:41:00',57.90,47.50,97.10,57.90,47.50,97.10,NULL,NULL,'2026-06-05 14:58:15.604246',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(722,4,'2026-04-21 15:42:00',61.60,46.80,94.40,61.60,46.80,94.40,NULL,NULL,'2026-06-05 14:58:15.615427',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(723,4,'2026-04-21 15:44:00',77.70,46.10,127.60,77.70,46.10,127.60,NULL,NULL,'2026-06-05 14:58:15.623278',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(724,4,'2026-04-21 15:45:00',89.20,43.80,100.00,89.20,43.80,100.00,NULL,NULL,'2026-06-05 14:58:15.634991',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(725,4,'2026-04-21 15:46:00',44.80,41.90,126.60,44.80,41.90,126.60,NULL,NULL,'2026-06-05 14:58:15.645095',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(726,4,'2026-04-21 15:47:00',50.00,42.80,74.20,50.00,42.80,74.20,NULL,NULL,'2026-06-05 14:58:15.655860',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(727,4,'2026-04-21 15:49:00',73.50,52.30,134.70,73.50,52.30,134.70,NULL,NULL,'2026-06-05 14:58:15.669107',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(728,4,'2026-04-21 15:50:00',86.30,51.90,100.50,86.30,51.90,100.50,NULL,NULL,'2026-06-05 14:58:15.680725',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(729,4,'2026-04-21 15:51:00',56.50,70.10,116.50,56.50,70.10,116.50,NULL,NULL,'2026-06-05 14:58:15.690697',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(730,4,'2026-04-21 15:53:00',53.90,54.90,103.20,53.90,54.90,103.20,NULL,NULL,'2026-06-05 14:58:15.702957',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(731,4,'2026-04-21 15:54:00',73.40,47.00,75.40,73.40,47.00,75.40,NULL,NULL,'2026-06-05 14:58:15.714047',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(732,4,'2026-04-21 15:55:00',86.70,46.50,162.40,86.70,46.50,162.40,NULL,NULL,'2026-06-05 14:58:15.723709',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(733,4,'2026-04-21 15:56:00',60.80,55.80,154.20,60.80,55.80,154.20,NULL,NULL,'2026-06-05 14:58:15.740333',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(734,4,'2026-04-21 15:58:00',75.30,45.60,65.60,75.30,45.60,65.60,NULL,NULL,'2026-06-05 14:58:15.750484',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(735,4,'2026-04-21 15:59:00',60.40,59.60,129.00,60.40,59.60,129.00,NULL,NULL,'2026-06-05 14:58:15.760183',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(736,4,'2026-04-21 16:00:00',77.00,49.20,78.50,77.00,49.20,78.50,NULL,NULL,'2026-06-05 14:58:15.769416',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(737,4,'2026-04-21 16:02:00',79.80,58.10,85.80,79.80,58.10,85.80,NULL,NULL,'2026-06-05 14:58:15.788642',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(738,4,'2026-04-21 16:03:00',58.70,77.30,124.90,58.70,77.30,124.90,NULL,NULL,'2026-06-05 14:58:15.800650',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(739,4,'2026-04-21 16:04:00',56.60,52.50,105.70,56.60,52.50,105.70,NULL,NULL,'2026-06-05 14:58:15.820691',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(740,4,'2026-04-21 16:05:00',74.50,61.50,127.60,74.50,61.50,127.60,NULL,NULL,'2026-06-05 14:58:15.833417',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(741,4,'2026-04-21 16:07:00',62.70,47.30,108.10,62.70,47.30,108.10,NULL,NULL,'2026-06-05 14:58:15.841990',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(742,4,'2026-04-21 16:08:00',60.60,89.90,154.20,60.60,89.90,154.20,NULL,NULL,'2026-06-05 14:58:15.852738',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(743,4,'2026-04-21 16:10:00',87.90,76.20,115.90,87.90,76.20,115.90,NULL,NULL,'2026-06-05 14:58:15.862445',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(744,4,'2026-04-21 16:11:00',63.00,61.50,87.10,63.00,61.50,87.10,NULL,NULL,'2026-06-05 14:58:15.880562',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(745,4,'2026-04-21 16:12:00',47.40,43.40,81.50,47.40,43.40,81.50,NULL,NULL,'2026-06-05 14:58:15.891600',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(746,4,'2026-04-21 16:13:00',74.50,54.40,113.40,74.50,54.40,113.40,NULL,NULL,'2026-06-05 14:58:15.900715',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(747,4,'2026-04-21 16:15:00',51.50,50.40,127.90,51.50,50.40,127.90,NULL,NULL,'2026-06-05 14:58:15.914134',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(748,4,'2026-04-21 16:16:00',60.30,50.80,125.20,60.30,50.80,125.20,NULL,NULL,'2026-06-05 14:58:15.927127',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(749,4,'2026-04-21 16:17:00',79.00,61.60,98.70,79.00,61.60,98.70,NULL,NULL,'2026-06-05 14:58:15.938923',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(750,4,'2026-04-21 16:19:00',56.20,71.20,88.70,56.20,71.20,88.70,NULL,NULL,'2026-06-05 14:58:15.948863',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(751,4,'2026-04-21 16:20:00',57.00,69.80,97.90,57.00,69.80,97.90,NULL,NULL,'2026-06-05 14:58:15.956521',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(752,4,'2026-04-21 16:21:00',88.10,79.90,153.60,88.10,79.90,153.60,NULL,NULL,'2026-06-05 14:58:15.965457',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(753,4,'2026-04-21 16:23:00',88.10,77.60,131.50,88.10,77.60,131.50,NULL,NULL,'2026-06-05 14:58:15.976360',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(754,4,'2026-04-21 16:24:00',84.10,57.80,122.90,84.10,57.80,122.90,NULL,NULL,'2026-06-05 14:58:15.987634',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(755,4,'2026-04-21 16:25:00',65.20,54.90,131.30,65.20,54.90,131.30,NULL,NULL,'2026-06-05 14:58:15.997179',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(756,4,'2026-04-21 16:26:00',79.10,58.20,98.40,79.10,58.20,98.40,NULL,NULL,'2026-06-05 14:58:16.005864',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(757,4,'2026-04-21 16:28:00',70.30,52.10,117.70,70.30,52.10,117.70,NULL,NULL,'2026-06-05 14:58:16.016252',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(758,4,'2026-04-21 16:29:00',83.90,63.10,113.60,83.90,63.10,113.60,NULL,NULL,'2026-06-05 14:58:16.026539',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(759,4,'2026-04-21 16:30:00',87.00,67.40,122.10,87.00,67.40,122.10,NULL,NULL,'2026-06-05 14:58:16.037601',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(760,4,'2026-04-21 16:32:00',72.80,74.10,137.70,72.80,74.10,137.70,NULL,NULL,'2026-06-05 14:58:16.050791',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(761,4,'2026-04-21 16:33:00',50.30,50.20,73.00,50.30,50.20,73.00,NULL,NULL,'2026-06-05 14:58:16.062179',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(762,4,'2026-04-21 16:34:00',57.10,60.80,72.00,57.10,60.80,72.00,NULL,NULL,'2026-06-05 14:58:16.072061',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(763,4,'2026-04-21 16:35:00',92.90,66.30,129.10,92.90,66.30,129.10,NULL,NULL,'2026-06-05 14:58:16.082827',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(764,4,'2026-04-21 16:37:00',49.50,57.90,109.10,49.50,57.90,109.10,NULL,NULL,'2026-06-05 14:58:16.092877',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(765,4,'2026-04-21 16:38:00',53.90,37.70,107.50,53.90,37.70,107.50,NULL,NULL,'2026-06-05 14:58:16.102722',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(766,4,'2026-04-21 16:39:00',46.30,49.10,58.20,46.30,49.10,58.20,NULL,NULL,'2026-06-05 14:58:16.112954',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(767,4,'2026-04-21 16:41:00',80.50,71.40,68.60,80.50,71.40,68.60,NULL,NULL,'2026-06-05 14:58:16.121828',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(768,4,'2026-04-21 16:42:00',107.90,59.40,101.80,107.90,59.40,101.80,NULL,NULL,'2026-06-05 14:58:16.133633',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(769,4,'2026-04-21 16:43:00',52.60,70.10,96.50,52.60,70.10,96.50,NULL,NULL,'2026-06-05 14:58:16.146006',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(770,4,'2026-04-21 16:44:00',46.50,63.20,69.50,46.50,63.20,69.50,NULL,NULL,'2026-06-05 14:58:16.155334',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(771,4,'2026-04-21 16:46:00',42.70,51.60,72.40,42.70,51.60,72.40,NULL,NULL,'2026-06-05 14:58:16.165677',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(772,4,'2026-04-21 16:47:00',80.00,40.30,74.90,80.00,40.30,74.90,NULL,NULL,'2026-06-05 14:58:16.178906',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(773,4,'2026-04-21 16:48:00',51.00,56.40,98.80,51.00,56.40,98.80,NULL,NULL,'2026-06-05 14:58:16.187199',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(774,4,'2026-04-21 16:50:00',68.40,65.90,71.20,68.40,65.90,71.20,NULL,NULL,'2026-06-05 14:58:16.197777',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(775,4,'2026-04-21 16:51:00',81.30,71.00,66.50,81.30,71.00,66.50,NULL,NULL,'2026-06-05 14:58:16.206374',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(776,4,'2026-04-21 16:52:00',111.90,76.70,70.60,111.90,76.70,70.60,NULL,NULL,'2026-06-05 14:58:16.215452',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(777,4,'2026-04-21 16:54:00',68.00,48.90,108.30,68.00,48.90,108.30,NULL,NULL,'2026-06-05 14:58:16.225625',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(778,4,'2026-04-21 16:55:00',55.70,60.10,65.20,55.70,60.10,65.20,NULL,NULL,'2026-06-05 14:58:16.235205',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(779,4,'2026-04-21 16:56:00',84.40,46.90,68.90,84.40,46.90,68.90,NULL,NULL,'2026-06-05 14:58:16.243842',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(780,4,'2026-04-21 16:58:00',124.10,59.00,69.00,124.10,59.00,69.00,NULL,NULL,'2026-06-05 14:58:16.252457',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(781,4,'2026-04-21 16:59:00',66.90,76.80,88.20,66.90,76.80,88.20,NULL,NULL,'2026-06-05 14:58:16.260977',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(782,4,'2026-04-21 17:00:00',64.30,91.00,102.60,64.30,91.00,102.60,NULL,NULL,'2026-06-05 14:58:16.271014',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(783,4,'2026-04-21 17:02:00',68.20,73.90,76.90,68.20,73.90,76.90,NULL,NULL,'2026-06-05 14:58:16.280208',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(784,4,'2026-04-21 17:04:00',62.70,72.80,89.10,62.70,72.80,89.10,NULL,NULL,'2026-06-05 14:58:16.287126',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(785,4,'2026-04-21 17:05:00',57.30,82.10,91.20,57.30,82.10,91.20,NULL,NULL,'2026-06-05 14:58:16.296552',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(786,4,'2026-04-21 17:06:00',124.90,80.40,78.10,124.90,80.40,78.10,NULL,NULL,'2026-06-05 14:58:16.303655',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(787,4,'2026-04-21 17:08:00',86.30,63.50,70.90,86.30,63.50,70.90,NULL,NULL,'2026-06-05 14:58:16.312575',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(788,4,'2026-04-21 17:09:00',67.40,84.20,73.50,67.40,84.20,73.50,NULL,NULL,'2026-06-05 14:58:16.321542',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(789,4,'2026-04-21 17:10:00',61.70,64.00,110.80,61.70,64.00,110.80,NULL,NULL,'2026-06-05 14:58:16.332816',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(790,4,'2026-04-21 17:11:00',82.20,57.70,96.20,82.20,57.70,96.20,NULL,NULL,'2026-06-05 14:58:16.343450',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(791,4,'2026-04-21 17:13:00',109.40,71.20,138.30,109.40,71.20,138.30,NULL,NULL,'2026-06-05 14:58:16.351721',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(792,4,'2026-04-21 17:14:00',68.30,95.20,72.90,68.30,95.20,72.90,NULL,NULL,'2026-06-05 14:58:16.362564',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(793,4,'2026-04-21 17:15:00',65.90,97.10,116.40,65.90,97.10,116.40,NULL,NULL,'2026-06-05 14:58:16.369919',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(794,4,'2026-04-21 17:17:00',88.80,104.90,122.40,88.80,104.90,122.40,NULL,NULL,'2026-06-05 14:58:16.378222',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(795,4,'2026-04-21 17:18:00',129.90,104.10,98.40,129.90,104.10,98.40,NULL,NULL,'2026-06-05 14:58:16.386733',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(796,4,'2026-04-21 17:19:00',117.40,62.80,72.70,117.40,62.80,72.70,NULL,NULL,'2026-06-05 14:58:16.395096',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(797,4,'2026-04-21 17:21:00',88.00,87.50,90.10,88.00,87.50,90.10,NULL,NULL,'2026-06-05 14:58:16.403336',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(798,4,'2026-04-21 17:22:00',97.30,86.70,132.70,97.30,86.70,132.70,NULL,NULL,'2026-06-05 14:58:16.412793',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(799,4,'2026-04-21 17:23:00',113.20,96.90,105.00,113.20,96.90,105.00,NULL,NULL,'2026-06-05 14:58:16.420480',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(800,4,'2026-04-21 17:25:00',108.40,101.50,88.50,108.40,101.50,88.50,NULL,NULL,'2026-06-05 14:58:16.431836',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(801,4,'2026-04-21 17:26:00',118.10,98.00,115.40,118.10,98.00,115.40,NULL,NULL,'2026-06-05 14:58:16.440644',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(802,4,'2026-04-21 17:27:00',115.90,90.40,134.50,115.90,90.40,134.50,NULL,NULL,'2026-06-05 14:58:16.450696',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(803,4,'2026-04-21 17:29:00',106.60,74.80,108.40,106.60,74.80,108.40,NULL,NULL,'2026-06-05 14:58:16.459521',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(804,4,'2026-04-21 17:30:00',87.50,88.00,109.90,87.50,88.00,109.90,NULL,NULL,'2026-06-05 14:58:16.468417',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(805,4,'2026-04-21 17:31:00',77.60,68.00,77.60,77.60,68.00,77.60,NULL,NULL,'2026-06-05 14:58:16.477825',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(806,4,'2026-04-21 17:33:00',87.70,110.10,82.50,87.70,110.10,82.50,NULL,NULL,'2026-06-05 14:58:16.486343',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(807,4,'2026-04-21 17:34:00',138.50,112.60,114.60,138.50,112.60,114.60,NULL,NULL,'2026-06-05 14:58:16.496672',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(808,4,'2026-04-21 17:35:00',99.40,95.90,89.20,99.40,95.90,89.20,NULL,NULL,'2026-06-05 14:58:16.507909',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(809,4,'2026-04-21 17:37:00',112.70,82.50,115.70,112.70,82.50,115.70,NULL,NULL,'2026-06-05 14:58:16.516338',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(810,4,'2026-04-21 17:38:00',106.10,57.60,66.10,106.10,57.60,66.10,NULL,NULL,'2026-06-05 14:58:16.524601',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(811,4,'2026-04-21 17:39:00',85.40,95.90,102.10,85.40,95.90,102.10,NULL,NULL,'2026-06-05 14:58:16.534226',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(812,4,'2026-04-21 17:41:00',117.90,98.60,99.60,117.90,98.60,99.60,NULL,NULL,'2026-06-05 14:58:16.542318',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(813,4,'2026-04-21 17:42:00',95.90,95.80,88.70,95.90,95.80,88.70,NULL,NULL,'2026-06-05 14:58:16.552404',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(814,4,'2026-04-21 17:43:00',87.80,111.90,71.20,87.80,111.90,71.20,NULL,NULL,'2026-06-05 14:58:16.562149',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(815,4,'2026-04-21 17:45:00',99.40,76.10,73.80,99.40,76.10,73.80,NULL,NULL,'2026-06-05 14:58:16.569442',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(816,4,'2026-04-21 17:46:00',92.30,81.90,98.30,92.30,81.90,98.30,NULL,NULL,'2026-06-05 14:58:16.580182',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(817,4,'2026-04-21 17:47:00',93.30,63.20,91.10,93.30,63.20,91.10,NULL,NULL,'2026-06-05 14:58:16.589828',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(818,4,'2026-04-21 17:49:00',110.50,73.60,73.90,110.50,73.60,73.90,NULL,NULL,'2026-06-05 14:58:16.597884',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(819,4,'2026-04-21 17:50:00',103.60,95.50,92.10,103.60,95.50,92.10,NULL,NULL,'2026-06-05 14:58:16.607521',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(820,4,'2026-04-21 17:51:00',106.90,101.60,92.10,106.90,101.60,92.10,NULL,NULL,'2026-06-05 14:58:16.614564',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(821,4,'2026-04-21 17:53:00',113.60,90.20,71.20,113.60,90.20,71.20,NULL,NULL,'2026-06-05 14:58:16.622843',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(822,4,'2026-04-21 17:54:00',79.70,100.30,86.00,79.70,100.30,86.00,NULL,NULL,'2026-06-05 14:58:16.632270',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(823,4,'2026-04-21 17:55:00',111.90,89.50,70.90,111.90,89.50,70.90,NULL,NULL,'2026-06-05 14:58:16.641072',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(824,4,'2026-04-21 17:56:00',144.20,79.70,76.70,144.20,79.70,76.70,NULL,NULL,'2026-06-05 14:58:16.651392',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(825,4,'2026-04-21 17:58:00',91.60,81.10,90.70,91.60,81.10,90.70,NULL,NULL,'2026-06-05 14:58:16.661046',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(826,4,'2026-04-21 17:59:00',104.50,73.80,90.00,104.50,73.80,90.00,NULL,NULL,'2026-06-05 14:58:16.668349',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(827,4,'2026-04-21 18:00:00',106.20,101.50,79.70,106.20,101.50,79.70,NULL,NULL,'2026-06-05 14:58:16.677065',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(828,4,'2026-04-21 18:02:00',108.90,103.70,72.20,108.90,103.70,72.20,NULL,NULL,'2026-06-05 14:58:16.685754',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(829,4,'2026-04-21 18:03:00',83.40,105.70,76.00,83.40,105.70,76.00,NULL,NULL,'2026-06-05 14:58:16.695442',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(830,4,'2026-04-21 18:04:00',105.10,104.40,92.90,105.10,104.40,92.90,NULL,NULL,'2026-06-05 14:58:16.702801',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(831,4,'2026-04-21 18:06:00',109.10,86.10,94.30,109.10,86.10,94.30,NULL,NULL,'2026-06-05 14:58:16.711815',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(832,4,'2026-04-21 18:07:00',110.20,91.90,104.80,110.20,91.90,104.80,NULL,NULL,'2026-06-05 14:58:16.718745',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(833,4,'2026-04-21 18:08:00',126.70,82.10,72.50,126.70,82.10,72.50,NULL,NULL,'2026-06-05 14:58:16.730024',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(834,4,'2026-04-21 18:09:00',127.30,130.80,132.10,127.30,130.80,132.10,NULL,NULL,'2026-06-05 14:58:16.737503',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(835,4,'2026-04-21 18:11:00',116.00,132.60,117.20,116.00,132.60,117.20,NULL,NULL,'2026-06-05 14:58:16.746746',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(836,4,'2026-04-21 18:12:00',137.80,107.50,70.60,137.80,107.50,70.60,NULL,NULL,'2026-06-05 14:58:16.755817',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(837,4,'2026-04-21 18:13:00',131.30,115.20,73.10,131.30,115.20,73.10,NULL,NULL,'2026-06-05 14:58:16.764388',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(838,4,'2026-04-21 18:15:00',120.00,136.60,88.40,120.00,136.60,88.40,NULL,NULL,'2026-06-05 14:58:16.774032',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(839,4,'2026-04-21 18:16:00',104.20,106.50,128.50,104.20,106.50,128.50,NULL,NULL,'2026-06-05 14:58:16.781501',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(840,4,'2026-04-21 18:17:00',126.00,90.00,79.70,126.00,90.00,79.70,NULL,NULL,'2026-06-05 14:58:16.790532',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(841,4,'2026-04-21 18:19:00',151.60,125.90,101.30,151.60,125.90,101.30,NULL,NULL,'2026-06-05 14:58:16.798828',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(842,4,'2026-04-21 18:20:00',134.40,133.90,90.50,134.40,133.90,90.50,NULL,NULL,'2026-06-05 14:58:16.808728',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(843,4,'2026-04-21 18:21:00',170.90,173.70,114.30,170.90,173.70,114.30,NULL,NULL,'2026-06-05 14:58:16.815987',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(844,4,'2026-04-21 18:23:00',147.20,158.40,171.60,147.20,158.40,171.60,NULL,NULL,'2026-06-05 14:58:16.824981',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(845,4,'2026-04-21 18:24:00',195.50,163.00,155.60,195.50,163.00,155.60,NULL,NULL,'2026-06-05 14:58:16.832580',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(846,4,'2026-04-21 18:25:00',171.20,157.10,133.50,171.20,157.10,133.50,NULL,NULL,'2026-06-05 14:58:16.841280',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(847,4,'2026-04-21 18:26:00',129.20,103.60,93.30,129.20,103.60,93.30,NULL,NULL,'2026-06-05 14:58:16.851109',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(848,4,'2026-04-21 18:28:00',182.00,142.30,148.90,182.00,142.30,148.90,NULL,NULL,'2026-06-05 14:58:16.860046',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(849,4,'2026-04-21 18:29:00',187.00,162.10,175.00,187.00,162.10,175.00,NULL,NULL,'2026-06-05 14:58:16.869426',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(850,4,'2026-04-21 18:30:00',112.10,149.40,95.30,112.10,149.40,95.30,NULL,NULL,'2026-06-05 14:58:16.879022',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(851,4,'2026-04-21 18:32:00',160.30,134.10,114.80,160.30,134.10,114.80,NULL,NULL,'2026-06-05 14:58:16.887005',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(852,4,'2026-04-21 18:33:00',164.90,137.20,120.80,164.90,137.20,120.80,NULL,NULL,'2026-06-05 14:58:16.896582',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(853,4,'2026-04-21 18:34:00',128.70,108.80,103.60,128.70,108.80,103.60,NULL,NULL,'2026-06-05 14:58:16.907210',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(854,4,'2026-04-21 18:36:00',114.20,111.60,146.70,114.20,111.60,146.70,NULL,NULL,'2026-06-05 14:58:16.915440',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(855,4,'2026-04-21 18:37:00',140.40,109.40,90.70,140.40,109.40,90.70,NULL,NULL,'2026-06-05 14:58:16.927782',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(856,4,'2026-04-21 18:38:00',98.30,77.10,70.00,98.30,77.10,70.00,NULL,NULL,'2026-06-05 14:58:16.935428',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(857,4,'2026-04-21 18:40:00',158.40,128.00,120.50,158.40,128.00,120.50,NULL,NULL,'2026-06-05 14:58:16.945430',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(858,4,'2026-04-21 18:41:00',128.80,138.00,118.90,128.80,138.00,118.90,NULL,NULL,'2026-06-05 14:58:16.953143',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(859,4,'2026-04-21 18:42:00',100.40,121.90,86.70,100.40,121.90,86.70,NULL,NULL,'2026-06-05 14:58:16.962414',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(860,4,'2026-04-21 18:44:00',137.80,117.80,98.40,137.80,117.80,98.40,NULL,NULL,'2026-06-05 14:58:16.970732',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(861,4,'2026-04-21 18:45:00',140.40,84.60,103.70,140.40,84.60,103.70,NULL,NULL,'2026-06-05 14:58:16.979356',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(862,4,'2026-04-21 18:46:00',107.40,135.10,89.30,107.40,135.10,89.30,NULL,NULL,'2026-06-05 14:58:16.990445',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(863,4,'2026-04-21 18:48:00',123.70,124.10,72.00,123.70,124.10,72.00,NULL,NULL,'2026-06-05 14:58:16.998982',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(864,4,'2026-04-21 18:49:00',161.40,133.10,76.80,161.40,133.10,76.80,NULL,NULL,'2026-06-05 14:58:17.008750',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(865,4,'2026-04-21 18:50:00',148.60,135.00,101.00,148.60,135.00,101.00,NULL,NULL,'2026-06-05 14:58:17.016507',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(866,4,'2026-04-21 18:51:00',129.80,87.80,98.10,129.80,87.80,98.10,NULL,NULL,'2026-06-05 14:58:17.025937',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(867,4,'2026-04-21 18:53:00',124.10,93.40,77.40,124.10,93.40,77.40,NULL,NULL,'2026-06-05 14:58:17.034406',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(868,4,'2026-04-21 18:54:00',110.20,92.50,114.60,110.20,92.50,114.60,NULL,NULL,'2026-06-05 14:58:17.045039',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(869,4,'2026-04-21 18:55:00',134.10,106.20,104.30,134.10,106.20,104.30,NULL,NULL,'2026-06-05 14:58:17.055714',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(870,4,'2026-04-21 18:57:00',115.10,113.20,103.90,115.10,113.20,103.90,NULL,NULL,'2026-06-05 14:58:17.064740',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(871,4,'2026-04-21 18:58:00',116.40,117.60,72.70,116.40,117.60,72.70,NULL,NULL,'2026-06-05 14:58:17.076242',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(872,4,'2026-04-21 18:59:00',116.60,120.80,70.60,116.60,120.80,70.60,NULL,NULL,'2026-06-05 14:58:17.084248',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(873,4,'2026-04-21 19:00:00',164.40,119.20,80.70,164.40,119.20,80.70,NULL,NULL,'2026-06-05 14:58:17.096653',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(874,4,'2026-04-21 19:02:00',113.00,98.30,104.60,113.00,98.30,104.60,NULL,NULL,'2026-06-05 14:58:17.105071',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(875,4,'2026-04-21 19:03:00',99.70,99.60,100.80,99.70,99.60,100.80,NULL,NULL,'2026-06-05 14:58:17.116411',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(876,4,'2026-04-21 19:04:00',122.40,100.00,89.90,122.40,100.00,89.90,NULL,NULL,'2026-06-05 14:58:17.127637',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(877,4,'2026-04-21 19:06:00',149.60,100.30,70.60,149.60,100.30,70.60,NULL,NULL,'2026-06-05 14:58:17.135863',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(878,4,'2026-04-21 19:07:00',102.80,119.50,102.20,102.80,119.50,102.20,NULL,NULL,'2026-06-05 14:58:17.147039',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(879,4,'2026-04-21 19:08:00',123.70,120.60,94.70,123.70,120.60,94.70,NULL,NULL,'2026-06-05 14:58:17.158484',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(880,4,'2026-04-21 19:10:00',92.20,121.20,76.80,92.20,121.20,76.80,NULL,NULL,'2026-06-05 14:58:17.166826',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(881,4,'2026-04-21 19:11:00',119.30,78.30,63.50,119.30,78.30,63.50,NULL,NULL,'2026-06-05 14:58:17.177059',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(882,4,'2026-04-21 19:12:00',96.50,86.50,84.90,96.50,86.50,84.90,NULL,NULL,'2026-06-05 14:58:17.188424',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(883,4,'2026-04-21 19:14:00',109.60,89.80,90.50,109.60,89.80,90.50,NULL,NULL,'2026-06-05 14:58:17.197060',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(884,4,'2026-04-21 19:15:00',88.00,77.30,88.90,88.00,77.30,88.90,NULL,NULL,'2026-06-05 14:58:17.209125',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(885,4,'2026-04-21 19:16:00',91.00,105.70,87.70,91.00,105.70,87.70,NULL,NULL,'2026-06-05 14:58:17.217173',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(886,4,'2026-04-21 19:17:00',136.50,146.50,122.30,136.50,146.50,122.30,NULL,NULL,'2026-06-05 14:58:17.227911',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(887,4,'2026-04-21 19:19:00',136.60,100.60,56.40,136.60,100.60,56.40,NULL,NULL,'2026-06-05 14:58:17.238212',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(888,4,'2026-04-21 19:20:00',115.90,88.90,82.20,115.90,88.90,82.20,NULL,NULL,'2026-06-05 14:58:17.247668',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(889,4,'2026-04-21 19:21:00',123.10,94.00,110.50,123.10,94.00,110.50,NULL,NULL,'2026-06-05 14:58:17.257863',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(890,4,'2026-04-21 19:22:00',129.80,101.50,113.70,129.80,101.50,113.70,NULL,NULL,'2026-06-05 14:58:17.265308',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(891,4,'2026-04-21 19:24:00',132.80,90.80,66.90,132.80,90.80,66.90,NULL,NULL,'2026-06-05 14:58:17.275662',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(892,4,'2026-04-21 19:25:00',107.90,125.50,111.30,107.90,125.50,111.30,NULL,NULL,'2026-06-05 14:58:17.284627',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(893,4,'2026-04-21 19:26:00',108.20,127.40,110.30,108.20,127.40,110.30,NULL,NULL,'2026-06-05 14:58:17.295962',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(894,4,'2026-04-21 19:28:00',102.50,123.50,109.70,102.50,123.50,109.70,NULL,NULL,'2026-06-05 14:58:17.305742',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(895,4,'2026-04-21 19:29:00',170.80,111.30,87.00,170.80,111.30,87.00,NULL,NULL,'2026-06-05 14:58:17.314544',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(896,4,'2026-04-21 19:30:00',124.40,123.90,97.70,124.40,123.90,97.70,NULL,NULL,'2026-06-05 14:58:17.325019',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(897,4,'2026-04-21 19:32:00',140.40,105.20,143.90,140.40,105.20,143.90,NULL,NULL,'2026-06-05 14:58:17.334939',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(898,4,'2026-04-21 19:33:00',161.90,93.50,145.00,161.90,93.50,145.00,NULL,NULL,'2026-06-05 14:58:17.344439',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(899,4,'2026-04-21 19:34:00',173.00,124.40,79.40,173.00,124.40,79.40,NULL,NULL,'2026-06-05 14:58:17.354290',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(900,4,'2026-04-21 19:36:00',122.30,123.20,80.20,122.30,123.20,80.20,NULL,NULL,'2026-06-05 14:58:17.363483',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(901,4,'2026-04-21 19:37:00',115.60,136.50,89.50,115.60,136.50,89.50,NULL,NULL,'2026-06-05 14:58:17.374419',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(902,4,'2026-04-21 19:38:00',149.90,126.90,89.30,149.90,126.90,89.30,NULL,NULL,'2026-06-05 14:58:17.383046',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(903,4,'2026-04-21 19:40:00',115.40,120.80,86.10,115.40,120.80,86.10,NULL,NULL,'2026-06-05 14:58:17.394472',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(904,4,'2026-04-21 19:41:00',154.70,147.20,116.00,154.70,147.20,116.00,NULL,NULL,'2026-06-05 14:58:17.403516',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(905,4,'2026-04-21 19:43:00',141.40,139.60,105.50,141.40,139.60,105.50,NULL,NULL,'2026-06-05 14:58:17.413146',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(906,4,'2026-04-21 19:44:00',124.60,111.70,104.40,124.60,111.70,104.40,NULL,NULL,'2026-06-05 14:58:17.423490',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(907,4,'2026-04-21 19:45:00',107.50,104.20,77.10,107.50,104.20,77.10,NULL,NULL,'2026-06-05 14:58:17.432897',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(908,4,'2026-04-21 19:47:00',127.60,88.90,119.30,127.60,88.90,119.30,NULL,NULL,'2026-06-05 14:58:17.444675',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(909,4,'2026-04-21 19:48:00',147.00,78.90,91.00,147.00,78.90,91.00,NULL,NULL,'2026-06-05 14:58:17.455699',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(910,4,'2026-04-21 19:49:00',122.90,132.90,103.70,122.90,132.90,103.70,NULL,NULL,'2026-06-05 14:58:17.466512',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(911,4,'2026-04-21 19:51:00',106.80,104.80,61.30,106.80,104.80,61.30,NULL,NULL,'2026-06-05 14:58:17.479193',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(912,4,'2026-04-21 19:52:00',185.00,125.70,114.30,185.00,125.70,114.30,NULL,NULL,'2026-06-05 14:58:17.491721',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(913,4,'2026-04-21 19:53:00',159.40,118.70,137.70,159.40,118.70,137.70,NULL,NULL,'2026-06-05 14:58:17.507206',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(914,4,'2026-04-21 19:55:00',83.20,75.90,83.00,83.20,75.90,83.00,NULL,NULL,'2026-06-05 14:58:17.515812',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(915,4,'2026-04-21 19:56:00',82.20,80.90,55.40,82.20,80.90,55.40,NULL,NULL,'2026-06-05 14:58:17.527432',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(916,4,'2026-04-21 19:57:00',130.10,94.00,55.60,130.10,94.00,55.60,NULL,NULL,'2026-06-05 14:58:17.537414',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(917,4,'2026-04-21 19:59:00',106.00,100.20,74.00,106.00,100.20,74.00,NULL,NULL,'2026-06-05 14:58:17.545939',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(918,4,'2026-04-21 20:00:00',126.00,111.40,88.80,126.00,111.40,88.80,NULL,NULL,'2026-06-05 14:58:17.557105',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(919,4,'2026-04-21 20:01:00',101.70,85.60,55.50,101.70,85.60,55.50,NULL,NULL,'2026-06-05 14:58:17.568623',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(920,4,'2026-04-21 20:02:00',121.70,90.00,66.10,121.70,90.00,66.10,NULL,NULL,'2026-06-05 14:58:17.582669',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(921,4,'2026-04-21 20:04:00',166.60,77.50,91.90,166.60,77.50,91.90,NULL,NULL,'2026-06-05 14:58:17.596302',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(922,4,'2026-04-21 20:05:00',93.50,87.70,95.80,93.50,87.70,95.80,NULL,NULL,'2026-06-05 14:58:17.607534',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(923,4,'2026-04-21 20:06:00',87.80,108.20,68.30,87.80,108.20,68.30,NULL,NULL,'2026-06-05 14:58:17.615950',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(924,4,'2026-04-21 20:08:00',106.70,109.90,68.30,106.70,109.90,68.30,NULL,NULL,'2026-06-05 14:58:17.628634',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(925,4,'2026-04-21 20:09:00',128.10,128.30,95.90,128.10,128.30,95.90,NULL,NULL,'2026-06-05 14:58:17.639089',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(926,4,'2026-04-21 20:10:00',93.40,113.90,90.00,93.40,113.90,90.00,NULL,NULL,'2026-06-05 14:58:17.649644',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(927,4,'2026-04-21 20:12:00',116.70,87.10,104.10,116.70,87.10,104.10,NULL,NULL,'2026-06-05 14:58:17.663601',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(928,4,'2026-04-21 20:13:00',135.60,92.30,81.10,135.60,92.30,81.10,NULL,NULL,'2026-06-05 14:58:17.675450',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(929,4,'2026-04-21 20:14:00',142.80,84.90,74.90,142.80,84.90,74.90,NULL,NULL,'2026-06-05 14:58:17.687534',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(930,4,'2026-04-21 20:15:00',135.70,125.30,113.10,135.70,125.30,113.10,NULL,NULL,'2026-06-05 14:58:17.696984',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(931,4,'2026-04-21 20:17:00',132.20,127.60,104.20,132.20,127.60,104.20,NULL,NULL,'2026-06-05 14:58:17.709382',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(932,4,'2026-04-21 20:18:00',115.30,123.80,103.10,115.30,123.80,103.10,NULL,NULL,'2026-06-05 14:58:17.718979',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(933,4,'2026-04-21 20:19:00',137.40,115.80,63.70,137.40,115.80,63.70,NULL,NULL,'2026-06-05 14:58:17.728124',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(934,4,'2026-04-21 20:20:00',144.30,104.20,66.80,144.30,104.20,66.80,NULL,NULL,'2026-06-05 14:58:17.739279',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(935,4,'2026-04-21 20:22:00',115.80,133.00,88.30,115.80,133.00,88.30,NULL,NULL,'2026-06-05 14:58:17.748644',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(936,4,'2026-04-21 20:23:00',111.50,113.80,117.10,111.50,113.80,117.10,NULL,NULL,'2026-06-05 14:58:17.759826',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(937,4,'2026-04-21 20:24:00',105.90,97.60,100.70,105.90,97.60,100.70,NULL,NULL,'2026-06-05 14:58:17.769962',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(938,4,'2026-04-21 20:26:00',105.90,88.60,119.10,105.90,88.60,119.10,NULL,NULL,'2026-06-05 14:58:17.780730',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(939,4,'2026-04-21 20:27:00',133.60,128.00,84.40,133.60,128.00,84.40,NULL,NULL,'2026-06-05 14:58:17.793935',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(940,4,'2026-04-21 20:28:00',124.60,134.10,102.30,124.60,134.10,102.30,NULL,NULL,'2026-06-05 14:58:17.807461',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(941,4,'2026-04-21 20:30:00',120.90,115.30,96.30,120.90,115.30,96.30,NULL,NULL,'2026-06-05 14:58:17.819736',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(942,4,'2026-04-21 20:31:00',137.30,139.80,124.70,137.30,139.80,124.70,NULL,NULL,'2026-06-05 14:58:17.832843',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(943,4,'2026-04-21 20:32:00',135.70,133.60,130.30,135.70,133.60,130.30,NULL,NULL,'2026-06-05 14:58:17.845849',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(944,4,'2026-04-21 20:33:00',141.60,111.30,99.90,141.60,111.30,99.90,NULL,NULL,'2026-06-05 14:58:17.857013',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(945,4,'2026-04-21 20:35:00',121.30,108.00,130.30,121.30,108.00,130.30,NULL,NULL,'2026-06-05 14:58:17.869327',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(946,4,'2026-04-21 20:36:00',116.60,95.90,116.80,116.60,95.90,116.80,NULL,NULL,'2026-06-05 14:58:17.878119',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(947,4,'2026-04-21 20:37:00',136.50,133.40,113.90,136.50,133.40,113.90,NULL,NULL,'2026-06-05 14:58:17.888306',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(948,4,'2026-04-21 20:39:00',106.60,147.00,93.00,106.60,147.00,93.00,NULL,NULL,'2026-06-05 14:58:17.898511',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(949,4,'2026-04-21 20:40:00',110.90,128.80,118.20,110.90,128.80,118.20,NULL,NULL,'2026-06-05 14:58:17.913035',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(950,4,'2026-04-21 20:41:00',129.80,122.70,154.60,129.80,122.70,154.60,NULL,NULL,'2026-06-05 14:58:17.931797',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(951,4,'2026-04-21 20:43:00',163.70,111.80,98.00,163.70,111.80,98.00,NULL,NULL,'2026-06-05 14:58:17.947299',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(952,4,'2026-04-21 20:44:00',96.90,113.30,105.50,96.90,113.30,105.50,NULL,NULL,'2026-06-05 14:58:17.959199',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(953,4,'2026-04-21 20:45:00',113.10,123.20,91.30,113.10,123.20,91.30,NULL,NULL,'2026-06-05 14:58:17.972375',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(954,4,'2026-04-21 20:47:00',153.90,142.90,96.70,153.90,142.90,96.70,NULL,NULL,'2026-06-05 14:58:17.983479',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(955,4,'2026-04-21 20:48:00',126.00,135.00,104.30,126.00,135.00,104.30,NULL,NULL,'2026-06-05 14:58:17.996233',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(956,4,'2026-04-21 20:49:00',118.00,130.30,91.60,118.00,130.30,91.60,NULL,NULL,'2026-06-05 14:58:18.022802',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(957,4,'2026-04-21 20:50:00',83.80,96.00,70.70,83.80,96.00,70.70,NULL,NULL,'2026-06-05 14:58:18.036771',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(958,4,'2026-04-21 20:52:00',94.60,108.50,120.80,94.60,108.50,120.80,NULL,NULL,'2026-06-05 14:58:18.052275',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(959,4,'2026-04-21 20:53:00',133.10,112.80,121.40,133.10,112.80,121.40,NULL,NULL,'2026-06-05 14:58:18.062065',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(960,4,'2026-04-21 20:54:00',115.70,115.10,82.70,115.70,115.10,82.70,NULL,NULL,'2026-06-05 14:58:18.072183',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(961,4,'2026-04-21 20:56:00',105.20,133.20,97.20,105.20,133.20,97.20,NULL,NULL,'2026-06-05 14:58:18.084743',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(962,4,'2026-04-21 20:57:00',85.40,114.80,103.80,85.40,114.80,103.80,NULL,NULL,'2026-06-05 14:58:18.098669',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(963,4,'2026-04-21 20:58:00',159.40,117.50,96.40,159.40,117.50,96.40,NULL,NULL,'2026-06-05 14:58:18.111841',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(964,4,'2026-04-21 20:59:00',153.50,124.60,102.00,153.50,124.60,102.00,NULL,NULL,'2026-06-05 14:58:18.125060',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(965,4,'2026-04-21 21:01:00',95.80,91.90,96.90,95.80,91.90,96.90,NULL,NULL,'2026-06-05 14:58:18.140699',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(966,4,'2026-04-21 21:02:00',129.20,77.70,82.10,129.20,77.70,82.10,NULL,NULL,'2026-06-05 14:58:18.152755',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(967,4,'2026-04-21 21:03:00',165.20,122.60,121.90,165.20,122.60,121.90,NULL,NULL,'2026-06-05 14:58:18.161955',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(968,4,'2026-04-21 21:05:00',144.60,102.90,91.30,144.60,102.90,91.30,NULL,NULL,'2026-06-05 14:58:18.172477',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(969,4,'2026-04-21 21:06:00',90.90,109.40,67.20,90.90,109.40,67.20,NULL,NULL,'2026-06-05 14:58:18.184172',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(970,4,'2026-04-21 21:07:00',81.00,103.10,66.50,81.00,103.10,66.50,NULL,NULL,'2026-06-05 14:58:18.193681',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(971,4,'2026-04-21 21:08:00',78.50,102.20,61.60,78.50,102.20,61.60,NULL,NULL,'2026-06-05 14:58:18.206165',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(972,4,'2026-04-21 21:10:00',124.10,91.10,110.80,124.10,91.10,110.80,NULL,NULL,'2026-06-05 14:58:18.215356',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(973,4,'2026-04-21 21:11:00',110.60,75.00,76.70,110.60,75.00,76.70,NULL,NULL,'2026-06-05 14:58:18.228483',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(974,4,'2026-04-21 21:12:00',90.20,118.00,73.40,90.20,118.00,73.40,NULL,NULL,'2026-06-05 14:58:18.243914',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(975,4,'2026-04-21 21:14:00',86.60,130.40,75.60,86.60,130.40,75.60,NULL,NULL,'2026-06-05 14:58:18.254531',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(976,4,'2026-04-21 21:15:00',144.10,113.70,104.10,144.10,113.70,104.10,NULL,NULL,'2026-06-05 14:58:18.263883',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(977,4,'2026-04-21 21:16:00',110.10,117.50,122.60,110.10,117.50,122.60,NULL,NULL,'2026-06-05 14:58:18.274714',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(978,4,'2026-04-21 21:17:00',102.30,113.20,72.00,102.30,113.20,72.00,NULL,NULL,'2026-06-05 14:58:18.286572',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(979,4,'2026-04-21 21:19:00',108.70,117.70,74.80,108.70,117.70,74.80,NULL,NULL,'2026-06-05 14:58:18.295180',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(980,4,'2026-04-21 21:20:00',93.40,106.90,88.10,93.40,106.90,88.10,NULL,NULL,'2026-06-05 14:58:18.307177',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(981,4,'2026-04-21 21:21:00',115.40,96.00,110.20,115.40,96.00,110.20,NULL,NULL,'2026-06-05 14:58:18.318801',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(982,4,'2026-04-21 21:23:00',115.30,100.20,103.90,115.30,100.20,103.90,NULL,NULL,'2026-06-05 14:58:18.328770',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(983,4,'2026-04-21 21:24:00',121.70,104.70,67.80,121.70,104.70,67.80,NULL,NULL,'2026-06-05 14:58:18.339981',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(984,4,'2026-04-21 21:25:00',92.40,130.50,84.80,92.40,130.50,84.80,NULL,NULL,'2026-06-05 14:58:18.349070',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(985,4,'2026-04-21 21:26:00',151.00,118.20,111.30,151.00,118.20,111.30,NULL,NULL,'2026-06-05 14:58:18.360768',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(986,4,'2026-04-21 21:28:00',165.90,129.50,114.00,165.90,129.50,114.00,NULL,NULL,'2026-06-05 14:58:18.370435',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(987,4,'2026-04-21 21:29:00',130.40,115.00,95.00,130.40,115.00,95.00,NULL,NULL,'2026-06-05 14:58:18.380153',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(988,4,'2026-04-21 21:30:00',88.80,107.40,107.80,88.80,107.40,107.80,NULL,NULL,'2026-06-05 14:58:18.389763',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(989,4,'2026-04-21 21:32:00',147.10,107.60,93.50,147.10,107.60,93.50,NULL,NULL,'2026-06-05 14:58:18.398700',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(990,4,'2026-04-21 21:33:00',161.10,148.60,141.40,161.10,148.60,141.40,NULL,NULL,'2026-06-05 14:58:18.409322',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(991,4,'2026-04-21 21:34:00',140.10,163.40,109.50,140.10,163.40,109.50,NULL,NULL,'2026-06-05 14:58:18.422426',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(992,4,'2026-04-21 21:36:00',143.20,154.30,122.10,143.20,154.30,122.10,NULL,NULL,'2026-06-05 14:58:18.434395',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(993,4,'2026-04-21 21:37:00',150.70,134.10,145.90,150.70,134.10,145.90,NULL,NULL,'2026-06-05 14:58:18.446959',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(994,4,'2026-04-21 21:38:00',125.60,105.50,118.90,125.60,105.50,118.90,NULL,NULL,'2026-06-05 14:58:18.457722',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(995,4,'2026-04-21 21:40:00',174.20,130.60,171.90,174.20,130.60,171.90,NULL,NULL,'2026-06-05 14:58:18.467964',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(996,4,'2026-04-21 21:41:00',158.90,144.50,120.30,158.90,144.50,120.30,NULL,NULL,'2026-06-05 14:58:18.478948',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(997,4,'2026-04-21 21:42:00',89.60,155.60,118.10,89.60,155.60,118.10,NULL,NULL,'2026-06-05 14:58:18.491818',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(998,4,'2026-04-21 21:43:00',179.30,178.80,134.20,179.30,178.80,134.20,NULL,NULL,'2026-06-05 14:58:18.504944',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(999,4,'2026-04-21 21:45:00',187.80,173.90,158.70,187.80,173.90,158.70,NULL,NULL,'2026-06-05 14:58:18.514990',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1000,4,'2026-04-21 21:46:00',110.50,144.80,129.40,110.50,144.80,129.40,NULL,NULL,'2026-06-05 14:58:18.524589',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1001,4,'2026-04-21 21:47:00',128.00,142.00,118.80,128.00,142.00,118.80,NULL,NULL,'2026-06-05 14:58:18.535895',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1002,4,'2026-04-21 21:49:00',129.80,132.00,113.90,129.80,132.00,113.90,NULL,NULL,'2026-06-05 14:58:18.545423',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1003,4,'2026-04-21 21:50:00',120.40,115.00,105.50,120.40,115.00,105.50,NULL,NULL,'2026-06-05 14:58:18.554760',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1004,4,'2026-04-21 21:51:00',127.90,176.10,148.60,127.90,176.10,148.60,NULL,NULL,'2026-06-05 14:58:18.563104',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1005,4,'2026-04-21 21:53:00',126.60,138.90,95.80,126.60,138.90,95.80,NULL,NULL,'2026-06-05 14:58:18.574587',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1006,4,'2026-04-21 21:54:00',86.80,115.40,73.20,86.80,115.40,73.20,NULL,NULL,'2026-06-05 14:58:18.586080',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1007,4,'2026-04-21 21:55:00',121.60,139.40,126.90,121.60,139.40,126.90,NULL,NULL,'2026-06-05 14:58:18.598162',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1008,4,'2026-04-21 21:56:00',127.30,121.80,117.50,127.30,121.80,117.50,NULL,NULL,'2026-06-05 14:58:18.611206',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1009,4,'2026-04-21 21:58:00',84.10,91.20,71.60,84.10,91.20,71.60,NULL,NULL,'2026-06-05 14:58:18.626323',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1010,4,'2026-04-21 21:59:00',107.30,130.80,97.10,107.30,130.80,97.10,NULL,NULL,'2026-06-05 14:58:18.636343',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1011,4,'2026-04-21 22:00:00',118.70,90.50,76.70,118.70,90.50,76.70,NULL,NULL,'2026-06-05 14:58:18.644963',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1012,4,'2026-04-21 22:02:00',120.70,126.30,112.30,120.70,126.30,112.30,NULL,NULL,'2026-06-05 14:58:18.657309',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1013,4,'2026-04-21 22:03:00',127.00,131.70,99.90,127.00,131.70,99.90,NULL,NULL,'2026-06-05 14:58:18.666665',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1014,4,'2026-04-21 22:04:00',130.30,124.70,72.30,130.30,124.70,72.30,NULL,NULL,'2026-06-05 14:58:18.676021',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1015,4,'2026-04-21 22:05:00',95.20,112.70,77.90,95.20,112.70,77.90,NULL,NULL,'2026-06-05 14:58:18.686340',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1016,4,'2026-04-21 22:07:00',121.40,92.90,100.70,121.40,92.90,100.70,NULL,NULL,'2026-06-05 14:58:18.696444',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1017,4,'2026-04-21 22:08:00',118.00,88.20,108.70,118.00,88.20,108.70,NULL,NULL,'2026-06-05 14:58:18.707713',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1018,4,'2026-04-21 22:09:00',121.70,105.90,109.40,121.70,105.90,109.40,NULL,NULL,'2026-06-05 14:58:18.718074',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1019,4,'2026-04-21 22:11:00',114.80,112.10,92.70,114.80,112.10,92.70,NULL,NULL,'2026-06-05 14:58:18.727481',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1020,4,'2026-04-21 22:12:00',115.60,109.80,98.80,115.60,109.80,98.80,NULL,NULL,'2026-06-05 14:58:18.738369',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1021,4,'2026-04-21 22:14:00',88.90,95.40,105.60,88.90,95.40,105.60,NULL,NULL,'2026-06-05 14:58:18.747708',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1022,4,'2026-04-21 22:15:00',82.10,101.70,78.70,82.10,101.70,78.70,NULL,NULL,'2026-06-05 14:58:18.757313',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1023,4,'2026-04-21 22:16:00',109.70,96.30,82.70,109.70,96.30,82.70,NULL,NULL,'2026-06-05 14:58:18.768931',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1024,4,'2026-04-21 22:18:00',87.20,120.50,95.10,87.20,120.50,95.10,NULL,NULL,'2026-06-05 14:58:18.777724',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1025,4,'2026-04-21 22:19:00',88.50,115.50,95.50,88.50,115.50,95.50,NULL,NULL,'2026-06-05 14:58:18.789484',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1026,4,'2026-04-21 22:20:00',147.10,117.80,115.00,147.10,117.80,115.00,NULL,NULL,'2026-06-05 14:58:18.799354',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1027,4,'2026-04-21 22:21:00',136.80,124.60,72.90,136.80,124.60,72.90,NULL,NULL,'2026-06-05 14:58:18.808911',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1028,4,'2026-04-21 22:23:00',82.40,94.50,91.40,82.40,94.50,91.40,NULL,NULL,'2026-06-05 14:58:18.821858',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1029,4,'2026-04-21 22:24:00',103.90,92.20,115.90,103.90,92.20,115.90,NULL,NULL,'2026-06-05 14:58:18.833141',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1030,4,'2026-04-21 22:25:00',134.50,104.30,131.10,134.50,104.30,131.10,NULL,NULL,'2026-06-05 14:58:18.844854',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1031,4,'2026-04-21 22:26:00',124.70,113.80,73.30,124.70,113.80,73.30,NULL,NULL,'2026-06-05 14:58:18.857706',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1032,4,'2026-04-21 22:28:00',124.50,111.00,70.30,124.50,111.00,70.30,NULL,NULL,'2026-06-05 14:58:18.868510',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1033,4,'2026-04-21 22:29:00',140.20,135.20,119.80,140.20,135.20,119.80,NULL,NULL,'2026-06-05 14:58:18.882264',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1034,4,'2026-04-21 22:30:00',98.30,142.60,129.10,98.30,142.60,129.10,NULL,NULL,'2026-06-05 14:58:18.898413',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1035,4,'2026-04-21 22:32:00',120.10,90.40,84.30,120.10,90.40,84.30,NULL,NULL,'2026-06-05 14:58:18.906347',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1036,4,'2026-04-21 22:33:00',147.80,100.70,98.90,147.80,100.70,98.90,NULL,NULL,'2026-06-05 14:58:18.917961',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1037,4,'2026-04-21 22:34:00',122.20,105.50,93.40,122.20,105.50,93.40,NULL,NULL,'2026-06-05 14:58:18.928606',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1038,4,'2026-04-21 22:35:00',130.40,138.00,116.70,130.40,138.00,116.70,NULL,NULL,'2026-06-05 14:58:18.939662',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1039,4,'2026-04-21 22:37:00',166.20,140.10,109.10,166.20,140.10,109.10,NULL,NULL,'2026-06-05 14:58:18.950381',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1040,4,'2026-04-21 22:38:00',132.40,135.90,93.60,132.40,135.90,93.60,NULL,NULL,'2026-06-05 14:58:18.959052',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1041,4,'2026-04-21 22:39:00',110.70,133.90,94.50,110.70,133.90,94.50,NULL,NULL,'2026-06-05 14:58:18.969984',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1042,4,'2026-04-21 22:41:00',125.60,132.90,123.20,125.60,132.90,123.20,NULL,NULL,'2026-06-05 14:58:18.978572',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1043,4,'2026-04-21 22:42:00',122.50,100.30,115.90,122.50,100.30,115.90,NULL,NULL,'2026-06-05 14:58:18.987853',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1044,4,'2026-04-21 22:43:00',139.20,102.90,131.70,139.20,102.90,131.70,NULL,NULL,'2026-06-05 14:58:18.996242',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1045,4,'2026-04-21 22:44:00',135.60,110.00,91.90,135.60,110.00,91.90,NULL,NULL,'2026-06-05 14:58:19.004972',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1046,4,'2026-04-21 22:46:00',82.00,144.20,89.80,82.00,144.20,89.80,NULL,NULL,'2026-06-05 14:58:19.014421',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1047,4,'2026-04-21 22:47:00',87.70,145.70,119.30,87.70,145.70,119.30,NULL,NULL,'2026-06-05 14:58:19.023273',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1048,4,'2026-04-21 22:48:00',139.60,134.70,125.70,139.60,134.70,125.70,NULL,NULL,'2026-06-05 14:58:19.033926',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1049,4,'2026-04-21 22:50:00',158.50,143.90,126.00,158.50,143.90,126.00,NULL,NULL,'2026-06-05 14:58:19.043673',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1050,4,'2026-04-21 22:51:00',100.40,113.50,88.10,100.40,113.50,88.10,NULL,NULL,'2026-06-05 14:58:19.054567',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1051,4,'2026-04-21 22:52:00',113.30,119.70,97.80,113.30,119.70,97.80,NULL,NULL,'2026-06-05 14:58:19.065450',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1052,4,'2026-04-21 22:54:00',141.80,102.10,100.00,141.80,102.10,100.00,NULL,NULL,'2026-06-05 14:58:19.075681',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1053,4,'2026-04-21 22:55:00',153.80,121.60,109.00,153.80,121.60,109.00,NULL,NULL,'2026-06-05 14:58:19.087098',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1054,4,'2026-04-21 22:56:00',90.80,121.40,83.40,90.80,121.40,83.40,NULL,NULL,'2026-06-05 14:58:19.099830',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1055,4,'2026-04-21 22:57:00',111.60,106.90,65.30,111.60,106.90,65.30,NULL,NULL,'2026-06-05 14:58:19.108567',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1056,4,'2026-04-21 22:59:00',74.40,123.80,96.60,74.40,123.80,96.60,NULL,NULL,'2026-06-05 14:58:19.120172',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1057,4,'2026-04-21 23:00:00',97.20,92.20,97.70,97.20,92.20,97.70,NULL,NULL,'2026-06-05 14:58:19.128877',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1058,4,'2026-04-21 23:01:00',83.50,79.80,66.50,83.50,79.80,66.50,NULL,NULL,'2026-06-05 14:58:19.142335',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1059,4,'2026-04-21 23:03:00',73.30,99.50,69.10,73.30,99.50,69.10,NULL,NULL,'2026-06-05 14:58:19.154460',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1060,4,'2026-04-21 23:04:00',77.80,106.40,73.60,77.80,106.40,73.60,NULL,NULL,'2026-06-05 14:58:19.164877',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1061,4,'2026-04-21 23:06:00',94.60,94.10,82.20,94.60,94.10,82.20,NULL,NULL,'2026-06-05 14:58:19.174432',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1062,4,'2026-04-21 23:07:00',97.80,81.80,65.30,97.80,81.80,65.30,NULL,NULL,'2026-06-05 14:58:19.184035',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1063,4,'2026-04-21 23:08:00',138.60,100.90,106.60,138.60,100.90,106.60,NULL,NULL,'2026-06-05 14:58:19.191851',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1064,4,'2026-04-21 23:09:00',118.10,127.20,104.10,118.10,127.20,104.10,NULL,NULL,'2026-06-05 14:58:19.201897',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1065,4,'2026-04-21 23:11:00',73.10,120.40,91.10,73.10,120.40,91.10,NULL,NULL,'2026-06-05 14:58:19.210257',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1066,4,'2026-04-21 23:12:00',97.40,123.90,75.50,97.40,123.90,75.50,NULL,NULL,'2026-06-05 14:58:19.219875',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1067,4,'2026-04-21 23:13:00',87.60,102.10,90.00,87.60,102.10,90.00,NULL,NULL,'2026-06-05 14:58:19.229125',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1068,4,'2026-04-21 23:15:00',108.10,91.00,126.10,108.10,91.00,126.10,NULL,NULL,'2026-06-05 14:58:19.240924',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1069,4,'2026-04-21 23:16:00',78.00,90.70,92.30,78.00,90.70,92.30,NULL,NULL,'2026-06-05 14:58:19.250980',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1070,4,'2026-04-21 23:17:00',85.10,82.30,69.00,85.10,82.30,69.00,NULL,NULL,'2026-06-05 14:58:19.259798',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1071,4,'2026-04-21 23:18:00',82.10,127.90,94.00,82.10,127.90,94.00,NULL,NULL,'2026-06-05 14:58:19.268823',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1072,4,'2026-04-21 23:20:00',139.60,120.00,101.40,139.60,120.00,101.40,NULL,NULL,'2026-06-05 14:58:19.280362',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1073,4,'2026-04-21 23:21:00',139.40,123.70,100.30,139.40,123.70,100.30,NULL,NULL,'2026-06-05 14:58:19.287924',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1074,4,'2026-04-21 23:22:00',96.90,120.60,109.70,96.90,120.60,109.70,NULL,NULL,'2026-06-05 14:58:19.301941',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1075,4,'2026-04-21 23:24:00',106.50,113.20,79.40,106.50,113.20,79.40,NULL,NULL,'2026-06-05 14:58:19.309109',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1076,4,'2026-04-21 23:25:00',100.70,81.90,72.20,100.70,81.90,72.20,NULL,NULL,'2026-06-05 14:58:19.319889',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1077,4,'2026-04-21 23:26:00',104.00,102.30,101.60,104.00,102.30,101.60,NULL,NULL,'2026-06-05 14:58:19.329023',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1078,4,'2026-04-21 23:27:00',88.60,89.30,98.10,88.60,89.30,98.10,NULL,NULL,'2026-06-05 14:58:19.340170',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1079,4,'2026-04-21 23:29:00',88.80,129.00,116.50,88.80,129.00,116.50,NULL,NULL,'2026-06-05 14:58:19.350157',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1080,4,'2026-04-21 23:30:00',94.00,121.80,71.60,94.00,121.80,71.60,NULL,NULL,'2026-06-05 14:58:19.358698',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1081,4,'2026-04-21 23:31:00',114.20,118.30,73.10,114.20,118.30,73.10,NULL,NULL,'2026-06-05 14:58:19.367394',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1082,4,'2026-04-21 23:33:00',115.70,134.90,120.10,115.70,134.90,120.10,NULL,NULL,'2026-06-05 14:58:19.379926',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1083,4,'2026-04-21 23:34:00',125.00,120.50,127.80,125.00,120.50,127.80,NULL,NULL,'2026-06-05 14:58:19.388455',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1084,4,'2026-04-21 23:35:00',89.20,86.10,82.20,89.20,86.10,82.20,NULL,NULL,'2026-06-05 14:58:19.398451',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1085,4,'2026-04-21 23:37:00',157.10,142.30,92.30,157.10,142.30,92.30,NULL,NULL,'2026-06-05 14:58:19.405780',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1086,4,'2026-04-21 23:38:00',102.70,133.90,144.10,102.70,133.90,144.10,NULL,NULL,'2026-06-05 14:58:19.414424',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1087,4,'2026-04-21 23:39:00',129.10,144.20,122.70,129.10,144.20,122.70,NULL,NULL,'2026-06-05 14:58:19.422469',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1088,4,'2026-04-21 23:41:00',145.90,146.50,92.20,145.90,146.50,92.20,NULL,NULL,'2026-06-05 14:58:19.432511',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1089,4,'2026-04-21 23:42:00',125.60,141.20,103.40,125.60,141.20,103.40,NULL,NULL,'2026-06-05 14:58:19.441883',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1090,4,'2026-04-21 23:43:00',89.50,109.30,113.90,89.50,109.30,113.90,NULL,NULL,'2026-06-05 14:58:19.451791',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1091,4,'2026-04-21 23:44:00',97.60,107.00,141.40,97.60,107.00,141.40,NULL,NULL,'2026-06-05 14:58:19.460492',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1092,4,'2026-04-21 23:46:00',120.30,134.50,90.20,120.30,134.50,90.20,NULL,NULL,'2026-06-05 14:58:19.470291',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1093,4,'2026-04-21 23:47:00',123.90,145.10,88.10,123.90,145.10,88.10,NULL,NULL,'2026-06-05 14:58:19.478819',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1094,4,'2026-04-21 23:48:00',141.40,146.20,131.50,141.40,146.20,131.50,NULL,NULL,'2026-06-05 14:58:19.488599',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1095,4,'2026-04-21 23:50:00',87.90,133.20,126.30,87.90,133.20,126.30,NULL,NULL,'2026-06-05 14:58:19.498130',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1096,4,'2026-04-21 23:51:00',105.80,123.30,129.60,105.80,123.30,129.60,NULL,NULL,'2026-06-05 14:58:19.505452',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1097,4,'2026-04-21 23:52:00',152.30,102.10,92.40,152.30,102.10,92.40,NULL,NULL,'2026-06-05 14:58:19.516328',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1098,4,'2026-04-21 23:54:00',166.20,105.20,88.40,166.20,105.20,88.40,NULL,NULL,'2026-06-05 14:58:19.523677',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1099,4,'2026-04-21 23:55:00',89.90,142.00,118.20,89.90,142.00,118.20,NULL,NULL,'2026-06-05 14:58:19.533486',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1100,4,'2026-04-21 23:56:00',92.80,140.20,119.00,92.80,140.20,119.00,NULL,NULL,'2026-06-05 14:58:19.540631',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1101,4,'2026-04-21 23:57:00',90.10,115.00,97.60,90.10,115.00,97.60,NULL,NULL,'2026-06-05 14:58:19.550440',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1102,4,'2026-04-21 23:59:00',103.60,131.60,91.50,103.60,131.60,91.50,NULL,NULL,'2026-06-05 14:58:19.559241',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1103,4,'2026-04-22 00:00:00',83.50,96.00,97.50,83.50,96.00,97.50,NULL,NULL,'2026-06-05 14:58:19.570029',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1104,4,'2026-04-22 00:01:00',93.60,87.40,95.10,93.60,87.40,95.10,NULL,NULL,'2026-06-05 14:58:19.579739',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1105,4,'2026-04-22 00:03:00',117.20,112.70,68.90,117.20,112.70,68.90,NULL,NULL,'2026-06-05 14:58:19.586784',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1106,4,'2026-04-22 00:04:00',139.20,119.90,83.70,139.20,119.90,83.70,NULL,NULL,'2026-06-05 14:58:19.596047',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1107,4,'2026-04-22 00:05:00',94.10,109.50,89.40,94.10,109.50,89.40,NULL,NULL,'2026-06-05 14:58:19.603673',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1108,4,'2026-04-22 00:06:00',80.10,109.60,92.20,80.10,109.60,92.20,NULL,NULL,'2026-06-05 14:58:19.611193',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1109,4,'2026-04-22 00:08:00',141.80,83.20,70.00,141.80,83.20,70.00,NULL,NULL,'2026-06-05 14:58:19.619061',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1110,4,'2026-04-22 00:09:00',101.80,117.10,112.00,101.80,117.10,112.00,NULL,NULL,'2026-06-05 14:58:19.626504',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1111,4,'2026-04-22 00:11:00',97.00,110.60,91.20,97.00,110.60,91.20,NULL,NULL,'2026-06-05 14:58:19.635132',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1112,4,'2026-04-22 00:12:00',141.80,116.90,99.30,141.80,116.90,99.30,NULL,NULL,'2026-06-05 14:58:19.643962',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1113,4,'2026-04-22 00:13:00',91.80,136.20,84.20,91.80,136.20,84.20,NULL,NULL,'2026-06-05 14:58:19.652045',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1114,4,'2026-04-22 00:14:00',81.70,104.70,72.60,81.70,104.70,72.60,NULL,NULL,'2026-06-05 14:58:19.659779',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1115,4,'2026-04-22 00:16:00',111.20,89.00,75.00,111.20,89.00,75.00,NULL,NULL,'2026-06-05 14:58:19.671000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1116,4,'2026-04-22 00:17:00',101.40,95.20,98.00,101.40,95.20,98.00,NULL,NULL,'2026-06-05 14:58:19.681594',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1117,4,'2026-04-22 00:18:00',135.10,116.40,115.10,135.10,116.40,115.10,NULL,NULL,'2026-06-05 14:58:19.691202',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1118,4,'2026-04-22 00:19:00',124.80,115.00,85.00,124.80,115.00,85.00,NULL,NULL,'2026-06-05 14:58:19.700469',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1119,4,'2026-04-22 00:21:00',113.00,138.00,71.10,113.00,138.00,71.10,NULL,NULL,'2026-06-05 14:58:19.713175',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1120,4,'2026-04-22 00:22:00',84.00,110.50,75.70,84.00,110.50,75.70,NULL,NULL,'2026-06-05 14:58:19.721713',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1121,4,'2026-04-22 00:23:00',150.60,116.80,101.80,150.60,116.80,101.80,NULL,NULL,'2026-06-05 14:58:19.735856',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1122,4,'2026-04-22 00:25:00',89.90,80.00,81.60,89.90,80.00,81.60,NULL,NULL,'2026-06-05 14:58:19.749618',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1123,4,'2026-04-22 00:26:00',88.60,89.80,73.00,88.60,89.80,73.00,NULL,NULL,'2026-06-05 14:58:19.759875',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1124,4,'2026-04-22 00:27:00',92.30,101.50,76.50,92.30,101.50,76.50,NULL,NULL,'2026-06-05 14:58:19.770740',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1125,4,'2026-04-22 00:28:00',119.80,117.90,99.20,119.80,117.90,99.20,NULL,NULL,'2026-06-05 14:58:19.783762',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1126,4,'2026-04-22 00:30:00',125.80,117.20,108.50,125.80,117.20,108.50,NULL,NULL,'2026-06-05 14:58:19.797367',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1127,4,'2026-04-22 00:31:00',82.70,116.20,96.80,82.70,116.20,96.80,NULL,NULL,'2026-06-05 14:58:19.808626',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1128,4,'2026-04-22 00:32:00',136.70,114.50,85.70,136.70,114.50,85.70,NULL,NULL,'2026-06-05 14:58:19.817661',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1129,4,'2026-04-22 00:34:00',116.40,93.60,80.50,116.40,93.60,80.50,NULL,NULL,'2026-06-05 14:58:19.827347',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1130,4,'2026-04-22 00:35:00',140.50,85.50,99.00,140.50,85.50,99.00,NULL,NULL,'2026-06-05 14:58:19.835890',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1131,4,'2026-04-22 00:36:00',136.60,130.30,120.80,136.60,130.30,120.80,NULL,NULL,'2026-06-05 14:58:19.847134',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1132,4,'2026-04-22 00:38:00',94.30,116.30,65.20,94.30,116.30,65.20,NULL,NULL,'2026-06-05 14:58:19.855408',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1133,4,'2026-04-22 00:39:00',124.50,104.70,62.50,124.50,104.70,62.50,NULL,NULL,'2026-06-05 14:58:19.866399',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1134,4,'2026-04-22 00:40:00',141.60,140.80,119.20,141.60,140.80,119.20,NULL,NULL,'2026-06-05 14:58:19.874438',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1135,4,'2026-04-22 00:42:00',143.10,132.90,121.70,143.10,132.90,121.70,NULL,NULL,'2026-06-05 14:58:19.887432',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1136,4,'2026-04-22 00:43:00',129.20,105.00,100.50,129.20,105.00,100.50,NULL,NULL,'2026-06-05 14:58:19.901304',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1137,4,'2026-04-22 00:44:00',155.70,127.80,91.90,155.70,127.80,91.90,NULL,NULL,'2026-06-05 14:58:19.911308',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1138,4,'2026-04-22 00:46:00',119.70,136.40,119.60,119.70,136.40,119.60,NULL,NULL,'2026-06-05 14:58:19.920640',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1139,4,'2026-04-22 00:47:00',129.60,144.90,120.90,129.60,144.90,120.90,NULL,NULL,'2026-06-05 14:58:19.933818',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1140,4,'2026-04-22 00:48:00',136.10,104.90,96.20,136.10,104.90,96.20,NULL,NULL,'2026-06-05 14:58:19.942085',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1141,4,'2026-04-22 00:50:00',154.30,112.30,126.10,154.30,112.30,126.10,NULL,NULL,'2026-06-05 14:58:19.951444',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1142,4,'2026-04-22 00:51:00',135.60,108.30,121.10,135.60,108.30,121.10,NULL,NULL,'2026-06-05 14:58:19.960787',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1143,4,'2026-04-22 00:52:00',99.60,148.10,95.10,99.60,148.10,95.10,NULL,NULL,'2026-06-05 14:58:19.971488',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1144,4,'2026-04-22 00:53:00',159.40,133.10,84.80,159.40,133.10,84.80,NULL,NULL,'2026-06-05 14:58:19.981495',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1145,4,'2026-04-22 00:55:00',142.30,134.30,120.80,142.30,134.30,120.80,NULL,NULL,'2026-06-05 14:58:19.988756',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1146,4,'2026-04-22 00:56:00',105.30,112.50,125.30,105.30,112.50,125.30,NULL,NULL,'2026-06-05 14:58:19.997685',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1147,4,'2026-04-22 00:57:00',97.60,114.70,120.40,97.60,114.70,120.40,NULL,NULL,'2026-06-05 14:58:20.007058',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1148,4,'2026-04-22 00:59:00',162.60,137.20,91.70,162.60,137.20,91.70,NULL,NULL,'2026-06-05 14:58:20.017338',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1149,4,'2026-04-22 01:00:00',113.40,145.20,147.60,113.40,145.20,147.60,NULL,NULL,'2026-06-05 14:58:20.025920',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1150,4,'2026-04-22 01:01:00',138.40,140.40,137.00,138.40,140.40,137.00,NULL,NULL,'2026-06-05 14:58:20.033770',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1151,4,'2026-04-22 01:03:00',125.60,117.60,106.70,125.60,117.60,106.70,NULL,NULL,'2026-06-05 14:58:20.043078',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1152,4,'2026-04-22 01:04:00',147.40,124.00,109.40,147.40,124.00,109.40,NULL,NULL,'2026-06-05 14:58:20.050450',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1153,4,'2026-04-22 01:05:00',164.50,132.10,137.00,164.50,132.10,137.00,NULL,NULL,'2026-06-05 14:58:20.057900',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1154,4,'2026-04-22 01:07:00',167.80,139.60,154.50,167.80,139.60,154.50,NULL,NULL,'2026-06-05 14:58:20.066213',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1155,4,'2026-04-22 01:08:00',105.00,131.00,93.80,105.00,131.00,93.80,NULL,NULL,'2026-06-05 14:58:20.078154',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1156,4,'2026-04-22 01:09:00',139.00,134.00,99.50,139.00,134.00,99.50,NULL,NULL,'2026-06-05 14:58:20.085952',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1157,4,'2026-04-22 01:11:00',133.50,147.90,116.10,133.50,147.90,116.10,NULL,NULL,'2026-06-05 14:58:20.095172',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1158,4,'2026-04-22 01:12:00',111.00,121.80,100.60,111.00,121.80,100.60,NULL,NULL,'2026-06-05 14:58:20.102549',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1159,4,'2026-04-22 01:13:00',127.30,115.90,123.90,127.30,115.90,123.90,NULL,NULL,'2026-06-05 14:58:20.110954',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1160,4,'2026-04-22 01:14:00',158.20,111.40,119.50,158.20,111.40,119.50,NULL,NULL,'2026-06-05 14:58:20.118267',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1161,4,'2026-04-22 01:16:00',123.50,116.10,76.40,123.50,116.10,76.40,NULL,NULL,'2026-06-05 14:58:20.128481',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1162,4,'2026-04-22 01:17:00',156.30,143.10,106.70,156.30,143.10,106.70,NULL,NULL,'2026-06-05 14:58:20.136409',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1163,4,'2026-04-22 01:18:00',157.40,150.20,125.70,157.40,150.20,125.70,NULL,NULL,'2026-06-05 14:58:20.144521',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1164,4,'2026-04-22 01:20:00',116.40,95.00,110.10,116.40,95.00,110.10,NULL,NULL,'2026-06-05 14:58:20.152365',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1165,4,'2026-04-22 01:21:00',158.70,122.80,96.10,158.70,122.80,96.10,NULL,NULL,'2026-06-05 14:58:20.163283',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1166,4,'2026-04-22 01:22:00',144.80,105.60,91.20,144.80,105.60,91.20,NULL,NULL,'2026-06-05 14:58:20.170382',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1167,4,'2026-04-22 01:24:00',108.10,111.00,99.90,108.10,111.00,99.90,NULL,NULL,'2026-06-05 14:58:20.179820',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1168,4,'2026-04-22 01:25:00',156.90,149.90,123.10,156.90,149.90,123.10,NULL,NULL,'2026-06-05 14:58:20.192653',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1169,4,'2026-04-22 01:26:00',128.00,149.80,116.50,128.00,149.80,116.50,NULL,NULL,'2026-06-05 14:58:20.200352',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1170,4,'2026-04-22 01:27:00',103.20,111.30,65.90,103.20,111.30,65.90,NULL,NULL,'2026-06-05 14:58:20.208197',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1171,4,'2026-04-22 01:29:00',141.10,109.80,123.90,141.10,109.80,123.90,NULL,NULL,'2026-06-05 14:58:20.216304',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1172,4,'2026-04-22 01:30:00',177.10,115.50,131.50,177.10,115.50,131.50,NULL,NULL,'2026-06-05 14:58:20.224787',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1173,4,'2026-04-22 01:31:00',105.70,137.50,96.80,105.70,137.50,96.80,NULL,NULL,'2026-06-05 14:58:20.234673',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1174,4,'2026-04-22 01:33:00',135.50,117.80,88.30,135.50,117.80,88.30,NULL,NULL,'2026-06-05 14:58:20.243147',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1175,4,'2026-04-22 01:34:00',112.60,123.30,103.10,112.60,123.30,103.10,NULL,NULL,'2026-06-05 14:58:20.253721',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1176,4,'2026-04-22 01:35:00',127.90,118.00,120.50,127.90,118.00,120.50,NULL,NULL,'2026-06-05 14:58:20.263989',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1177,4,'2026-04-22 01:36:00',134.40,116.60,96.00,134.40,116.60,96.00,NULL,NULL,'2026-06-05 14:58:20.273118',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1178,4,'2026-04-22 01:38:00',106.80,106.70,79.90,106.80,106.70,79.90,NULL,NULL,'2026-06-05 14:58:20.284391',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1179,4,'2026-04-22 01:39:00',121.70,122.20,106.80,121.70,122.20,106.80,NULL,NULL,'2026-06-05 14:58:20.294767',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1180,4,'2026-04-22 01:40:00',111.10,143.10,126.90,111.10,143.10,126.90,NULL,NULL,'2026-06-05 14:58:20.303815',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1181,4,'2026-04-22 01:42:00',104.60,138.20,95.20,104.60,138.20,95.20,NULL,NULL,'2026-06-05 14:58:20.314229',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1182,4,'2026-04-22 01:43:00',151.10,100.60,79.40,151.10,100.60,79.40,NULL,NULL,'2026-06-05 14:58:20.322914',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1183,4,'2026-04-22 01:45:00',99.80,142.50,126.20,99.80,142.50,126.20,NULL,NULL,'2026-06-05 14:58:20.332214',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1184,4,'2026-04-22 01:46:00',137.30,131.50,93.80,137.30,131.50,93.80,NULL,NULL,'2026-06-05 14:58:20.340485',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1185,4,'2026-04-22 01:48:00',162.00,146.50,119.50,162.00,146.50,119.50,NULL,NULL,'2026-06-05 14:58:20.349873',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1186,4,'2026-04-22 01:49:00',143.80,133.90,88.10,143.80,133.90,88.10,NULL,NULL,'2026-06-05 14:58:20.358964',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1187,4,'2026-04-22 01:50:00',142.00,146.80,118.40,142.00,146.80,118.40,NULL,NULL,'2026-06-05 14:58:20.366666',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1188,4,'2026-04-22 01:51:00',130.80,116.20,154.60,130.80,116.20,154.60,NULL,NULL,'2026-06-05 14:58:20.375962',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1189,4,'2026-04-22 01:53:00',103.80,96.10,93.30,103.80,96.10,93.30,NULL,NULL,'2026-06-05 14:58:20.384618',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1190,4,'2026-04-22 01:54:00',90.10,107.10,117.70,90.10,107.10,117.70,NULL,NULL,'2026-06-05 14:58:20.394524',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1191,4,'2026-04-22 01:55:00',121.50,100.90,83.30,121.50,100.90,83.30,NULL,NULL,'2026-06-05 14:58:20.401740',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1192,4,'2026-04-22 01:56:00',95.40,133.30,109.90,95.40,133.30,109.90,NULL,NULL,'2026-06-05 14:58:20.410475',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1193,4,'2026-04-22 01:58:00',101.90,148.30,135.80,101.90,148.30,135.80,NULL,NULL,'2026-06-05 14:58:20.418045',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1194,4,'2026-04-22 01:59:00',91.60,125.40,90.90,91.60,125.40,90.90,NULL,NULL,'2026-06-05 14:58:20.427037',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1195,4,'2026-04-22 02:00:00',137.00,137.60,98.30,137.00,137.60,98.30,NULL,NULL,'2026-06-05 14:58:20.437776',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1196,4,'2026-04-22 02:01:00',121.90,144.40,97.10,121.90,144.40,97.10,NULL,NULL,'2026-06-05 14:58:20.448305',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1197,4,'2026-04-22 02:03:00',135.90,116.30,76.10,135.90,116.30,76.10,NULL,NULL,'2026-06-05 14:58:20.458264',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1198,4,'2026-04-22 02:04:00',145.00,135.30,100.70,145.00,135.30,100.70,NULL,NULL,'2026-06-05 14:58:20.466459',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1199,4,'2026-04-22 02:05:00',137.00,112.10,140.40,137.00,112.10,140.40,NULL,NULL,'2026-06-05 14:58:20.476199',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1200,4,'2026-04-22 02:06:00',83.40,92.40,101.30,83.40,92.40,101.30,NULL,NULL,'2026-06-05 14:58:20.484371',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1201,4,'2026-04-22 02:08:00',124.40,114.90,86.90,124.40,114.90,86.90,NULL,NULL,'2026-06-05 14:58:20.496600',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1202,4,'2026-04-22 02:09:00',113.40,117.70,71.70,113.40,117.70,71.70,NULL,NULL,'2026-06-05 14:58:20.506519',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1203,4,'2026-04-22 02:10:00',109.20,107.50,69.00,109.20,107.50,69.00,NULL,NULL,'2026-06-05 14:58:20.515595',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1204,4,'2026-04-22 02:12:00',103.30,119.90,103.40,103.30,119.90,103.40,NULL,NULL,'2026-06-05 14:58:20.523654',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1205,4,'2026-04-22 02:13:00',83.40,119.60,94.90,83.40,119.60,94.90,NULL,NULL,'2026-06-05 14:58:20.548765',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1206,4,'2026-04-22 02:14:00',89.80,112.00,97.10,89.80,112.00,97.10,NULL,NULL,'2026-06-05 14:58:20.557671',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1207,4,'2026-04-22 02:15:00',115.40,116.90,99.00,115.40,116.90,99.00,NULL,NULL,'2026-06-05 14:58:20.566971',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1208,4,'2026-04-22 02:17:00',118.10,127.40,83.80,118.10,127.40,83.80,NULL,NULL,'2026-06-05 14:58:20.575881',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1209,4,'2026-04-22 02:18:00',118.80,133.20,73.40,118.80,133.20,73.40,NULL,NULL,'2026-06-05 14:58:20.583614',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1210,4,'2026-04-22 02:19:00',139.30,114.50,102.60,139.30,114.50,102.60,NULL,NULL,'2026-06-05 14:58:20.592832',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1211,4,'2026-04-22 02:20:00',94.00,92.10,119.70,94.00,92.10,119.70,NULL,NULL,'2026-06-05 14:58:20.600761',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1212,4,'2026-04-22 02:22:00',138.80,90.20,110.50,138.80,90.20,110.50,NULL,NULL,'2026-06-05 14:58:20.611743',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1213,4,'2026-04-22 02:23:00',129.70,116.30,94.00,129.70,116.30,94.00,NULL,NULL,'2026-06-05 14:58:20.618909',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1214,4,'2026-04-22 02:24:00',98.80,135.60,98.00,98.80,135.60,98.00,NULL,NULL,'2026-06-05 14:58:20.627636',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1215,4,'2026-04-22 02:25:00',79.30,118.10,93.00,79.30,118.10,93.00,NULL,NULL,'2026-06-05 14:58:20.634702',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1216,4,'2026-04-22 02:27:00',135.00,115.70,96.60,135.00,115.70,96.60,NULL,NULL,'2026-06-05 14:58:20.644810',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1217,4,'2026-04-22 02:28:00',116.60,79.60,66.80,116.60,79.60,66.80,NULL,NULL,'2026-06-05 14:58:20.653642',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1218,4,'2026-04-22 02:29:00',93.30,86.70,101.90,93.30,86.70,101.90,NULL,NULL,'2026-06-05 14:58:20.666192',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1219,4,'2026-04-22 02:31:00',78.50,82.30,92.50,78.50,82.30,92.50,NULL,NULL,'2026-06-05 14:58:20.676463',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1220,4,'2026-04-22 02:32:00',147.20,104.80,97.70,147.20,104.80,97.70,NULL,NULL,'2026-06-05 14:58:20.684483',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1221,4,'2026-04-22 02:33:00',120.30,114.70,92.10,120.30,114.70,92.10,NULL,NULL,'2026-06-05 14:58:20.694667',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1222,4,'2026-04-22 02:35:00',122.90,116.50,72.70,122.90,116.50,72.70,NULL,NULL,'2026-06-05 14:58:20.702484',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1223,4,'2026-04-22 02:36:00',97.70,111.20,88.30,97.70,111.20,88.30,NULL,NULL,'2026-06-05 14:58:20.716179',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1224,4,'2026-04-22 02:37:00',95.30,119.10,100.10,95.30,119.10,100.10,NULL,NULL,'2026-06-05 14:58:20.725602',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1225,4,'2026-04-22 02:38:00',124.80,104.50,79.10,124.80,104.50,79.10,NULL,NULL,'2026-06-05 14:58:20.735725',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1226,4,'2026-04-22 02:40:00',92.10,109.20,92.10,92.10,109.20,92.10,NULL,NULL,'2026-06-05 14:58:20.743956',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1227,4,'2026-04-22 02:41:00',107.70,95.70,76.80,107.70,95.70,76.80,NULL,NULL,'2026-06-05 14:58:20.751678',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1228,4,'2026-04-22 02:42:00',104.30,114.90,118.80,104.30,114.90,118.80,NULL,NULL,'2026-06-05 14:58:20.760871',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1229,4,'2026-04-22 02:44:00',146.90,141.30,125.60,146.90,141.30,125.60,NULL,NULL,'2026-06-05 14:58:20.769071',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1230,4,'2026-04-22 02:45:00',93.70,128.20,78.00,93.70,128.20,78.00,NULL,NULL,'2026-06-05 14:58:20.780131',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1231,4,'2026-04-22 02:46:00',100.70,113.20,69.40,100.70,113.20,69.40,NULL,NULL,'2026-06-05 14:58:20.791228',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1232,4,'2026-04-22 02:48:00',158.00,114.50,124.40,158.00,114.50,124.40,NULL,NULL,'2026-06-05 14:58:20.798883',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1233,4,'2026-04-22 02:49:00',114.80,113.70,128.30,114.80,113.70,128.30,NULL,NULL,'2026-06-05 14:58:20.808955',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1234,4,'2026-04-22 02:50:00',86.60,124.70,71.50,86.60,124.70,71.50,NULL,NULL,'2026-06-05 14:58:20.817164',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1235,4,'2026-04-22 02:51:00',105.00,147.80,96.10,105.00,147.80,96.10,NULL,NULL,'2026-06-05 14:58:20.827100',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1236,4,'2026-04-22 02:53:00',127.60,135.80,130.10,127.60,135.80,130.10,NULL,NULL,'2026-06-05 14:58:20.833806',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1237,4,'2026-04-22 02:54:00',108.70,137.10,84.10,108.70,137.10,84.10,NULL,NULL,'2026-06-05 14:58:20.843252',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1238,4,'2026-04-22 02:55:00',139.10,121.90,85.00,139.10,121.90,85.00,NULL,NULL,'2026-06-05 14:58:20.849959',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1239,4,'2026-04-22 02:57:00',105.10,102.40,79.90,105.10,102.40,79.90,NULL,NULL,'2026-06-05 14:58:20.860838',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1240,4,'2026-04-22 02:58:00',156.70,93.70,113.30,156.70,93.70,113.30,NULL,NULL,'2026-06-05 14:58:20.870174',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1241,4,'2026-04-22 02:59:00',120.30,127.70,114.90,120.30,127.70,114.90,NULL,NULL,'2026-06-05 14:58:20.879313',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1242,4,'2026-04-22 03:00:00',104.80,136.40,125.50,104.80,136.40,125.50,NULL,NULL,'2026-06-05 14:58:20.886604',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1243,4,'2026-04-22 03:02:00',111.90,131.00,87.10,111.90,131.00,87.10,NULL,NULL,'2026-06-05 14:58:20.895232',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1244,4,'2026-04-22 03:03:00',144.70,123.90,80.30,144.70,123.90,80.30,NULL,NULL,'2026-06-05 14:58:20.902086',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1245,4,'2026-04-22 03:04:00',111.40,151.40,146.70,111.40,151.40,146.70,NULL,NULL,'2026-06-05 14:58:20.911084',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1246,4,'2026-04-22 03:06:00',105.60,112.60,124.10,105.60,112.60,124.10,NULL,NULL,'2026-06-05 14:58:20.919695',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1247,4,'2026-04-22 03:07:00',94.40,90.50,74.30,94.40,90.50,74.30,NULL,NULL,'2026-06-05 14:58:20.928339',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1248,4,'2026-04-22 03:08:00',124.60,106.60,97.60,124.60,106.60,97.60,NULL,NULL,'2026-06-05 14:58:20.936594',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1249,4,'2026-04-22 03:10:00',142.70,131.50,120.70,142.70,131.50,120.70,NULL,NULL,'2026-06-05 14:58:20.946300',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1250,4,'2026-04-22 03:11:00',121.00,114.20,112.00,121.00,114.20,112.00,NULL,NULL,'2026-06-05 14:58:20.956508',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1251,4,'2026-04-22 03:12:00',92.00,129.00,85.70,92.00,129.00,85.70,NULL,NULL,'2026-06-05 14:58:20.965609',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1252,4,'2026-04-22 03:13:00',105.30,119.20,70.40,105.30,119.20,70.40,NULL,NULL,'2026-06-05 14:58:20.974700',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1253,4,'2026-04-22 03:15:00',123.70,106.10,79.60,123.70,106.10,79.60,NULL,NULL,'2026-06-05 14:58:20.982565',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1254,4,'2026-04-22 03:16:00',95.80,117.30,121.20,95.80,117.30,121.20,NULL,NULL,'2026-06-05 14:58:20.991900',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1255,4,'2026-04-22 03:17:00',116.60,86.40,70.60,116.60,86.40,70.60,NULL,NULL,'2026-06-05 14:58:20.999007',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1256,4,'2026-04-22 03:19:00',109.40,97.70,68.20,109.40,97.70,68.20,NULL,NULL,'2026-06-05 14:58:21.008383',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1257,4,'2026-04-22 03:20:00',75.70,106.10,86.00,75.70,106.10,86.00,NULL,NULL,'2026-06-05 14:58:21.016218',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1258,4,'2026-04-22 03:22:00',94.10,124.10,71.30,94.10,124.10,71.30,NULL,NULL,'2026-06-05 14:58:21.026432',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1259,4,'2026-04-22 03:23:00',94.10,123.20,98.60,94.10,123.20,98.60,NULL,NULL,'2026-06-05 14:58:21.034482',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1260,4,'2026-04-22 03:24:00',123.30,92.60,83.50,123.30,92.60,83.50,NULL,NULL,'2026-06-05 14:58:21.046153',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1261,4,'2026-04-22 03:25:00',119.50,91.30,91.90,119.50,91.30,91.90,NULL,NULL,'2026-06-05 14:58:21.058330',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1262,4,'2026-04-22 03:27:00',103.90,105.10,88.30,103.90,105.10,88.30,NULL,NULL,'2026-06-05 14:58:21.069020',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1263,4,'2026-04-22 03:28:00',90.60,113.40,92.50,90.60,113.40,92.50,NULL,NULL,'2026-06-05 14:58:21.081313',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1264,4,'2026-04-22 03:30:00',166.00,124.20,73.00,166.00,124.20,73.00,NULL,NULL,'2026-06-05 14:58:21.092987',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1265,4,'2026-04-22 03:31:00',145.80,128.40,90.40,145.80,128.40,90.40,NULL,NULL,'2026-06-05 14:58:21.108655',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1266,4,'2026-04-22 03:33:00',137.70,113.60,74.70,137.70,113.60,74.70,NULL,NULL,'2026-06-05 14:58:21.116210',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1267,4,'2026-04-22 03:34:00',81.20,114.80,66.50,81.20,114.80,66.50,NULL,NULL,'2026-06-05 14:58:21.128164',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1268,4,'2026-04-22 03:35:00',97.40,115.00,97.40,97.40,115.00,97.40,NULL,NULL,'2026-06-05 14:58:21.135420',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1269,4,'2026-04-22 03:36:00',105.50,121.50,73.60,105.50,121.50,73.60,NULL,NULL,'2026-06-05 14:58:21.145657',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1270,4,'2026-04-22 03:38:00',118.70,100.20,67.70,118.70,100.20,67.70,NULL,NULL,'2026-06-05 14:58:21.154752',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1271,4,'2026-04-22 03:39:00',111.00,93.50,73.30,111.00,93.50,73.30,NULL,NULL,'2026-06-05 14:58:21.162773',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1272,4,'2026-04-22 03:40:00',113.80,80.40,89.30,113.80,80.40,89.30,NULL,NULL,'2026-06-05 14:58:21.172199',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1273,4,'2026-04-22 03:41:00',109.50,83.30,113.10,109.50,83.30,113.10,NULL,NULL,'2026-06-05 14:58:21.181268',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1274,4,'2026-04-22 03:43:00',123.30,92.10,95.70,123.30,92.10,95.70,NULL,NULL,'2026-06-05 14:58:21.192691',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1275,4,'2026-04-22 03:44:00',134.40,118.40,78.90,134.40,118.40,78.90,NULL,NULL,'2026-06-05 14:58:21.199516',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1276,4,'2026-04-22 03:45:00',84.20,119.90,90.80,84.20,119.90,90.80,NULL,NULL,'2026-06-05 14:58:21.208118',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1277,4,'2026-04-22 03:47:00',82.90,125.30,90.00,82.90,125.30,90.00,NULL,NULL,'2026-06-05 14:58:21.216318',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1278,4,'2026-04-22 03:48:00',125.80,135.30,123.30,125.80,135.30,123.30,NULL,NULL,'2026-06-05 14:58:21.226044',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1279,4,'2026-04-22 03:49:00',88.40,123.10,94.10,88.40,123.10,94.10,NULL,NULL,'2026-06-05 14:58:21.232909',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1280,4,'2026-04-22 03:51:00',80.20,80.80,66.50,80.20,80.80,66.50,NULL,NULL,'2026-06-05 14:58:21.242599',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1281,4,'2026-04-22 03:52:00',114.90,89.30,76.50,114.90,89.30,76.50,NULL,NULL,'2026-06-05 14:58:21.250297',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1282,4,'2026-04-22 03:53:00',185.10,142.90,127.40,185.10,142.90,127.40,NULL,NULL,'2026-06-05 14:58:21.259685',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1283,4,'2026-04-22 03:54:00',109.20,139.50,134.90,109.20,139.50,134.90,NULL,NULL,'2026-06-05 14:58:21.267397',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1284,4,'2026-04-22 03:56:00',120.60,122.80,86.60,120.60,122.80,86.60,NULL,NULL,'2026-06-05 14:58:21.276406',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1285,4,'2026-04-22 03:57:00',124.60,143.70,91.80,124.60,143.70,91.80,NULL,NULL,'2026-06-05 14:58:21.283976',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1286,4,'2026-04-22 03:58:00',151.50,124.40,124.10,151.50,124.40,124.10,NULL,NULL,'2026-06-05 14:58:21.294924',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1287,4,'2026-04-22 04:00:00',166.90,111.10,123.70,166.90,111.10,123.70,NULL,NULL,'2026-06-05 14:58:21.302963',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1288,4,'2026-04-22 04:01:00',98.20,105.90,115.00,98.20,105.90,115.00,NULL,NULL,'2026-06-05 14:58:21.311445',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1289,4,'2026-04-22 04:02:00',119.30,128.80,85.40,119.30,128.80,85.40,NULL,NULL,'2026-06-05 14:58:21.321733',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1290,4,'2026-04-22 04:04:00',143.70,140.50,136.10,143.70,140.50,136.10,NULL,NULL,'2026-06-05 14:58:21.329786',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1291,4,'2026-04-22 04:05:00',97.00,137.50,105.10,97.00,137.50,105.10,NULL,NULL,'2026-06-05 14:58:21.339647',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1292,4,'2026-04-22 04:06:00',103.10,148.70,94.10,103.10,148.70,94.10,NULL,NULL,'2026-06-05 14:58:21.346610',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1293,4,'2026-04-22 04:08:00',148.30,105.20,92.10,148.30,105.20,92.10,NULL,NULL,'2026-06-05 14:58:21.356466',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1294,4,'2026-04-22 04:09:00',145.10,142.30,137.90,145.10,142.30,137.90,NULL,NULL,'2026-06-05 14:58:21.363310',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1295,4,'2026-04-22 04:11:00',137.60,142.50,92.70,137.60,142.50,92.70,NULL,NULL,'2026-06-05 14:58:21.372348',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1296,4,'2026-04-22 04:12:00',111.60,115.10,73.80,111.60,115.10,73.80,NULL,NULL,'2026-06-05 14:58:21.379114',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1297,4,'2026-04-22 04:13:00',141.30,163.30,142.90,141.30,163.30,142.90,NULL,NULL,'2026-06-05 14:58:21.387527',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1298,4,'2026-04-22 04:14:00',168.20,134.10,146.80,168.20,134.10,146.80,NULL,NULL,'2026-06-05 14:58:21.394859',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1299,4,'2026-04-22 04:16:00',122.70,112.00,130.50,122.70,112.00,130.50,NULL,NULL,'2026-06-05 14:58:21.403852',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1300,4,'2026-04-22 04:17:00',96.80,104.90,92.10,96.80,104.90,92.10,NULL,NULL,'2026-06-05 14:58:21.411150',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1301,4,'2026-04-22 04:18:00',149.00,141.20,99.60,149.00,141.20,99.60,NULL,NULL,'2026-06-05 14:58:21.417223',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1302,4,'2026-04-22 04:20:00',116.30,152.80,128.00,116.30,152.80,128.00,NULL,NULL,'2026-06-05 14:58:21.427072',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1303,4,'2026-04-22 04:21:00',107.50,133.50,117.50,107.50,133.50,117.50,NULL,NULL,'2026-06-05 14:58:21.434767',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1304,4,'2026-04-22 04:22:00',147.20,119.20,75.60,147.20,119.20,75.60,NULL,NULL,'2026-06-05 14:58:21.442450',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1305,4,'2026-04-22 04:23:00',139.60,124.30,82.60,139.60,124.30,82.60,NULL,NULL,'2026-06-05 14:58:21.449749',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1306,4,'2026-04-22 04:25:00',103.60,103.40,102.20,103.60,103.40,102.20,NULL,NULL,'2026-06-05 14:58:21.462127',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1307,4,'2026-04-22 04:26:00',135.40,87.20,102.80,135.40,87.20,102.80,NULL,NULL,'2026-06-05 14:58:21.472360',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1308,4,'2026-04-22 04:27:00',126.80,117.30,75.20,126.80,117.30,75.20,NULL,NULL,'2026-06-05 14:58:21.480485',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1309,4,'2026-04-22 04:29:00',99.10,116.90,78.00,99.10,116.90,78.00,NULL,NULL,'2026-06-05 14:58:21.490561',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1310,4,'2026-04-22 04:30:00',88.90,122.40,100.20,88.90,122.40,100.20,NULL,NULL,'2026-06-05 14:58:21.498386',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1311,4,'2026-04-22 04:31:00',94.80,113.00,100.30,94.80,113.00,100.30,NULL,NULL,'2026-06-05 14:58:21.507886',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1312,4,'2026-04-22 04:33:00',149.50,104.50,87.50,149.50,104.50,87.50,NULL,NULL,'2026-06-05 14:58:21.515765',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1313,4,'2026-04-22 04:34:00',91.50,92.80,74.50,91.50,92.80,74.50,NULL,NULL,'2026-06-05 14:58:21.524904',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1314,4,'2026-04-22 04:35:00',86.60,85.60,100.30,86.60,85.60,100.30,NULL,NULL,'2026-06-05 14:58:21.534795',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1315,4,'2026-04-22 04:37:00',91.50,124.20,76.00,91.50,124.20,76.00,NULL,NULL,'2026-06-05 14:58:21.543076',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1316,4,'2026-04-22 04:38:00',154.80,115.00,97.30,154.80,115.00,97.30,NULL,NULL,'2026-06-05 14:58:21.554250',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1317,4,'2026-04-22 04:39:00',85.10,114.50,68.80,85.10,114.50,68.80,NULL,NULL,'2026-06-05 14:58:21.562879',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1318,4,'2026-04-22 04:41:00',91.00,122.80,93.90,91.00,122.80,93.90,NULL,NULL,'2026-06-05 14:58:21.577510',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1319,4,'2026-04-22 04:42:00',112.50,106.00,99.40,112.50,106.00,99.40,NULL,NULL,'2026-06-05 14:58:21.586685',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1320,4,'2026-04-22 04:43:00',125.10,96.00,95.50,125.10,96.00,95.50,NULL,NULL,'2026-06-05 14:58:21.594727',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1321,4,'2026-04-22 04:44:00',97.90,84.40,97.50,97.90,84.40,97.50,NULL,NULL,'2026-06-05 14:58:21.604779',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1322,4,'2026-04-22 04:46:00',76.00,85.00,65.60,76.00,85.00,65.60,NULL,NULL,'2026-06-05 14:58:21.613734',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1323,4,'2026-04-22 04:47:00',101.40,113.90,91.90,101.40,113.90,91.90,NULL,NULL,'2026-06-05 14:58:21.623943',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1324,4,'2026-04-22 04:48:00',115.20,113.50,93.90,115.20,113.50,93.90,NULL,NULL,'2026-06-05 14:58:21.632605',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1325,4,'2026-04-22 04:50:00',90.40,136.70,69.50,90.40,136.70,69.50,NULL,NULL,'2026-06-05 14:58:21.644882',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1326,4,'2026-04-22 04:51:00',82.70,81.50,85.60,82.70,81.50,85.60,NULL,NULL,'2026-06-05 14:58:21.657839',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1327,4,'2026-04-22 04:52:00',78.30,110.20,60.30,78.30,110.20,60.30,NULL,NULL,'2026-06-05 14:58:21.666720',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1328,4,'2026-04-22 04:53:00',167.80,86.70,93.90,167.80,86.70,93.90,NULL,NULL,'2026-06-05 14:58:21.680324',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1329,4,'2026-04-22 04:54:00',147.00,113.30,143.80,147.00,113.30,143.80,NULL,NULL,'2026-06-05 14:58:21.691246',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1330,4,'2026-04-22 04:56:00',76.30,97.40,64.70,76.30,97.40,64.70,NULL,NULL,'2026-06-05 14:58:21.700474',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1331,4,'2026-04-22 04:57:00',97.70,112.30,61.40,97.70,112.30,61.40,NULL,NULL,'2026-06-05 14:58:21.708853',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1332,4,'2026-04-22 04:58:00',149.70,125.00,115.10,149.70,125.00,115.10,NULL,NULL,'2026-06-05 14:58:21.718350',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1333,4,'2026-04-22 05:00:00',104.30,133.60,117.90,104.30,133.60,117.90,NULL,NULL,'2026-06-05 14:58:21.727062',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1334,4,'2026-04-22 05:01:00',89.60,140.60,92.80,89.60,140.60,92.80,NULL,NULL,'2026-06-05 14:58:21.737913',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1335,4,'2026-04-22 05:02:00',128.60,103.50,92.80,128.60,103.50,92.80,NULL,NULL,'2026-06-05 14:58:21.745759',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1336,4,'2026-04-22 05:04:00',129.30,111.80,145.00,129.30,111.80,145.00,NULL,NULL,'2026-06-05 14:58:21.755131',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1337,4,'2026-04-22 05:05:00',147.90,95.00,113.90,147.90,95.00,113.90,NULL,NULL,'2026-06-05 14:58:21.763476',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1338,4,'2026-04-22 05:06:00',119.10,122.70,101.80,119.10,122.70,101.80,NULL,NULL,'2026-06-05 14:58:21.777412',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1339,4,'2026-04-22 05:07:00',114.60,125.30,82.70,114.60,125.30,82.70,NULL,NULL,'2026-06-05 14:58:21.792732',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1340,4,'2026-04-22 05:09:00',143.20,124.70,84.20,143.20,124.70,84.20,NULL,NULL,'2026-06-05 14:58:21.801857',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1341,4,'2026-04-22 05:10:00',119.90,143.30,147.50,119.90,143.30,147.50,NULL,NULL,'2026-06-05 14:58:21.810136',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1342,4,'2026-04-22 05:11:00',115.40,106.50,121.50,115.40,106.50,121.50,NULL,NULL,'2026-06-05 14:58:21.821093',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1343,4,'2026-04-22 05:13:00',131.30,102.90,92.30,131.30,102.90,92.30,NULL,NULL,'2026-06-05 14:58:21.831966',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1344,4,'2026-04-22 05:14:00',105.30,108.50,86.50,105.30,108.50,86.50,NULL,NULL,'2026-06-05 14:58:21.841539',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1345,4,'2026-04-22 05:15:00',95.80,132.60,108.10,95.80,132.60,108.10,NULL,NULL,'2026-06-05 14:58:21.850216',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1346,4,'2026-04-22 05:17:00',102.70,147.60,138.20,102.70,147.60,138.20,NULL,NULL,'2026-06-05 14:58:21.861077',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1347,4,'2026-04-22 05:18:00',96.70,108.40,67.40,96.70,108.40,67.40,NULL,NULL,'2026-06-05 14:58:21.874197',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1348,4,'2026-04-22 05:19:00',121.90,135.30,91.20,121.90,135.30,91.20,NULL,NULL,'2026-06-05 14:58:21.883495',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1349,4,'2026-04-22 05:20:00',128.50,126.80,86.90,128.50,126.80,86.90,NULL,NULL,'2026-06-05 14:58:21.892716',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1350,4,'2026-04-22 05:22:00',123.60,85.10,91.40,123.60,85.10,91.40,NULL,NULL,'2026-06-05 14:58:21.903242',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1351,4,'2026-04-22 05:23:00',128.70,122.00,97.30,128.70,122.00,97.30,NULL,NULL,'2026-06-05 14:58:21.913362',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1352,4,'2026-04-22 05:24:00',136.20,97.30,65.30,136.20,97.30,65.30,NULL,NULL,'2026-06-05 14:58:21.924053',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1353,4,'2026-04-22 05:26:00',104.20,117.60,84.30,104.20,117.60,84.30,NULL,NULL,'2026-06-05 14:58:21.932190',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1354,4,'2026-04-22 05:27:00',149.70,118.30,94.20,149.70,118.30,94.20,NULL,NULL,'2026-06-05 14:58:21.942527',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1355,4,'2026-04-22 05:29:00',96.20,93.00,95.50,96.20,93.00,95.50,NULL,NULL,'2026-06-05 14:58:21.953962',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1356,4,'2026-04-22 05:30:00',86.70,85.00,66.30,86.70,85.00,66.30,NULL,NULL,'2026-06-05 14:58:21.962015',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1357,4,'2026-04-22 05:31:00',82.10,111.50,118.90,82.10,111.50,118.90,NULL,NULL,'2026-06-05 14:58:21.973629',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1358,4,'2026-04-22 05:33:00',109.80,106.20,61.00,109.80,106.20,61.00,NULL,NULL,'2026-06-05 14:58:21.982013',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1359,4,'2026-04-22 05:34:00',90.20,116.50,84.90,90.20,116.50,84.90,NULL,NULL,'2026-06-05 14:58:21.992142',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1360,4,'2026-04-22 05:35:00',97.40,115.50,69.80,97.40,115.50,69.80,NULL,NULL,'2026-06-05 14:58:22.000217',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1361,4,'2026-04-22 05:36:00',117.10,111.80,66.10,117.10,111.80,66.10,NULL,NULL,'2026-06-05 14:58:22.011277',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1362,4,'2026-04-22 05:38:00',141.70,87.00,121.30,141.70,87.00,121.30,NULL,NULL,'2026-06-05 14:58:22.022366',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1363,4,'2026-04-22 05:39:00',129.70,97.10,103.80,129.70,97.10,103.80,NULL,NULL,'2026-06-05 14:58:22.030788',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1364,4,'2026-04-22 05:40:00',133.60,88.60,70.60,133.60,88.60,70.60,NULL,NULL,'2026-06-05 14:58:22.042510',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1365,4,'2026-04-22 05:42:00',101.30,115.00,60.80,101.30,115.00,60.80,NULL,NULL,'2026-06-05 14:58:22.054771',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1366,4,'2026-04-22 05:43:00',109.30,116.40,66.40,109.30,116.40,66.40,NULL,NULL,'2026-06-05 14:58:22.063432',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1367,4,'2026-04-22 05:44:00',95.40,112.40,92.20,95.40,112.40,92.20,NULL,NULL,'2026-06-05 14:58:22.073702',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1368,4,'2026-04-22 05:45:00',92.20,111.00,87.80,92.20,111.00,87.80,NULL,NULL,'2026-06-05 14:58:22.082762',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1369,4,'2026-04-22 05:47:00',101.80,112.30,75.70,101.80,112.30,75.70,NULL,NULL,'2026-06-05 14:58:22.092443',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1370,4,'2026-04-22 05:48:00',132.40,87.70,66.60,132.40,87.70,66.60,NULL,NULL,'2026-06-05 14:58:22.102793',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1371,4,'2026-04-22 05:49:00',86.80,87.40,87.70,86.80,87.40,87.70,NULL,NULL,'2026-06-05 14:58:22.111998',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1372,4,'2026-04-22 05:51:00',127.20,109.80,109.50,127.20,109.80,109.50,NULL,NULL,'2026-06-05 14:58:22.122751',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1373,4,'2026-04-22 05:52:00',153.20,121.80,67.90,153.20,121.80,67.90,NULL,NULL,'2026-06-05 14:58:22.131764',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1374,4,'2026-04-22 05:53:00',109.40,104.00,59.30,109.40,104.00,59.30,NULL,NULL,'2026-06-05 14:58:22.141818',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1375,4,'2026-04-22 05:54:00',137.10,126.60,94.20,137.10,126.60,94.20,NULL,NULL,'2026-06-05 14:58:22.153714',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1376,4,'2026-04-22 05:56:00',105.70,126.00,108.70,105.70,126.00,108.70,NULL,NULL,'2026-06-05 14:58:22.161106',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1377,4,'2026-04-22 05:57:00',89.20,97.30,84.80,89.20,97.30,84.80,NULL,NULL,'2026-06-05 14:58:22.171225',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1378,4,'2026-04-22 05:58:00',117.10,78.60,62.10,117.10,78.60,62.10,NULL,NULL,'2026-06-05 14:58:22.178901',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1379,4,'2026-04-22 06:00:00',111.00,95.60,74.80,111.00,95.60,74.80,NULL,NULL,'2026-06-05 14:58:22.188556',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1380,4,'2026-04-22 06:01:00',94.40,123.60,111.50,94.40,123.60,111.50,NULL,NULL,'2026-06-05 14:58:22.207413',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1381,4,'2026-04-22 06:02:00',105.90,135.10,106.40,105.90,135.10,106.40,NULL,NULL,'2026-06-05 14:58:22.223538',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1382,4,'2026-04-22 06:03:00',167.20,118.00,102.10,167.20,118.00,102.10,NULL,NULL,'2026-06-05 14:58:22.236219',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1383,4,'2026-04-22 06:05:00',104.70,137.40,82.50,104.70,137.40,82.50,NULL,NULL,'2026-06-05 14:58:22.245552',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1384,4,'2026-04-22 06:06:00',132.90,118.40,139.50,132.90,118.40,139.50,NULL,NULL,'2026-06-05 14:58:22.257461',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1385,4,'2026-04-22 06:08:00',152.50,120.60,121.40,152.50,120.60,121.40,NULL,NULL,'2026-06-05 14:58:22.269280',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1386,4,'2026-04-22 06:09:00',108.80,126.60,82.50,108.80,126.60,82.50,NULL,NULL,'2026-06-05 14:58:22.279295',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1387,4,'2026-04-22 06:10:00',147.40,135.60,86.50,147.40,135.60,86.50,NULL,NULL,'2026-06-05 14:58:22.291783',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1388,4,'2026-04-22 06:12:00',156.50,130.30,113.10,156.50,130.30,113.10,NULL,NULL,'2026-06-05 14:58:22.303403',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1389,4,'2026-04-22 06:13:00',119.20,101.80,82.00,119.20,101.80,82.00,NULL,NULL,'2026-06-05 14:58:22.314258',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1390,4,'2026-04-22 06:15:00',103.60,98.10,87.10,103.60,98.10,87.10,NULL,NULL,'2026-06-05 14:58:22.329020',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1391,4,'2026-04-22 06:16:00',126.30,108.00,117.90,126.30,108.00,117.90,NULL,NULL,'2026-06-05 14:58:22.343628',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1392,4,'2026-04-22 06:17:00',170.10,128.90,114.80,170.10,128.90,114.80,NULL,NULL,'2026-06-05 14:58:22.355890',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1393,4,'2026-04-22 06:19:00',124.00,119.20,99.30,124.00,119.20,99.30,NULL,NULL,'2026-06-05 14:58:22.365754',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1394,4,'2026-04-22 06:20:00',138.80,133.90,82.70,138.80,133.90,82.70,NULL,NULL,'2026-06-05 14:58:22.379568',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1395,4,'2026-04-22 06:21:00',159.30,137.60,92.90,159.30,137.60,92.90,NULL,NULL,'2026-06-05 14:58:22.394046',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1396,4,'2026-04-22 06:23:00',113.70,92.80,114.20,113.70,92.80,114.20,NULL,NULL,'2026-06-05 14:58:22.404944',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1397,4,'2026-04-22 06:24:00',136.00,105.40,110.60,136.00,105.40,110.60,NULL,NULL,'2026-06-05 14:58:22.421091',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1398,4,'2026-04-22 06:25:00',133.90,121.20,71.60,133.90,121.20,71.60,NULL,NULL,'2026-06-05 14:58:22.435260',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1399,4,'2026-04-22 06:26:00',119.60,109.10,66.30,119.60,109.10,66.30,NULL,NULL,'2026-06-05 14:58:22.446004',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1400,4,'2026-04-22 06:28:00',121.50,130.90,138.10,121.50,130.90,138.10,NULL,NULL,'2026-06-05 14:58:22.458023',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1401,4,'2026-04-22 06:29:00',107.20,104.30,90.10,107.20,104.30,90.10,NULL,NULL,'2026-06-05 14:58:22.468366',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1402,4,'2026-04-22 06:31:00',76.60,72.80,63.80,76.60,72.80,63.80,NULL,NULL,'2026-06-05 14:58:22.482525',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1403,4,'2026-04-22 06:32:00',104.40,81.60,68.40,104.40,81.60,68.40,NULL,NULL,'2026-06-05 14:58:22.493199',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1404,4,'2026-04-22 06:33:00',140.00,80.20,60.00,140.00,80.20,60.00,NULL,NULL,'2026-06-05 14:58:22.510155',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1405,4,'2026-04-22 06:34:00',161.10,87.00,69.00,161.10,87.00,69.00,NULL,NULL,'2026-06-05 14:58:22.526978',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1406,4,'2026-04-22 06:35:00',103.60,84.90,96.50,103.60,84.90,96.50,NULL,NULL,'2026-06-05 14:58:22.546332',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1407,4,'2026-04-22 06:37:00',107.80,79.60,94.10,107.80,79.60,94.10,NULL,NULL,'2026-06-05 14:58:22.559855',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1408,4,'2026-04-22 06:38:00',121.00,94.70,94.30,121.00,94.70,94.30,NULL,NULL,'2026-06-05 14:58:22.576760',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1409,4,'2026-04-22 06:39:00',125.20,113.90,62.50,125.20,113.90,62.50,NULL,NULL,'2026-06-05 14:58:22.595225',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1410,4,'2026-04-22 06:41:00',90.50,101.00,60.70,90.50,101.00,60.70,NULL,NULL,'2026-06-05 14:58:22.610929',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1411,4,'2026-04-22 06:42:00',118.50,114.50,118.30,118.50,114.50,118.30,NULL,NULL,'2026-06-05 14:58:22.624373',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1412,4,'2026-04-22 06:43:00',129.30,83.00,95.30,129.30,83.00,95.30,NULL,NULL,'2026-06-05 14:58:22.637040',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1413,4,'2026-04-22 06:44:00',120.70,71.40,67.60,120.70,71.40,67.60,NULL,NULL,'2026-06-05 14:58:22.651153',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1414,4,'2026-04-22 06:46:00',107.30,106.40,77.70,107.30,106.40,77.70,NULL,NULL,'2026-06-05 14:58:22.662381',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1415,4,'2026-04-22 06:47:00',99.80,105.30,83.20,99.80,105.30,83.20,NULL,NULL,'2026-06-05 14:58:22.676053',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1416,4,'2026-04-22 06:48:00',131.20,109.50,105.40,131.20,109.50,105.40,NULL,NULL,'2026-06-05 14:58:22.706586',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1417,4,'2026-04-22 06:50:00',118.90,110.00,84.70,118.90,110.00,84.70,NULL,NULL,'2026-06-05 14:58:22.725197',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1418,4,'2026-04-22 06:51:00',98.20,80.40,75.10,98.20,80.40,75.10,NULL,NULL,'2026-06-05 14:58:22.743234',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1419,4,'2026-04-22 06:52:00',108.00,77.50,74.40,108.00,77.50,74.40,NULL,NULL,'2026-06-05 14:58:22.756101',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1420,4,'2026-04-22 06:54:00',115.20,78.40,99.40,115.20,78.40,99.40,NULL,NULL,'2026-06-05 14:58:22.769856',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1421,4,'2026-04-22 06:55:00',113.80,104.20,95.30,113.80,104.20,95.30,NULL,NULL,'2026-06-05 14:58:22.780563',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1422,4,'2026-04-22 06:56:00',116.10,96.30,71.30,116.10,96.30,71.30,NULL,NULL,'2026-06-05 14:58:22.793730',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1423,4,'2026-04-22 06:57:00',102.50,112.20,87.50,102.50,112.20,87.50,NULL,NULL,'2026-06-05 14:58:22.806062',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1424,4,'2026-04-22 07:00:00',100.50,107.70,82.40,100.50,107.70,82.40,NULL,NULL,'2026-06-05 14:58:22.816389',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1425,4,'2026-04-22 07:01:00',116.80,102.70,64.50,116.80,102.70,64.50,NULL,NULL,'2026-06-05 14:58:22.826180',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1426,4,'2026-04-22 07:03:00',102.80,85.50,87.20,102.80,85.50,87.20,NULL,NULL,'2026-06-05 14:58:22.840288',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1427,4,'2026-04-22 07:04:00',85.90,90.70,111.30,85.90,90.70,111.30,NULL,NULL,'2026-06-05 14:58:22.852660',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1428,4,'2026-04-22 07:05:00',153.20,156.80,170.40,153.20,156.80,170.40,NULL,NULL,'2026-06-05 14:58:22.868199',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1429,4,'2026-04-22 07:06:00',153.60,141.80,141.50,153.60,141.80,141.50,NULL,NULL,'2026-06-05 14:58:22.878665',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1430,4,'2026-04-22 07:08:00',173.10,188.70,193.80,173.10,188.70,193.80,NULL,NULL,'2026-06-05 14:58:22.889506',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1431,4,'2026-04-22 07:09:00',166.20,194.30,188.10,166.20,194.30,188.10,NULL,NULL,'2026-06-05 14:58:22.904236',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1432,4,'2026-04-22 07:10:00',202.80,242.50,217.90,202.80,242.50,217.90,NULL,NULL,'2026-06-05 14:58:22.915780',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1433,4,'2026-04-22 07:12:00',297.00,273.60,251.30,297.00,273.60,251.30,NULL,NULL,'2026-06-05 14:58:22.930130',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1434,4,'2026-04-22 07:13:00',178.50,168.40,197.50,178.50,168.40,197.50,NULL,NULL,'2026-06-05 14:58:22.939588',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1435,4,'2026-04-22 07:14:00',270.20,249.30,300.40,270.20,249.30,300.40,NULL,NULL,'2026-06-05 14:58:22.952893',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1436,4,'2026-04-22 07:16:00',197.80,174.40,183.30,197.80,174.40,183.30,NULL,NULL,'2026-06-05 14:58:22.966140',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1437,4,'2026-04-22 07:17:00',269.40,237.50,221.50,269.40,237.50,221.50,NULL,NULL,'2026-06-05 14:58:22.978431',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1438,4,'2026-04-22 07:18:00',172.60,178.70,158.20,172.60,178.70,158.20,NULL,NULL,'2026-06-05 14:58:22.987920',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1439,4,'2026-04-22 07:20:00',205.30,225.50,220.60,205.30,225.50,220.60,NULL,NULL,'2026-06-05 14:58:22.998463',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1440,4,'2026-04-22 07:21:00',218.60,232.40,250.70,218.60,232.40,250.70,NULL,NULL,'2026-06-05 14:58:23.008880',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1441,4,'2026-04-22 07:22:00',243.40,247.20,256.50,243.40,247.20,256.50,NULL,NULL,'2026-06-05 14:58:23.022917',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1442,4,'2026-04-22 07:23:00',235.00,207.30,206.70,235.00,207.30,206.70,NULL,NULL,'2026-06-05 14:58:23.035276',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1443,4,'2026-04-22 07:25:00',204.50,212.60,204.80,204.50,212.60,204.80,NULL,NULL,'2026-06-05 14:58:23.047952',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1444,4,'2026-04-22 07:26:00',196.90,202.00,217.40,196.90,202.00,217.40,NULL,NULL,'2026-06-05 14:58:23.058735',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1445,4,'2026-04-22 07:27:00',183.90,171.80,176.50,183.90,171.80,176.50,NULL,NULL,'2026-06-05 14:58:23.071666',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1446,4,'2026-04-22 07:29:00',196.80,184.30,187.70,196.80,184.30,187.70,NULL,NULL,'2026-06-05 14:58:23.082440',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1447,4,'2026-04-22 07:30:00',175.50,201.80,195.60,175.50,201.80,195.60,NULL,NULL,'2026-06-05 14:58:23.092906',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1448,4,'2026-04-22 07:31:00',168.70,159.30,196.70,168.70,159.30,196.70,NULL,NULL,'2026-06-05 14:58:23.103059',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1449,4,'2026-04-22 07:32:00',216.50,184.70,217.80,216.50,184.70,217.80,NULL,NULL,'2026-06-05 14:58:23.111999',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1450,4,'2026-04-22 07:34:00',184.40,176.10,153.00,184.40,176.10,153.00,NULL,NULL,'2026-06-05 14:58:23.123020',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1451,4,'2026-04-22 07:35:00',137.40,155.80,133.80,137.40,155.80,133.80,NULL,NULL,'2026-06-05 14:58:23.132201',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1452,4,'2026-04-22 07:36:00',171.40,185.40,175.40,171.40,185.40,175.40,NULL,NULL,'2026-06-05 14:58:23.139776',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1453,4,'2026-04-22 07:38:00',191.80,175.30,186.50,191.80,175.30,186.50,NULL,NULL,'2026-06-05 14:58:23.151173',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1454,4,'2026-04-22 07:39:00',201.20,154.80,183.30,201.20,154.80,183.30,NULL,NULL,'2026-06-05 14:58:23.158501',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1455,4,'2026-04-22 07:40:00',176.50,173.50,180.10,176.50,173.50,180.10,NULL,NULL,'2026-06-05 14:58:23.168626',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1456,4,'2026-04-22 07:41:00',138.70,131.60,140.90,138.70,131.60,140.90,NULL,NULL,'2026-06-05 14:58:23.175579',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1457,4,'2026-04-22 07:43:00',180.90,173.90,188.10,180.90,173.90,188.10,NULL,NULL,'2026-06-05 14:58:23.185439',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1458,4,'2026-04-22 07:44:00',234.00,227.60,233.30,234.00,227.60,233.30,NULL,NULL,'2026-06-05 14:58:23.193121',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1459,4,'2026-04-22 07:45:00',161.20,158.10,178.10,161.20,158.10,178.10,NULL,NULL,'2026-06-05 14:58:23.202641',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1460,4,'2026-04-22 07:47:00',165.10,182.60,164.90,165.10,182.60,164.90,NULL,NULL,'2026-06-05 14:58:23.210930',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1461,4,'2026-04-22 07:48:00',168.70,159.50,155.30,168.70,159.50,155.30,NULL,NULL,'2026-06-05 14:58:23.220140',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1462,4,'2026-04-22 07:49:00',214.90,151.20,219.00,214.90,151.20,219.00,NULL,NULL,'2026-06-05 14:58:23.227319',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1463,4,'2026-04-22 07:51:00',179.70,144.50,180.30,179.70,144.50,180.30,NULL,NULL,'2026-06-05 14:58:23.235629',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1464,4,'2026-04-22 07:52:00',218.60,215.40,209.30,218.60,215.40,209.30,NULL,NULL,'2026-06-05 14:58:23.243660',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1465,4,'2026-04-22 07:53:00',267.70,274.50,277.00,267.70,274.50,277.00,NULL,NULL,'2026-06-05 14:58:23.253087',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1466,4,'2026-04-22 07:55:00',241.00,222.60,245.40,241.00,222.60,245.40,NULL,NULL,'2026-06-05 14:58:23.263553',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1467,4,'2026-04-22 07:56:00',169.50,158.80,207.90,169.50,158.80,207.90,NULL,NULL,'2026-06-05 14:58:23.273782',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1468,4,'2026-04-22 07:57:00',170.70,177.40,190.40,170.70,177.40,190.40,NULL,NULL,'2026-06-05 14:58:23.284084',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1469,4,'2026-04-22 07:58:00',213.90,230.40,232.20,213.90,230.40,232.20,NULL,NULL,'2026-06-05 14:58:23.291556',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1470,4,'2026-04-22 08:00:00',196.30,154.30,178.30,196.30,154.30,178.30,NULL,NULL,'2026-06-05 14:58:23.300764',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1471,4,'2026-04-22 08:01:00',212.60,185.90,229.20,212.60,185.90,229.20,NULL,NULL,'2026-06-05 14:58:23.307816',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1472,4,'2026-04-22 08:02:00',197.00,208.80,241.50,197.00,208.80,241.50,NULL,NULL,'2026-06-05 14:58:23.316877',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1473,4,'2026-04-22 08:04:00',209.70,179.40,182.70,209.70,179.40,182.70,NULL,NULL,'2026-06-05 14:58:23.326227',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1474,4,'2026-04-22 08:05:00',211.60,196.50,239.00,211.60,196.50,239.00,NULL,NULL,'2026-06-05 14:58:23.335673',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1475,4,'2026-04-22 08:06:00',212.20,183.70,245.20,212.20,183.70,245.20,NULL,NULL,'2026-06-05 14:58:23.345654',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1476,4,'2026-04-22 08:08:00',173.00,159.90,209.60,173.00,159.90,209.60,NULL,NULL,'2026-06-05 14:58:23.354884',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1477,4,'2026-04-22 08:09:00',197.90,197.50,243.90,197.90,197.50,243.90,NULL,NULL,'2026-06-05 14:58:23.363827',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1478,4,'2026-04-22 08:10:00',288.30,267.50,274.40,288.30,267.50,274.40,NULL,NULL,'2026-06-05 14:58:23.371186',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1479,4,'2026-04-22 08:12:00',188.90,194.40,243.00,188.90,194.40,243.00,NULL,NULL,'2026-06-05 14:58:23.379502',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1480,4,'2026-04-22 08:13:00',211.30,202.00,243.00,211.30,202.00,243.00,NULL,NULL,'2026-06-05 14:58:23.387223',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1481,4,'2026-04-22 08:14:00',213.30,218.80,259.00,213.30,218.80,259.00,NULL,NULL,'2026-06-05 14:58:23.395630',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1482,4,'2026-04-22 08:15:00',279.00,253.40,308.90,279.00,253.40,308.90,NULL,NULL,'2026-06-05 14:58:23.403699',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1483,4,'2026-04-22 08:17:00',155.90,147.50,180.40,155.90,147.50,180.40,NULL,NULL,'2026-06-05 14:58:23.412143',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1484,4,'2026-04-22 08:19:00',163.40,172.40,211.00,163.40,172.40,211.00,NULL,NULL,'2026-06-05 14:58:23.420438',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1485,4,'2026-04-22 08:20:00',189.40,171.00,179.70,189.40,171.00,179.70,NULL,NULL,'2026-06-05 14:58:23.428473',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1486,4,'2026-04-22 08:21:00',261.10,275.70,280.10,261.10,275.70,280.10,NULL,NULL,'2026-06-05 14:58:23.436347',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1487,4,'2026-04-22 08:23:00',247.00,220.00,279.80,247.00,220.00,279.80,NULL,NULL,'2026-06-05 14:58:23.444528',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1488,4,'2026-04-22 08:24:00',161.40,120.20,182.30,161.40,120.20,182.30,NULL,NULL,'2026-06-05 14:58:23.452265',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1489,4,'2026-04-22 08:25:00',134.60,136.10,155.80,134.60,136.10,155.80,NULL,NULL,'2026-06-05 14:58:23.460170',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1490,4,'2026-04-22 08:27:00',146.20,157.50,179.80,146.20,157.50,179.80,NULL,NULL,'2026-06-05 14:58:23.468741',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1491,4,'2026-04-22 08:28:00',182.50,157.60,207.70,182.50,157.60,207.70,NULL,NULL,'2026-06-05 14:58:23.476138',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1492,4,'2026-04-22 08:29:00',121.00,109.60,133.90,121.00,109.60,133.90,NULL,NULL,'2026-06-05 14:58:23.483773',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1493,4,'2026-04-22 08:31:00',77.80,64.60,85.70,77.80,64.60,85.70,NULL,NULL,'2026-06-05 14:58:23.490441',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1494,4,'2026-04-22 08:32:00',92.30,73.20,109.00,92.30,73.20,109.00,NULL,NULL,'2026-06-05 14:58:23.500081',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1495,4,'2026-04-22 08:33:00',84.10,77.40,122.90,84.10,77.40,122.90,NULL,NULL,'2026-06-05 14:58:23.509195',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1496,4,'2026-04-22 08:35:00',85.40,59.80,93.20,85.40,59.80,93.20,NULL,NULL,'2026-06-05 14:58:23.521033',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1497,4,'2026-04-22 08:36:00',53.20,55.80,91.20,53.20,55.80,91.20,NULL,NULL,'2026-06-05 14:58:23.532182',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1498,4,'2026-04-22 08:37:00',65.10,41.60,61.80,65.10,41.60,61.80,NULL,NULL,'2026-06-05 14:58:23.539209',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1499,4,'2026-04-22 08:39:00',60.90,38.80,64.40,60.90,38.80,64.40,NULL,NULL,'2026-06-05 14:58:23.550407',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1500,4,'2026-04-22 08:40:00',61.20,44.40,95.00,61.20,44.40,95.00,NULL,NULL,'2026-06-05 14:58:23.558951',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1501,4,'2026-04-22 08:41:00',60.50,48.80,96.90,60.50,48.80,96.90,NULL,NULL,'2026-06-05 14:58:23.567958',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1502,4,'2026-04-22 08:43:00',46.80,49.40,77.40,46.80,49.40,77.40,NULL,NULL,'2026-06-05 14:58:23.575461',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1503,4,'2026-04-22 08:44:00',47.90,47.50,66.40,47.90,47.50,66.40,NULL,NULL,'2026-06-05 14:58:23.583813',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1504,4,'2026-04-22 08:45:00',68.70,46.80,71.60,68.70,46.80,71.60,NULL,NULL,'2026-06-05 14:58:23.590469',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1505,4,'2026-04-22 08:46:00',56.00,45.20,91.00,56.00,45.20,91.00,NULL,NULL,'2026-06-05 14:58:23.600997',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1506,4,'2026-04-22 08:48:00',52.70,41.00,80.50,52.70,41.00,80.50,NULL,NULL,'2026-06-05 14:58:23.612687',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1507,4,'2026-04-22 08:49:00',87.60,55.10,74.10,87.60,55.10,74.10,NULL,NULL,'2026-06-05 14:58:23.622279',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1508,4,'2026-04-22 08:50:00',73.60,45.80,64.60,73.60,45.80,64.60,NULL,NULL,'2026-06-05 14:58:23.632560',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1509,4,'2026-04-22 08:52:00',54.50,53.30,103.80,54.50,53.30,103.80,NULL,NULL,'2026-06-05 14:58:23.642031',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1510,4,'2026-04-22 08:53:00',65.80,45.60,77.90,65.80,45.60,77.90,NULL,NULL,'2026-06-05 14:58:23.652299',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1511,4,'2026-04-22 08:54:00',91.80,43.60,68.20,91.80,43.60,68.20,NULL,NULL,'2026-06-05 14:58:23.661328',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1512,4,'2026-04-22 08:55:00',82.60,36.70,62.20,82.60,36.70,62.20,NULL,NULL,'2026-06-05 14:58:23.671051',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1513,4,'2026-04-22 08:57:00',58.90,49.40,87.30,58.90,49.40,87.30,NULL,NULL,'2026-06-05 14:58:23.680645',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1514,4,'2026-04-22 08:58:00',60.50,51.50,82.60,60.50,51.50,82.60,NULL,NULL,'2026-06-05 14:58:23.687821',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1515,4,'2026-04-22 08:59:00',64.30,44.30,94.90,64.30,44.30,94.90,NULL,NULL,'2026-06-05 14:58:23.697176',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1516,4,'2026-04-22 09:00:00',78.70,64.70,91.70,78.70,64.70,91.70,NULL,NULL,'2026-06-05 14:58:23.704021',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1517,4,'2026-04-22 09:02:00',115.40,70.90,88.10,115.40,70.90,88.10,NULL,NULL,'2026-06-05 14:58:23.712962',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1518,4,'2026-04-22 09:03:00',53.00,50.50,60.60,53.00,50.50,60.60,NULL,NULL,'2026-06-05 14:58:23.722533',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1519,4,'2026-04-22 09:04:00',58.70,62.60,62.50,58.70,62.60,62.50,NULL,NULL,'2026-06-05 14:58:23.731475',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1520,4,'2026-04-22 09:06:00',54.50,45.90,96.40,54.50,45.90,96.40,NULL,NULL,'2026-06-05 14:58:23.738293',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1521,4,'2026-04-22 09:07:00',70.20,43.50,92.50,70.20,43.50,92.50,NULL,NULL,'2026-06-05 14:58:23.747574',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1522,4,'2026-04-22 09:08:00',63.30,44.70,81.40,63.30,44.70,81.40,NULL,NULL,'2026-06-05 14:58:23.754683',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1523,4,'2026-04-22 09:09:00',58.90,45.50,63.90,58.90,45.50,63.90,NULL,NULL,'2026-06-05 14:58:23.764838',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1524,4,'2026-04-22 09:11:00',58.70,63.50,113.20,58.70,63.50,113.20,NULL,NULL,'2026-06-05 14:58:23.773576',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1525,4,'2026-04-22 09:12:00',94.70,75.50,124.10,94.70,75.50,124.10,NULL,NULL,'2026-06-05 14:58:23.786179',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1526,4,'2026-04-22 09:13:00',71.30,56.10,93.60,71.30,56.10,93.60,NULL,NULL,'2026-06-05 14:58:23.797771',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1527,4,'2026-04-22 09:15:00',79.60,56.80,100.50,79.60,56.80,100.50,NULL,NULL,'2026-06-05 14:58:23.812485',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1528,4,'2026-04-22 09:16:00',59.70,45.80,95.90,59.70,45.80,95.90,NULL,NULL,'2026-06-05 14:58:23.820567',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1529,4,'2026-04-22 09:17:00',85.70,60.20,113.00,85.70,60.20,113.00,NULL,NULL,'2026-06-05 14:58:23.829985',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1530,4,'2026-04-22 09:19:00',75.90,45.60,107.00,75.90,45.60,107.00,NULL,NULL,'2026-06-05 14:58:23.837368',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1531,4,'2026-04-22 09:20:00',91.30,64.40,120.80,91.30,64.40,120.80,NULL,NULL,'2026-06-05 14:58:23.849089',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1532,4,'2026-04-22 09:21:00',76.20,77.40,128.10,76.20,77.40,128.10,NULL,NULL,'2026-06-05 14:58:23.856990',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1533,4,'2026-04-22 09:22:00',44.70,55.60,88.70,44.70,55.60,88.70,NULL,NULL,'2026-06-05 14:58:23.867657',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1534,4,'2026-04-22 09:24:00',56.10,46.50,84.30,56.10,46.50,84.30,NULL,NULL,'2026-06-05 14:58:23.877766',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1535,4,'2026-04-22 09:25:00',81.30,46.80,113.20,81.30,46.80,113.20,NULL,NULL,'2026-06-05 14:58:23.887199',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1536,4,'2026-04-22 09:26:00',49.50,41.30,113.70,49.50,41.30,113.70,NULL,NULL,'2026-06-05 14:58:23.895822',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1537,4,'2026-04-22 09:28:00',54.00,50.70,101.00,54.00,50.70,101.00,NULL,NULL,'2026-06-05 14:58:23.904709',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1538,4,'2026-04-22 09:29:00',61.20,47.60,95.80,61.20,47.60,95.80,NULL,NULL,'2026-06-05 14:58:23.913977',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1539,4,'2026-04-22 09:30:00',93.80,62.50,121.60,93.80,62.50,121.60,NULL,NULL,'2026-06-05 14:58:23.925224',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1540,4,'2026-04-22 09:31:00',48.00,44.20,83.10,48.00,44.20,83.10,NULL,NULL,'2026-06-05 14:58:23.933266',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1541,4,'2026-04-22 09:33:00',66.30,49.30,96.90,66.30,49.30,96.90,NULL,NULL,'2026-06-05 14:58:23.942647',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1542,4,'2026-04-22 09:34:00',70.10,44.50,65.90,70.10,44.50,65.90,NULL,NULL,'2026-06-05 14:58:23.950567',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1543,4,'2026-04-22 09:35:00',60.10,59.70,105.30,60.10,59.70,105.30,NULL,NULL,'2026-06-05 14:58:23.960884',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1544,4,'2026-04-22 09:37:00',39.10,43.30,83.60,39.10,43.30,83.60,NULL,NULL,'2026-06-05 14:58:23.972886',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1545,4,'2026-04-22 09:38:00',75.60,44.80,60.70,75.60,44.80,60.70,NULL,NULL,'2026-06-05 14:58:23.983210',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1546,4,'2026-04-22 09:39:00',100.30,60.30,64.30,100.30,60.30,64.30,NULL,NULL,'2026-06-05 14:58:23.991986',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1547,4,'2026-04-22 09:41:00',55.00,42.90,73.90,55.00,42.90,73.90,NULL,NULL,'2026-06-05 14:58:24.002803',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1548,4,'2026-04-22 09:42:00',64.00,46.60,94.50,64.00,46.60,94.50,NULL,NULL,'2026-06-05 14:58:24.015359',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1549,4,'2026-04-22 09:44:00',87.80,60.60,109.40,87.80,60.60,109.40,NULL,NULL,'2026-06-05 14:58:24.028405',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1550,4,'2026-04-22 09:45:00',83.50,48.60,61.90,83.50,48.60,61.90,NULL,NULL,'2026-06-05 14:58:24.037431',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1551,4,'2026-04-22 09:46:00',49.80,48.60,67.30,49.80,48.60,67.30,NULL,NULL,'2026-06-05 14:58:24.050622',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1552,4,'2026-04-22 09:47:00',40.70,43.80,74.40,40.70,43.80,74.40,NULL,NULL,'2026-06-05 14:58:24.064053',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1553,4,'2026-04-22 09:49:00',55.40,41.50,86.40,55.40,41.50,86.40,NULL,NULL,'2026-06-05 14:58:24.073394',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1554,4,'2026-04-22 09:50:00',78.60,48.60,96.60,78.60,48.60,96.60,NULL,NULL,'2026-06-05 14:58:24.090546',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1555,4,'2026-04-22 09:51:00',59.40,55.90,63.50,59.40,55.90,63.50,NULL,NULL,'2026-06-05 14:58:24.136010',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1556,4,'2026-04-22 09:53:00',52.40,48.60,62.40,52.40,48.60,62.40,NULL,NULL,'2026-06-05 14:58:24.167278',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1557,4,'2026-04-22 09:54:00',59.30,59.10,75.30,59.30,59.10,75.30,NULL,NULL,'2026-06-05 14:58:24.181099',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1558,4,'2026-04-22 09:55:00',64.70,59.00,66.00,64.70,59.00,66.00,NULL,NULL,'2026-06-05 14:58:24.195165',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1559,4,'2026-04-22 09:56:00',94.20,49.10,90.30,94.20,49.10,90.30,NULL,NULL,'2026-06-05 14:58:24.205341',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1560,4,'2026-04-22 09:58:00',59.20,43.80,65.10,59.20,43.80,65.10,NULL,NULL,'2026-06-05 14:58:24.221052',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1561,4,'2026-04-22 09:59:00',77.30,63.00,76.50,77.30,63.00,76.50,NULL,NULL,'2026-06-05 14:58:24.237130',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1562,4,'2026-04-22 10:01:00',94.60,63.50,123.80,94.60,63.50,123.80,NULL,NULL,'2026-06-05 14:58:24.251663',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1563,4,'2026-04-22 10:02:00',75.20,59.20,96.20,75.20,59.20,96.20,NULL,NULL,'2026-06-05 14:58:24.264172',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1564,4,'2026-04-22 10:03:00',47.40,51.00,91.60,47.40,51.00,91.60,NULL,NULL,'2026-06-05 14:58:24.275586',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1565,4,'2026-04-22 10:05:00',66.90,70.90,88.80,66.90,70.90,88.80,NULL,NULL,'2026-06-05 14:58:24.294014',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1566,4,'2026-04-22 10:06:00',60.10,50.10,69.90,60.10,50.10,69.90,NULL,NULL,'2026-06-05 14:58:24.311232',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1567,4,'2026-04-22 10:07:00',72.10,38.40,81.00,72.10,38.40,81.00,NULL,NULL,'2026-06-05 14:58:24.321631',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1568,4,'2026-04-22 10:08:00',38.80,39.00,84.50,38.80,39.00,84.50,NULL,NULL,'2026-06-05 14:58:24.337324',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1569,4,'2026-04-22 10:10:00',49.90,57.60,121.40,49.90,57.60,121.40,NULL,NULL,'2026-06-05 14:58:24.365793',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1570,4,'2026-04-22 10:11:00',57.60,46.90,59.70,57.60,46.90,59.70,NULL,NULL,'2026-06-05 14:58:24.384625',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1571,4,'2026-04-22 10:12:00',55.60,49.00,68.60,55.60,49.00,68.60,NULL,NULL,'2026-06-05 14:58:24.400500',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1572,4,'2026-04-22 10:14:00',79.60,54.60,61.10,79.60,54.60,61.10,NULL,NULL,'2026-06-05 14:58:24.410787',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1573,4,'2026-04-22 10:15:00',79.60,59.80,110.20,79.60,59.80,110.20,NULL,NULL,'2026-06-05 14:58:24.420403',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1574,4,'2026-04-22 10:16:00',62.70,44.80,108.60,62.70,44.80,108.60,NULL,NULL,'2026-06-05 14:58:24.431099',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1575,4,'2026-04-22 10:17:00',40.40,42.90,87.70,40.40,42.90,87.70,NULL,NULL,'2026-06-05 14:58:24.443804',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1576,4,'2026-04-22 10:19:00',74.30,42.90,80.80,74.30,42.90,80.80,NULL,NULL,'2026-06-05 14:58:24.455280',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1577,4,'2026-04-22 10:20:00',67.10,61.90,110.10,67.10,61.90,110.10,NULL,NULL,'2026-06-05 14:58:24.468060',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1578,4,'2026-04-22 10:22:00',35.70,42.30,88.40,35.70,42.30,88.40,NULL,NULL,'2026-06-05 14:58:24.487516',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1579,4,'2026-04-22 10:23:00',72.80,64.70,117.20,72.80,64.70,117.20,NULL,NULL,'2026-06-05 14:58:24.513788',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1580,4,'2026-04-22 10:24:00',69.00,48.00,76.70,69.00,48.00,76.70,NULL,NULL,'2026-06-05 14:58:24.532729',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1581,4,'2026-04-22 10:26:00',66.40,42.30,83.80,66.40,42.30,83.80,NULL,NULL,'2026-06-05 14:58:24.549249',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1582,4,'2026-04-22 10:27:00',56.70,40.40,112.70,56.70,40.40,112.70,NULL,NULL,'2026-06-05 14:58:24.562172',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1583,4,'2026-04-22 10:28:00',86.60,49.80,103.80,86.60,49.80,103.80,NULL,NULL,'2026-06-05 14:58:24.577515',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1584,4,'2026-04-22 10:30:00',56.90,50.00,81.60,56.90,50.00,81.60,NULL,NULL,'2026-06-05 14:58:24.587101',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1585,4,'2026-04-22 10:31:00',57.00,45.80,85.60,57.00,45.80,85.60,NULL,NULL,'2026-06-05 14:58:24.598455',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1586,4,'2026-04-22 10:32:00',50.30,41.30,108.20,50.30,41.30,108.20,NULL,NULL,'2026-06-05 14:58:24.618514',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1587,4,'2026-04-22 10:33:00',77.70,41.90,97.50,77.70,41.90,97.50,NULL,NULL,'2026-06-05 14:58:24.632147',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1588,4,'2026-04-22 10:35:00',60.30,44.30,112.30,60.30,44.30,112.30,NULL,NULL,'2026-06-05 14:58:24.645460',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1589,4,'2026-04-22 10:36:00',44.70,46.70,102.50,44.70,46.70,102.50,NULL,NULL,'2026-06-05 14:58:24.664048',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1590,4,'2026-04-22 10:37:00',48.20,45.60,57.50,48.20,45.60,57.50,NULL,NULL,'2026-06-05 14:58:24.680068',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1591,4,'2026-04-22 10:39:00',102.50,92.30,113.30,102.50,92.30,113.30,NULL,NULL,'2026-06-05 14:58:24.693036',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1592,4,'2026-04-22 10:40:00',61.30,58.30,76.10,61.30,58.30,76.10,NULL,NULL,'2026-06-05 14:58:24.714047',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1593,4,'2026-04-22 10:41:00',66.50,48.30,93.90,66.50,48.30,93.90,NULL,NULL,'2026-06-05 14:58:24.726068',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1594,4,'2026-04-22 10:43:00',84.10,46.50,80.50,84.10,46.50,80.50,NULL,NULL,'2026-06-05 14:58:24.737447',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1595,4,'2026-04-22 10:44:00',102.60,58.40,67.40,102.60,58.40,67.40,NULL,NULL,'2026-06-05 14:58:24.752047',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1596,4,'2026-04-22 10:45:00',62.80,63.30,78.70,62.80,63.30,78.70,NULL,NULL,'2026-06-05 14:58:24.765300',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1597,4,'2026-04-22 10:47:00',60.60,60.40,59.30,60.60,60.40,59.30,NULL,NULL,'2026-06-05 14:58:24.781680',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1598,4,'2026-04-22 10:48:00',56.50,53.00,92.60,56.50,53.00,92.60,NULL,NULL,'2026-06-05 14:58:24.793790',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1599,4,'2026-04-22 10:49:00',68.10,40.90,68.40,68.10,40.90,68.40,NULL,NULL,'2026-06-05 14:58:24.802646',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1600,4,'2026-04-22 10:50:00',56.90,47.10,97.90,56.90,47.10,97.90,NULL,NULL,'2026-06-05 14:58:24.817488',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1601,4,'2026-04-22 10:52:00',65.90,48.50,123.50,65.90,48.50,123.50,NULL,NULL,'2026-06-05 14:58:24.831194',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1602,4,'2026-04-22 10:53:00',61.50,54.90,124.60,61.50,54.90,124.60,NULL,NULL,'2026-06-05 14:58:24.841959',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1603,4,'2026-04-22 10:54:00',61.80,46.60,60.30,61.80,46.60,60.30,NULL,NULL,'2026-06-05 14:58:24.851433',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1604,4,'2026-04-22 10:56:00',48.20,50.00,79.50,48.20,50.00,79.50,NULL,NULL,'2026-06-05 14:58:24.861173',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1605,4,'2026-04-22 10:57:00',69.90,78.40,80.30,69.90,78.40,80.30,NULL,NULL,'2026-06-05 14:58:24.873783',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1606,4,'2026-04-22 10:58:00',46.50,50.60,95.30,46.50,50.60,95.30,NULL,NULL,'2026-06-05 14:58:24.885430',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1607,4,'2026-04-22 10:59:00',68.40,48.80,130.60,68.40,48.80,130.60,NULL,NULL,'2026-06-05 14:58:24.898071',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1608,4,'2026-04-22 11:01:00',103.30,43.30,98.20,103.30,43.30,98.20,NULL,NULL,'2026-06-05 14:58:24.911966',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1609,4,'2026-04-22 11:02:00',56.10,48.80,63.00,56.10,48.80,63.00,NULL,NULL,'2026-06-05 14:58:24.922702',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1610,4,'2026-04-22 11:04:00',57.30,52.40,67.80,57.30,52.40,67.80,NULL,NULL,'2026-06-05 14:58:24.934963',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1611,4,'2026-04-22 11:05:00',105.30,77.60,98.40,105.30,77.60,98.40,NULL,NULL,'2026-06-05 14:58:24.945757',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1612,4,'2026-04-22 11:06:00',88.60,66.00,94.70,88.60,66.00,94.70,NULL,NULL,'2026-06-05 14:58:24.957851',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1613,4,'2026-04-22 11:07:00',72.10,61.50,98.00,72.10,61.50,98.00,NULL,NULL,'2026-06-05 14:58:24.966101',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1614,4,'2026-04-22 11:09:00',62.30,45.80,65.60,62.30,45.80,65.60,NULL,NULL,'2026-06-05 14:58:24.979549',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1615,4,'2026-04-22 11:10:00',84.30,44.30,84.80,84.30,44.30,84.80,NULL,NULL,'2026-06-05 14:58:24.991490',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1616,4,'2026-04-22 11:11:00',82.00,61.30,110.40,82.00,61.30,110.40,NULL,NULL,'2026-06-05 14:58:25.001851',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1617,4,'2026-04-22 11:12:00',66.60,50.40,85.30,66.60,50.40,85.30,NULL,NULL,'2026-06-05 14:58:25.013354',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1618,4,'2026-04-22 11:14:00',49.10,56.90,67.20,49.10,56.90,67.20,NULL,NULL,'2026-06-05 14:58:25.023642',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1619,4,'2026-04-22 11:15:00',87.40,51.30,94.70,87.40,51.30,94.70,NULL,NULL,'2026-06-05 14:58:25.033583',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1620,4,'2026-04-22 11:16:00',77.20,63.70,101.30,77.20,63.70,101.30,NULL,NULL,'2026-06-05 14:58:25.045654',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1621,4,'2026-04-22 11:18:00',97.50,48.20,100.60,97.50,48.20,100.60,NULL,NULL,'2026-06-05 14:58:25.057481',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1622,4,'2026-04-22 11:19:00',63.80,47.60,98.60,63.80,47.60,98.60,NULL,NULL,'2026-06-05 14:58:25.069955',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1623,4,'2026-04-22 11:20:00',41.70,44.40,94.30,41.70,44.40,94.30,NULL,NULL,'2026-06-05 14:58:25.080323',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1624,4,'2026-04-22 11:22:00',73.00,47.40,120.40,73.00,47.40,120.40,NULL,NULL,'2026-06-05 14:58:25.094469',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1625,4,'2026-04-22 11:23:00',82.60,57.20,83.60,82.60,57.20,83.60,NULL,NULL,'2026-06-05 14:58:25.108523',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1626,4,'2026-04-22 11:24:00',52.00,55.90,99.50,52.00,55.90,99.50,NULL,NULL,'2026-06-05 14:58:25.116644',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1627,4,'2026-04-22 11:26:00',77.20,79.50,131.30,77.20,79.50,131.30,NULL,NULL,'2026-06-05 14:58:25.128964',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1628,4,'2026-04-22 11:27:00',70.30,74.20,125.70,70.30,74.20,125.70,NULL,NULL,'2026-06-05 14:58:25.140463',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1629,4,'2026-04-22 11:28:00',64.60,52.10,117.50,64.60,52.10,117.50,NULL,NULL,'2026-06-05 14:58:25.148202',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1630,4,'2026-04-22 11:29:00',85.80,41.40,65.30,85.80,41.40,65.30,NULL,NULL,'2026-06-05 14:58:25.163145',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1631,4,'2026-04-22 11:30:00',62.10,51.60,70.40,62.10,51.60,70.40,NULL,NULL,'2026-06-05 14:58:25.175354',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1632,4,'2026-04-22 11:32:00',61.80,46.70,87.80,61.80,46.70,87.80,NULL,NULL,'2026-06-05 14:58:25.185724',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1633,4,'2026-04-22 11:33:00',60.10,46.20,107.60,60.10,46.20,107.60,NULL,NULL,'2026-06-05 14:58:25.195477',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1634,4,'2026-04-22 11:34:00',63.10,58.60,126.10,63.10,58.60,126.10,NULL,NULL,'2026-06-05 14:58:25.205876',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1635,4,'2026-04-22 11:36:00',76.90,62.30,114.20,76.90,62.30,114.20,NULL,NULL,'2026-06-05 14:58:25.213363',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1636,4,'2026-04-22 11:37:00',82.60,63.00,123.80,82.60,63.00,123.80,NULL,NULL,'2026-06-05 14:58:25.223343',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1637,4,'2026-04-22 11:38:00',89.40,84.00,96.20,89.40,84.00,96.20,NULL,NULL,'2026-06-05 14:58:25.231666',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1638,4,'2026-04-22 11:39:00',43.90,42.50,84.00,43.90,42.50,84.00,NULL,NULL,'2026-06-05 14:58:25.243034',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1639,4,'2026-04-22 11:41:00',58.90,48.00,106.60,58.90,48.00,106.60,NULL,NULL,'2026-06-05 14:58:25.250265',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1640,4,'2026-04-22 11:42:00',60.30,46.70,121.80,60.30,46.70,121.80,NULL,NULL,'2026-06-05 14:58:25.260406',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1641,4,'2026-04-22 11:43:00',82.70,44.30,123.60,82.70,44.30,123.60,NULL,NULL,'2026-06-05 14:58:25.268672',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1642,4,'2026-04-22 11:44:00',85.40,57.50,98.00,85.40,57.50,98.00,NULL,NULL,'2026-06-05 14:58:25.278871',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1643,4,'2026-04-22 11:46:00',81.30,58.80,100.20,81.30,58.80,100.20,NULL,NULL,'2026-06-05 14:58:25.287449',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1644,4,'2026-04-22 11:47:00',57.70,51.30,125.70,57.70,51.30,125.70,NULL,NULL,'2026-06-05 14:58:25.296308',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1645,4,'2026-04-22 11:49:00',58.40,49.90,112.10,58.40,49.90,112.10,NULL,NULL,'2026-06-05 14:58:25.306439',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1646,4,'2026-04-22 11:50:00',57.30,42.20,76.10,57.30,42.20,76.10,NULL,NULL,'2026-06-05 14:58:25.316063',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1647,4,'2026-04-22 11:51:00',86.00,55.50,75.10,86.00,55.50,75.10,NULL,NULL,'2026-06-05 14:58:25.326248',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1648,4,'2026-04-22 11:52:00',78.60,51.80,100.40,78.60,51.80,100.40,NULL,NULL,'2026-06-05 14:58:25.339131',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1649,4,'2026-04-22 11:54:00',49.50,51.10,99.70,49.50,51.10,99.70,NULL,NULL,'2026-06-05 14:58:25.346803',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1650,4,'2026-04-22 11:55:00',40.00,49.70,86.30,40.00,49.70,86.30,NULL,NULL,'2026-06-05 14:58:25.356303',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1651,4,'2026-04-22 11:56:00',47.80,49.20,94.50,47.80,49.20,94.50,NULL,NULL,'2026-06-05 14:58:25.363505',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1652,4,'2026-04-22 11:58:00',73.80,51.50,67.60,73.80,51.50,67.60,NULL,NULL,'2026-06-05 14:58:25.372853',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1653,4,'2026-04-22 11:59:00',56.70,45.20,67.30,56.70,45.20,67.30,NULL,NULL,'2026-06-05 14:58:25.379891',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1654,4,'2026-04-22 12:00:00',58.30,43.50,84.80,58.30,43.50,84.80,NULL,NULL,'2026-06-05 14:58:25.389098',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1655,4,'2026-04-22 12:01:00',45.40,40.80,78.70,45.40,40.80,78.70,NULL,NULL,'2026-06-05 14:58:25.397022',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1656,4,'2026-04-22 12:03:00',70.70,44.20,91.40,70.70,44.20,91.40,NULL,NULL,'2026-06-05 14:58:25.406934',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1657,4,'2026-04-22 12:04:00',49.50,38.80,72.30,49.50,38.80,72.30,NULL,NULL,'2026-06-05 14:58:25.414169',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1658,4,'2026-04-22 12:05:00',63.80,40.30,54.30,63.80,40.30,54.30,NULL,NULL,'2026-06-05 14:58:25.427513',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1659,4,'2026-04-22 12:07:00',55.20,42.10,57.50,55.20,42.10,57.50,NULL,NULL,'2026-06-05 14:58:25.439571',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1660,4,'2026-04-22 12:08:00',49.80,49.70,71.20,49.80,49.70,71.20,NULL,NULL,'2026-06-05 14:58:25.447908',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1661,4,'2026-04-22 12:09:00',62.70,39.70,84.50,62.70,39.70,84.50,NULL,NULL,'2026-06-05 14:58:25.458162',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1662,4,'2026-04-22 12:11:00',76.60,37.00,73.40,76.60,37.00,73.40,NULL,NULL,'2026-06-05 14:58:25.466996',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1663,4,'2026-04-22 12:12:00',49.50,42.50,56.20,49.50,42.50,56.20,NULL,NULL,'2026-06-05 14:58:25.476089',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1664,4,'2026-04-22 12:13:00',44.50,40.80,70.80,44.50,40.80,70.80,NULL,NULL,'2026-06-05 14:58:25.485777',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1665,4,'2026-04-22 12:15:00',86.30,58.40,88.30,86.30,58.40,88.30,NULL,NULL,'2026-06-05 14:58:25.494349',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1666,4,'2026-04-22 12:16:00',92.50,51.70,92.40,92.50,51.70,92.40,NULL,NULL,'2026-06-05 14:58:25.503999',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1667,4,'2026-04-22 12:17:00',43.20,46.20,62.00,43.20,46.20,62.00,NULL,NULL,'2026-06-05 14:58:25.511340',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1668,4,'2026-04-22 12:19:00',43.00,41.60,75.50,43.00,41.60,75.50,NULL,NULL,'2026-06-05 14:58:25.523984',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1669,4,'2026-04-22 12:20:00',47.10,42.20,71.90,47.10,42.20,71.90,NULL,NULL,'2026-06-05 14:58:25.536073',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1670,4,'2026-04-22 12:21:00',68.50,42.70,88.20,68.50,42.70,88.20,NULL,NULL,'2026-06-05 14:58:25.545972',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1671,4,'2026-04-22 12:22:00',65.70,82.60,107.90,65.70,82.60,107.90,NULL,NULL,'2026-06-05 14:58:25.560332',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1672,4,'2026-04-22 12:24:00',50.40,48.30,54.50,50.40,48.30,54.50,NULL,NULL,'2026-06-05 14:58:25.569476',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1673,4,'2026-04-22 12:25:00',66.30,59.30,56.60,66.30,59.30,56.60,NULL,NULL,'2026-06-05 14:58:25.577081',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1674,4,'2026-04-22 12:26:00',91.10,64.90,121.30,91.10,64.90,121.30,NULL,NULL,'2026-06-05 14:58:25.586408',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1675,4,'2026-04-22 12:28:00',39.30,39.30,85.20,39.30,39.30,85.20,NULL,NULL,'2026-06-05 14:58:25.594536',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1676,4,'2026-04-22 12:29:00',50.10,39.30,72.00,50.10,39.30,72.00,NULL,NULL,'2026-06-05 14:58:25.604050',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1677,4,'2026-04-22 12:30:00',65.60,38.70,84.40,65.60,38.70,84.40,NULL,NULL,'2026-06-05 14:58:25.610990',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1678,4,'2026-04-22 12:32:00',79.40,51.20,89.80,79.40,51.20,89.80,NULL,NULL,'2026-06-05 14:58:25.620615',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1679,4,'2026-04-22 12:33:00',61.30,42.80,87.50,61.30,42.80,87.50,NULL,NULL,'2026-06-05 14:58:25.627596',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1680,4,'2026-04-22 12:34:00',40.30,48.60,100.90,40.30,48.60,100.90,NULL,NULL,'2026-06-05 14:58:25.634864',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1681,4,'2026-04-22 12:36:00',40.80,55.70,89.40,40.80,55.70,89.40,NULL,NULL,'2026-06-05 14:58:25.642543',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1682,4,'2026-04-22 12:37:00',64.10,40.30,83.00,64.10,40.30,83.00,NULL,NULL,'2026-06-05 14:58:25.650130',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1683,4,'2026-04-22 12:38:00',59.60,40.50,81.60,59.60,40.50,81.60,NULL,NULL,'2026-06-05 14:58:25.658600',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1684,4,'2026-04-22 12:40:00',49.30,40.20,108.80,49.30,40.20,108.80,NULL,NULL,'2026-06-05 14:58:25.672039',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1685,4,'2026-04-22 12:41:00',45.20,48.60,116.20,45.20,48.60,116.20,NULL,NULL,'2026-06-05 14:58:25.680339',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1686,4,'2026-04-22 12:43:00',64.00,44.40,81.20,64.00,44.40,81.20,NULL,NULL,'2026-06-05 14:58:25.695995',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1687,4,'2026-04-22 12:44:00',46.60,44.10,84.90,46.60,44.10,84.90,NULL,NULL,'2026-06-05 14:58:25.710003',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1688,4,'2026-04-22 12:45:00',42.20,43.10,110.10,42.20,43.10,110.10,NULL,NULL,'2026-06-05 14:58:25.722898',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1689,4,'2026-04-22 12:46:00',55.20,40.80,116.40,55.20,40.80,116.40,NULL,NULL,'2026-06-05 14:58:25.731070',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1690,4,'2026-04-22 12:48:00',45.50,41.90,115.90,45.50,41.90,115.90,NULL,NULL,'2026-06-05 14:58:25.745054',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1691,4,'2026-04-22 12:49:00',69.10,46.10,124.10,69.10,46.10,124.10,NULL,NULL,'2026-06-05 14:58:25.755036',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1692,4,'2026-04-22 12:50:00',54.10,70.00,84.10,54.10,70.00,84.10,NULL,NULL,'2026-06-05 14:58:25.765129',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1693,4,'2026-04-22 12:52:00',49.40,76.10,117.90,49.40,76.10,117.90,NULL,NULL,'2026-06-05 14:58:25.786452',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1694,4,'2026-04-22 12:53:00',38.20,45.30,96.40,38.20,45.30,96.40,NULL,NULL,'2026-06-05 14:58:25.795783',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1695,4,'2026-04-22 12:54:00',61.50,44.90,97.10,61.50,44.90,97.10,NULL,NULL,'2026-06-05 14:58:25.807853',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1696,4,'2026-04-22 12:55:00',52.80,67.20,118.00,52.80,67.20,118.00,NULL,NULL,'2026-06-05 14:58:25.821755',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1697,4,'2026-04-22 12:57:00',52.30,44.20,65.80,52.30,44.20,65.80,NULL,NULL,'2026-06-05 14:58:25.830928',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1698,4,'2026-04-22 12:58:00',87.20,71.70,118.20,87.20,71.70,118.20,NULL,NULL,'2026-06-05 14:58:25.844335',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1699,4,'2026-04-22 13:00:00',70.30,62.50,87.80,70.30,62.50,87.80,NULL,NULL,'2026-06-05 14:58:25.857813',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1700,4,'2026-04-22 13:01:00',57.20,51.40,57.60,57.20,51.40,57.60,NULL,NULL,'2026-06-05 14:58:25.872920',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1701,4,'2026-04-22 13:02:00',75.40,45.00,92.40,75.40,45.00,92.40,NULL,NULL,'2026-06-05 14:58:25.886716',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1702,4,'2026-04-22 13:04:00',54.10,52.60,74.00,54.10,52.60,74.00,NULL,NULL,'2026-06-05 14:58:25.893694',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1703,4,'2026-04-22 13:05:00',52.20,48.30,70.40,52.20,48.30,70.40,NULL,NULL,'2026-06-05 14:58:25.903242',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1704,4,'2026-04-22 13:06:00',50.20,43.90,77.40,50.20,43.90,77.40,NULL,NULL,'2026-06-05 14:58:25.910105',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1705,4,'2026-04-22 13:07:00',58.70,63.50,69.80,58.70,63.50,69.80,NULL,NULL,'2026-06-05 14:58:25.919764',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1706,4,'2026-04-22 13:09:00',90.60,68.50,90.90,90.60,68.50,90.90,NULL,NULL,'2026-06-05 14:58:25.930566',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1707,4,'2026-04-22 13:10:00',63.80,56.60,98.80,63.80,56.60,98.80,NULL,NULL,'2026-06-05 14:58:25.940600',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1708,4,'2026-04-22 13:12:00',53.40,56.40,96.00,53.40,56.40,96.00,NULL,NULL,'2026-06-05 14:58:25.948452',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1709,4,'2026-04-22 13:13:00',48.70,44.70,71.50,48.70,44.70,71.50,NULL,NULL,'2026-06-05 14:58:25.959163',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1710,4,'2026-04-22 13:14:00',72.10,45.30,85.40,72.10,45.30,85.40,NULL,NULL,'2026-06-05 14:58:25.968661',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1711,4,'2026-04-22 13:16:00',66.90,49.60,95.90,66.90,49.60,95.90,NULL,NULL,'2026-06-05 14:58:25.976052',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1712,4,'2026-04-22 13:17:00',62.40,51.90,97.00,62.40,51.90,97.00,NULL,NULL,'2026-06-05 14:58:25.984131',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1713,4,'2026-04-22 13:18:00',44.20,50.20,62.70,44.20,50.20,62.70,NULL,NULL,'2026-06-05 14:58:25.993725',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1714,4,'2026-04-22 13:20:00',63.30,44.20,72.90,63.30,44.20,72.90,NULL,NULL,'2026-06-05 14:58:26.003960',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1715,4,'2026-04-22 13:21:00',62.80,48.50,79.80,62.80,48.50,79.80,NULL,NULL,'2026-06-05 14:58:26.013021',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1716,4,'2026-04-22 13:22:00',43.10,47.10,89.10,43.10,47.10,89.10,NULL,NULL,'2026-06-05 14:58:26.027497',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1717,4,'2026-04-22 13:24:00',71.80,56.40,70.20,71.80,56.40,70.20,NULL,NULL,'2026-06-05 14:58:26.037179',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1718,4,'2026-04-22 13:25:00',64.20,61.70,81.20,64.20,61.70,81.20,NULL,NULL,'2026-06-05 14:58:26.045174',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1719,4,'2026-04-22 13:26:00',54.20,52.20,88.30,54.20,52.20,88.30,NULL,NULL,'2026-06-05 14:58:26.054740',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1720,4,'2026-04-22 13:28:00',52.20,53.70,85.80,52.20,53.70,85.80,NULL,NULL,'2026-06-05 14:58:26.061881',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1721,4,'2026-04-22 13:29:00',38.70,42.50,83.90,38.70,42.50,83.90,NULL,NULL,'2026-06-05 14:58:26.070954',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1722,4,'2026-04-22 13:30:00',70.90,40.10,63.10,70.90,40.10,63.10,NULL,NULL,'2026-06-05 14:58:26.079013',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1723,4,'2026-04-22 13:32:00',64.70,54.50,73.10,64.70,54.50,73.10,NULL,NULL,'2026-06-05 14:58:26.089052',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1724,4,'2026-04-22 13:33:00',47.60,42.30,57.80,47.60,42.30,57.80,NULL,NULL,'2026-06-05 14:58:26.096484',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1725,4,'2026-04-22 13:34:00',65.80,43.20,81.60,65.80,43.20,81.60,NULL,NULL,'2026-06-05 14:58:26.108474',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1726,4,'2026-04-22 13:35:00',69.70,80.80,121.10,69.70,80.80,121.10,NULL,NULL,'2026-06-05 14:58:26.118508',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1727,4,'2026-04-22 13:37:00',114.40,79.70,88.70,114.40,79.70,88.70,NULL,NULL,'2026-06-05 14:58:26.129042',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1728,4,'2026-04-22 13:38:00',98.10,86.40,99.90,98.10,86.40,99.90,NULL,NULL,'2026-06-05 14:58:26.143934',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1729,4,'2026-04-22 13:39:00',41.30,44.60,55.50,41.30,44.60,55.50,NULL,NULL,'2026-06-05 14:58:26.156631',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1730,4,'2026-04-22 13:40:00',64.80,76.20,86.80,64.80,76.20,86.80,NULL,NULL,'2026-06-05 14:58:26.164402',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1731,4,'2026-04-22 13:42:00',52.50,45.30,93.10,52.50,45.30,93.10,NULL,NULL,'2026-06-05 14:58:26.174127',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1732,4,'2026-04-22 13:43:00',49.40,69.00,86.20,49.40,69.00,86.20,NULL,NULL,'2026-06-05 14:58:26.181732',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1733,4,'2026-04-22 13:45:00',66.40,70.30,85.70,66.40,70.30,85.70,NULL,NULL,'2026-06-05 14:58:26.193318',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1734,4,'2026-04-22 13:46:00',65.80,45.50,101.70,65.80,45.50,101.70,NULL,NULL,'2026-06-05 14:58:26.201224',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1735,4,'2026-04-22 13:47:00',69.90,42.10,129.50,69.90,42.10,129.50,NULL,NULL,'2026-06-05 14:58:26.211822',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1736,4,'2026-04-22 13:49:00',46.40,42.80,112.90,46.40,42.80,112.90,NULL,NULL,'2026-06-05 14:58:26.222876',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1737,4,'2026-04-22 13:50:00',65.70,57.80,130.40,65.70,57.80,130.40,NULL,NULL,'2026-06-05 14:58:26.232399',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1738,4,'2026-04-22 13:51:00',82.70,76.70,113.60,82.70,76.70,113.60,NULL,NULL,'2026-06-05 14:58:26.244358',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1739,4,'2026-04-22 13:53:00',77.30,99.70,144.30,77.30,99.70,144.30,NULL,NULL,'2026-06-05 14:58:26.252413',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1740,4,'2026-04-22 13:54:00',52.30,56.00,119.50,52.30,56.00,119.50,NULL,NULL,'2026-06-05 14:58:26.263291',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1741,4,'2026-04-22 13:55:00',66.80,61.40,86.90,66.80,61.40,86.90,NULL,NULL,'2026-06-05 14:58:26.274840',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1742,4,'2026-04-22 13:57:00',66.50,74.40,112.50,66.50,74.40,112.50,NULL,NULL,'2026-06-05 14:58:26.283030',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1743,4,'2026-04-22 13:58:00',87.20,46.50,113.90,87.20,46.50,113.90,NULL,NULL,'2026-06-05 14:58:26.293754',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1744,4,'2026-04-22 13:59:00',54.60,50.20,121.00,54.60,50.20,121.00,NULL,NULL,'2026-06-05 14:58:26.303061',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1745,4,'2026-04-22 14:01:00',82.80,95.50,142.40,82.80,95.50,142.40,NULL,NULL,'2026-06-05 14:58:26.313877',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1746,4,'2026-04-22 14:02:00',110.60,70.80,152.10,110.60,70.80,152.10,NULL,NULL,'2026-06-05 14:58:26.325022',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1747,4,'2026-04-22 14:04:00',57.70,48.00,103.60,57.70,48.00,103.60,NULL,NULL,'2026-06-05 14:58:26.334084',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1748,4,'2026-04-22 14:05:00',58.20,46.50,118.50,58.20,46.50,118.50,NULL,NULL,'2026-06-05 14:58:26.344501',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1749,4,'2026-04-22 14:06:00',76.90,48.50,100.00,76.90,48.50,100.00,NULL,NULL,'2026-06-05 14:58:26.354085',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1750,4,'2026-04-22 14:07:00',111.60,53.90,93.10,111.60,53.90,93.10,NULL,NULL,'2026-06-05 14:58:26.364309',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1751,4,'2026-04-22 14:09:00',66.00,78.90,97.40,66.00,78.90,97.40,NULL,NULL,'2026-06-05 14:58:26.377786',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1752,4,'2026-04-22 14:10:00',48.30,53.10,89.00,48.30,53.10,89.00,NULL,NULL,'2026-06-05 14:58:26.386028',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1753,4,'2026-04-22 14:11:00',47.90,53.10,111.00,47.90,53.10,111.00,NULL,NULL,'2026-06-05 14:58:26.398012',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1754,4,'2026-04-22 14:13:00',80.00,42.30,103.90,80.00,42.30,103.90,NULL,NULL,'2026-06-05 14:58:26.409764',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1755,4,'2026-04-22 14:14:00',61.20,47.60,67.60,61.20,47.60,67.60,NULL,NULL,'2026-06-05 14:58:26.419824',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1756,4,'2026-04-22 14:15:00',54.20,45.30,67.60,54.20,45.30,67.60,NULL,NULL,'2026-06-05 14:58:26.430227',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1757,4,'2026-04-22 14:17:00',69.20,47.60,61.70,69.20,47.60,61.70,NULL,NULL,'2026-06-05 14:58:26.438687',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1758,4,'2026-04-22 14:18:00',69.90,55.50,91.70,69.90,55.50,91.70,NULL,NULL,'2026-06-05 14:58:26.450269',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1759,4,'2026-04-22 14:19:00',63.00,66.50,92.20,63.00,66.50,92.20,NULL,NULL,'2026-06-05 14:58:26.459007',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1760,4,'2026-04-22 14:21:00',56.80,54.90,63.70,56.80,54.90,63.70,NULL,NULL,'2026-06-05 14:58:26.467579',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1761,4,'2026-04-22 14:22:00',68.80,45.50,91.20,68.80,45.50,91.20,NULL,NULL,'2026-06-05 14:58:26.479443',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1762,4,'2026-04-22 14:23:00',54.30,44.20,86.10,54.30,44.20,86.10,NULL,NULL,'2026-06-05 14:58:26.487544',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1763,4,'2026-04-22 14:25:00',50.80,55.20,88.80,50.80,55.20,88.80,NULL,NULL,'2026-06-05 14:58:26.498954',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1764,4,'2026-04-22 14:26:00',62.80,44.70,28.00,62.80,44.70,28.00,NULL,NULL,'2026-06-05 14:58:26.510358',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1765,4,'2026-04-22 14:27:00',42.60,24.50,39.70,42.60,24.50,39.70,NULL,NULL,'2026-06-05 14:58:26.520098',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1766,4,'2026-04-22 14:29:00',69.80,21.80,36.20,69.80,21.80,36.20,NULL,NULL,'2026-06-05 14:58:26.530065',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1767,4,'2026-04-22 14:30:00',51.80,18.40,69.10,51.80,18.40,69.10,NULL,NULL,'2026-06-05 14:58:26.537833',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1768,4,'2026-04-22 14:31:00',58.00,15.60,54.90,58.00,15.60,54.90,NULL,NULL,'2026-06-05 14:58:26.550886',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1769,4,'2026-04-22 14:32:00',43.80,16.90,32.60,43.80,16.90,32.60,NULL,NULL,'2026-06-05 14:58:26.562940',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1770,4,'2026-04-22 14:34:00',37.70,18.90,31.20,37.70,18.90,31.20,NULL,NULL,'2026-06-05 14:58:26.572371',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1771,4,'2026-04-22 14:35:00',79.10,27.20,55.90,79.10,27.20,55.90,NULL,NULL,'2026-06-05 14:58:26.581950',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1772,4,'2026-04-22 14:36:00',78.20,37.10,75.40,78.20,37.10,75.40,NULL,NULL,'2026-06-05 14:58:26.589682',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1773,4,'2026-04-22 14:38:00',42.00,24.90,56.30,42.00,24.90,56.30,NULL,NULL,'2026-06-05 14:58:26.599523',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1774,4,'2026-04-22 14:39:00',58.70,14.00,28.20,58.70,14.00,28.20,NULL,NULL,'2026-06-05 14:58:26.607443',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1775,4,'2026-04-22 14:40:00',NULL,26.60,47.50,NULL,26.60,47.50,NULL,NULL,'2026-06-05 14:58:26.621213',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1776,4,'2026-04-22 14:42:00',NULL,26.30,63.30,NULL,26.30,63.30,NULL,NULL,'2026-06-05 14:58:26.634116',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1777,4,'2026-04-22 14:43:00',NULL,26.60,77.90,NULL,26.60,77.90,NULL,NULL,'2026-06-05 14:58:26.644790',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1778,4,'2026-04-22 14:44:00',NULL,25.30,70.90,NULL,25.30,70.90,NULL,NULL,'2026-06-05 14:58:26.654251',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1779,4,'2026-04-22 14:45:00',NULL,40.30,58.00,NULL,40.30,58.00,NULL,NULL,'2026-06-05 14:58:26.664778',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1780,4,'2026-04-22 14:47:00',NULL,52.30,51.40,NULL,52.30,51.40,NULL,NULL,'2026-06-05 14:58:26.672993',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1781,4,'2026-04-22 14:48:00',NULL,18.70,50.50,NULL,18.70,50.50,NULL,NULL,'2026-06-05 14:58:26.684678',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1782,4,'2026-04-22 14:49:00',NULL,57.60,82.90,NULL,57.60,82.90,NULL,NULL,'2026-06-05 14:58:26.693133',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1783,4,'2026-04-22 14:51:00',NULL,33.60,85.90,NULL,33.60,85.90,NULL,NULL,'2026-06-05 14:58:26.703699',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1784,4,'2026-04-22 14:52:00',NULL,19.30,53.80,NULL,19.30,53.80,NULL,NULL,'2026-06-05 14:58:26.714322',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1785,4,'2026-04-22 14:53:00',NULL,17.40,71.40,NULL,17.40,71.40,NULL,NULL,'2026-06-05 14:58:26.724252',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1786,4,'2026-04-22 14:55:00',NULL,15.60,51.90,NULL,15.60,51.90,NULL,NULL,'2026-06-05 14:58:26.736028',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1787,4,'2026-04-22 14:56:00',NULL,29.90,56.90,NULL,29.90,56.90,NULL,NULL,'2026-06-05 14:58:26.743405',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1788,4,'2026-04-22 14:57:00',NULL,50.40,72.40,NULL,50.40,72.40,NULL,NULL,'2026-06-05 14:58:26.753770',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1789,4,'2026-04-22 14:58:00',NULL,25.60,51.10,NULL,25.60,51.10,NULL,NULL,'2026-06-05 14:58:26.762437',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1790,4,'2026-04-22 15:00:00',NULL,36.20,75.80,NULL,36.20,75.80,NULL,NULL,'2026-06-05 14:58:26.772502',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1791,4,'2026-04-22 15:01:00',NULL,26.80,55.00,NULL,26.80,55.00,NULL,NULL,'2026-06-05 14:58:26.782709',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1792,4,'2026-04-22 15:02:00',NULL,34.50,56.10,NULL,34.50,56.10,NULL,NULL,'2026-06-05 14:58:26.791747',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1793,4,'2026-04-22 15:04:00',NULL,42.60,70.80,NULL,42.60,70.80,NULL,NULL,'2026-06-05 14:58:26.803437',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1794,4,'2026-04-22 15:05:00',NULL,26.30,20.50,NULL,26.30,20.50,NULL,NULL,'2026-06-05 14:58:26.811258',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1795,4,'2026-04-22 15:06:00',NULL,47.20,39.90,NULL,47.20,39.90,NULL,NULL,'2026-06-05 14:58:26.821705',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1796,4,'2026-04-22 15:07:00',NULL,27.60,39.30,NULL,27.60,39.30,NULL,NULL,'2026-06-05 14:58:26.829876',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1797,4,'2026-04-22 15:09:00',NULL,57.80,77.50,NULL,57.80,77.50,NULL,NULL,'2026-06-05 14:58:26.840871',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1798,4,'2026-04-22 15:10:00',NULL,22.40,28.90,NULL,22.40,28.90,NULL,NULL,'2026-06-05 14:58:26.850360',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1799,4,'2026-04-22 15:11:00',NULL,22.40,57.40,NULL,22.40,57.40,NULL,NULL,'2026-06-05 14:58:26.858877',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1800,4,'2026-04-22 15:13:00',NULL,23.60,42.40,NULL,23.60,42.40,NULL,NULL,'2026-06-05 14:58:26.871825',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1801,4,'2026-04-22 15:14:00',NULL,26.50,63.30,NULL,26.50,63.30,NULL,NULL,'2026-06-05 14:58:26.880923',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1802,4,'2026-04-22 15:15:00',NULL,42.50,44.20,NULL,42.50,44.20,NULL,NULL,'2026-06-05 14:58:26.892840',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1803,4,'2026-04-22 15:17:00',NULL,31.60,71.10,NULL,31.60,71.10,NULL,NULL,'2026-06-05 14:58:26.903632',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `power_records_preinstall` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_list`
--

DROP TABLE IF EXISTS `product_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_list` (
  `productID` int(11) NOT NULL AUTO_INCREMENT,
  `sku` varchar(100) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `Capacity (kVA)` varchar(100) DEFAULT NULL,
  `MCB` varchar(100) DEFAULT NULL,
  `Size (WxLxH) cm.` varchar(150) DEFAULT NULL,
  `Weight` varchar(100) DEFAULT NULL,
  `price` decimal(12,2) DEFAULT 0.00,
  `Pin_VAT` decimal(12,2) DEFAULT 0.00,
  `unit` varchar(50) DEFAULT 'unit',
  `category` varchar(100) DEFAULT 'General',
  `Pro_Image` varchar(500) DEFAULT NULL,
  `stock_qty` int(11) DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`productID`),
  KEY `idx_product_list_active` (`is_active`),
  KEY `idx_product_list_category` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_list`
--

LOCK TABLES `product_list` WRITE;
/*!40000 ALTER TABLE `product_list` DISABLE KEYS */;
INSERT INTO `product_list` VALUES
(1,'ES-15KVA','GE-IoT Energy Saver 15 kVA','เครื่องประหยัดพลังงานสำหรับโหลดเริ่มต้น','15','63A','38x28x17','8kg',39000.00,42900.00,'unit','Energy Saver','/placeholder-product.jpg',15,1,'2026-05-29 09:42:50','2026-05-29 09:42:50'),
(2,'ES-30KVA','GE-IoT Energy Saver 30 kVA','เครื่องประหยัดพลังงานสำหรับร้านค้า/อาคารกลาง','30','100A','42x30x18','10kg',49000.00,53900.00,'unit','Energy Saver','/placeholder-product.jpg',12,1,'2026-05-29 09:42:50','2026-05-29 09:42:50'),
(3,'ES-50KVA','GE-IoT Energy Saver 50 kVA','เครื่องประหยัดพลังงานสำหรับโรงงานขนาดกลาง','50','125A','48x34x20','14kg',62000.00,68200.00,'unit','Energy Saver','/placeholder-product.jpg',9,1,'2026-05-29 09:42:50','2026-05-29 09:42:50'),
(4,'ES-100KVA','GE-IoT Energy Saver 100 kVA','เครื่องประหยัดพลังงานสำหรับโหลดสูง','100','250A','58x40x24','20kg',89000.00,97900.00,'unit','Energy Saver','/placeholder-product.jpg',6,1,'2026-05-29 09:42:50','2026-05-29 09:42:50'),
(5,'IOT-CT-3P','GE 3-Phase CT Sensor Kit','ชุดเซ็นเซอร์ CT สำหรับการติดตามพลังงาน','','','','',6900.00,7590.00,'set','IoT Device','/placeholder-product.jpg',40,1,'2026-05-29 09:42:50','2026-05-29 09:42:50'),
(6,'IOT-GW-LTE','GE IoT Gateway LTE','เกตเวย์ IoT สำหรับส่งข้อมูลขึ้นคลาวด์','','','','',9900.00,10890.00,'unit','IoT Device','/placeholder-product.jpg',25,1,'2026-05-29 09:42:50','2026-05-29 09:42:50'),
(7,'IOT-MTR-PM','GE Smart Power Meter','มิเตอร์ไฟอัจฉริยะเชื่อมต่อแดชบอร์ดเรียลไทม์','','','','',12900.00,14190.00,'unit','IoT Device','/placeholder-product.jpg',30,1,'2026-05-29 09:42:50','2026-05-29 09:42:50');
/*!40000 ALTER TABLE `product_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `recommendations`
--

DROP TABLE IF EXISTS `recommendations`;
/*!50001 DROP VIEW IF EXISTS `recommendations`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `recommendations` AS SELECT
 1 AS `id`,
  1 AS `report_id`,
  1 AS `priority`,
  1 AS `title`,
  1 AS `description`,
  1 AS `expected_saving`,
  1 AS `investment_cost`,
  1 AS `payback_period` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!50001 DROP VIEW IF EXISTS `reports`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `reports` AS SELECT
 1 AS `id`,
  1 AS `customer_id`,
  1 AS `site_id`,
  1 AS `device_id`,
  1 AS `report_number`,
  1 AS `report_title`,
  1 AS `measurement_start`,
  1 AS `measurement_end`,
  1 AS `issue_date`,
  1 AS `prepared_by`,
  1 AS `report_status`,
  1 AS `pdf_file_path`,
  1 AS `created_at`,
  1 AS `updated_at` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!50001 DROP VIEW IF EXISTS `sites`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `sites` AS SELECT
 1 AS `id`,
  1 AS `customer_id`,
  1 AS `site_name`,
  1 AS `location`,
  1 AS `site_region`,
  1 AS `transformer_size`,
  1 AS `contract_demand`,
  1 AS `voltage_system`,
  1 AS `created_at`,
  1 AS `updated_at` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `support_tickets`
--

DROP TABLE IF EXISTS `support_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT 1,
  `subject` text NOT NULL,
  `type` varchar(100) NOT NULL,
  `priority` varchar(50) NOT NULL DEFAULT 'Normal',
  `status` varchar(50) NOT NULL DEFAULT 'Open',
  `description` text DEFAULT NULL,
  `created_at` datetime(6) DEFAULT current_timestamp(6),
  `updated_at` datetime(6) DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  `created_by` varchar(100) DEFAULT 'system',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ticket_id` (`ticket_id`),
  KEY `idx_tickets_user` (`user_id`),
  KEY `idx_tickets_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_tickets`
--

LOCK TABLES `support_tickets` WRITE;
/*!40000 ALTER TABLE `support_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_feedback`
--

DROP TABLE IF EXISTS `user_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(191) DEFAULT NULL,
  `category` varchar(100) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `rating` int(11) DEFAULT 0,
  `branch` varchar(50) DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'Pending',
  `created_at` datetime(6) DEFAULT current_timestamp(6),
  `updated_at` datetime(6) DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  `created_by` varchar(100) DEFAULT 'anonymous',
  PRIMARY KEY (`id`),
  KEY `idx_feedback_status` (`status`),
  KEY `idx_feedback_branch` (`branch`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_feedback`
--

LOCK TABLES `user_feedback` WRITE;
/*!40000 ALTER TABLE `user_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_permissions`
--

DROP TABLE IF EXISTS `user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(191) NOT NULL,
  `portal` varchar(50) NOT NULL,
  `is_allowed` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_portal` (`user_id`,`portal`),
  KEY `idx_user_permissions_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_permissions`
--

LOCK TABLES `user_permissions` WRITE;
/*!40000 ALTER TABLE `user_permissions` DISABLE KEYS */;
INSERT INTO `user_permissions` VALUES
(1,'c43585d0ad80aeca6ea58f153','energy',1,'2026-05-25 22:36:15','2026-05-27 22:46:38'),
(2,'c43585d0ad80aeca6ea58f153','customer',1,'2026-05-25 22:36:15','2026-05-27 22:46:38'),
(3,'c43585d0ad80aeca6ea58f153','classroom',0,'2026-05-25 22:36:15','2026-05-27 22:46:38'),
(4,'c43585d0ad80aeca6ea58f153','partner',1,'2026-05-25 22:36:16','2026-05-27 22:46:38'),
(5,'c43585d0ad80aeca6ea58f153','client',0,'2026-05-25 22:36:16','2026-05-27 22:46:38'),
(6,'c43585d0ad80aeca6ea58f153','admin',0,'2026-05-25 22:36:16','2026-05-27 22:46:38'),
(7,'cmox6qo9t0000jhpk0qz39m5a','energy',1,'2026-05-25 22:36:42','2026-05-25 22:36:42'),
(8,'cmox6qo9t0000jhpk0qz39m5a','customer',1,'2026-05-25 22:36:42','2026-05-25 22:36:42'),
(9,'cmox6qo9t0000jhpk0qz39m5a','classroom',0,'2026-05-25 22:36:42','2026-05-25 22:36:42'),
(10,'cmox6qo9t0000jhpk0qz39m5a','partner',1,'2026-05-25 22:36:43','2026-05-25 22:36:43'),
(11,'cmox6qo9t0000jhpk0qz39m5a','client',0,'2026-05-25 22:36:43','2026-05-25 22:36:43'),
(12,'cmox6qo9t0000jhpk0qz39m5a','admin',0,'2026-05-25 22:36:43','2026-05-25 22:36:43'),
(13,'momoge01','energy',1,'2026-05-25 22:37:12','2026-05-25 22:37:12'),
(14,'momoge01','customer',1,'2026-05-25 22:37:12','2026-05-25 22:37:12'),
(15,'momoge01','classroom',0,'2026-05-25 22:37:12','2026-05-25 22:37:12'),
(16,'momoge01','partner',0,'2026-05-25 22:37:12','2026-05-25 22:37:12'),
(17,'momoge01','client',0,'2026-05-25 22:37:12','2026-05-25 22:37:12'),
(18,'momoge01','admin',0,'2026-05-25 22:37:12','2026-05-25 22:37:12'),
(19,'cmpl94xec0001jhxxkns7vwwh','energy',0,'2026-05-25 22:39:01','2026-05-25 22:39:01'),
(20,'cmpl94xec0001jhxxkns7vwwh','customer',0,'2026-05-25 22:39:01','2026-05-25 22:39:01'),
(21,'cmpl94xec0001jhxxkns7vwwh','classroom',1,'2026-05-25 22:39:02','2026-05-25 22:39:02'),
(22,'cmpl94xec0001jhxxkns7vwwh','partner',0,'2026-05-25 22:39:02','2026-05-25 22:39:02'),
(23,'cmpl94xec0001jhxxkns7vwwh','client',0,'2026-05-25 22:39:02','2026-05-25 22:39:02'),
(24,'cmpl94xec0001jhxxkns7vwwh','admin',0,'2026-05-25 22:39:02','2026-05-25 22:39:02'),
(33,'c43585d0ad80aeca6ea58f153','geet_login',1,'2026-05-27 22:46:38','2026-05-27 22:46:38'),
(37,'c43585d0ad80aeca6ea58f153','erp',1,'2026-05-27 22:46:38','2026-05-27 22:46:38');
/*!40000 ALTER TABLE `user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'goeunserverhub'
--

--
-- Current Database: `goeunserverhub`
--

USE `goeunserverhub`;

--
-- Final view structure for view `analysis_results`
--

/*!50001 DROP VIEW IF EXISTS `analysis_results`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`geserverhub`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `analysis_results` AS select `eq_analysis_results`.`id` AS `id`,`eq_analysis_results`.`site_id` AS `site_id`,`eq_analysis_results`.`report_id` AS `report_id`,`eq_analysis_results`.`device_id` AS `device_id`,`eq_analysis_results`.`total_energy` AS `total_energy`,`eq_analysis_results`.`average_load` AS `average_load`,`eq_analysis_results`.`max_demand` AS `max_demand`,`eq_analysis_results`.`load_factor` AS `load_factor`,`eq_analysis_results`.`average_pf` AS `average_pf`,`eq_analysis_results`.`current_imbalance` AS `current_imbalance`,`eq_analysis_results`.`voltage_imbalance` AS `voltage_imbalance`,`eq_analysis_results`.`thdi_avg` AS `thdi_avg`,`eq_analysis_results`.`thdv_avg` AS `thdv_avg`,`eq_analysis_results`.`risk_level` AS `risk_level`,`eq_analysis_results`.`created_at` AS `created_at` from `eq_analysis_results` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `customers`
--

/*!50001 DROP VIEW IF EXISTS `customers`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`geserverhub`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `customers` AS select `eq_customers`.`id` AS `id`,`eq_customers`.`customer_name` AS `customer_name`,`eq_customers`.`business_type` AS `business_type`,`eq_customers`.`address` AS `address`,`eq_customers`.`contact_person` AS `contact_person`,`eq_customers`.`phone` AS `phone`,`eq_customers`.`email` AS `email`,`eq_customers`.`created_at` AS `created_at`,`eq_customers`.`updated_at` AS `updated_at` from `eq_customers` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `energy_data`
--

/*!50001 DROP VIEW IF EXISTS `energy_data`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`geserverhub`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `energy_data` AS select `eq_energy_data`.`id` AS `id`,`eq_energy_data`.`device_id` AS `device_id`,`eq_energy_data`.`recorded_at` AS `timestamp`,`eq_energy_data`.`voltage_l1` AS `voltage_l1`,`eq_energy_data`.`voltage_l2` AS `voltage_l2`,`eq_energy_data`.`voltage_l3` AS `voltage_l3`,`eq_energy_data`.`current_l1` AS `current_l1`,`eq_energy_data`.`current_l2` AS `current_l2`,`eq_energy_data`.`current_l3` AS `current_l3`,`eq_energy_data`.`power_kw` AS `power_kw`,`eq_energy_data`.`energy_kwh` AS `energy_kwh`,`eq_energy_data`.`power_factor` AS `power_factor`,`eq_energy_data`.`frequency` AS `frequency`,`eq_energy_data`.`thdi_l1` AS `thdi_l1`,`eq_energy_data`.`thdi_l2` AS `thdi_l2`,`eq_energy_data`.`thdi_l3` AS `thdi_l3`,`eq_energy_data`.`thdv_l1` AS `thdv_l1`,`eq_energy_data`.`thdv_l2` AS `thdv_l2`,`eq_energy_data`.`thdv_l3` AS `thdv_l3` from `eq_energy_data` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `recommendations`
--

/*!50001 DROP VIEW IF EXISTS `recommendations`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`geserverhub`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `recommendations` AS select `eq_recommendations`.`id` AS `id`,`eq_recommendations`.`report_id` AS `report_id`,`eq_recommendations`.`priority` AS `priority`,`eq_recommendations`.`title` AS `title`,`eq_recommendations`.`description` AS `description`,`eq_recommendations`.`expected_saving` AS `expected_saving`,`eq_recommendations`.`investment_cost` AS `investment_cost`,`eq_recommendations`.`payback_period` AS `payback_period` from `eq_recommendations` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `reports`
--

/*!50001 DROP VIEW IF EXISTS `reports`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`geserverhub`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `reports` AS select `eq_reports`.`id` AS `id`,`eq_reports`.`customer_id` AS `customer_id`,`eq_reports`.`site_id` AS `site_id`,`eq_reports`.`device_id` AS `device_id`,`eq_reports`.`report_number` AS `report_number`,`eq_reports`.`report_title` AS `report_title`,`eq_reports`.`measurement_start` AS `measurement_start`,`eq_reports`.`measurement_end` AS `measurement_end`,`eq_reports`.`issue_date` AS `issue_date`,`eq_reports`.`prepared_by` AS `prepared_by`,`eq_reports`.`report_status` AS `report_status`,`eq_reports`.`pdf_file_path` AS `pdf_file_path`,`eq_reports`.`created_at` AS `created_at`,`eq_reports`.`updated_at` AS `updated_at` from `eq_reports` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `sites`
--

/*!50001 DROP VIEW IF EXISTS `sites`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`geserverhub`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `sites` AS select `eq_sites`.`id` AS `id`,`eq_sites`.`customer_id` AS `customer_id`,`eq_sites`.`site_name` AS `site_name`,`eq_sites`.`location` AS `location`,`eq_sites`.`site_region` AS `site_region`,`eq_sites`.`transformer_size` AS `transformer_size`,`eq_sites`.`contract_demand` AS `contract_demand`,`eq_sites`.`voltage_system` AS `voltage_system`,`eq_sites`.`created_at` AS `created_at`,`eq_sites`.`updated_at` AS `updated_at` from `eq_sites` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-15 11:05:12
